import { createHash, randomBytes } from 'crypto';
import { getDb } from '@/lib/db';
import { deriveKey, encrypt, decrypt } from './engine';

function normalizeCode(code: string): string {
  return code.replace(/-/g, '').toUpperCase();
}

/** 128비트 복구 코드 생성: XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX */
export function generateRecoveryPhrase(): string {
  const bytes = randomBytes(16);
  const hex = bytes.toString('hex').toUpperCase();
  return hex.match(/.{4}/g)!.join('-');
}

/**
 * 복구 코드로 마스터 키를 암호화해 crypto_meta에 저장.
 * 비밀번호 설정/변경 후 키가 메모리에 있을 때 호출.
 */
export function storeRecovery(phrase: string, masterKey: Buffer): void {
  const db = getDb();
  const normalized = normalizeCode(phrase);

  const codeHash = createHash('sha256').update(normalized).digest('hex');
  const salt = randomBytes(32);
  const recoveryKey = deriveKey(normalized, salt);
  const encryptedMasterKey = encrypt(masterKey.toString('hex'), recoveryKey);

  const upsert = db.prepare('INSERT OR REPLACE INTO crypto_meta (key, value) VALUES (?, ?)');
  db.transaction(() => {
    upsert.run('recovery_code_hash', codeHash);
    upsert.run('recovery_salt', salt.toString('hex'));
    upsert.run('recovery_key_enc', encryptedMasterKey);
  })();
}

/** 저장된 복구 코드 여부 확인 */
export function hasRecovery(): boolean {
  const db = getDb();
  const row = db.prepare("SELECT value FROM crypto_meta WHERE key = 'recovery_key_enc'").get();
  return !!row;
}

/** 복구 코드를 검증하고 마스터 키를 반환. 실패 시 null. */
export function loadKeyFromRecovery(phrase: string): Buffer | null {
  const db = getDb();
  const normalized = normalizeCode(phrase);

  const hashRow = db.prepare("SELECT value FROM crypto_meta WHERE key = 'recovery_code_hash'").get() as { value: string } | undefined;
  if (!hashRow) return null;

  const inputHash = createHash('sha256').update(normalized).digest('hex');
  if (inputHash !== hashRow.value) return null;

  const saltRow = db.prepare("SELECT value FROM crypto_meta WHERE key = 'recovery_salt'").get() as { value: string } | undefined;
  const encRow = db.prepare("SELECT value FROM crypto_meta WHERE key = 'recovery_key_enc'").get() as { value: string } | undefined;
  if (!saltRow || !encRow) return null;

  try {
    const salt = Buffer.from(saltRow.value, 'hex');
    const recoveryKey = deriveKey(normalized, salt);
    const masterKeyHex = decrypt(encRow.value, recoveryKey);
    return Buffer.from(masterKeyHex, 'hex');
  } catch {
    return null;
  }
}

/** 복구 관련 crypto_meta 항목 삭제 (비밀번호 변경 시 호출) */
export function clearRecovery(): void {
  const db = getDb();
  db.prepare("DELETE FROM crypto_meta WHERE key IN ('recovery_code_hash', 'recovery_salt', 'recovery_key_enc')").run();
}
