import { createCipheriv, createDecipheriv, pbkdf2Sync, randomBytes } from 'crypto';

const PREFIX = 'ENC:v1:';
const ITERATIONS = 100_000;
const KEY_LEN = 32;
const DIGEST = 'sha512';
const IV_LEN = 12;
const AUTH_TAG_LEN = 16;

/** PBKDF2(SHA-512, 100,000 iterations) 키 파생 — NIST SP 800-38D 준거 */
export function deriveKey(password: string, salt: Buffer): Buffer {
  return pbkdf2Sync(password, salt, ITERATIONS, KEY_LEN, DIGEST);
}

export function generateSalt(): Buffer {
  return randomBytes(32);
}

/** AES-256-GCM 암호화. 반환 포맷: ENC:v1:{base64(iv)}:{base64(ciphertext+authTag)} */
export function encrypt(plaintext: string, key: Buffer): string {
  const iv = randomBytes(IV_LEN);
  const cipher = createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  const combined = Buffer.concat([encrypted, authTag]);
  return `${PREFIX}${iv.toString('base64')}:${combined.toString('base64')}`;
}

/** AES-256-GCM 복호화. ENC:v1: 프리픽스가 없으면 평문 그대로 반환 (마이그레이션 전 데이터 호환). */
export function decrypt(ciphertext: string, key: Buffer): string {
  if (!isEncrypted(ciphertext)) return ciphertext;

  const body = ciphertext.slice(PREFIX.length);
  const colonIdx = body.indexOf(':');
  if (colonIdx === -1) throw new Error('Invalid encrypted format');

  const iv = Buffer.from(body.slice(0, colonIdx), 'base64');
  const combined = Buffer.from(body.slice(colonIdx + 1), 'base64');
  const ciphertextBuf = combined.slice(0, -AUTH_TAG_LEN);
  const authTag = combined.slice(-AUTH_TAG_LEN);

  const decipher = createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(ciphertextBuf), decipher.final()]).toString('utf8');
}

export function isEncrypted(value: string | null | undefined): boolean {
  return typeof value === 'string' && value.startsWith(PREFIX);
}
