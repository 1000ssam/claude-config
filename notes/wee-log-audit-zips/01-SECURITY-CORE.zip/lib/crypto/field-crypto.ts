import { encrypt, decrypt, isEncrypted } from './engine';

export type EncryptableTable =
  | 'students'
  | 'cases'
  | 'sessions'
  | 'case_conceptualizations'
  | 'consent_requests'
  | 'consent_responses';

/** 테이블별 암호화 대상 필드 */
export const ENCRYPTED_FIELDS: Record<EncryptableTable, string[]> = {
  students: ['name', 'contact', 'birth_date', 'guardian_name', 'guardian_contact'],
  cases: [
    'referrer_name', 'referrer_contact',
    'main_complaint', 'notes',
    'counseling_goal', 'teacher_opinion',
  ],
  sessions: ['session_content', 'internal_notes', 'summary_short'],
  case_conceptualizations: ['sections'],
  // sealed-box 개인키(base64)는 다른 민감필드와 동일하게 AES-256-GCM으로 이중 보호.
  consent_requests: ['private_key'],
  // 복호된 보호자 응답(JSON 문자열) — 미성년자 민감정보이므로 로컬에서도 암호화 저장.
  consent_responses: ['answers'],
};

/** settings 테이블에서 암호화할 키 목록 */
export const ENCRYPTED_SETTING_KEYS = new Set<string>([
  'ai_remote_api_key',
]);

/**
 * 행의 암호화 대상 필드를 AES-256-GCM으로 암호화한다.
 * 이미 암호화된 필드나 null/빈 문자열은 건너뛴다.
 */
export function encryptRow<T extends Record<string, unknown>>(
  table: EncryptableTable,
  row: T,
  key: Buffer,
): T {
  const fields = ENCRYPTED_FIELDS[table];
  const result = { ...row };
  for (const field of fields) {
    const value = result[field];
    if (typeof value === 'string' && value !== '' && !isEncrypted(value)) {
      (result as Record<string, unknown>)[field] = encrypt(value, key);
    }
  }
  return result;
}

/**
 * 행의 암호화된 필드를 복호화한다.
 * ENC:v1: 프리픽스가 없는 필드(평문 레거시)는 그대로 반환한다.
 */
export function decryptRow<T extends Record<string, unknown>>(
  table: EncryptableTable,
  row: T,
  key: Buffer,
): T {
  const fields = ENCRYPTED_FIELDS[table];
  const result = { ...row };
  for (const field of fields) {
    const value = result[field];
    if (typeof value === 'string' && isEncrypted(value)) {
      try {
        (result as Record<string, unknown>)[field] = decrypt(value, key);
      } catch {
        (result as Record<string, unknown>)[field] = '[복호화 실패]';
      }
    }
  }
  return result;
}

/** 단일 값 암호화 헬퍼 — null/빈 문자열은 null로 반환, 이미 암호화된 값은 통과 */
export function encryptValue(value: string | null | undefined, key: Buffer): string | null {
  if (!value) return null;
  return isEncrypted(value) ? value : encrypt(value, key);
}

/** 단일 값 복호화 헬퍼 — settings, reports 등에서 사용 */
export function decryptValue(value: string, key: Buffer): string {
  if (!isEncrypted(value)) return value;
  try {
    return decrypt(value, key);
  } catch {
    return '';
  }
}
