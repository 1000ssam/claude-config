import { getDb } from '@/lib/db';
import { encrypt, decrypt, isEncrypted } from './engine';
import { ENCRYPTED_FIELDS, ENCRYPTED_SETTING_KEYS, type EncryptableTable } from './field-crypto';

/**
 * 기존 평문 DB를 암호화한다. (최초 비밀번호 설정 시 1회 실행)
 * 이미 암호화된 필드는 건너뜀 — 멱등성 보장.
 */
export function migrateToEncrypted(key: Buffer): void {
  const db = getDb();

  db.transaction(() => {
    const tables: EncryptableTable[] = ['students', 'cases', 'sessions', 'case_conceptualizations'];
    for (const table of tables) {
      const rows = db.prepare(`SELECT * FROM ${table}`).all() as Record<string, unknown>[];
      for (const row of rows) {
        const updates: Record<string, unknown> = {};
        let hasChanges = false;

        for (const field of ENCRYPTED_FIELDS[table]) {
          const value = row[field];
          if (typeof value === 'string' && value !== '' && !isEncrypted(value)) {
            updates[field] = encrypt(value, key);
            hasChanges = true;
          }
        }

        if (hasChanges) {
          const setClauses = Object.keys(updates).map((f) => `${f} = ?`).join(', ');
          const values = [...Object.values(updates), row.id as number];
          db.prepare(`UPDATE ${table} SET ${setClauses} WHERE id = ?`).run(...values);
        }
      }
    }

    // settings의 API 키 암호화
    for (const key_ of ENCRYPTED_SETTING_KEYS) {
      const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key_) as { value: string } | undefined;
      if (row && row.value && !isEncrypted(row.value)) {
        const encrypted = encrypt(row.value, key);
        db.prepare("UPDATE settings SET value = ? WHERE key = ?").run(encrypted, key_);
      }
    }
  })();
}

/**
 * 비밀번호 변경 시 모든 암호화 데이터를 oldKey로 복호화 후 newKey로 재암호화.
 * 트랜잭션으로 원자성 보장.
 */
export function reEncryptAll(oldKey: Buffer, newKey: Buffer): void {
  const db = getDb();

  db.transaction(() => {
    const tables: EncryptableTable[] = ['students', 'cases', 'sessions', 'case_conceptualizations'];
    for (const table of tables) {
      const rows = db.prepare(`SELECT * FROM ${table}`).all() as Record<string, unknown>[];
      for (const row of rows) {
        const updates: Record<string, unknown> = {};
        let hasChanges = false;

        for (const field of ENCRYPTED_FIELDS[table]) {
          const value = row[field];
          if (typeof value === 'string' && isEncrypted(value)) {
            const plaintext = decrypt(value, oldKey);
            updates[field] = encrypt(plaintext, newKey);
            hasChanges = true;
          }
        }

        if (hasChanges) {
          const setClauses = Object.keys(updates).map((f) => `${f} = ?`).join(', ');
          const values = [...Object.values(updates), row.id as number];
          db.prepare(`UPDATE ${table} SET ${setClauses} WHERE id = ?`).run(...values);
        }
      }
    }

    // settings API 키 재암호화
    for (const settingKey of ENCRYPTED_SETTING_KEYS) {
      const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(settingKey) as { value: string } | undefined;
      if (row && isEncrypted(row.value)) {
        const plaintext = decrypt(row.value, oldKey);
        const reEncrypted = encrypt(plaintext, newKey);
        db.prepare("UPDATE settings SET value = ? WHERE key = ?").run(reEncrypted, settingKey);
      }
    }
  })();
}
