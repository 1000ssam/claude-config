import { safeStorage } from 'electron';
import { getDb } from '@/lib/db';
import { deriveKey, generateSalt, encrypt, decrypt } from './engine';
import { migrateToEncrypted, reEncryptAll } from './migration';
import { generateRecoveryPhrase, storeRecovery, hasRecovery, loadKeyFromRecovery, clearRecovery } from './recovery';

/** 복호화 검증에 사용되는 알려진 상수 — 비밀번호 정확성 확인용 */
const CHECK_PLAINTEXT = 'wee-log-crypto-v1';

/** 메모리에만 보관되는 현재 세션의 암호화 키 */
let _key: Buffer | null = null;

export function isKeyLoaded(): boolean {
  return _key !== null;
}

export function getKey(): Buffer {
  if (!_key) throw new Error('키가 로드되지 않았습니다. 비밀번호를 입력해주세요.');
  return _key;
}

/** 앱 종료 또는 잠금 시 키를 메모리에서 안전하게 제거 */
export function clearKey(): void {
  if (_key) {
    _key.fill(0);
    _key = null;
  }
}

/** crypto_meta 테이블에 비밀번호 설정이 완료됐는지 확인 */
export function isSetup(): boolean {
  const db = getDb();
  const row = db.prepare("SELECT value FROM crypto_meta WHERE key = 'salt_encrypted'").get();
  return !!row;
}

/** salt를 OS 키체인(safeStorage)으로 암호화해 crypto_meta에 저장 */
function storeSalt(salt: Buffer): void {
  const db = getDb();
  let stored: string;
  if (safeStorage.isEncryptionAvailable()) {
    // OS 키체인으로 암호화 (Windows DPAPI / macOS Keychain / Linux libsecret)
    const encryptedBuf = safeStorage.encryptString(salt.toString('hex'));
    stored = encryptedBuf.toString('base64');
  } else {
    // fallback: 일부 Linux 환경에서 keychain 미사용 시 평문 hex (덜 안전하나 동작은 함)
    stored = salt.toString('hex');
  }
  db.prepare("INSERT OR REPLACE INTO crypto_meta (key, value) VALUES ('salt_encrypted', ?)").run(stored);
}

/** crypto_meta에서 salt 복원 */
function loadSalt(): Buffer | null {
  const db = getDb();
  const row = db.prepare("SELECT value FROM crypto_meta WHERE key = 'salt_encrypted'").get() as { value: string } | undefined;
  if (!row) return null;

  if (safeStorage.isEncryptionAvailable()) {
    try {
      const encryptedBuf = Buffer.from(row.value, 'base64');
      const saltHex = safeStorage.decryptString(encryptedBuf);
      return Buffer.from(saltHex, 'hex');
    } catch {
      return null;
    }
  } else {
    return Buffer.from(row.value, 'hex');
  }
}

function storeCheckValue(key: Buffer): void {
  const db = getDb();
  const checkValue = encrypt(CHECK_PLAINTEXT, key);
  db.prepare("INSERT OR REPLACE INTO crypto_meta (key, value) VALUES ('check_value', ?)").run(checkValue);
}

function verifyKey(key: Buffer): boolean {
  const db = getDb();
  const row = db.prepare("SELECT value FROM crypto_meta WHERE key = 'check_value'").get() as { value: string } | undefined;
  if (!row) return false;
  try {
    return decrypt(row.value, key) === CHECK_PLAINTEXT;
  } catch {
    return false;
  }
}

/**
 * 최초 비밀번호 설정.
 * salt 생성 → 키 파생 → salt + check_value 저장 → 기존 평문 데이터 마이그레이션
 */
export function setup(password: string, hint?: string): void {
  const salt = generateSalt();
  const key = deriveKey(password, salt);
  storeSalt(salt);
  storeCheckValue(key);

  // 기존 평문 데이터를 암호화 (신규 설치는 데이터가 없어 no-op)
  migrateToEncrypted(key);

  const db = getDb();
  db.prepare("INSERT OR REPLACE INTO crypto_meta (key, value) VALUES ('migrated_at', ?)").run(new Date().toISOString());

  if (hint?.trim()) {
    db.prepare("INSERT OR REPLACE INTO crypto_meta (key, value) VALUES ('password_hint', ?)").run(hint.trim());
  }

  _key = key;
}

/**
 * 비밀번호로 잠금 해제.
 * @returns true: 성공, false: 비밀번호 불일치
 */
export function unlock(password: string): boolean {
  const salt = loadSalt();
  if (!salt) return false;

  const key = deriveKey(password, salt);
  if (!verifyKey(key)) return false;

  _key = key;
  return true;
}

/**
 * 비밀번호 변경. 기존 비밀번호 확인 후 전체 데이터 re-encrypt.
 * 마스터 키가 바뀌므로 기존 복구 코드는 삭제됨 (재생성 필요).
 * @returns true: 성공, false: 현재 비밀번호 불일치
 */
/**
 * 비밀번호 변경. 기존 비밀번호 확인 후 전체 데이터 re-encrypt.
 * 성공 시 새 복구 코드를 자동 발급하여 반환. 실패 시 false.
 */
export function changePassword(currentPassword: string, newPassword: string): string | false {
  const salt = loadSalt();
  if (!salt) return false;

  const oldKey = deriveKey(currentPassword, salt);
  if (!verifyKey(oldKey)) return false;

  const newSalt = generateSalt();
  const newKey = deriveKey(newPassword, newSalt);

  // 전체 데이터 re-encrypt (트랜잭션 내부)
  reEncryptAll(oldKey, newKey);

  // salt + check_value 갱신
  storeSalt(newSalt);
  storeCheckValue(newKey);

  // 메모리 키 교체 후 새 복구 코드 자동 발급
  clearKey();
  _key = newKey;
  const phrase = generateRecoveryPhrase();
  storeRecovery(phrase, newKey);

  return phrase;
}

// ─── 힌트 ────────────────────────────────────────────────────────────────────

/** 저장된 비밀번호 힌트 반환 (잠금 화면에서 키 없이 호출 가능) */
export function getHint(): string {
  const db = getDb();
  const row = db.prepare("SELECT value FROM crypto_meta WHERE key = 'password_hint'").get() as { value: string } | undefined;
  return row?.value ?? '';
}

/** 비밀번호 힌트 저장/삭제 (키 로드 상태에서 호출) */
export function setHint(hint: string): void {
  const db = getDb();
  if (hint.trim()) {
    db.prepare("INSERT OR REPLACE INTO crypto_meta (key, value) VALUES ('password_hint', ?)").run(hint.trim());
  } else {
    db.prepare("DELETE FROM crypto_meta WHERE key = 'password_hint'").run();
  }
}

// ─── 복구 코드 ────────────────────────────────────────────────────────────────

/** 복구 코드 생성 및 crypto_meta 저장. 키가 메모리에 있어야 함. */
export function generateAndStoreRecovery(): string {
  if (!_key) throw new Error('키가 로드되지 않았습니다.');
  const phrase = generateRecoveryPhrase();
  storeRecovery(phrase, _key);
  return phrase;
}

/** 저장된 복구 코드 여부 확인 (잠금 화면에서 키 없이 호출 가능) */
export function checkHasRecovery(): boolean {
  return hasRecovery();
}

/**
 * 복구 코드로 잠금 해제. 성공 시 _key 설정 + recovery_used 플래그 저장 후 true 반환.
 * 앱은 반드시 비밀번호 재설정을 강제해야 함.
 */
export function useRecoveryCode(code: string): boolean {
  const key = loadKeyFromRecovery(code);
  if (!key) return false;
  _key = key;
  const db = getDb();
  db.prepare("INSERT OR REPLACE INTO crypto_meta (key, value) VALUES ('recovery_used', '1')").run();
  return true;
}

/** 복구 코드로 해제 후 비밀번호 재설정이 필요한지 확인 */
export function isRecoveryUsed(): boolean {
  const db = getDb();
  const row = db.prepare("SELECT value FROM crypto_meta WHERE key = 'recovery_used'").get();
  return !!row;
}

/**
 * 복구 후 비밀번호 재설정 (현재 비밀번호 불필요).
 * 마스터 키로 전체 데이터 re-encrypt, recovery_used 플래그 삭제.
 */
export function resetPassword(newPassword: string): void {
  if (!_key) throw new Error('키가 로드되지 않았습니다.');

  const oldKey = _key;
  const newSalt = generateSalt();
  const newKey = deriveKey(newPassword, newSalt);

  reEncryptAll(oldKey, newKey);
  storeSalt(newSalt);
  storeCheckValue(newKey);
  clearRecovery(); // 마스터 키 교체 → 기존 복구 코드 무효화

  const db = getDb();
  db.prepare("DELETE FROM crypto_meta WHERE key = 'recovery_used'").run();

  clearKey();
  _key = newKey;
}

// ─── 공장 초기화 ──────────────────────────────────────────────────────────────

/**
 * 잠금 화면에서 비밀번호 없이 전체 초기화.
 * 상담 데이터 + 암호화 설정 모두 삭제. 앱이 초기 설정 화면으로 돌아감.
 */
export function factoryReset(): void {
  const db = getDb();

  const resetAll = db.transaction(() => {
    db.prepare('DELETE FROM sessions').run();
    db.prepare('DELETE FROM cases').run();
    db.prepare('DELETE FROM students').run();
    db.prepare('DELETE FROM crypto_meta').run();

    const updateSetting = db.prepare("UPDATE settings SET value = ? WHERE key = ?");
    updateSetting.run('', 'school_name');
    updateSetting.run('', 'neis_atpt_code');
    updateSetting.run('', 'neis_schul_code');
    updateSetting.run('', 'school_type');
    updateSetting.run('', 'counselor_name');
    updateSetting.run('', 'anthropic_api_key');
    updateSetting.run('', 'clova_api_key');
    updateSetting.run('', 'default_counseling_class');
    updateSetting.run('전문상담교사', 'counselor_affiliation');
    updateSetting.run('일반', 'wee_class');
    updateSetting.run('1', 'next_case_seq');
    updateSetting.run(new Date().getFullYear().toString(), 'academic_year');
  });

  resetAll();
}
