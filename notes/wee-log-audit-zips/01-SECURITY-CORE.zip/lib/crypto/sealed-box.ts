/**
 * libsodium sealed box (crypto_box_seal) 래퍼.
 *
 * 영지식 E2E의 앱 측 구현. 보호자 브라우저는 동일한 libsodium-wrappers로
 * `crypto_box_seal(payload, publicKey)`를 수행하고, 서버는 암호문만 보관한다.
 * 개인키를 가진 앱만 `crypto_box_seal_open`으로 복호할 수 있다.
 *
 * sealed box = X25519 + XSalsa20-Poly1305 + 송신자 익명(요청별 임시 키).
 * 직접 구현(hand-roll) 금지 — 표준 라이브러리 구성을 그대로 사용한다.
 *
 * base64는 ORIGINAL(표준, padding 포함) 변형으로 통일한다(브라우저 측과 일치 필수).
 */

import _sodium from 'libsodium-wrappers';

let readyPromise: Promise<typeof _sodium> | null = null;

async function getSodium(): Promise<typeof _sodium> {
  if (!readyPromise) {
    readyPromise = _sodium.ready.then(() => _sodium);
  }
  return readyPromise;
}

export interface SealedBoxKeypair {
  /** base64(ORIGINAL) X25519 공개키 */
  publicKey: string;
  /** base64(ORIGINAL) X25519 개인키 */
  privateKey: string;
}

/** 요청별 X25519 키쌍 생성. 공개키만 서버로, 개인키는 로컬 암호화 저장. */
export async function generateKeypair(): Promise<SealedBoxKeypair> {
  const s = await getSodium();
  const kp = s.crypto_box_keypair();
  return {
    publicKey: s.to_base64(kp.publicKey, s.base64_variants.ORIGINAL),
    privateKey: s.to_base64(kp.privateKey, s.base64_variants.ORIGINAL),
  };
}

/**
 * 공개키로 평문을 sealed box 암호화한다(보호자 브라우저가 하는 일과 동일).
 * 앱 측에서는 주로 테스트/검증용이지만, 수동 링크 미사용 시나리오 등에서 재사용 가능.
 */
export async function seal(plaintext: string, publicKeyB64: string): Promise<string> {
  const s = await getSodium();
  const pk = s.from_base64(publicKeyB64, s.base64_variants.ORIGINAL);
  const ct = s.crypto_box_seal(s.from_string(plaintext), pk);
  return s.to_base64(ct, s.base64_variants.ORIGINAL);
}

/**
 * sealed box 암호문을 개인키로 복호한다.
 * 복호 실패(잘못된 키/변조) 시 throw.
 */
export async function sealOpen(
  ciphertextB64: string,
  publicKeyB64: string,
  privateKeyB64: string,
): Promise<string> {
  const s = await getSodium();
  const ct = s.from_base64(ciphertextB64, s.base64_variants.ORIGINAL);
  const pk = s.from_base64(publicKeyB64, s.base64_variants.ORIGINAL);
  const sk = s.from_base64(privateKeyB64, s.base64_variants.ORIGINAL);
  const msg = s.crypto_box_seal_open(ct, pk, sk);
  if (!msg) throw new Error('sealed box 복호 실패');
  return s.to_string(msg);
}
