/**
 * 기본 동의서 폼 스키마 구조 검증.
 * 실행: node --experimental-strip-types scripts/consent-schema.check.mts
 */

import { DEFAULT_CONSENT_SCHEMA, DEFAULT_CONSENT_TEMPLATE_NAME } from '../lib/constants/consent-templates.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('consent-schema');

t.eq('스키마 버전', DEFAULT_CONSENT_SCHEMA.version, 1);
t.ok('제목 존재', !!DEFAULT_CONSENT_SCHEMA.title);
t.ok('법적 전문(intro) 존재', !!DEFAULT_CONSENT_SCHEMA.intro);
t.ok('필드 1개 이상', DEFAULT_CONSENT_SCHEMA.fields.length > 0);
t.eq('기본 템플릿명 일치', DEFAULT_CONSENT_SCHEMA.title, DEFAULT_CONSENT_TEMPLATE_NAME);

// 키 유일성
const keys = DEFAULT_CONSENT_SCHEMA.fields.map((f) => f.key);
t.eq('필드 키 유일', new Set(keys).size, keys.length);

// 모든 필드 키는 영문 snake_case (응답 JSON 키로 안전)
t.ok('키는 영문/숫자/언더스코어', keys.every((k) => /^[a-z][a-z0-9_]*$/.test(k)));

// 미성년자 동의 흐름 필수 요소: consent 타입 + signature 타입 존재
const types = DEFAULT_CONSENT_SCHEMA.fields.map((f) => f.type);
t.ok('동의(consent) 필드 존재', types.includes('consent'));
t.ok('전자서명(signature) 필드 존재', types.includes('signature'));

// 개인정보 동의·상담 동의·서명은 필수
const byKey = Object.fromEntries(DEFAULT_CONSENT_SCHEMA.fields.map((f) => [f.key, f]));
t.ok('개인정보 동의 필수', byKey['consent_privacy']?.required === true);
t.ok('상담 동의 필수', byKey['consent_counseling']?.required === true);
t.ok('전자서명 필수', byKey['signature']?.required === true);

// select 필드는 options 보유
for (const f of DEFAULT_CONSENT_SCHEMA.fields) {
  if (f.type === 'select' || f.type === 'radio') {
    t.ok(`${f.key} 선택지 보유`, Array.isArray(f.options) && f.options.length > 0);
  }
}

t.report();
