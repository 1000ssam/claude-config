/**
 * 동의서 E2E sealed-box 크립토 검증 (영지식 증명 포함).
 *
 *  - 라운드트립: 앱이 만든 공개키로 암호화한 페이로드를 앱 개인키로만 복호 성공.
 *  - 영지식: 개인키 없이는(다른 키쌍 포함) 복호 불가 — 서버는 복호할 수 없음.
 *  - 한글/JSON/서명 dataURL 등 실제 페이로드 형태 보존.
 *
 * 실행: node --experimental-strip-types scripts/consent-crypto.check.mts
 */

import { generateKeypair, seal, sealOpen } from '../lib/crypto/sealed-box.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('consent-crypto');

const kp = await generateKeypair();
const attacker = await generateKeypair();

// 키 형식 (X25519 32바이트 → base64 ORIGINAL 44자)
t.ok('공개키 base64 길이', kp.publicKey.length === 44);
t.ok('개인키 base64 길이', kp.privateKey.length === 44);
t.ok('공개키 ≠ 개인키', kp.publicKey !== kp.privateKey);

// 실제 응답 형태 페이로드
const payload = JSON.stringify({
  guardian_name: '김보호',
  guardian_relation: '모',
  guardian_contact: '010-1234-5678',
  consent_privacy: true,
  consent_counseling: true,
  note: '오후 시간대 연락 부탁드립니다.',
  signature: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVR4nGNgYGAAAAAEAAH2FzhVAAAAAElFTkSuQmCC',
});

// 보호자 브라우저가 하는 일: 공개키로 sealed box
const ciphertext = await seal(payload, kp.publicKey);
t.ok('암호문 ≠ 평문', ciphertext !== payload);
t.ok('암호문 base64 형식', /^[A-Za-z0-9+/=]+$/.test(ciphertext));

// 앱이 하는 일: 개인키로 복호 → 원문 일치
const opened = await sealOpen(ciphertext, kp.publicKey, kp.privateKey);
t.eq('라운드트립 원문 보존', JSON.parse(opened), JSON.parse(payload));

// ── 영지식: 개인키 없이는 복호 불가 ──────────────────────────────────────────
// 공격자/서버가 다른 키쌍의 개인키로 시도 → 반드시 실패.
let failedWithWrongPriv = false;
try {
  await sealOpen(ciphertext, kp.publicKey, attacker.privateKey);
} catch {
  failedWithWrongPriv = true;
}
t.ok('다른 개인키로 복호 실패(영지식)', failedWithWrongPriv);

// 공개키/개인키 모두 공격자 것으로 시도 → 실패(서버가 가진 정보는 공개키뿐).
let failedWithAttackerPair = false;
try {
  await sealOpen(ciphertext, attacker.publicKey, attacker.privateKey);
} catch {
  failedWithAttackerPair = true;
}
t.ok('공격자 키쌍으로 복호 실패', failedWithAttackerPair);

// 변조된 암호문은 복호 실패(무결성).
const tampered = ciphertext.slice(0, -4) + (ciphertext.slice(-4) === 'AAAA' ? 'BBBB' : 'AAAA');
let failedTampered = false;
try {
  await sealOpen(tampered, kp.publicKey, kp.privateKey);
} catch {
  failedTampered = true;
}
t.ok('변조 암호문 복호 실패(무결성)', failedTampered);

t.report();
