/**
 * 감사 로그 빌더(buildAuditEvent) 검증 — 이벤트 화이트리스트 + PII 레닥션.
 * DB 미의존(순수) → WSL에서 실행 가능.
 * 실행: node --experimental-strip-types scripts/consent-audit.check.mts
 */

import { buildAuditEvent, CONSENT_AUDIT_EVENTS } from '../lib/constants/consent-audit.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('consent-audit');

// 유효 이벤트는 빌드된다.
t.eq('유효 이벤트 보존', buildAuditEvent({ event: 'request_created', requestId: 1 }).event, 'request_created');

// 알 수 없는 이벤트는 throw(프로그래밍 오류 조기 노출).
t.throws('알 수 없는 이벤트 거부', () =>
  buildAuditEvent({ event: 'bogus_event' as unknown as typeof CONSENT_AUDIT_EVENTS[number], requestId: 1 }),
);

// requestId 미지정 → null.
t.eq('requestId 미지정 시 null', buildAuditEvent({ event: 'requests_expired' }).request_id, null);

// detail 없으면 null.
t.eq('detail 없으면 null', buildAuditEvent({ event: 'poll_started' }).detail, null);

// PII 키 제거 + 비-PII 보존.
const r1 = buildAuditEvent({
  event: 'request_created',
  requestId: 2,
  detail: { guardian_name: '홍길동', contact: '010-1234-5678', channel: 'sms' },
});
const d1 = JSON.parse(r1.detail!);
t.ok('보호자 성명 키 제거', !('guardian_name' in d1));
t.ok('연락처 키 제거', !('contact' in d1));
t.eq('비-PII 채널 보존', d1.channel, 'sms');

// 비-PII 키(template) 보존 — 'name' 부분일치 오탐 방지용 키 네이밍 확인.
const rT = buildAuditEvent({ event: 'request_created', requestId: 2, detail: { template: '상담 접수 동의서' } });
t.eq('template 키 보존', JSON.parse(rT.detail!).template, '상담 접수 동의서');

// 값에 숨어든 전화번호 마스킹.
const r2 = buildAuditEvent({ event: 'send_failed', requestId: 3, detail: { error: '발송 실패 010-9999-8888 차단됨' } });
const d2 = JSON.parse(r2.detail!);
t.ok('값 내 전화번호 마스킹', d2.error.includes('[전화번호]') && !/\d{4}-\d{4}/.test(d2.error));

// answers(응답 본문) 키 제거 + 비-PII count 보존.
const r3 = buildAuditEvent({ event: 'response_recorded', requestId: 4, detail: { answers: { a: 1 }, count: 3 } });
const d3 = JSON.parse(r3.detail!);
t.ok('응답 본문(answers) 제거', !('answers' in d3));
t.eq('비-PII count 보존', d3.count, 3);

// 중첩 객체는 통째로 버린다(레닥션 누락 방지).
const r5 = buildAuditEvent({ event: 'status_sent', requestId: 6, detail: { meta: { phone: '010-0000-0000' }, channel: 'link' } });
const d5 = JSON.parse(r5.detail!);
t.ok('중첩 객체 제거', !('meta' in d5));
t.eq('평면 비-PII 보존', d5.channel, 'link');

// detail이 PII만으로 구성되면 정제 후 null.
const r4 = buildAuditEvent({ event: 'request_created', requestId: 5, detail: { name: 'x', phone: 'y' } });
t.eq('PII만 있으면 detail null', r4.detail, null);

// 모든 정의 이벤트는 빌드 가능(스모크).
for (const e of CONSENT_AUDIT_EVENTS) {
  t.eq(`이벤트 빌드: ${e}`, buildAuditEvent({ event: e, requestId: 1 }).event, e);
}

t.report();
