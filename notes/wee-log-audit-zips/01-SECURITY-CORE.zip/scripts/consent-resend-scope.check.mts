/**
 * 회귀 테스트: 재발송 무효화 범위 (여러 양식 동시 발송 시 상호 무효화 방지).
 *
 * 버그(수정 전): consent:send 가 무효화 대상을 (학생) 단위로만 좁혀, 같은 학생에게
 *   양식 A·B를 잇따라 보내면 B 발송이 A의 진행 중 요청까지 expired 처리 → 마지막 1건만 남음.
 * 수정: buildActiveRequestsQuery 에 templateName 을 주면 (학생 + 양식) 단위로 좁힌다.
 *
 * 순수 빌더 + in-memory SQLite 로 SQL 동작과 무효화 시나리오를 검증한다.
 * (앱은 better-sqlite3 를 쓰지만 그 네이티브 빌드는 Windows 전용이라 WSL에서 못 연다.
 *  검증은 동일 SQL 을 Node 내장 node:sqlite 로 돌려 플랫폼 독립적으로 수행한다.)
 *
 * 실행: node --experimental-strip-types scripts/consent-resend-scope.check.mts
 */

import { DatabaseSync } from 'node:sqlite';
import { buildActiveRequestsQuery } from '../lib/queries/consent-active-query.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('consent-resend-scope');

// ── 1) 빌더 형태(SQL/파라미터) 검증 ────────────────────────────────────────────
const scoped = buildActiveRequestsQuery(10, 5, '동의서A');
t.ok('양식 지정 시 template_name 조건 포함', scoped.sql.includes('template_name = ?'));
t.eq('양식 지정 파라미터', scoped.params, [10, 5, '동의서A']);

const unscoped = buildActiveRequestsQuery(10, 5);
t.ok('양식 미지정 시 template_name 조건 없음', !unscoped.sql.includes('template_name'));
t.eq('양식 미지정 파라미터', unscoped.params, [10, 5]);

t.ok('항상 진행 중(pending/sent)만 대상', scoped.sql.includes("status IN ('pending', 'sent')"));

// ── 2) in-memory DB 시드 ───────────────────────────────────────────────────────
const db = new DatabaseSync(':memory:');
db.exec(`
  CREATE TABLE consent_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    case_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    template_name TEXT NOT NULL,
    token TEXT NOT NULL,
    status TEXT NOT NULL
  );
`);
const seed = db.prepare(
  'INSERT INTO consent_requests (case_id, student_id, template_name, token, status) VALUES (?, ?, ?, ?, ?)',
);
seed.run(10, 5, '동의서A', 'tA', 'sent');       // id 1 — 학생5/사례10/양식A (진행 중)
seed.run(10, 5, '동의서B', 'tB', 'pending');    // id 2 — 학생5/사례10/양식B (진행 중)
seed.run(10, 5, '동의서A', 'tA_old', 'ingested'); // id 3 — 이미 수합됨(대상 아님)
seed.run(10, 5, '동의서A', 'tA_exp', 'expired');  // id 4 — 이미 만료(대상 아님)
seed.run(10, 9, '동의서A', 'tOther', 'sent');     // id 5 — 다른 학생(대상 아님)
seed.run(99, 5, '동의서A', 'tCase', 'sent');      // id 6 — 다른 사례(대상 아님)

function activeIds(caseId: number, studentId: number, templateName?: string): number[] {
  const { sql, params } = buildActiveRequestsQuery(caseId, studentId, templateName);
  return (db.prepare(sql).all(...params) as Array<{ id: number }>).map((r) => r.id).sort((a, b) => a - b);
}

// ── 3) 범위 좁히기 검증 ────────────────────────────────────────────────────────
t.eq('양식A 진행중만(다른 학생/사례/완료/만료 제외)', activeIds(10, 5, '동의서A'), [1]);
t.eq('양식B 진행중만', activeIds(10, 5, '동의서B'), [2]);
t.eq('양식 미지정 = 학생의 모든 진행중(레거시 버그 경로)', activeIds(10, 5), [1, 2]);

// ── 4) 무효화 시나리오: B 재발송이 A를 건드리면 안 된다 ──────────────────────────
// consent:send 의 무효화 루프를 재현: 대상 요청을 expired 로.
function invalidate(caseId: number, studentId: number, templateName?: string): void {
  for (const id of activeIds(caseId, studentId, templateName)) {
    db.prepare("UPDATE consent_requests SET status = 'expired' WHERE id = ?").run(id);
  }
}

invalidate(10, 5, '동의서B'); // 양식B 재발송 직전 무효화
const aStatus = (db.prepare('SELECT status FROM consent_requests WHERE id = 1').get() as { status: string }).status;
const bStatus = (db.prepare('SELECT status FROM consent_requests WHERE id = 2').get() as { status: string }).status;
t.eq('B 재발송 후에도 A는 진행중 유지(자기들끼리 무효화 안 함)', aStatus, 'sent');
t.eq('B의 옛 요청만 만료', bStatus, 'expired');

// ── 5) 같은 양식 재발송은 옛 링크를 무효화해야 한다 ─────────────────────────────
invalidate(10, 5, '동의서A'); // 양식A 재발송 직전 무효화
const aAfter = (db.prepare('SELECT status FROM consent_requests WHERE id = 1').get() as { status: string }).status;
t.eq('같은 양식(A) 재발송 시 옛 A는 만료', aAfter, 'expired');

// ── 6) 레거시 경로(양식 미지정)는 여전히 학생의 모든 진행중을 무효화 ────────────
seed.run(20, 7, '동의서A', 'l1', 'sent');
seed.run(20, 7, '동의서B', 'l2', 'sent');
invalidate(20, 7); // templateName 생략 → 양식 무관 전부
t.eq('미지정 무효화는 학생의 모든 양식 대상', activeIds(20, 7), []);

db.close();
t.report();
