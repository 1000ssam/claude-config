/**
 * libsodium-wrappers ESM 빌드 형제 모듈 누락 패치 (ERR_MODULE_NOT_FOUND).
 *
 * 배경: `libsodium-wrappers`(0.7.x)의 `exports."import"`는
 *   dist/modules-esm/libsodium-wrappers.mjs 를 가리키는데, 이 파일은
 *   `import e from "./libsodium.mjs"` 로 형제 파일을 찾는다. 그러나 그 형제
 *   `libsodium.mjs`는 같은 디렉토리에 없고 별도 패키지 `libsodium`의
 *   dist/modules-esm/libsodium.mjs 에 있다 → 순수 ESM import 시 해석 실패.
 *
 * 영향: ESM 테스트 하니스(`cloudflare/test/flow.mjs`, `scripts/consent-crypto.check.mts`)가
 *   `import 'libsodium-wrappers'` 로 로드할 때 깨진다. (앱 메인 프로세스는 CJS=require라 무관.)
 *
 * 처치: 누락된 형제 파일을 `libsodium` 패키지에서 복사해 채운다. `npm install`마다
 *   postinstall로 자동 재적용되므로 멱등·안전하게 동작한다.
 *
 * 경로 해석: 두 패키지 모두 `exports`로 `./package.json` 접근을 막아 require.resolve가
 *   실패하므로, 이 스크립트(<repo>/scripts/) 기준 <repo>/node_modules 를 1순위로 본다.
 *
 * 관련 노트: ~/.claude/knowledge/libsodium-wrappers-esm-sibling.md (case 2)
 */
import { existsSync, copyFileSync, statSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = dirname(fileURLToPath(import.meta.url));
const nodeModules = join(scriptDir, '..', 'node_modules');

const target = join(nodeModules, 'libsodium-wrappers', 'dist', 'modules-esm', 'libsodium.mjs');
const source = join(nodeModules, 'libsodium', 'dist', 'modules-esm', 'libsodium.mjs');

function patch() {
  // libsodium-wrappers ESM 디렉토리 자체가 없으면 패치 대상 아님 — 조용히 통과.
  if (!existsSync(dirname(target))) return;

  // 이미 정상(형제 파일 존재 + 비어있지 않음)이면 아무것도 하지 않음.
  if (existsSync(target) && statSync(target).size > 0) return;

  if (!existsSync(source)) {
    // 패키지 레이아웃이 바뀌어 원본을 못 찾으면, 깨뜨리지 말고 경고만.
    console.warn(
      `[patch-libsodium-esm] 원본을 찾지 못해 건너뜀: ${source}\n` +
        `  libsodium-wrappers ESM이 고쳐진 릴리스라면 이 스크립트는 제거해도 됩니다.`,
    );
    return;
  }

  copyFileSync(source, target);
  console.log(`[patch-libsodium-esm] 형제 모듈 복원: ${target}`);
}

patch();
