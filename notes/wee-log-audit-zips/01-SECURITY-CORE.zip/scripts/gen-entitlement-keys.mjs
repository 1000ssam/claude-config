#!/usr/bin/env node
// 엔타이틀먼트 서명용 EdDSA(Ed25519) 키페어 생성.
// ⚠️ 이 스크립트는 **사용자가 직접** 실행한다(비공개키가 Claude 컨텍스트에 노출되지 않도록).
//    Claude는 이 스크립트를 실행하지 않는다.
//
// 산출:
//   keys/entitlement-public.jwk.json   ← 공개키. 앱·동의서 Worker에 내장. 커밋 OK(비밀 아님).
//   keys/entitlement-private.jwk.json  ← 비공개키. .gitignore. 절대 커밋·공유·대화창 노출 금지.
//
// 다음 단계(가이드는 README-subscription.md):
//   supabase secrets set ENTITLEMENT_PRIVATE_JWK="$(cat keys/entitlement-private.jwk.json)"
//   등록 후 로컬 비공개키 파일은 삭제 권장.

import { writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const keysDir = join(here, '..', 'keys');
const privPath = join(keysDir, 'entitlement-private.jwk.json');
const pubPath = join(keysDir, 'entitlement-public.jwk.json');

if (existsSync(privPath) && !process.argv.includes('--force')) {
  console.error('이미 비공개키가 존재합니다:', privPath);
  console.error('덮어쓰면 기존 토큰이 전부 무효화됩니다. 정말 새로 만들려면 --force.');
  process.exit(1);
}

const kp = await crypto.subtle.generateKey({ name: 'Ed25519' }, true, ['sign', 'verify']);
const pub = await crypto.subtle.exportKey('jwk', kp.publicKey);
const priv = await crypto.subtle.exportKey('jwk', kp.privateKey);
for (const k of [pub, priv]) { k.alg = 'EdDSA'; k.use = 'sig'; }

mkdirSync(keysDir, { recursive: true });
writeFileSync(pubPath, JSON.stringify(pub, null, 2) + '\n');
writeFileSync(privPath, JSON.stringify(priv)); // 한 줄(시크릿 등록 편의)

console.log('✅ 키페어 생성 완료 (키 값은 출력하지 않음)');
console.log('   공개키  →', pubPath, '(커밋 OK)');
console.log('   비공개키 →', privPath, '(gitignore — 절대 커밋·공유 금지)');
console.log('');
console.log('다음: Supabase 함수 시크릿에 등록');
console.log('   supabase secrets set ENTITLEMENT_PRIVATE_JWK="$(cat ' + privPath + ')"');
console.log('등록 후 로컬 비공개키 파일 삭제 권장:  rm ' + privPath);
