import { contextBridge, ipcRenderer } from 'electron';

// window.api로 노출되는 타입-safe IPC 브릿지
contextBridge.exposeInMainWorld('api', {
  auth: {
    isSetup: () =>
      ipcRenderer.invoke('auth:is-setup'),
    setup: (password: string, hint?: string) =>
      ipcRenderer.invoke('auth:setup', password, hint),
    unlock: (password: string) =>
      ipcRenderer.invoke('auth:unlock', password),
    changePassword: (currentPassword: string, newPassword: string) =>
      ipcRenderer.invoke('auth:change-password', currentPassword, newPassword),
    getHint: () =>
      ipcRenderer.invoke('auth:get-hint'),
    setHint: (hint: string) =>
      ipcRenderer.invoke('auth:set-hint', hint),
    hasRecovery: () =>
      ipcRenderer.invoke('auth:has-recovery'),
    generateRecovery: () =>
      ipcRenderer.invoke('auth:generate-recovery'),
    useRecovery: (code: string) =>
      ipcRenderer.invoke('auth:use-recovery', code),
    isRecoveryUsed: () =>
      ipcRenderer.invoke('auth:is-recovery-used'),
    resetPassword: (newPassword: string) =>
      ipcRenderer.invoke('auth:reset-password', newPassword),
    factoryReset: () =>
      ipcRenderer.invoke('auth:factory-reset'),
  },

  cases: {
    list: (params?: { year?: string; status?: string; search?: string }) =>
      ipcRenderer.invoke('cases:list', params ?? {}),
    get: (id: number) =>
      ipcRenderer.invoke('cases:get', id),
    create: (input: unknown) =>
      ipcRenderer.invoke('cases:create', input),
    update: (id: number, input: unknown) =>
      ipcRenderer.invoke('cases:update', id, input),
    delete: (id: number) =>
      ipcRenderer.invoke('cases:delete', id),
  },

  conceptualizations: {
    get: (caseId: number) =>
      ipcRenderer.invoke('conceptualizations:get', caseId),
    upsert: (caseId: number, input: unknown) =>
      ipcRenderer.invoke('conceptualizations:upsert', caseId, input),
    delete: (caseId: number) =>
      ipcRenderer.invoke('conceptualizations:delete', caseId),
  },

  sessions: {
    list: (caseId: number) =>
      ipcRenderer.invoke('sessions:list', caseId),
    get: (sessionId: number) =>
      ipcRenderer.invoke('sessions:get', sessionId),
    create: (caseId: number, input: unknown) =>
      ipcRenderer.invoke('sessions:create', caseId, input),
    update: (sessionId: number, input: unknown) =>
      ipcRenderer.invoke('sessions:update', sessionId, input),
    delete: (sessionId: number) =>
      ipcRenderer.invoke('sessions:delete', sessionId),
    calendar: (from: string, to: string) =>
      ipcRenderer.invoke('sessions:calendar', from, to),
    updateDate: (sessionId: number, newDate: string) =>
      ipcRenderer.invoke('sessions:update-date', sessionId, newDate),
    refreshReminders: () =>
      ipcRenderer.invoke('sessions:refresh-reminders'),
  },

  settings: {
    get: () =>
      ipcRenderer.invoke('settings:get'),
    update: (updates: unknown) =>
      ipcRenderer.invoke('settings:update', updates),
  },

  statistics: {
    get: (params: { year?: string; from?: string; to?: string }) =>
      ipcRenderer.invoke('statistics:get', params),
  },

  print: {
    save: (opts?: { pageSize?: string; landscape?: boolean; defaultName?: string }) =>
      ipcRenderer.invoke('app:print', { action: 'save', ...opts }),
    preview: (opts?: { pageSize?: string; landscape?: boolean }) =>
      ipcRenderer.invoke('app:print', { action: 'preview', ...opts }),
    print: (opts?: { pageSize?: string; landscape?: boolean }) =>
      ipcRenderer.invoke('app:print', { action: 'print', ...opts }),
  },

  reports: {
    get: (params: { year?: string }) =>
      ipcRenderer.invoke('reports:get', params),
    generate: (params: { startDate: string; endDate: string }) =>
      ipcRenderer.invoke('reports:generate', params),
    savePdf: (params?: { from?: string; to?: string }) =>
      ipcRenderer.invoke('reports:save-pdf', params),
    print: () =>
      ipcRenderer.invoke('reports:print'),
    previewPdf: () =>
      ipcRenderer.invoke('reports:preview-pdf'),
  },

  students: {
    list: (params?: { search?: string; academic_year?: string }) =>
      ipcRenderer.invoke('students:list', params ?? {}),
    profile: (id: number) =>
      ipcRenderer.invoke('students:profile', id),
    search: (query: string) =>
      ipcRenderer.invoke('students:search', query),
    create: (input: unknown) =>
      ipcRenderer.invoke('students:create', input),
    update: (id: number, input: unknown) =>
      ipcRenderer.invoke('students:update', id, input),
    delete: (id: number) =>
      ipcRenderer.invoke('students:delete', id),
    findByIdentity: (name: string, grade?: string, className?: string, number?: string) =>
      ipcRenderer.invoke('students:findByIdentity', name, grade, className, number),
    uploadExcel: () =>
      ipcRenderer.invoke('students:upload-excel'),
    confirmUpload: (filePath: string) =>
      ipcRenderer.invoke('students:confirm-upload', filePath),
    bulkDelete: (ids: number[]) =>
      ipcRenderer.invoke('students:bulk-delete', ids),
    bulkUpdateStatus: (ids: number[], status: string) =>
      ipcRenderer.invoke('students:bulk-update-status', ids, status),
    checkGraduationEligibility: (ids: number[], currentYear: string, graduationGrade: string) =>
      ipcRenderer.invoke('students:check-graduation-eligibility', ids, currentYear, graduationGrade),
  },

  enrollments: {
    byStudent: (studentId: number) =>
      ipcRenderer.invoke('enrollments:by-student', studentId),
    years: () =>
      ipcRenderer.invoke('enrollments:years'),
  },

  backup: {
    create: () =>
      ipcRenderer.invoke('backup:create'),
    restore: () =>
      ipcRenderer.invoke('backup:restore'),
    reset: (password: string) =>
      ipcRenderer.invoke('backup:reset', password),
  },

  export: {
    xlsx: (params: { year?: string; from?: string; to?: string }) =>
      ipcRenderer.invoke('export:xlsx', params),
  },

  holidays: {
    getYear: (year: number) =>
      ipcRenderer.invoke('holidays:get-year', year),
  },

  remote: {
    getNotices: () =>
      ipcRenderer.invoke('remote:get-notices'),
    markNoticeRead: (noticeId: string) =>
      ipcRenderer.invoke('remote:mark-notice-read', noticeId),
  },

  school: {
    search: (query: string) =>
      ipcRenderer.invoke('school:search', query),
    getSchedule: (year: number) =>
      ipcRenderer.invoke('school:get-schedule', year),
  },

  stt: {
    getStatus: () =>
      ipcRenderer.invoke('stt:get-status'),
    downloadModel: () =>
      ipcRenderer.invoke('stt:download-model'),
    cancelDownload: () =>
      ipcRenderer.invoke('stt:cancel-download'),
    transcribe: (payload: unknown) =>
      ipcRenderer.invoke('stt:transcribe', payload),
    cancel: (requestId: string) =>
      ipcRenderer.invoke('stt:cancel', requestId),
    updateSettings: (updates: unknown) =>
      ipcRenderer.invoke('stt:update-settings', updates),
    onEvent: (cb: (evt: unknown) => void) => {
      const listener = (_: unknown, evt: unknown) => cb(evt);
      ipcRenderer.on('stt:event', listener as never);
      return () => {
        ipcRenderer.removeListener('stt:event', listener as never);
      };
    },
  },

  // ── AI 도우미 (온디바이스 LLM) ───────────────────────────────────────────
  // 토큰 스트리밍은 `ai:event` 채널로 push되며, onEvent로 구독한다.
  ai: {
    getStatus: () =>
      ipcRenderer.invoke('ai:get-status'),
    downloadModel: () =>
      ipcRenderer.invoke('ai:download-model'),
    cancelDownload: () =>
      ipcRenderer.invoke('ai:cancel-download'),
    generate: (payload: unknown) =>
      ipcRenderer.invoke('ai:generate', payload),
    cancel: (requestId: string) =>
      ipcRenderer.invoke('ai:cancel', { requestId }),
    warmUp: () =>
      ipcRenderer.invoke('ai:warm-up'),
    refreshSummaries: (caseId?: number) =>
      ipcRenderer.invoke('ai:refresh-summaries', { caseId }),
    onEvent: (cb: (e: unknown) => void) => {
      const handler = (_e: unknown, evt: unknown) => cb(evt);
      ipcRenderer.on('ai:event', handler);
      return () => ipcRenderer.removeListener('ai:event', handler);
    },
  },

  // ── 보호자 동의서 (E2E 영지식) ───────────────────────────────────────────
  consent: {
    capabilities: () =>
      ipcRenderer.invoke('consent:capabilities'),
    templatesList: () =>
      ipcRenderer.invoke('consent:templates-list'),
    templateCreate: (input: unknown) =>
      ipcRenderer.invoke('consent:template-create', input),
    templateUpdate: (id: number, input: unknown) =>
      ipcRenderer.invoke('consent:template-update', id, input),
    templateDelete: (id: number) =>
      ipcRenderer.invoke('consent:template-delete', id),
    list: (caseId: number) =>
      ipcRenderer.invoke('consent:list', caseId),
    response: (requestId: number) =>
      ipcRenderer.invoke('consent:response', requestId),
    auditList: (caseId: number) =>
      ipcRenderer.invoke('consent:audit-list', caseId),
    send: (args: unknown) =>
      ipcRenderer.invoke('consent:send', args),
    sendBatch: (args: unknown) =>
      ipcRenderer.invoke('consent:send-batch', args),
    poll: () =>
      ipcRenderer.invoke('consent:poll'),
  },

});
