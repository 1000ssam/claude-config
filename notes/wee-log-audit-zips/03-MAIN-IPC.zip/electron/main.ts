import { app, BrowserWindow, ipcMain, dialog, shell, Notification, globalShortcut } from 'electron';
import path from 'path';
import fs from 'fs';

// 암호화 키 관리
import { isSetup, unlock, setup, changePassword, isKeyLoaded, clearKey, getHint, setHint, generateAndStoreRecovery, checkHasRecovery, useRecoveryCode, isRecoveryUsed, resetPassword, factoryReset } from '../lib/crypto/key-manager';

// DB queries (동기 방식)
import { getCases, getCaseById, createCase, updateCase, deleteCase } from '../lib/queries/cases';
import { getSessionsByCaseId, getSessionById, createSession, updateSession, deleteSession, getSessionsForExport, updateSessionDate } from '../lib/queries/sessions';
import { getAcademicYear } from '../lib/academic-year';
import { getAllSettings, updateSettings } from '../lib/queries/settings';
import { getStatistics } from '../lib/queries/statistics';
import { getReportsData } from '../lib/queries/reports';
import { generateReportData } from '../lib/queries/report-generator';
import { searchStudents, createStudent, getAllStudents, updateStudent, deleteStudent, findStudentByIdentity, bulkDeleteStudents, bulkUpdateStudentStatus, getStudentProfile } from '../lib/queries/students';
import { getEnrollmentsByStudentId, getDistinctEnrollmentYears, checkGraduationEligibility } from '../lib/queries/enrollments';
import { parseNeisExcel, parseCsv, processUpload } from '../lib/queries/excel-upload';
import { getConceptualization, upsertConceptualization, deleteConceptualization } from '../lib/queries/conceptualizations';
import { generateXlsx } from '../lib/export/xlsx-exporter';
import { createBackup, restoreFromBackup, resetAllData } from '../lib/backup';
import { getDb } from '../lib/db';
import { getCalendarSessions, getTodayReminders } from '../lib/queries/calendar';
import { getCachedHolidays, setCachedHolidays } from '../lib/queries/holiday-cache';
import { getCachedNotices, setCachedNotices, getReadNoticeIds, markNoticeRead } from '../lib/queries/notice-cache';
import { getCachedSchedule, setCachedSchedule } from '../lib/queries/school-cache';
import { fetchHolidays, fetchNotices, fetchSchoolSearch, fetchSchoolSchedule } from './remote-data';
import { getSetting } from '../lib/queries/settings';
import { sttService, updateSttSettings } from '../lib/stt/stt-service';
import type { SttEvent, SttModelId, SttTranscribePayload } from '../lib/stt/stt-types';
import { aiService } from '../lib/ai';
import type { AiEvent, GenerateStartPayload } from '../lib/ai';
import {
  enqueueSummary,
  bootstrapSummaryQueue,
  refreshSummaries,
} from '../lib/ai/summary-queue';

// 보호자 동의서 (E2E 영지식)
import { generateKeypair, sealOpen } from '../lib/crypto/sealed-box';
import {
  listConsentTemplates,
  getConsentTemplate,
  createConsentTemplate,
  updateConsentTemplate,
  deleteConsentTemplate,
  listConsentRequestsByCase,
  getConsentResponse,
  createConsentRequest,
  getRequestCryptoByToken,
  getActiveRequestsForStudent,
  updateConsentRequest,
  expireStaleRequests,
  recordConsentResponse,
  getGuardianContact,
} from '../lib/queries/consent';
import { appendAuditEvent, listAuditEvents } from '../lib/queries/consent-audit';
import {
  postRequest,
  fetchPending,
  ackRequest,
  revokeRequest,
  buildLink,
  isServerConfigured,
} from './consent-remote';
import { sendSms, isSmsConfigured } from './sms';
import type { ConsentChannel, ConsentRequest } from '../types/consent';

// 구 경로(wee-log) → 신 경로(Wee-Story) DB 마이그레이션
// 구 DB가 신 DB보다 크면(실제 데이터 있음) 덮어써서 이전
(function migrateUserData() {
  const appData = app.getPath('appData');
  const oldDir = path.join(appData, 'wee-log');
  const newDir = app.getPath('userData'); // productName 기준: Wee-Story
  const oldDb = path.join(oldDir, 'wee-log.db');
  const newDb = path.join(newDir, 'wee-log.db');

  if (!fs.existsSync(oldDb)) return;

  const oldSize = fs.statSync(oldDb).size;
  const newSize = fs.existsSync(newDb) ? fs.statSync(newDb).size : 0;

  if (oldSize > newSize) {
    fs.mkdirSync(newDir, { recursive: true });
    fs.copyFileSync(oldDb, newDb);
    // recordings 폴더도 이전
    const oldRec = path.join(oldDir, 'recordings');
    const newRec = path.join(newDir, 'recordings');
    if (fs.existsSync(oldRec) && !fs.existsSync(newRec)) {
      fs.cpSync(oldRec, newRec, { recursive: true });
    }
  }
})();

// HMR 개발 환경 감지
const isDev = !app.isPackaged;

/**
 * 인쇄 미리보기 HTML 래퍼 — 상단 툴바(돌아가기 버튼) + PDF iframe.
 * PDF 뷰어 위에는 UI를 얹을 수 없으므로, file:// HTML 페이지로 감싸서 표시한다.
 */
function buildPreviewHtml(pdfUrl: string): string {
  return `<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8" />
<title>인쇄 미리보기</title>
<style>
  html, body { margin: 0; height: 100%; }
  body {
    display: flex; flex-direction: column; background: #525659;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Pretendard', sans-serif;
  }
  .toolbar {
    flex: 0 0 auto;
    display: flex; align-items: center; gap: 10px;
    padding: 8px 14px;
    background: #323639; color: #e8e8e8;
    border-bottom: 1px solid rgba(0, 0, 0, 0.4);
  }
  .back-btn {
    display: inline-flex; align-items: center; gap: 6px;
    background: #4a4d50; color: #fff;
    border: 1px solid rgba(255, 255, 255, 0.14);
    padding: 7px 14px; border-radius: 7px;
    font-size: 13px; font-weight: 500; cursor: pointer;
    transition: background 0.12s ease;
  }
  .back-btn:hover { background: #5a5e61; }
  .back-btn:active { background: #444749; }
  .back-btn svg { width: 15px; height: 15px; }
  .hint { font-size: 12px; color: #9aa0a6; }
  iframe { flex: 1 1 auto; width: 100%; border: 0; }
</style>
</head>
<body>
  <div class="toolbar">
    <button class="back-btn" id="backBtn" type="button">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"
           stroke-linecap="round" stroke-linejoin="round">
        <path d="M15 18l-6-6 6-6" />
      </svg>
      돌아가기
    </button>
    <span class="hint">ESC 키로도 닫을 수 있습니다</span>
  </div>
  <iframe src="${pdfUrl}"></iframe>
  <script>
    document.getElementById('backBtn').addEventListener('click', function () {
      window.close();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') window.close();
    });
  </script>
</body>
</html>`;
}

let mainWindow: BrowserWindow | null = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 900,
    minHeight: 600,
    webPreferences: {
      preload: path.join(__dirname, '../preload/preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
    titleBarStyle: 'default',
    title: 'Wee-Story',
  });

  // E6: 외부 URL 네비게이션 차단
  const devOrigin = isDev
    ? new URL(process.env['ELECTRON_RENDERER_URL'] || 'http://localhost:5173').origin
    : null;
  mainWindow.webContents.on('will-navigate', (event, url) => {
    try {
      const parsed = new URL(url);
      if (parsed.protocol === 'file:') return;
      if (devOrigin && parsed.origin === devOrigin) return;
      event.preventDefault();
    } catch {
      event.preventDefault();
    }
  });
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));

  if (isDev) {
    const rendererUrl = process.env['ELECTRON_RENDERER_URL'] || 'http://localhost:5173';
    mainWindow.loadURL(rendererUrl);
    mainWindow.webContents.openDevTools();
    mainWindow.webContents.on('console-message', (_e, level, message, line, sourceId) => {
      if (level >= 3) console.error(`[RENDERER ERROR] ${message} (${sourceId}:${line})`);
    });
  } else {
    mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'));
  }
}

app.commandLine.appendSwitch('disable-features', 'AutofillServerCommunication');

app.whenReady().then(() => {
  registerIpcHandlers();
  createWindow();
  setupAiEventRelay();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  // 워커 프로세스 정리. dispose는 비동기지만 워커가 process.exit으로 자체 종료한다.
  aiService().dispose().catch((err) => console.warn('[aiService.dispose]', err));
  clearKey(); // 앱 종료 시 메모리에서 키 제거
  if (process.platform !== 'darwin') app.quit();
});

/** ai-service의 AiEvent를 포커스된 렌더러로 relay한다. */
function setupAiEventRelay(): void {
  aiService().on('ai-event', (evt: AiEvent) => {
    const win = mainWindow || BrowserWindow.getAllWindows()[0];
    win?.webContents.send('ai:event', evt);
  });
}

// ─── 리마인더 스케줄러 ────────────────────────────────────────────────────────

const scheduledReminderIds = new Set<ReturnType<typeof setTimeout>>();

/**
 * 오늘 날짜 기준으로 리마인더가 설정된 세션의 Notification 타이머를 등록한다.
 * unlock/setup 성공 후 호출된다.
 */
function scheduleRemindersForToday(): void {
  // 기존 타이머 모두 취소
  for (const id of scheduledReminderIds) clearTimeout(id);
  scheduledReminderIds.clear();

  if (!isKeyLoaded()) return;

  let sessions: ReturnType<typeof getTodayReminders>;
  try {
    sessions = getTodayReminders();
  } catch {
    return;
  }

  const now = Date.now();
  for (const s of sessions) {
    if (!s.appointment_time || s.reminder_minutes == null) continue;
    const [h, m] = s.appointment_time.split(':').map(Number);
    const apptDate = new Date(s.session_date);
    apptDate.setHours(h, m, 0, 0);
    const fireAt = apptDate.getTime() - s.reminder_minutes * 60 * 1000;
    const delay = fireAt - now;
    if (delay > 0 && delay < 24 * 60 * 60 * 1000) {
      const tid = setTimeout(() => {
        new Notification({
          title: '상담 일정 알림',
          body: `${s.reminder_minutes}분 후 [${s.student_names}] 상담 예정`,
        }).show();
        scheduledReminderIds.delete(tid);
      }, delay);
      scheduledReminderIds.add(tid);
    }
  }
}

// ─── IPC 헬퍼 ────────────────────────────────────────────────────────────────

/** 데이터 접근 전 키 로드 여부를 확인하는 헬퍼 */
function requireKey<T>(fn: () => T): T {
  if (!isKeyLoaded()) throw new Error('잠금 상태입니다. 비밀번호를 입력해주세요.');
  return fn();
}

/**
 * 동기 DB 핸들러를 try/catch로 래핑합니다.
 * SQLite 내부 오류 메시지가 렌더러에 그대로 노출되지 않도록 합니다.
 */
function wrapSync<T>(fn: () => T): T {
  try {
    return fn();
  } catch (err) {
    console.error('[wrapSync]', err);
    const msg = err instanceof Error ? err.message : String(err);
    // SQLite 내부 오류 패턴을 사용자 친화적 메시지로 변환
    if (msg.includes('FOREIGN KEY constraint failed')) {
      throw new Error('연결된 데이터가 존재하여 삭제할 수 없습니다.');
    }
    if (msg.includes('UNIQUE constraint failed')) {
      throw new Error('이미 존재하는 데이터입니다.');
    }
    if (msg.includes('NOT NULL constraint failed')) {
      throw new Error('필수 항목이 누락되었습니다.');
    }
    // 그 외 DB 오류는 일반 메시지로
    throw new Error(`데이터 처리 중 오류가 발생했습니다. (${msg.substring(0, 80)})`);
  }
}

// ─── 동의서 발송 헬퍼 (단일/배치 공용) ──────────────────────────────────────

/** 동의서 SMS 본문. 링크 1개면 기존 문구, 여러 개면 번호 목록으로 한 통에 묶는다(PII 0). */
function consentSmsBody(links: string[]): string {
  if (links.length <= 1) {
    return `[Wee 상담실] 상담 접수 동의서를 보내드립니다. 아래 링크에서 작성해 주세요.\n${links[0] ?? ''}`;
  }
  const list = links.map((l, i) => `${i + 1}. ${l}`).join('\n');
  return `[Wee 상담실] 상담 접수 동의서 ${links.length}건을 보내드립니다. 아래 각 링크에서 작성해 주세요.\n${list}`;
}

/**
 * 동의서 요청 1건을 생성·서버 등록한다. **SMS 발송과 'sent' 전이는 하지 않는다**
 * (SMS를 한 통에 묶기 위해 호출자가 링크를 모은 뒤 별도로 처리). 재발송 무효화는
 * (학생 + 양식) 단위로 좁혀 다른 양식 요청을 건드리지 않는다.
 */
async function prepareConsentRequest(args: {
  case_id: number;
  student_id: number;
  template_id: number;
  channel: ConsentChannel;
  expiry_days?: number;
}): Promise<
  | { ok: true; request: ConsentRequest; link: string }
  | { ok: false; error: string }
> {
  const template = getConsentTemplate(args.template_id);
  if (!template) return { ok: false, error: '템플릿을 찾을 수 없습니다.' };

  // 0) 재발송: (학생 + 양식) 단위로만 진행 중 요청 무효화 — 다른 양식은 보존.
  //    revoke(만료처리) 사용 — 옛 링크는 보호자에게 410 "만료"로 보임(ack=409 "제출완료"와 구분).
  for (const prior of getActiveRequestsForStudent(args.case_id, args.student_id, template.name)) {
    try {
      await revokeRequest(prior.token);
    } catch {
      /* 서버 미도달은 무시 — 로컬 만료만이라도 적용 */
    }
    updateConsentRequest(prior.id, { status: 'expired', last_error: '재발송으로 무효화됨' });
    appendAuditEvent({ event: 'resend_invalidated', requestId: prior.id });
  }

  // 1) 요청별 키쌍 + 로컬 요청 저장(pending). 폼 스키마는 라벨 보존용 스냅샷.
  const kp = await generateKeypair();
  const request = createConsentRequest({
    case_id: args.case_id,
    student_id: args.student_id,
    template_name: template.name,
    form_schema: JSON.stringify(template.schema),
    public_key: kp.publicKey,
    private_key: kp.privateKey,
    channel: args.channel,
    expiry_days: args.expiry_days && args.expiry_days > 0 ? args.expiry_days : 7,
  });
  appendAuditEvent({
    event: 'request_created',
    requestId: request.id,
    detail: { template: template.name, channel: args.channel },
  });

  // 2) 서버 등록(공개키 + 평문 스키마 + 만료)
  try {
    await postRequest({
      token: request.token,
      publicKey: kp.publicKey,
      formSchema: template.schema,
      title: template.name,
      expiresAt: request.expires_at,
    });
    appendAuditEvent({ event: 'sent_to_server', requestId: request.id });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    updateConsentRequest(request.id, { status: 'failed', last_error: msg });
    appendAuditEvent({ event: 'send_failed', requestId: request.id, detail: { stage: 'server', error: msg } });
    return { ok: false, error: msg };
  }

  return { ok: true, request, link: buildLink(request.token) };
}

// ─── IPC 핸들러 등록 ────────────────────────────────────────────────────────

function registerIpcHandlers() {
  // ── Auth ───────────────────────────────────────────────────────────────────
  ipcMain.handle('auth:is-setup', () => isSetup());

  ipcMain.handle('auth:setup', (_e, password: string, hint?: string) => {
    try {
      setup(password, hint);
      scheduleRemindersForToday();
      bootstrapSummaryQueue();
      return { success: true };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  });

  ipcMain.handle('auth:unlock', (_e, password: string) => {
    const ok = unlock(password);
    if (ok) {
      scheduleRemindersForToday();
      bootstrapSummaryQueue();
    }
    return { success: ok };
  });

  ipcMain.handle('auth:change-password', (_e, currentPassword: string, newPassword: string) => {
    try {
      const result = changePassword(currentPassword, newPassword);
      if (result === false) return { success: false };
      return { success: true, recoveryPhrase: result };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  });

  // 힌트 (잠금 화면에서 키 없이 접근 가능)
  ipcMain.handle('auth:get-hint', () => getHint());

  ipcMain.handle('auth:set-hint', (_e, hint: string) => {
    try {
      if (!isKeyLoaded()) return { success: false, error: '잠금 상태입니다.' };
      setHint(hint);
      return { success: true };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  });

  // 복구 코드 (잠금 화면에서 키 없이 일부 접근 가능)
  ipcMain.handle('auth:has-recovery', () => checkHasRecovery());

  ipcMain.handle('auth:generate-recovery', () => {
    try {
      const phrase = generateAndStoreRecovery();
      return { success: true, phrase };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  });

  ipcMain.handle('auth:use-recovery', (_e, code: string) => {
    const ok = useRecoveryCode(code);
    return { success: ok };
  });

  ipcMain.handle('auth:is-recovery-used', () => isRecoveryUsed());

  ipcMain.handle('auth:reset-password', (_e, newPassword: string) => {
    try {
      resetPassword(newPassword);
      return { success: true };
    } catch (err) {
      return { success: false, error: (err as Error).message };
    }
  });

  // 잠금 화면 공장 초기화 (비밀번호 없이 전체 삭제 후 리로드)
  ipcMain.handle('auth:factory-reset', async () => {
    const win = mainWindow || BrowserWindow.getAllWindows()[0];
    const { response } = await dialog.showMessageBox(win!, {
      type: 'warning',
      title: '앱 초기화',
      message: '모든 상담 기록과 학생 정보가 영구 삭제됩니다.\n암호화 설정도 초기화되어 새로 비밀번호를 설정해야 합니다.\n\n이 작업은 절대 되돌릴 수 없습니다.',
      buttons: ['취소', '모두 삭제하고 초기화'],
      defaultId: 0,
      cancelId: 0,
    });

    if (response === 0) return { success: false, message: '취소되었습니다.' };

    try {
      factoryReset();
      clearKey();
      win!.webContents.reload();
      return { success: true };
    } catch (err) {
      return { success: false, message: (err as Error).message };
    }
  });

  // ── Cases ──────────────────────────────────────────────────────────────────
  ipcMain.handle('cases:list', (_e, params) => {
    return wrapSync(() => requireKey(() => getCases(params)));
  });

  ipcMain.handle('cases:get', (_e, id: number) => {
    return wrapSync(() => requireKey(() => getCaseById(id)));
  });

  ipcMain.handle('cases:create', (_e, input) => {
    return wrapSync(() => requireKey(() => createCase(input)));
  });

  ipcMain.handle('cases:update', (_e, id: number, input) => {
    return wrapSync(() => requireKey(() => updateCase(id, input)));
  });

  ipcMain.handle('cases:delete', (_e, id: number) => {
    return wrapSync(() => requireKey(() => deleteCase(id)));
  });

  // ── Case Conceptualizations ─────────────────────────────────────────────────
  ipcMain.handle('conceptualizations:get', (_e, caseId: number) => {
    return wrapSync(() => requireKey(() => getConceptualization(caseId)));
  });

  ipcMain.handle('conceptualizations:upsert', (_e, caseId: number, input) => {
    return wrapSync(() => requireKey(() => upsertConceptualization(caseId, input)));
  });

  ipcMain.handle('conceptualizations:delete', (_e, caseId: number) => {
    return wrapSync(() => requireKey(() => deleteConceptualization(caseId)));
  });

  // ── Sessions ───────────────────────────────────────────────────────────────
  ipcMain.handle('sessions:list', (_e, caseId: number) => {
    return wrapSync(() => requireKey(() => getSessionsByCaseId(caseId)));
  });

  ipcMain.handle('sessions:get', (_e, sessionId: number) => {
    return wrapSync(() => requireKey(() => getSessionById(sessionId)));
  });

  ipcMain.handle('sessions:create', (_e, caseId: number, input) => {
    const result = wrapSync(() => requireKey(() => createSession(caseId, input)));
    scheduleRemindersForToday();
    if (result?.id) enqueueSummary(result.id);
    return result;
  });

  ipcMain.handle('sessions:update', (_e, sessionId: number, input) => {
    const result = wrapSync(() => requireKey(() => updateSession(sessionId, input)));
    scheduleRemindersForToday();
    // updateSession에서 session_content가 변경되면 summary_status가 'pending'으로
    // 자동 reset된다. 그 신호로 항상 enqueue를 시도(중복은 큐가 알아서 무시).
    if (result && input?.session_content !== undefined) enqueueSummary(sessionId);
    return result;
  });

  ipcMain.handle('sessions:delete', (_e, sessionId: number) => {
    const result = wrapSync(() => requireKey(() => deleteSession(sessionId)));
    scheduleRemindersForToday();
    return result;
  });

  ipcMain.handle('sessions:calendar', (_e, from: string, to: string) => {
    return wrapSync(() => requireKey(() => getCalendarSessions(from, to)));
  });

  ipcMain.handle('sessions:update-date', (_e, sessionId: number, newDate: string) => {
    return wrapSync(() => requireKey(() => updateSessionDate(sessionId, newDate)));
  });

  ipcMain.handle('sessions:refresh-reminders', () => {
    if (isKeyLoaded()) scheduleRemindersForToday();
  });

  // ── Settings ───────────────────────────────────────────────────────────────
  ipcMain.handle('settings:get', () => {
    return wrapSync(() => requireKey(() => getAllSettings()));
  });

  ipcMain.handle('settings:update', (_e, updates) => {
    return wrapSync(() => requireKey(() => {
      updateSettings(updates);
      return getAllSettings();
    }));
  });

  // ── Statistics ─────────────────────────────────────────────────────────────
  ipcMain.handle('statistics:get', (_e, params) => {
    return wrapSync(() => requireKey(() => getStatistics(params)));
  });

  // ── Reports ──────────────────────────────────────────────────────────────
  ipcMain.handle('reports:get', (_e, params) => {
    return wrapSync(() => requireKey(() => getReportsData(params)));
  });

  ipcMain.handle('reports:generate', (_e, params) => {
    return wrapSync(() => requireKey(() => generateReportData(params)));
  });

  // ── 공용 인쇄 ────────────────────────────────────────────────────────────
  async function handlePrint(opts: {
    action: 'save' | 'preview' | 'print';
    pageSize?: string;
    landscape?: boolean;
    defaultName?: string;
  }): Promise<{ success: boolean; filePath?: string; message?: string }> {
    const win = mainWindow || BrowserWindow.getAllWindows()[0];
    if (!win) return { success: false, message: '윈도우를 찾을 수 없습니다.' };

    const pdfOpts: Electron.PrintToPDFOptions = {
      pageSize: (opts.pageSize as 'A4' | 'A3' | 'Letter') || 'A4',
      landscape: opts.landscape ?? false,
      printBackground: true,
      margins: { marginType: 'none' },
    };

    if (opts.action === 'print') {
      win.webContents.print({ silent: false, printBackground: true });
      return { success: true };
    }

    try {
      const data = await win.webContents.printToPDF(pdfOpts);

      if (opts.action === 'save') {
        const defaultName = opts.defaultName || `문서_${new Date().getFullYear()}.pdf`;
        const result = await dialog.showSaveDialog(win, {
          defaultPath: defaultName,
          filters: [{ name: 'PDF', extensions: ['pdf'] }],
        });
        if (result.canceled || !result.filePath) return { success: false };
        fs.writeFileSync(result.filePath, data);
        shell.showItemInFolder(result.filePath);
        return { success: true, filePath: result.filePath };
      }

      // preview — HTML 래퍼(돌아가기 툴바)로 PDF를 감싸 표시한다.
      const os = await import('os');
      const stamp = Date.now();
      const tmpPdf = path.join(os.tmpdir(), `wee-preview-${stamp}.pdf`);
      const tmpHtml = path.join(os.tmpdir(), `wee-preview-${stamp}.html`);
      fs.writeFileSync(tmpPdf, data);
      const pdfUrl = `file:///${tmpPdf.replace(/\\/g, '/')}`;
      fs.writeFileSync(tmpHtml, buildPreviewHtml(pdfUrl));

      const previewWin = new BrowserWindow({
        width: 900,
        height: 1100,
        title: '인쇄 미리보기',
        autoHideMenuBar: true,
        parent: win,
      });
      previewWin.loadFile(tmpHtml);

      // ESC 키로 닫기 — PDF 뷰어(iframe)에 포커스가 있어도 동작하도록
      // 미리보기 창이 포커스된 동안만 전역 단축키로 등록한다.
      const closeOnEsc = () => { if (!previewWin.isDestroyed()) previewWin.close(); };
      globalShortcut.register('Escape', closeOnEsc);
      previewWin.on('focus', () => globalShortcut.register('Escape', closeOnEsc));
      previewWin.on('blur', () => globalShortcut.unregister('Escape'));
      previewWin.on('closed', () => {
        globalShortcut.unregister('Escape');
        try { fs.unlinkSync(tmpPdf); } catch { /* 임시 파일 정리 실패 무시 */ }
        try { fs.unlinkSync(tmpHtml); } catch { /* 임시 파일 정리 실패 무시 */ }
      });
      return { success: true };
    } catch (err) {
      return { success: false, message: String(err) };
    }
  }

  ipcMain.handle('app:print', async (_e, opts) => handlePrint(opts));

  // 기존 보고서 핸들러 — 하위 호환 (내부적으로 공용 로직 위임)
  ipcMain.handle('reports:save-pdf', async (_e, params?: { from?: string; to?: string }) => {
    const from = params?.from?.replace(/-/g, '') ?? '';
    const to = params?.to?.replace(/-/g, '') ?? '';
    const defaultName = from && to ? `상담활동보고서_${from}-${to}.pdf` : `상담활동보고서_${new Date().getFullYear()}.pdf`;
    return handlePrint({ action: 'save', defaultName });
  });

  ipcMain.handle('reports:print', async () => {
    return handlePrint({ action: 'print' });
  });

  ipcMain.handle('reports:preview-pdf', async () => {
    return handlePrint({ action: 'preview' });
  });

  // ── Students ───────────────────────────────────────────────────────────────
  ipcMain.handle('students:list', (_e, params) => {
    return wrapSync(() => requireKey(() => getAllStudents(params)));
  });

  ipcMain.handle('students:profile', (_e, id: number) => {
    return wrapSync(() => requireKey(() => getStudentProfile(id)));
  });

  ipcMain.handle('students:search', (_e, query: string) => {
    return wrapSync(() => requireKey(() => searchStudents(query)));
  });

  ipcMain.handle('students:create', (_e, input) => {
    return wrapSync(() => requireKey(() => createStudent(input)));
  });

  ipcMain.handle('students:update', (_e, id: number, input) => {
    return wrapSync(() => requireKey(() => updateStudent(id, input)));
  });

  ipcMain.handle('students:delete', (_e, id: number) => {
    return wrapSync(() => requireKey(() => deleteStudent(id)));
  });

  ipcMain.handle('students:findByIdentity', (_e, name: string, grade?: string, className?: string, number?: string) => {
    return wrapSync(() => requireKey(() => findStudentByIdentity(name, grade, className, number)));
  });

  // ── Enrollments ─────────────────────────────────────────────────────────────
  ipcMain.handle('enrollments:by-student', (_e, studentId: number) => {
    return wrapSync(() => requireKey(() => getEnrollmentsByStudentId(studentId)));
  });

  ipcMain.handle('enrollments:years', () => {
    return wrapSync(() => requireKey(() => getDistinctEnrollmentYears()));
  });

  // ── Excel Upload ────────────────────────────────────────────────────────────
  ipcMain.handle('students:upload-excel', async () => {
    if (!isKeyLoaded()) {
      console.error('[upload-excel] key not loaded');
      throw new Error('잠금 상태입니다.');
    }

    try {
      const win = mainWindow || BrowserWindow.getAllWindows()[0];
      console.log('[upload-excel] win:', win ? 'ok' : 'null', 'isKeyLoaded:', isKeyLoaded());
      const result = await dialog.showOpenDialog(win!, {
        title: '반배정 파일 선택',
        filters: [
          { name: 'Excel / CSV', extensions: ['xlsx', 'xls', 'csv'] },
        ],
        properties: ['openFile'],
      });

      if (result.canceled || result.filePaths.length === 0) {
        return { success: false, canceled: true };
      }

      const filePath = result.filePaths[0];
      const ext = filePath.split('.').pop()?.toLowerCase();

      if (ext === 'csv') {
        const academicYear = getAcademicYear(new Date());
        const rows = await parseCsv(filePath, academicYear);
        return {
          success: true,
          preview: true,
          academicYear,
          grade: '',
          rowCount: rows.length,
          filePath,
          sampleRows: rows,
        };
      }

      const parsed = await parseNeisExcel(filePath);
      return {
        success: true,
        preview: true,
        academicYear: parsed.academicYear,
        grade: parsed.grade,
        rowCount: parsed.rows.length,
        filePath,
        sampleRows: parsed.rows,
      };
    } catch (err) {
      console.error('[upload-excel] error:', err);
      return { success: false, message: (err as Error).message };
    }
  });

  ipcMain.handle('students:confirm-upload', async (_e, filePath: string) => {
    if (!isKeyLoaded()) throw new Error('잠금 상태입니다.');

    try {
      const ext = filePath.split('.').pop()?.toLowerCase();
      let academicYear: string;
      let rows;

      if (ext === 'csv') {
        academicYear = getAcademicYear(new Date());
        rows = await parseCsv(filePath, academicYear);
      } else {
        const parsed = await parseNeisExcel(filePath);
        academicYear = parsed.academicYear;
        rows = parsed.rows;
      }

      const uploadResult = processUpload(academicYear, rows);
      return { success: true, result: uploadResult };
    } catch (err) {
      return { success: false, message: (err as Error).message };
    }
  });

  // ── Students Bulk ────────────────────────────────────────────────────────────
  ipcMain.handle('students:bulk-delete', (_e, ids: number[]) => {
    return wrapSync(() => requireKey(() => bulkDeleteStudents(ids)));
  });

  ipcMain.handle('students:bulk-update-status', (_e, ids: number[], status: string) => {
    return wrapSync(() => requireKey(() => bulkUpdateStudentStatus(ids, status)));
  });

  ipcMain.handle('students:check-graduation-eligibility', (_e, ids: number[], currentYear: string, graduationGrade: string) => {
    return wrapSync(() => requireKey(() => checkGraduationEligibility(ids, currentYear, graduationGrade)));
  });

  // ── Backup ──────────────────────────────────────────────────────────────────
  ipcMain.handle('backup:create', async () => {
    const win = mainWindow || BrowserWindow.getAllWindows()[0];
    const now = new Date();
    const timestamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
    const defaultName = `wee-story-backup-${timestamp}.db`;

    const result = await dialog.showSaveDialog(win!, {
      defaultPath: defaultName,
      filters: [{ name: 'SQLite Database', extensions: ['db'] }],
    });

    if (result.canceled || !result.filePath) {
      return { success: false };
    }

    try {
      await createBackup(result.filePath);
      shell.showItemInFolder(result.filePath);
      return { success: true, filePath: result.filePath };
    } catch (err) {
      return { success: false, message: (err as Error).message };
    }
  });

  ipcMain.handle('backup:restore', async () => {
    const win = mainWindow || BrowserWindow.getAllWindows()[0];

    // 복원 전 확인 다이얼로그 (메인 프로세스에서 처리)
    const result = await dialog.showOpenDialog(win!, {
      title: '복원할 백업 파일 선택',
      filters: [{ name: 'SQLite Database', extensions: ['db'] }],
      properties: ['openFile'],
    });

    if (result.canceled || result.filePaths.length === 0) {
      return { success: false, message: '취소되었습니다.' };
    }

    const { response: confirmResponse } = await dialog.showMessageBox(win!, {
      type: 'warning',
      title: '데이터 복원',
      message: `복원하면 현재 데이터가 백업 파일의 데이터로 대체됩니다.\n현재 데이터는 자동으로 안전 백업됩니다.\n\n선택한 파일: ${path.basename(result.filePaths[0])}\n\n복원하시겠습니까?`,
      buttons: ['취소', '복원'],
      defaultId: 0,
      cancelId: 0,
    });

    if (confirmResponse === 0) {
      return { success: false, message: '취소되었습니다.' };
    }

    try {
      await restoreFromBackup(result.filePaths[0]);

      clearKey(); // 복원된 DB의 비밀번호로 재인증 필요
      getDb();    // 새 DB 파일로 재연결
      win!.webContents.reload();  // 렌더러 새로고침 → 잠금 화면 표시
      return { success: true };
    } catch (err) {
      return { success: false, message: (err as Error).message };
    }
  });

  ipcMain.handle('backup:reset', async (_e, password: string) => {
    // 비밀번호 검증
    if (!password || !unlock(password)) {
      return { success: false, message: '비밀번호가 올바르지 않습니다.' };
    }

    const win = mainWindow || BrowserWindow.getAllWindows()[0];
    try {
      factoryReset(); // 사례/학생/암호화 설정 전체 삭제
      clearKey();
      win!.webContents.reload(); // 렌더러 리로드 → SetupScreen 표시
      return { success: true };
    } catch (err) {
      return { success: false, message: (err as Error).message };
    }
  });

  // ── 공휴일 ────────────────────────────────────────────────────────────────
  ipcMain.handle('holidays:get-year', async (_e, year: number) => {
    const db = getDb();
    try {
      const cached = getCachedHolidays(db, year);
      if (cached) return cached;
      const holidays = await fetchHolidays(year);
      if (holidays.length > 0) setCachedHolidays(db, year, holidays);
      return holidays;
    } catch (err) {
      console.error('[holidays] fetch failed:', err);
      return null; // 렌더러에서 정적 데이터로 fallback
    }
  });

  // ── 공지사항 ──────────────────────────────────────────────────────────────
  ipcMain.handle('remote:get-notices', async () => {
    const db = getDb();
    try {
      const cached = getCachedNotices(db);
      const notices = cached ?? await fetchNotices().then((n) => {
        setCachedNotices(db, n);
        return n;
      });
      const readIds = new Set(getReadNoticeIds(db));
      return notices.map((n) => ({ ...n, isRead: readIds.has(n.id) }));
    } catch (err) {
      console.error('[notices] fetch failed:', err);
      return [];
    }
  });

  ipcMain.handle('remote:mark-notice-read', (_e, noticeId: string) => {
    markNoticeRead(getDb(), noticeId);
  });

  // ── 학교 검색 / 학사일정 ──────────────────────────────────────────────────
  ipcMain.handle('school:search', async (_e, query: string) => {
    try {
      return await fetchSchoolSearch(query);
    } catch (err) {
      console.error('[school:search] failed:', err);
      return [];
    }
  });

  ipcMain.handle('school:get-schedule', async (_e, year: number) => {
    const db = getDb();
    try {
      const atptCode = getSetting('neis_atpt_code');
      const schulCode = getSetting('neis_schul_code');
      if (!atptCode || !schulCode) return [];

      const cached = getCachedSchedule(db, schulCode, year);
      if (cached) return cached;

      const events = await fetchSchoolSchedule(atptCode, schulCode, year);
      setCachedSchedule(db, schulCode, year, events);
      return events;
    } catch (err) {
      console.error('[school:get-schedule] failed:', err);
      return [];
    }
  });

  // ── 보호자 동의서 (E2E 영지식) ─────────────────────────────────────────────
  // 템플릿 CRUD (스키마는 평문 — PII 없음)
  ipcMain.handle('consent:templates-list', () =>
    wrapSync(() => requireKey(() => listConsentTemplates())),
  );
  ipcMain.handle('consent:template-create', (_e, input) =>
    wrapSync(() => requireKey(() => createConsentTemplate(input))),
  );
  ipcMain.handle('consent:template-update', (_e, id: number, input) =>
    wrapSync(() => requireKey(() => updateConsentTemplate(id, input))),
  );
  ipcMain.handle('consent:template-delete', (_e, id: number) =>
    wrapSync(() => requireKey(() => deleteConsentTemplate(id))),
  );

  // 사례별 요청 목록 / 응답 조회
  ipcMain.handle('consent:list', (_e, caseId: number) =>
    wrapSync(() => requireKey(() => listConsentRequestsByCase(caseId))),
  );
  ipcMain.handle('consent:response', (_e, requestId: number) =>
    wrapSync(() => requireKey(() => getConsentResponse(requestId))),
  );
  // 감사 로그(Phase 6): 사례별 발송/수합/파기 이벤트 이력(비-PII).
  ipcMain.handle('consent:audit-list', (_e, caseId: number) =>
    wrapSync(() => requireKey(() => listAuditEvents({ caseId }))),
  );

  ipcMain.handle('consent:capabilities', () => ({
    server: isServerConfigured(),
    sms: isSmsConfigured(),
  }));

  // 발송(단일): 요청 준비(prepareConsentRequest) → (SMS면 1통 발송) → sent 전이.
  ipcMain.handle(
    'consent:send',
    async (
      _e,
      args: {
        case_id: number;
        student_id: number;
        template_id: number;
        channel: ConsentChannel;
        expiry_days?: number;
      },
    ) => {
      if (!isKeyLoaded()) return { success: false, error: '잠금 상태입니다.' };
      if (!isServerConfigured()) {
        return { success: false, error: '동의서 서버 주소(VITE_CONSENT_SERVER_URL)가 설정되지 않았습니다.' };
      }

      if (args.channel === 'sms') {
        if (!isSmsConfigured()) return { success: false, error: 'SMS 자격증명이 설정되지 않았습니다.' };
        if (!getGuardianContact(args.student_id)) {
          return { success: false, error: '학생의 보호자 연락처가 등록되어 있지 않습니다.' };
        }
      }

      const prep = await prepareConsentRequest(args);
      if (!prep.ok) return { success: false, error: prep.error };
      const { request, link } = prep;
      const nowIso = new Date().toISOString();

      // 전달 (SMS 본문엔 링크만 — PII 0)
      let smsMessageId: string | null = null;
      if (args.channel === 'sms') {
        const contact = getGuardianContact(args.student_id)!;
        const sms = await sendSms({ to: contact, text: consentSmsBody([link]), subject: '상담 접수 동의서' });
        if (!sms.ok) {
          updateConsentRequest(request.id, { status: 'failed', link, last_error: sms.error });
          appendAuditEvent({ event: 'send_failed', requestId: request.id, detail: { stage: 'sms', error: sms.error ?? '' } });
          return { success: false, error: `SMS 발송 실패: ${sms.error}`, link };
        }
        smsMessageId = sms.messageId;
        appendAuditEvent({ event: 'delivered', requestId: request.id, detail: { channel: 'sms' } });
      }

      updateConsentRequest(request.id, { status: 'sent', sent_at: nowIso, link, last_error: null });
      appendAuditEvent({ event: 'status_sent', requestId: request.id, detail: { channel: args.channel } });
      return { success: true, request: { ...request, status: 'sent', link, sent_at: nowIso }, link, smsMessageId };
    },
  );

  // 발송(배치): 여러 양식을 한 보호자에게. 각 양식은 (학생+양식) 단위로만 무효화되어
  // 서로를 덮어쓰지 않는다(①). SMS는 준비된 링크를 모아 **한 통**으로 발송(③).
  ipcMain.handle(
    'consent:send-batch',
    async (
      _e,
      args: {
        case_id: number;
        student_id: number;
        template_ids: number[];
        channel: ConsentChannel;
        expiry_days?: number;
      },
    ) => {
      if (!isKeyLoaded()) return { success: false, error: '잠금 상태입니다.', results: [] };
      if (!isServerConfigured()) {
        return { success: false, error: '동의서 서버 주소(VITE_CONSENT_SERVER_URL)가 설정되지 않았습니다.', results: [] };
      }
      if (!Array.isArray(args.template_ids) || args.template_ids.length === 0) {
        return { success: false, error: '발송할 양식을 선택해 주세요.', results: [] };
      }
      // 같은 양식 중복 선택 제거 — 자기들끼리 무효화되는 것을 막는다.
      const templateIds = [...new Set(args.template_ids)];

      if (args.channel === 'sms') {
        if (!isSmsConfigured()) return { success: false, error: 'SMS 자격증명이 설정되지 않았습니다.', results: [] };
        if (!getGuardianContact(args.student_id)) {
          return { success: false, error: '학생의 보호자 연락처가 등록되어 있지 않습니다.', results: [] };
        }
      }

      type BatchResult = { template_id: number; success: boolean; request?: ConsentRequest; link?: string; error?: string };
      const results: BatchResult[] = [];
      const prepared: Array<{ template_id: number; request: ConsentRequest; link: string }> = [];

      // 1) 양식별 요청 생성·서버 등록(SMS는 아직 보내지 않음).
      for (const template_id of templateIds) {
        const prep = await prepareConsentRequest({
          case_id: args.case_id,
          student_id: args.student_id,
          template_id,
          channel: args.channel,
          expiry_days: args.expiry_days,
        });
        if (prep.ok) prepared.push({ template_id, request: prep.request, link: prep.link });
        else results.push({ template_id, success: false, error: prep.error });
      }

      const nowIso = new Date().toISOString();
      let smsMessageId: string | null = null;

      // 2) SMS면 준비된 링크 전부를 한 통에 묶어 발송. 실패 시 해당 요청들 failed 처리.
      if (args.channel === 'sms' && prepared.length > 0) {
        const contact = getGuardianContact(args.student_id)!;
        const sms = await sendSms({
          to: contact,
          text: consentSmsBody(prepared.map((p) => p.link)),
          subject: '상담 접수 동의서',
        });
        if (!sms.ok) {
          for (const p of prepared) {
            updateConsentRequest(p.request.id, { status: 'failed', link: p.link, last_error: sms.error });
            appendAuditEvent({ event: 'send_failed', requestId: p.request.id, detail: { stage: 'sms', error: sms.error ?? '' } });
            results.push({ template_id: p.template_id, success: false, link: p.link, error: `SMS 발송 실패: ${sms.error}` });
          }
          return { success: false, error: `SMS 발송 실패: ${sms.error}`, results, sentCount: 0, failedCount: results.length };
        }
        smsMessageId = sms.messageId;
        for (const p of prepared) appendAuditEvent({ event: 'delivered', requestId: p.request.id, detail: { channel: 'sms' } });
      }

      // 3) 준비된 요청 전부 sent 전이.
      for (const p of prepared) {
        updateConsentRequest(p.request.id, { status: 'sent', sent_at: nowIso, link: p.link, last_error: null });
        appendAuditEvent({ event: 'status_sent', requestId: p.request.id, detail: { channel: args.channel } });
        results.push({
          template_id: p.template_id,
          success: true,
          request: { ...p.request, status: 'sent', link: p.link, sent_at: nowIso },
          link: p.link,
        });
      }

      const sentCount = prepared.length;
      const failedCount = results.length - sentCount;
      return { success: sentCount > 0, results, sentCount, failedCount, smsMessageId };
    },
  );

  // 수합: 서버 폴링(먼저) → sealed-box 복호 → 로컬 기록 → 서버 ack 파기 → 그 다음 만료 처리.
  // 만료 처리를 폴링 뒤로 둔 이유: 만료 직전 제출분이 만료 처리에 먼저 걸려 유실되는 것을 막는다.
  ipcMain.handle('consent:poll', async () => {
    if (!isKeyLoaded()) return { success: false, error: '잠금 상태입니다.', ingested: 0, expired: 0, errors: 0 };
    if (!isServerConfigured()) {
      return { success: false, error: '동의서 서버 미설정', ingested: 0, expired: 0, errors: 0 };
    }

    let pending: Awaited<ReturnType<typeof fetchPending>>;
    try {
      pending = await fetchPending();
    } catch (err) {
      return { success: false, error: (err as Error).message, ingested: 0, expired: 0, errors: 0 };
    }
    appendAuditEvent({ event: 'poll_started', requestId: null, detail: { pending: pending.length } });

    let ingested = 0;
    let errors = 0;
    for (const item of pending) {
      // 만료 여부와 무관하게 토큰으로 조회 — 서버가 응답을 들고 있으면 수합한다(유실 방지).
      const loc = getRequestCryptoByToken(item.token);
      if (!loc) continue; // 우리 디바이스 소유가 아님

      // 복호 영구 실패(변조 등)로 표시된 건은 재복호하지 않고 서버 파기만 재시도(무한 재시도 차단).
      if (loc.status === 'failed') {
        try { await ackRequest(item.token); } catch { /* 다음 폴링에서 재시도 */ }
        continue;
      }

      // 미수합이면 복호 → 로컬 암호화 기록.
      if (loc.status !== 'ingested') {
        try {
          const plaintext = await sealOpen(item.ciphertext, loc.public_key, loc.private_key);
          const answers = JSON.parse(plaintext) as Record<string, unknown>;
          recordConsentResponse(loc.id, answers, item.submittedAt);
          ingested++;
          appendAuditEvent({ event: 'response_recorded', requestId: loc.id });
        } catch (err) {
          // 복호/파싱 영구 실패 → failed로 전이(무한 재시도 차단). 서버 암호문은 파기 시도.
          errors++;
          console.error('[consent:poll] decrypt', item.token, err);
          updateConsentRequest(loc.id, { status: 'failed', last_error: `복호 실패: ${(err as Error).message}` });
          appendAuditEvent({ event: 'decrypt_failed', requestId: loc.id, detail: { error: (err as Error).message } });
          try { await ackRequest(item.token); } catch { /* 무시 */ }
          continue;
        }
      }

      // 로컬 기록 완료(또는 이미 ingested인데 직전 ack 실패) → 서버 암호문 즉시 파기. 실패 시 다음 폴링 재시도.
      try {
        await ackRequest(item.token);
        appendAuditEvent({ event: 'response_destroyed', requestId: loc.id });
      } catch (err) {
        errors++;
        console.error('[consent:poll] ack', item.token, err);
        updateConsentRequest(loc.id, { last_error: `파기 지시 실패: ${(err as Error).message}` });
      }
    }

    // 수합을 마친 뒤, 서버에 응답이 없던 미완료 요청만 만료 처리.
    let expired = 0;
    try {
      expired = expireStaleRequests();
      if (expired > 0) {
        appendAuditEvent({ event: 'requests_expired', requestId: null, detail: { count: expired } });
      }
    } catch (err) {
      console.error('[consent:poll] expire', err);
    }

    return { success: true, ingested, expired, errors };
  });

  // ── AI 도우미 (온디바이스 LLM) ─────────────────────────────────────────────
  // 토큰 스트리밍은 webContents.send('ai:event', ...) 로 push된다.
  // ai:generate만 requireKey 게이트 — 향후 ContextBuilder가 DB를 복호화하기 때문.
  ipcMain.handle('ai:get-status', () => {
    return aiService().getStatus();
  });

  ipcMain.handle('ai:download-model', () => {
    return aiService().startDownload();
  });

  ipcMain.handle('ai:cancel-download', () => {
    return aiService().cancelDownload();
  });

  ipcMain.handle('ai:warm-up', () => {
    return requireKey(() => aiService().warmUp());
  });

  ipcMain.handle('ai:generate', (_e, payload: GenerateStartPayload) => {
    return requireKey(() => aiService().generate(payload));
  });

  ipcMain.handle('ai:cancel', (_e, args: { requestId: string }) => {
    return aiService().cancel(args.requestId);
  });

  // 사이드패널 "요약 갱신" — 누락/실패 회기를 다시 큐에 넣는다. 결과는 enqueued 개수.
  ipcMain.handle('ai:refresh-summaries', (_e, args?: { caseId?: number }) => {
    return requireKey(() => refreshSummaries(args?.caseId));
  });

  // ── Export ─────────────────────────────────────────────────────────────────
  ipcMain.handle('export:xlsx', async (_e, params) => {
    const sessions = getSessionsForExport(params);

    if (sessions.length === 0) {
      return { success: false, message: '내보낼 데이터가 없습니다.' };
    }

    const buffer = await generateXlsx(sessions);

    const from = (params.from as string | undefined)?.replace(/-/g, '') ?? '';
    const to = (params.to as string | undefined)?.replace(/-/g, '') ?? '';
    const defaultName = from && to ? `NEIS_상담기록_${from}-${to}.xlsx` : `NEIS_상담기록_${new Date().getFullYear()}.xlsx`;

    const win = mainWindow || BrowserWindow.getAllWindows()[0];
    const result = await dialog.showSaveDialog(win!, {
      defaultPath: defaultName,
      filters: [{ name: 'Excel Files', extensions: ['xlsx'] }],
    });

    if (result.canceled || !result.filePath) {
      return { success: false };
    }

    try {
      fs.writeFileSync(result.filePath, buffer);
      shell.showItemInFolder(result.filePath);
      return { success: true, filePath: result.filePath };
    } catch (err) {
      return { success: false, message: `파일 저장 실패: ${(err as Error).message}` };
    }
  });

  // ── STT ────────────────────────────────────────────────────────────────────
  registerSttHandlers();
}

function registerSttHandlers() {
  const svc = sttService();

  // 이벤트 → 메인 윈도우로 forward
  svc.on('stt-event', (evt: SttEvent) => {
    mainWindow?.webContents.send('stt:event', evt);
  });

  ipcMain.handle('stt:get-status', () => svc.getStatus());

  ipcMain.handle('stt:download-model', () => svc.startDownload());

  ipcMain.handle('stt:cancel-download', () => ({ ok: svc.cancelDownload() }));

  ipcMain.handle('stt:transcribe', async (_e, payload: SttTranscribePayload) => {
    if (!isKeyLoaded()) throw new Error('잠금 상태입니다. 비밀번호를 입력해주세요.');
    return svc.transcribe(payload);
  });

  ipcMain.handle('stt:cancel', (_e, requestId: string) => ({ ok: svc.cancel(requestId) }));

  ipcMain.handle('stt:update-settings', (_e, updates: Partial<{
    stt_enabled: '0' | '1';
    stt_engine: 'whisper-cli';
    stt_model: SttModelId;
    stt_language: 'ko';
  }>) => {
    updateSttSettings(updates);
    return svc.getStatus();
  });

  // 앱 종료 시 STT 워커 정리
  app.on('before-quit', () => {
    void svc.dispose();
  });
}
