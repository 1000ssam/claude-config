/**
 * 동의서 영지식 서버(Cloudflare Worker) HTTP 클라이언트 — 메인 프로세스 전용.
 *
 * 서버는 암호문만 보관(개인키 부재 → 복호 불가). 이 클라이언트는:
 *  - POST /requests          : 공개키 + 폼 스키마(평문) + 만료 등록
 *  - GET  /requests/pending  : 이 디바이스가 만든 '응답완료' 요청의 암호문 수령
 *  - POST /requests/:token/ack : 수합 완료 후 서버 암호문 파기 지시
 *
 * 앱↔서버 인증: 디바이스별 경량 bearer 토큰(로컬 settings에 1회 생성·보관).
 * 서버는 생성 시 토큰 해시를 요청에 묶어두고, pending/ack 시 동일 디바이스만 허용한다.
 * (풀 OAuth는 구독 단계에서 추가 — 플랜 §통합 서버리스.)
 */

import { randomBytes } from 'crypto';
import { getDb } from '../lib/db';
import { getKey } from '../lib/crypto/key-manager';
import { encryptValue, decryptValue } from '../lib/crypto/field-crypto';
import type { ConsentFormSchema } from '../types/consent';

const DEVICE_TOKEN_KEY = 'consent_device_token';

function serverBase(): string {
  const url = import.meta.env.VITE_CONSENT_SERVER_URL as string | undefined;
  if (!url) throw new Error('VITE_CONSENT_SERVER_URL 미설정 — 동의서 서버 주소가 필요합니다.');
  return url.replace(/\/$/, '');
}

export function isServerConfigured(): boolean {
  return !!(import.meta.env.VITE_CONSENT_SERVER_URL as string | undefined);
}

/**
 * 디바이스 bearer 토큰 — 없으면 생성해 settings에 저장.
 * 저장 시 AES-256-GCM 암호화(다른 민감필드와 동일) → DB 파일 탈취 시 토큰 유출 방지.
 * (호출은 네트워크 작업 중에만 일어나므로 키는 항상 로드된 상태.)
 */
export function getDeviceToken(): string {
  const db = getDb();
  const key = getKey();
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(DEVICE_TOKEN_KEY) as
    | { value: string }
    | undefined;
  if (row?.value) return decryptValue(row.value, key); // 레거시 평문도 그대로 통과
  const token = randomBytes(32).toString('hex');
  db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run(
    DEVICE_TOKEN_KEY,
    encryptValue(token, key),
  );
  return token;
}

function authHeaders(): Record<string, string> {
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${getDeviceToken()}`,
  };
}

/** 보호자 접속 링크 URL. */
export function buildLink(token: string): string {
  return `${serverBase()}/f/${token}`;
}

/** 요청 등록(공개키 + 평문 스키마 + 만료). 서버는 status=pending으로 저장. */
export async function postRequest(args: {
  token: string;
  publicKey: string;
  formSchema: ConsentFormSchema;
  title: string;
  expiresAt: string;
}): Promise<void> {
  const res = await fetch(`${serverBase()}/requests`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify({
      token: args.token,
      publicKey: args.publicKey,
      formSchema: args.formSchema,
      title: args.title,
      expiresAt: args.expiresAt,
    }),
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`서버 등록 실패 (HTTP ${res.status}) ${body.slice(0, 120)}`);
  }
}

export interface PendingItem {
  token: string;
  ciphertext: string; // base64 sealed box
  submittedAt: string;
}

/** 이 디바이스의 '응답완료' 요청 암호문 목록. */
export async function fetchPending(): Promise<PendingItem[]> {
  const res = await fetch(`${serverBase()}/requests/pending`, {
    method: 'GET',
    headers: authHeaders(),
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`수합 조회 실패 (HTTP ${res.status}) ${body.slice(0, 120)}`);
  }
  const data = (await res.json()) as { requests?: PendingItem[] };
  return Array.isArray(data.requests) ? data.requests : [];
}

/** 수합 완료 후 서버 암호문 파기. */
export async function ackRequest(token: string): Promise<void> {
  const res = await fetch(`${serverBase()}/requests/${encodeURIComponent(token)}/ack`, {
    method: 'POST',
    headers: authHeaders(),
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`파기 지시 실패 (HTTP ${res.status}) ${body.slice(0, 120)}`);
  }
}

/** 재발송 무효화: 옛 링크를 서버에서 만료 처리(보호자에겐 410 "만료된 링크"). ack(제출완료)와 구분. */
export async function revokeRequest(token: string): Promise<void> {
  const res = await fetch(`${serverBase()}/requests/${encodeURIComponent(token)}/revoke`, {
    method: 'POST',
    headers: authHeaders(),
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`무효화 지시 실패 (HTTP ${res.status}) ${body.slice(0, 120)}`);
  }
}
