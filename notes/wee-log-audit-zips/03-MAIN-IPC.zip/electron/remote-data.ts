/**
 * remote-data.ts
 * 모든 외부 HTTP 요청을 메인 프로세스에서 일괄 관리하는 서비스.
 * 환경변수로 엔드포인트/키를 주입받아 인수인계 시 코드 수정 없이 교체 가능.
 */

import type { HolidayEntry } from '../lib/queries/holiday-cache';

// ── 공지사항 ──────────────────────────────────────────────────────────────────

export interface Notice {
  id: string;
  title: string;
  body: string;
  type: 'info' | 'warning' | 'update';
  publishedAt: string; // ISO 8601
}

export async function fetchNotices(): Promise<Notice[]> {
  const url = import.meta.env.VITE_ANNOUNCEMENTS_URL as string | undefined;
  if (!url) return [];

  const res = await fetch(url, { signal: AbortSignal.timeout(10_000) });
  if (!res.ok) throw new Error(`notices fetch failed: ${res.status}`);

  const data = await res.json() as unknown;
  if (!Array.isArray(data)) throw new Error('notices response is not an array');

  return data as Notice[];
}

// ── 학사일정 ──────────────────────────────────────────────────────────────────

export interface SchoolInfo {
  atptCode: string;
  schulCode: string;
  schulName: string;
  schulKind: string;  // 초등학교/중학교/고등학교
  addr: string;
}

export interface SchoolEvent {
  date: string;  // YYYY-MM-DD
  name: string;
}

const NEIS_BASE = 'https://open.neis.go.kr/hub';

function neisKey(): string {
  return (import.meta.env.VITE_NEIS_API_KEY as string | undefined) ?? '';
}

export async function fetchSchoolSearch(query: string): Promise<SchoolInfo[]> {
  const key = neisKey();
  const url = `${NEIS_BASE}/schoolInfo?Type=json&pSize=20&SCHUL_NM=${encodeURIComponent(query)}${key ? `&KEY=${key}` : ''}`;
  const res = await fetch(url, { signal: AbortSignal.timeout(10_000) });
  const json = await res.json() as Record<string, unknown>;

  const rows = (json.schoolInfo as { row?: unknown[] }[] | undefined)?.[1]?.row ?? [];
  return (rows as Record<string, string>[]).map((r) => ({
    atptCode: r.ATPT_OFCDC_SC_CODE,
    schulCode: r.SD_SCHUL_CODE,
    schulName: r.SCHUL_NM,
    schulKind: r.SCHUL_CRSE_SC_NM,
    addr: r.ORG_RDNMA ?? '',
  }));
}

export async function fetchSchoolSchedule(atptCode: string, schulCode: string, year: number): Promise<SchoolEvent[]> {
  const key = neisKey();
  const from = `${year}0101`;
  const to   = `${year}1231`;
  const url =
    `${NEIS_BASE}/SchoolSchedule?Type=json&pSize=365` +
    `&ATPT_OFCDC_SC_CODE=${atptCode}&SD_SCHUL_CODE=${schulCode}` +
    `&AA_FROM_YMD=${from}&AA_TO_YMD=${to}${key ? `&KEY=${key}` : ''}`;

  const res = await fetch(url, { signal: AbortSignal.timeout(10_000) });
  const json = await res.json() as Record<string, unknown>;

  const rows = (json.SchoolSchedule as { row?: unknown[] }[] | undefined)?.[1]?.row ?? [];
  return (rows as Record<string, string>[]).map((r) => ({
    date: `${r.AA_YMD.slice(0, 4)}-${r.AA_YMD.slice(4, 6)}-${r.AA_YMD.slice(6, 8)}`,
    name: r.EVENT_NM,
  }));
}

// ── 공휴일 ────────────────────────────────────────────────────────────────────

export async function fetchHolidays(year: number): Promise<HolidayEntry[]> {
  const apiKey = import.meta.env.VITE_HOLIDAY_API_KEY as string | undefined;
  if (!apiKey) return [];

  const url =
    `https://apis.data.go.kr/B090041/openapi/service/SpcdeInfoService/getRestDeInfo` +
    `?serviceKey=${encodeURIComponent(apiKey)}&solYear=${year}&numOfRows=50&pageNo=1`;

  const res = await fetch(url, { signal: AbortSignal.timeout(10_000) });
  const xml = await res.text();

  const results: HolidayEntry[] = [];
  for (const match of xml.matchAll(/<item>([\s\S]*?)<\/item>/g)) {
    const item = match[1];
    const isHoliday = item.match(/<isHoliday>(.*?)<\/isHoliday>/)?.[1];
    const locdate   = item.match(/<locdate>(.*?)<\/locdate>/)?.[1];
    const dateName  = item.match(/<dateName>(.*?)<\/dateName>/)?.[1];
    if (isHoliday === 'Y' && locdate && dateName) {
      results.push({
        date: `${locdate.slice(0, 4)}-${locdate.slice(4, 6)}-${locdate.slice(6, 8)}`,
        name: dateName,
      });
    }
  }
  return results;
}
