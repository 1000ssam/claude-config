/**
 * SMS 게이트웨이(Solapi v4, HMAC-SHA256) 클라이언트 — 메인 프로세스 전용.
 *
 * 보안: 자격증명은 `MAIN_VITE_SOLAPI_*` 환경변수로 주입한다. electron-vite는
 * `MAIN_VITE_` 접두사를 **메인 프로세스에만** 노출하므로(렌더러 번들에 인라인 불가),
 * 누군가 렌더러에서 동적 env 접근을 하더라도 시크릿이 새지 않는다.
 *
 * 본문(text)에는 개인정보를 넣지 않는다 — 1회용 링크만.
 * 발신번호(SOLAPI_SENDER)는 전기통신사업법상 사전 등록된 번호여야 한다.
 */

import { createHmac, randomBytes } from 'crypto';

const API_BASE = 'https://api.solapi.com';

function cred(name: 'KEY' | 'SECRET' | 'SENDER'): string | undefined {
  const env = import.meta.env as Record<string, string | undefined>;
  if (name === 'KEY') return env.MAIN_VITE_SOLAPI_API_KEY;
  if (name === 'SECRET') return env.MAIN_VITE_SOLAPI_API_SECRET;
  return env.MAIN_VITE_SOLAPI_SENDER;
}

export function isSmsConfigured(): boolean {
  return !!(cred('KEY') && cred('SECRET') && cred('SENDER'));
}

function authHeader(): string {
  const apiKey = cred('KEY');
  const apiSecret = cred('SECRET');
  if (!apiKey || !apiSecret) {
    throw new Error('SOLAPI 자격증명 미설정');
  }
  const date = new Date().toISOString();
  const salt = randomBytes(32).toString('hex');
  const signature = createHmac('sha256', apiSecret).update(date + salt).digest('hex');
  return `HMAC-SHA256 apiKey=${apiKey}, date=${date}, salt=${salt}, signature=${signature}`;
}

function normalizePhone(phone: string): string {
  let digits = String(phone).replace(/[^0-9]/g, '');
  // 국제 prefix '00' 또는 +82 표기를 국내 0xx로 복원
  if (digits.startsWith('0082')) digits = '0' + digits.slice(4);
  else if (digits.startsWith('82') && !digits.startsWith('820')) digits = '0' + digits.slice(2);
  return digits;
}

export interface SmsResult {
  ok: boolean;
  messageId: string | null;
  error: string | null;
}

/** 단일 SMS/LMS 발송. subject가 있으면 Solapi가 LMS로 분류한다. */
export async function sendSms(opts: { to: string; text: string; subject?: string }): Promise<SmsResult> {
  const from = cred('SENDER');
  if (!from) return { ok: false, messageId: null, error: 'SOLAPI_SENDER 미설정' };

  const to = normalizePhone(opts.to);
  if (!to) return { ok: false, messageId: null, error: '수신번호 형식 오류' };

  const message: Record<string, string> = { to, from: normalizePhone(from), text: opts.text };
  if (opts.subject && opts.subject.trim()) message.subject = opts.subject.trim();

  let res: Response;
  let data: Record<string, unknown>;
  try {
    res = await fetch(`${API_BASE}/messages/v4/send`, {
      method: 'POST',
      headers: { Authorization: authHeader(), 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
      signal: AbortSignal.timeout(15_000),
    });
    data = (await res.json()) as Record<string, unknown>;
  } catch (e) {
    return { ok: false, messageId: null, error: `네트워크 오류: ${(e as Error).message}` };
  }

  if (!res.ok) {
    const err =
      (data?.message as string) ||
      (data?.errorMessage as string) ||
      (data?.errorCode as string) ||
      `HTTP ${res.status}`;
    return { ok: false, messageId: null, error: err };
  }

  const messageId = (data?.messageId as string) || (data?.groupId as string) || null;
  const statusCode = String(data?.statusCode ?? '');
  if (statusCode && !statusCode.startsWith('2')) {
    return {
      ok: false,
      messageId,
      error: `Solapi statusCode=${statusCode}: ${(data?.statusMessage as string) ?? ''}`,
    };
  }
  return { ok: true, messageId, error: null };
}
