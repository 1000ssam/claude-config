import Database from 'better-sqlite3';
import path from 'path';
import os from 'os';

const DB_PATH = path.join(os.homedir(), 'AppData', 'Roaming', 'Wee-Story', 'wee-log.db');
const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');
db.exec(`
  DELETE FROM session_students;
  DELETE FROM sessions;
  DELETE FROM case_conceptualizations;
  DELETE FROM case_students;
  DELETE FROM cases;
  DELETE FROM student_enrollments;
  DELETE FROM students;
`);
db.prepare("UPDATE settings SET value = '1' WHERE key = 'next_case_seq'").run();
console.log('Data cleared');
db.close();
