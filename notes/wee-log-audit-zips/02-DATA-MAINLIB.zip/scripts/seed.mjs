/**
 * 개발용 대규모 샘플 데이터 시드 스크립트
 * 3학년 × 2학급 × 20명 = 120명 학생 + 10건 사례 + ~60건 세션
 * 상/검/자/교/연/의뢰 6개 카테고리를 고르게 배분
 *
 * 사용법: node scripts/seed.mjs
 * ⚠️  앱이 실행 중이면 먼저 종료 후 실행
 */

import Database from 'better-sqlite3';
import path from 'path';
import os from 'os';

const DB_PATH = path.join(
  os.homedir(), 'AppData', 'Roaming', 'Wee-Story', 'wee-log.db',
);
console.log(`DB: ${DB_PATH}`);
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ── 컬럼 존재 보장 (레거시 마이그레이션 제거 후 누락 가능) ───────────────────
function ensureColumn(table, column, type = 'TEXT') {
  const cols = db.pragma(`table_info(${table})`);
  if (!cols.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${type}`);
    console.log(`  + ${table}.${column} 컬럼 추가`);
  }
}
ensureColumn('cases', 'counseling_goal');
ensureColumn('cases', 'teacher_opinion');
ensureColumn('cases', 'close_reason');
ensureColumn('cases', 'close_reason_detail');
ensureColumn('sessions', 'appointment_time');
ensureColumn('sessions', 'reminder_minutes', 'INTEGER');

// ── 한국 이름 생성 ──────────────────────────────────────────────────────────
const FAMILY = [
  '김','이','박','최','정','강','윤','임','한','오',
  '송','장','배','유','권','조','전','류','서','문',
  '안','홍','양','노','하','신','고','남','민','황',
];
const MALE_GIVEN = [
  '민준','서준','도윤','시우','준서','지호','태민','현우','도현','성민',
  '재윤','우진','승현','예준','주원','건우','시윤','지환','승우','은찬',
  '민성','준혁','진우','현성','태양','하준','연우','찬영','은호','동현',
];
const FEMALE_GIVEN = [
  '서연','지우','하은','나연','수아','예린','지민','서윤','하린','수빈',
  '은서','채원','유진','민서','소율','지아','서현','예은','다인','연서',
  '시은','하윤','유나','지윤','민지','소연','서영','예지','채린','하영',
];

function makeNames(count, givenPool) {
  const names = [];
  const used = new Set();
  for (let f = 0; f < FAMILY.length && names.length < count; f++) {
    for (let g = 0; g < givenPool.length && names.length < count; g++) {
      const n = FAMILY[f] + givenPool[g];
      if (!used.has(n)) { used.add(n); names.push(n); }
    }
  }
  return names;
}

const maleNames = makeNames(60, MALE_GIVEN);
const femaleNames = makeNames(60, FEMALE_GIVEN);

// ── 날짜 헬퍼 ──────────────────────────────────────────────────────────────
function date(m, d) {
  return `2026-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}
function ts(m, d) {
  return `${date(m, d)} 09:00:00`;
}

// ── 메인 트랜잭션 ──────────────────────────────────────────────────────────
const seed = db.transaction(() => {
  // ── 1. 학생 120명 ──────────────────────────────────────────────────────
  const insertStudent = db.prepare(
    'INSERT INTO students (name, gender, status) VALUES (?, ?, ?)',
  );
  const insertEnrollment = db.prepare(
    'INSERT INTO student_enrollments (student_id, academic_year, grade, class_name, number) VALUES (?, ?, ?, ?, ?)',
  );

  const studentIds = []; // flat list, index 0~119
  let mi = 0;
  let fi = 0;
  for (let grade = 1; grade <= 3; grade++) {
    for (let cls = 1; cls <= 2; cls++) {
      for (let num = 1; num <= 20; num++) {
        const isMale = num <= 10;
        const name = isMale ? maleNames[mi++] : femaleNames[fi++];
        const gender = isMale ? '남' : '여';
        const status = (grade === 3 && cls === 2 && num <= 3) ? '졸업' : '재학';
        const r = insertStudent.run(name, gender, status);
        const sid = Number(r.lastInsertRowid);
        studentIds.push(sid);
        insertEnrollment.run(sid, '2026', `${grade}학년`, String(cls), String(num));
      }
    }
  }
  console.log(`✅ 학생 ${studentIds.length}명 + 학적 삽입`);

  // grade-class 별 학생 id 맵 (0-indexed)
  // grade 1 cls 1: index 0~19, cls 2: 20~39
  // grade 2 cls 1: 40~59, cls 2: 60~79
  // grade 3 cls 1: 80~99, cls 2: 100~119
  function pick(grade, cls, num) {
    return studentIds[((grade - 1) * 40) + ((cls - 1) * 20) + (num - 1)];
  }

  // ── 2. 사례 10건 ──────────────────────────────────────────────────────
  const seqRow = db.prepare("SELECT value FROM settings WHERE key = 'next_case_seq'").get();
  let seq = parseInt(seqRow?.value ?? '1');
  const year = '2026';

  const insertCase = db.prepare(`
    INSERT INTO cases (
      case_number, academic_year,
      referrer_name, referrer_role, referrer_contact,
      main_complaint, counseling_goal, teacher_opinion,
      status, close_reason, close_reason_detail, notes,
      created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insertCaseStudent = db.prepare(
    'INSERT INTO case_students (case_id, student_id) VALUES (?, ?)',
  );

  const caseDefs = [
    // [studentPicks, referrerName, referrerRole, referrerContact, mainComplaint, counselingGoal, teacherOpinion, status, closeReason, closeReasonDetail, notes, createdDate]
    {
      students: [pick(1, 1, 3)],
      ref: ['박영희', '담임교사', '010-1234-5678'],
      complaint: '또래관계에서 반복적으로 갈등이 발생하며 교우관계가 위축되어 있음',
      goal: '또래관계 기술 향상 및 자기표현 능력 증진', opinion: '수업 중 혼자 있는 시간이 많고 모둠활동을 기피함',
      status: 'active', close: [null, null], notes: '3월 초 담임 의뢰', created: date(3, 5),
    },
    {
      students: [pick(2, 1, 15)],
      ref: ['김정은', '학부모', '010-2345-6789'],
      complaint: '중간고사 이후 학업 의욕 저하, 성적 하락에 대한 스트레스',
      goal: '학습 동기 회복 및 시험 불안 완화', opinion: null,
      status: 'closed', close: ['상담 목표 달성', '학습 계획 수립 후 자기주도 학습 가능해짐'],
      notes: '학부모가 먼저 연락', created: date(3, 7),
    },
    {
      students: [pick(1, 2, 5)],
      ref: ['이수진', '담임교사', '010-3456-7890'],
      complaint: '자해 흔적 발견, 자살 사고 보고됨. 즉각적 개입 필요',
      goal: '자해 충동 조절 및 안전 계획 수립', opinion: '최근 결석이 잦아지고 표정이 어두워짐. 팔목에 긁힌 상처 확인',
      status: 'active', close: [null, null], notes: '위기 사례 — 주 2회 상담 진행 중', created: date(3, 10),
    },
    {
      students: [pick(3, 2, 1)],  // 졸업생
      ref: [null, '자발적', null],
      complaint: '대학 진학 방향을 정하지 못해 불안함',
      goal: '진로 탐색 및 의사결정 역량 강화', opinion: null,
      status: 'closed', close: ['학적 변동', '졸업으로 인한 종결, Wee센터 연계 완료'],
      notes: null, created: date(3, 12),
    },
    {
      students: [pick(1, 1, 18)],
      ref: ['정민호', '교과교사', '010-4567-8901'],
      complaint: '부모 이혼 과정에서 정서적 불안정, 수업 중 감정 폭발',
      goal: '정서 안정 및 가족 변화 적응 지원', opinion: '수학 수업 중 갑자기 울거나 책을 집어던지는 행동 관찰',
      status: 'active', close: [null, null], notes: '학부모 상담 병행 필요', created: date(3, 14),
    },
    {
      students: [pick(2, 1, 2), pick(2, 1, 7), pick(2, 1, 12), pick(2, 1, 16), pick(2, 2, 4)],
      ref: ['김선미', '기타', null],
      complaint: '또래 갈등으로 학급 분위기 악화, 집단 개입 필요',
      goal: '갈등 해결 기술 습득 및 학급 응집력 강화', opinion: null,
      status: 'active', close: [null, null], notes: '2학년 학급 집단상담 프로그램', created: date(3, 17),
    },
    {
      students: [pick(2, 2, 11)],
      ref: [null, '자발적', null],
      complaint: '지속적인 우울감과 무기력, 수면 장애 호소',
      goal: '우울 증상 완화 및 일상 기능 회복', opinion: null,
      status: 'active', close: [null, null], notes: '정신건강의학과 연계 검토 중', created: date(3, 20),
    },
    {
      students: [pick(1, 2, 14)],
      ref: ['강민호', '또래', null],
      complaint: '같은 반 학생들에게 지속적으로 따돌림을 당하고 있음',
      goal: '심리적 회복 및 안전한 학교생활 지원', opinion: null,
      status: 'active', close: [null, null], notes: '학교폭력대책심의위 병행', created: date(3, 24),
    },
    {
      students: [pick(2, 2, 3), pick(2, 2, 14)],
      ref: ['오지영', '교과교사', '010-5678-9012'],
      complaint: '분노 조절 어려움, 충동적 행동으로 또래 갈등 빈번',
      goal: '감정 인식 및 분노 조절 기술 습득', opinion: '체육 수업 중 사소한 시비로 몸싸움이 잦음',
      status: 'active', close: [null, null], notes: '2명 동시 상담 진행', created: date(3, 27),
    },
    {
      students: [pick(3, 1, 9)],
      ref: ['최동우', '담임교사', '010-6789-0123'],
      complaint: '하루 6시간 이상 게임, 수업 중 졸음, 과제 미제출 반복',
      goal: '스마트폰 사용 조절 및 건강한 생활습관 형성', opinion: '매일 지각하고 1교시 내내 엎드려 잠',
      status: 'closed', close: ['기타', '학생 본인의 상담 거부로 조기 종결. 담임 모니터링 전환'],
      notes: null, created: date(4, 1),
    },
  ];

  const caseIds = [];
  for (const c of caseDefs) {
    const caseNum = `${year}-${String(seq++).padStart(3, '0')}`;
    const r = insertCase.run(
      caseNum, year,
      c.ref[0], c.ref[1], c.ref[2],
      c.complaint, c.goal, c.opinion,
      c.status, c.close[0], c.close[1], c.notes,
      ts(parseInt(c.created.split('-')[1]), parseInt(c.created.split('-')[2])),
      ts(parseInt(c.created.split('-')[1]), parseInt(c.created.split('-')[2])),
    );
    const cid = Number(r.lastInsertRowid);
    caseIds.push(cid);
    for (const sid of c.students) {
      insertCaseStudent.run(cid, sid);
    }
  }
  db.prepare("UPDATE settings SET value = ? WHERE key = 'next_case_seq'").run(String(seq));
  console.log(`✅ 사례 ${caseIds.length}건 삽입 (case_students 포함)`);

  // ── 3. 세션 데이터 ──────────────────────────────────────────────────────
  const insertSession = db.prepare(`
    INSERT INTO sessions (
      case_id, counseling_class, wee_class,
      category_large, category_medium, category_detail,
      headcount, academic_year, session_date, appointment_time, reminder_minutes,
      grade, gender, session_title, session_content,
      session_hour, session_minute, counselor_affil, medium, session_number, internal_notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const insertSessionStudent = db.prepare(
    'INSERT INTO session_students (session_id, student_id) VALUES (?, ?)',
  );

  // 세션 정의: [caseIndex, counselingClass, weeClass, catL, catM, catD,
  //   headcount, date, appointmentTime, reminderMin,
  //   grade, gender, title, content, hour, min, affil, medium, sessionNum, internalNotes]
  const sessions = [
    // ━━━ Case 0: 대인관계 (1-1-3) — 상담 5회 + 검사 1회 ━━━
    [0, '일반상담', '일반', '상담', '개인상담', '대인관계', 1, date(3,7), '10:00', 30, '1학년', '남',
     '초기 상담 — 주호소 파악', '또래관계 어려움에 대한 주호소를 청취하고 상담 구조화를 진행함. 초등학교 때부터 친구 사귀기가 어려웠다고 보고.',
     0, 50, '전문상담교사', '면담', 1, null],
    [0, '일반상담', '일반', '상담', '개인상담', '대인관계', 1, date(3,14), '10:00', 30, '1학년', '남',
     '또래관계 탐색', '가장 힘들었던 또래 경험을 구체적으로 탐색. 모둠활동 시 의견을 내면 무시당하는 느낌이 든다고 호소.',
     0, 50, '전문상담교사', '면담', 2, null],
    [0, '일반상담', '일반', '상담', '개인상담', '대인관계', 1, date(3,21), '10:00', 30, '1학년', '남',
     '자기표현 연습', '나-전달법을 활용한 자기표현 연습. 역할극을 통해 모둠활동 상황을 시뮬레이션함.',
     0, 50, '전문상담교사', '면담', 3, null],
    [0, '일반상담', '일반', '상담', '개인상담', '대인관계', 1, date(4,4), '10:00', 30, '1학년', '남',
     '변화 점검', '지난 2주간 모둠활동에서 한 번 의견을 냈다고 보고. 긍정적 변화에 대해 강화.',
     0, 50, '전문상담교사', '면담', 4, '다음 회기에 사회기술훈련 워크시트 준비'],
    [0, '일반상담', '일반', '상담', '개인상담', '대인관계', 1, date(4,11), null, null, '1학년', '남',
     '사회기술훈련', '갈등상황 대처 카드를 활용한 사회기술훈련 실시. 친구에게 먼저 말 걸기 과제 부여.',
     0, 50, '전문상담교사', '면담', 5, null],
    [0, '일반상담', '일반', '검사', '심리검사', '개인심리검사', 1, date(3,10), null, null, '1학년', '남',
     'MMPI-A 검사 실시', 'MMPI-A 실시. 검사 태도 양호, 약 40분 소요. 결과는 다음 회기에 해석 예정.',
     1, 0, '전문상담교사', '면담', null, '검사 결과지 파일 보관'],

    // ━━━ Case 1: 학업 (2-1-15) — 상담 3회 + 검사 1회 (종결) ━━━
    [1, '전문상담', '일반', '상담', '개인상담', '학업', 1, date(3,9), '14:00', 15, '2학년', '여',
     '초기 상담', '학업 스트레스 호소. 중간고사 후 성적이 30등 이상 하락, 학원을 3개 다니고 있으나 효과가 없다고 느낌.',
     0, 50, '전문상담교사', '면담', 1, null],
    [1, '전문상담', '일반', '상담', '개인상담', '학업', 1, date(3,16), '14:00', 15, '2학년', '여',
     '학습 전략 탐색', '현재 학습 방법을 점검하고 자기주도학습 전략 소개. 시간관리 매트릭스 작성.',
     1, 0, '전문상담교사', '면담', 2, null],
    [1, '전문상담', '일반', '상담', '개인상담', '학업', 1, date(3,23), null, null, '2학년', '여',
     '종결 상담', '학습 계획표 실천 여부 점검. 2주간 계획대로 학습한 결과 자신감 회복. 상담 목표 달성으로 종결 합의.',
     0, 50, '전문상담교사', '면담', 3, null],
    [1, '전문상담', '일반', '검사', '심리검사', '개인심리검사', 1, date(3,11), null, null, '2학년', '여',
     '학습유형검사', '홀랜드 직업흥미검사 겸 학습유형검사 실시. 탐구형(I)과 사회형(S) 높게 나옴.',
     0, 40, '전문상담교사', '면담', null, null],

    // ━━━ Case 2: 자해/자살 (1-2-5) — 상담 6회 + 자문 1회 + 의뢰 1회 ━━━
    [2, '전문상담', '일반', '상담', '개인상담', '자해 및 자살', 1, date(3,11), '09:00', 60, '1학년', '남',
     '위기 초기 상담', '담임 의뢰. 팔목에 자해 흔적(긁힘) 확인. 자살 사고 척도 실시 — 중등도 위험. 안전 계획 수립.',
     1, 0, '전문상담교사', '면담', 1, '보호자 긴급 연락 완료, 안전서약서 작성'],
    [2, '전문상담', '일반', '상담', '개인상담', '자해 및 자살', 1, date(3,13), '09:00', 60, '1학년', '남',
     '2회차 — 안전 점검', '주말 동안 자해 충동 1회 있었으나 안전 계획대로 대처했다고 보고. 감정일기 시작.',
     1, 0, '전문상담교사', '면담', 2, null],
    [2, '전문상담', '일반', '상담', '개인상담', '자해 및 자살', 1, date(3,18), null, null, '1학년', '남',
     '3회차 — 촉발 요인 탐색', '자해 충동의 촉발 요인 탐색. 부모 간 다툼 목격 후 충동이 강해진다고 보고.',
     0, 50, '전문상담교사', '면담', 3, null],
    [2, '전문상담', '일반', '상담', '개인상담', '자해 및 자살', 1, date(3,25), '09:00', 60, '1학년', '남',
     '4회차 — 대안행동 훈련', '자해 충동 시 대안 행동(얼음 쥐기, 고무줄 튕기기) 연습. 지난주 자해 0회.',
     0, 50, '전문상담교사', '면담', 4, null],
    [2, '전문상담', '일반', '상담', '개인상담', '자해 및 자살', 1, date(4,1), null, null, '1학년', '남',
     '5회차 — 감정 조절', '감정 온도계를 활용한 감정 인식 훈련. 분노와 슬픔을 구분하는 연습.',
     0, 50, '전문상담교사', '면담', 5, null],
    [2, '전문상담', '일반', '상담', '개인상담', '자해 및 자살', 1, date(4,8), '09:00', 60, '1학년', '남',
     '6회차 — 중간 점검', '최근 2주간 자해 충동 감소 추세. 감정일기 지속 중. 정신건강의학과 초진 예약 완료.',
     0, 50, '전문상담교사', '면담', 6, '병원 초진 4/15 예정'],
    [2, '전문상담', '일반', '자문', '교원자문', '정서발달', 1, date(3,15), null, null, '해당없음', '해당없음',
     '담임교사 자문', '담임교사에게 자해 학생 대응 가이드라인 안내. 수업 중 관찰 포인트와 위기 시 대응 절차 공유.',
     0, 30, '전문상담교사', '면담', null, null],
    [2, '전문상담', '일반', '의뢰', '교내외의뢰', '외부전문가에게 상담의뢰', 1, date(4,5), null, null, '해당없음', '해당없음',
     'Wee센터 의뢰', '지역 Wee센터에 심층 상담 의뢰서 발송. 정신건강의학과 연계 협조 요청.',
     0, 20, '전문상담교사', '면담', null, null],

    // ━━━ Case 3: 진로 (3-2-1, 졸업생) — 상담 3회 + 교육 1회 (종결) ━━━
    [3, '일반상담', '일반', '상담', '개인상담', '진로', 1, date(3,13), null, null, '3학년', '남',
     '진로 탐색 상담', '대학 진학 방향 미정. 이과/문과 선택에서 갈등. 관심 분야: 생명공학, 경영학.',
     0, 50, '전문상담교사', '면담', 1, null],
    [3, '일반상담', '일반', '상담', '개인상담', '진로', 1, date(3,20), null, null, '3학년', '남',
     '직업 카드 활동', '직업 카드 분류 활동 실시. 연구직과 기획직에 높은 관심. 커리어넷 검사 결과 연계.',
     0, 50, '전문상담교사', '면담', 2, null],
    [3, '일반상담', '일반', '상담', '개인상담', '진로', 1, date(3,27), null, null, '3학년', '남',
     '종결 상담', '생명공학과 진학 방향으로 결정. 학과 탐색 보고서 작성 완료. 졸업으로 Wee센터 연계.',
     0, 50, '전문상담교사', '면담', 3, null],
    [3, '일반상담', '일반', '교육', '프로그램운영', '진로발달', 1, date(3,18), null, null, '3학년', '남',
     '진로체험 프로그램', '3학년 진로체험의 날 프로그램 운영. 대학 학과 탐방 사전교육 실시.',
     1, 30, '전문상담교사', '면담', null, null],

    // ━━━ Case 4: 가족관계 (1-1-18) — 상담 4회 + 학부모상담 2회 + 연구 1회 ━━━
    [4, '전문상담', '일반', '상담', '개인상담', '가정 및 가족관계', 1, date(3,16), '11:00', 15, '1학년', '여',
     '초기 상담', '부모 이혼 소송 중. 아버지와 어머니 사이에서 눈치를 보는 상황. 최근 식욕 저하, 불면 호소.',
     0, 50, '전문상담교사', '면담', 1, null],
    [4, '전문상담', '일반', '상담', '개인상담', '가정 및 가족관계', 1, date(3,23), '11:00', 15, '1학년', '여',
     '감정 탐색', '부모 이혼에 대한 감정 작업. "내 잘못인 것 같다"는 자기비난 패턴 확인. 인지 재구조화 시작.',
     0, 50, '전문상담교사', '면담', 2, null],
    [4, '전문상담', '일반', '상담', '개인상담', '가정 및 가족관계', 1, date(4,6), null, null, '1학년', '여',
     '대처 자원 탐색', '학교에서 안전감을 느끼는 장소와 사람 탐색. 미술실 선생님과 친한 친구 2명이 지지자원.',
     0, 50, '전문상담교사', '면담', 3, null],
    [4, '전문상담', '일반', '상담', '개인상담', '가정 및 가족관계', 1, date(4,13), '11:00', 15, '1학년', '여',
     '중간 점검', '식욕과 수면 개선됨. 부모 상황을 "내 잘못이 아니다"로 재인식하기 시작.',
     0, 50, '전문상담교사', '전화상담', 4, null],
    [4, '전문상담', '일반', '상담', '학부모상담', '학생관련상담', 1, date(3,19), null, null, '해당없음', '해당없음',
     '모 상담', '어머니와 전화 상담. 가정 내 상황 파악 및 자녀 양육 협조 요청. 이혼 과정에서 자녀 앞 다툼 자제 당부.',
     0, 30, '전문상담교사', '전화상담', null, null],
    [4, '전문상담', '일반', '상담', '학부모상담', '학생관련상담', 1, date(4,9), null, null, '해당없음', '해당없음',
     '부 상담', '아버지와 면담. 양육권 관련 자녀 의견 존중 필요성 안내. 정서적 안정을 위한 일관된 태도 요청.',
     0, 40, '전문상담교사', '면담', null, null],
    [4, '전문상담', '일반', '연구', '자기계발', '상담연수참석', 1, date(3,22), null, null, '해당없음', '해당없음',
     '이혼가정 자녀상담 연수', '한국상담학회 주관 "이혼가정 아동·청소년 상담" 온라인 연수 참석 (3시간).',
     3, 0, '전문상담교사', '사이버상담', null, null],

    // ━━━ Case 5: 집단상담 (2-1 다수) — 집단상담 3회 + 교육 1회 ━━━
    [5, '일반상담', '일반', '상담', '집단상담', '성격/대인관계', 5, date(3,19), '15:00', 30, '2학년', '혼성',
     '집단상담 1회 — 오리엔테이션', '프로그램 소개 및 집단 규칙 설정. 자기소개 활동. 별칭 정하기.',
     1, 30, '전문상담교사', '면담', 1, null],
    [5, '일반상담', '일반', '상담', '집단상담', '성격/대인관계', 5, date(3,26), '15:00', 30, '2학년', '혼성',
     '집단상담 2회 — 나를 알아가기', '강점 카드 활동. 서로의 강점 찾아주기. 집단 응집력 형성 활동.',
     1, 30, '전문상담교사', '면담', 2, null],
    [5, '일반상담', '일반', '상담', '집단상담', '성격/대인관계', 5, date(4,2), '15:00', 30, '2학년', '혼성',
     '집단상담 3회 — 갈등 해결', '갈등 상황 역할극. 비폭력대화(NVC) 4단계 연습. 실생활 적용 과제 부여.',
     1, 30, '전문상담교사', '면담', 3, null],
    [5, '일반상담', '일반', '교육', '프로그램운영', '사회성발달', 5, date(4,9), null, null, '2학년', '혼성',
     '학급 사회성 프로그램', '2학년 1반 대상 학급 사회성 향상 프로그램 1회기 운영.',
     1, 0, '전문상담교사', '면담', null, null],

    // ━━━ Case 6: 정신건강 (2-2-11) — 상담 3회 + 검사 1회 + 자문 1회 ━━━
    [6, '전문상담', 'Wee센터', '상담', '개인상담', '정신건강', 1, date(3,22), '13:00', 15, '2학년', '여',
     '초기 상담', '우울감 호소. PHQ-9 점수 14점(중등도 우울). 무기력감, 흥미 상실, 수면 과다.',
     0, 50, '전문상담교사', '면담', 1, null],
    [6, '전문상담', 'Wee센터', '상담', '개인상담', '정신건강', 1, date(3,29), '13:00', 15, '2학년', '여',
     '감정 일기 점검', '감정 일기 작성 결과 검토. 하교 후 방에 혼자 있을 때 우울감 심화. 활동 스케줄링 시작.',
     0, 50, '전문상담교사', '면담', 2, null],
    [6, '전문상담', 'Wee센터', '상담', '개인상담', '정신건강', 1, date(4,12), null, null, '2학년', '여',
     '3회차 상담', '활동 스케줄링 실천 점검. 동아리 활동 참여 시작. PHQ-9 재검사 11점으로 소폭 개선.',
     0, 50, '전문상담교사', '사이버상담', 3, '화상 상담으로 진행 (학생 요청)'],
    [6, '전문상담', 'Wee센터', '검사', '심리검사', '개인심리검사', 1, date(3,24), null, null, '2학년', '여',
     'SCT 문장완성검사', '문장완성검사 실시. 가족관계, 자아개념, 대인관계 영역 탐색.',
     0, 50, '전문상담교사', '면담', null, null],
    [6, '전문상담', 'Wee센터', '자문', '교원자문', '사회성발달', 1, date(4,3), null, null, '해당없음', '해당없음',
     '담임 자문', '우울 학생 학급 내 관찰 포인트 안내. 또래지지 체계 구축 방안 논의.',
     0, 30, '전문상담교사', '면담', null, null],

    // ━━━ Case 7: 학교폭력 피해 (1-2-14) — 상담 4회 + 의뢰 1회 + 자문 1회 ━━━
    [7, '전문상담', '일반', '상담', '개인상담', '학교폭력 피해', 1, date(3,25), '10:30', 30, '1학년', '여',
     '피해 사실 확인 상담', '또래 신고로 상담 시작. 같은 반 3명에게 지속적 언어폭력(험담, 무시) 당하고 있음 확인.',
     1, 0, '전문상담교사', '면담', 1, '학교폭력 사안 보고서 작성 필요'],
    [7, '전문상담', '일반', '상담', '개인상담', '학교폭력 피해', 1, date(4,1), null, null, '1학년', '여',
     '심리적 안정 지원', '피해 경험으로 인한 불안, 등교 거부감 탐색. 안전한 공간(상담실, 도서관) 안내.',
     0, 50, '전문상담교사', '면담', 2, null],
    [7, '전문상담', '일반', '상담', '개인상담', '학교폭력 피해', 1, date(4,8), '10:30', 30, '1학년', '여',
     '3회차 상담', '학폭위 결과 통보 후 심리 지원. 가해학생 접근금지 조치 시행 중. 불안 수준 감소.',
     0, 50, '전문상담교사', '면담', 3, null],
    [7, '전문상담', '일반', '상담', '개인상담', '학교폭력 피해', 1, date(4,15), null, null, '1학년', '여',
     '4회차 — 회복 지원', '교우관계 재형성 의지 표현. 새로운 친구 만들기에 대한 불안 탐색. 점진적 노출 계획.',
     0, 50, '전문상담교사', '전화상담', 4, null],
    [7, '전문상담', '일반', '의뢰', '교내외의뢰', '교내 교사에게 상담의뢰', 1, date(3,26), null, null, '해당없음', '해당없음',
     '생활지도부 의뢰', '학교폭력 사안 접수를 위해 생활지도부에 공식 의뢰. 사안 보고서 첨부.',
     0, 15, '전문상담교사', '면담', null, null],
    [7, '전문상담', '일반', '자문', '교원자문', '정서발달', 1, date(4,7), null, null, '해당없음', '해당없음',
     '담임 자문 — 학폭 피해학생 지원', '피해학생 학급 내 보호 방안 논의. 자리 배치 조정, 모둠 편성 시 배려 요청.',
     0, 20, '전문상담교사', '면담', null, null],

    // ━━━ Case 8: 성격/분노조절 (2-2-3, 2-2-14 다중) — 상담 3회 + 교육 1회 + 연구 1회 ━━━
    [8, '순회상담', '일반', '상담', '개인상담', '성격', 2, date(3,28), null, null, '2학년', '혼성',
     '초기 상담 — 사건 경위 파악', '체육 수업 중 몸싸움 사건 후 의뢰. 두 학생 개별 면담 후 합동 상담 진행.',
     1, 0, '전문상담순회교사', '면담', 1, null],
    [8, '순회상담', '일반', '상담', '개인상담', '성격', 2, date(4,4), null, null, '2학년', '혼성',
     '분노 조절 훈련', '분노 신호 인식 훈련. 신체 반응(심장 빨라짐, 주먹 쥠)을 알아차리고 멈추기 연습.',
     0, 50, '전문상담순회교사', '면담', 2, null],
    [8, '순회상담', '일반', '상담', '개인상담', '성격', 2, date(4,11), null, null, '2학년', '혼성',
     '관계 회복 대화', '두 학생 간 관계 회복 대화 진행. 서로의 입장을 듣고 이해하는 시간.',
     0, 50, '전문상담순회교사', '면담', 3, '회복적 생활교육 기법 적용'],
    [8, '순회상담', '일반', '교육', '연수', '교직원 상담연수', 1, date(4,14), null, null, '해당없음', '해당없음',
     '교사 대상 분노조절 연수', '교직원 대상 "학생 분노 행동 이해와 대응" 연수 (2시간). 교사 15명 참석.',
     2, 0, '전문상담순회교사', '면담', null, null],
    [8, '순회상담', '일반', '연구', '직무계발', '상담프로그램개발', 1, date(4,18), null, null, '해당없음', '해당없음',
     '분노조절 프로그램 개발', '순회상담 대상교 분노조절 집단 프로그램 매뉴얼 초안 작성.',
     2, 0, '전문상담순회교사', '면담', null, null],

    // ━━━ Case 9: 스마트폰 과사용 (3-1-9) — 상담 2회 + 검사 1회 (종결) ━━━
    [9, '일반상담', '일반', '상담', '개인상담', '컴퓨터 및 스마트폰 과사용', 1, date(4,3), null, null, '3학년', '남',
     '초기 상담', '하루 6시간 이상 게임. 새벽 2~3시까지 게임 후 등교 시 졸음. 담임 의뢰.',
     0, 50, '전문상담교사', '면담', 1, null],
    [9, '일반상담', '일반', '상담', '개인상담', '컴퓨터 및 스마트폰 과사용', 1, date(4,10), null, null, '3학년', '남',
     '2회차 — 상담 거부', '학생이 "상담 필요 없다"며 조기 종결 요청. 상담 동기 탐색 시도했으나 거부.',
     0, 20, '전문상담교사', '면담', 2, '담임에게 모니터링 요청'],
    [9, '일반상담', '일반', '검사', '심리검사', '집단심리검사', 30, date(4,7), null, null, '3학년', '혼성',
     '3학년 1반 인터넷중독 선별검사', '3학년 1반 전체 인터넷/스마트폰 사용 습관 선별검사 실시. 위험군 3명 선별.',
     1, 0, '전문상담교사', '면담', null, null],

    // ━━━ 추가: 교육/연구/의뢰 보강 (기존 케이스에 추가) ━━━
    [0, '일반상담', '일반', '교육', '프로그램운영', '인성발달', 25, date(4,16), null, null, '1학년', '혼성',
     '1학년 인성교육 프로그램', '1학년 전체 대상 인성교육 프로그램 "나와 너, 우리" 1회기 운영.',
     1, 30, '전문상담교사', '면담', null, null],
    [3, '일반상담', '일반', '연구', '자기계발', '외부강연', 1, date(4,17), null, null, '해당없음', '해당없음',
     '진로교육 외부강연', '○○대학교 입학처 초청 강연 "2027 대입 전형 분석" 운영 지원.',
     2, 0, '전문상담교사', '면담', null, null],
    [5, '일반상담', '일반', '교육', '연수', '학부모 상담연수', 20, date(4,19), null, null, '해당없음', '해당없음',
     '학부모 소통역량 강화 연수', '학부모 대상 "사춘기 자녀와의 대화법" 연수. 학부모 20명 참석.',
     2, 0, '전문상담교사', '면담', null, null],
    [7, '전문상담', '일반', '의뢰', '교내외의뢰', '기타', 1, date(4,20), null, null, '해당없음', '해당없음',
     '경찰 신고 연계', '학교폭력 피해 사안 심화로 관할 경찰서 학교폭력 전담팀 연계.',
     0, 15, '전문상담교사', '면담', null, null],
  ];

  let sessionCount = 0;
  for (const s of sessions) {
    const [ci, ...rest] = s;
    const caseId = caseIds[ci];
    // rest: [counselingClass, weeClass, catL, catM, catD, headcount, date, ...]
    // INSERT 순서에 academic_year 삽입 (headcount 다음, session_date 앞)
    const params = [...rest.slice(0, 6), year, ...rest.slice(6)];
    const r = insertSession.run(caseId, ...params);
    const sessionId = Number(r.lastInsertRowid);
    sessionCount++;

    // session_students 연결
    const cStudents = caseDefs[ci].students;
    for (const sid of cStudents) {
      insertSessionStudent.run(sessionId, sid);
    }
  }
  console.log(`✅ 세션 ${sessionCount}건 삽입 (session_students 포함)`);

  // ── 4. 사례 개념화 2건 ──────────────────────────────────────────────────
  const insertConcept = db.prepare(
    'INSERT INTO case_conceptualizations (case_id, template_type, sections) VALUES (?, ?, ?)',
  );

  // Case 0 (대인관계) 개념화
  insertConcept.run(caseIds[0], 'wee_standard', JSON.stringify({
    presenting_problem: '또래관계에서 반복적 갈등, 모둠활동 기피, 자기표현 어려움',
    background: '초등학교 때부터 소극적 성격. 형제 없이 부모와 단둘이 생활. 부모가 과보호적.',
    hypothesis: '자기표현 기술 부족 + 거절에 대한 두려움 → 관계 회피 → 고립 심화의 악순환',
    goals: '1. 자기표현 기술 향상\n2. 또래관계 기술 습득\n3. 모둠활동 참여 증가',
    plan: '사회기술훈련(SST) 중심 개인상담 주 1회, 필요 시 집단상담 연계',
  }));

  // Case 2 (자해/자살) 개념화
  insertConcept.run(caseIds[2], 'wee_standard', JSON.stringify({
    presenting_problem: '자해 행동(팔목 긁힘), 자살 사고 중등도, 결석 증가',
    background: '부모 간 잦은 다툼, 가정 내 정서적 지지 부족. 중학교 때 따돌림 경험.',
    hypothesis: '가정 내 갈등 → 무력감/통제 상실감 → 자해를 통한 감정 조절 시도',
    goals: '1. 자해 중단 및 안전 확보\n2. 건강한 감정 조절 전략 습득\n3. 외부 전문 치료 연계',
    plan: '위기개입 중심 주 2회 상담, 안전 계획 매 회기 점검, 정신건강의학과 연계, Wee센터 의뢰',
  }));

  console.log('✅ 사례 개념화 2건 삽입');

  // ── 5. 설정값 업데이트 ──────────────────────────────────────────────────
  const upsert = db.prepare(
    "INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now','localtime'))",
  );
  upsert.run('school_name', '세움고등학교');
  upsert.run('counselor_name', '김용천');
  upsert.run('counselor_affiliation', '전문상담교사');
  upsert.run('wee_class', '일반');
  upsert.run('school_type', '고등학교');
  console.log('✅ 기본 설정 업데이트');
});

try {
  seed();
  console.log('\n🎉 시드 완료!');
  console.log('   학생 120명 | 사례 10건 | 세션 60+건 | 개념화 2건');
  console.log('   앱을 실행하고 로그인하면 데이터를 확인할 수 있습니다.');
} catch (err) {
  console.error('❌ 오류:', err.message);
  console.error(err.stack);
} finally {
  db.close();
}
