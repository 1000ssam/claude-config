import type Database from 'better-sqlite3';
import { DEFAULT_CONSENT_SCHEMA, DEFAULT_CONSENT_TEMPLATE_NAME } from './constants/consent-templates';

/**
 * 컬럼이 없으면 ALTER TABLE ADD COLUMN으로 추가. SQLite는 IF NOT EXISTS를
 * ADD COLUMN에 지원하지 않으므로 PRAGMA table_info로 직접 확인한다.
 * 멱등 — 이미 존재하면 no-op.
 */
function ensureColumn(
  db: Database.Database,
  table: string,
  column: string,
  definition: string,
): void {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all() as { name: string }[];
  if (cols.some((c) => c.name === column)) return;
  db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
}

export function initializeDatabase(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      gender TEXT,
      birth_date TEXT,
      contact TEXT,
      guardian_name TEXT,
      guardian_relation TEXT,
      guardian_contact TEXT,
      status TEXT NOT NULL DEFAULT '재학' CHECK(status IN ('재학', '졸업')),
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE INDEX IF NOT EXISTS idx_students_name ON students(name);

    CREATE TABLE IF NOT EXISTS student_enrollments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      academic_year TEXT NOT NULL,
      grade TEXT,
      class_name TEXT,
      number TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      UNIQUE(student_id, academic_year)
    );

    CREATE INDEX IF NOT EXISTS idx_enrollments_student ON student_enrollments(student_id);
    CREATE INDEX IF NOT EXISTS idx_enrollments_year ON student_enrollments(academic_year);
    CREATE INDEX IF NOT EXISTS idx_enrollments_lookup ON student_enrollments(academic_year, grade, class_name, number);

    CREATE TABLE IF NOT EXISTS cases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      case_number TEXT NOT NULL UNIQUE,
      academic_year TEXT NOT NULL,
      referrer_name TEXT,
      referrer_role TEXT CHECK(referrer_role IN ('담임교사', '교과교사', '학부모', '자발적', '또래', '기타')),
      referrer_contact TEXT,
      main_complaint TEXT,
      status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'closed')),
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE INDEX IF NOT EXISTS idx_cases_academic_year ON cases(academic_year);
    CREATE INDEX IF NOT EXISTS idx_cases_status ON cases(status);
    CREATE INDEX IF NOT EXISTS idx_cases_case_number ON cases(case_number);

    CREATE TABLE IF NOT EXISTS case_students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      UNIQUE(case_id, student_id)
    );

    CREATE INDEX IF NOT EXISTS idx_case_students_case ON case_students(case_id);
    CREATE INDEX IF NOT EXISTS idx_case_students_student ON case_students(student_id);

    -- [의도적 비정규화] grade, gender, headcount, counselor_affil은 각각
    -- session_students / settings에서 참조 가능하지만, NEIS 엑셀 내보내기 포맷 호환을 위해
    -- 세션별로 저장한다. grade/gender/headcount는 computeDemographics()가 자동 계산,
    -- counselor_affil은 settings.counselor_affiliation에서 프리필 후 사용자가 세션별 변경 가능.
    -- 직접 편집하지 말 것.
    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
      counseling_class TEXT NOT NULL CHECK(counseling_class IN ('일반상담', '전문상담', '순회상담')),
      wee_class TEXT NOT NULL CHECK(wee_class IN ('일반', 'Wee센터')),
      category_large TEXT NOT NULL,
      category_medium TEXT NOT NULL,
      category_detail TEXT NOT NULL,
      headcount INTEGER NOT NULL DEFAULT 1,        -- 자동계산: session_students 수
      academic_year TEXT NOT NULL,
      session_date TEXT NOT NULL,
      appointment_time TEXT,                       -- 예약 시각(HH:mm, optional)
      reminder_minutes INTEGER,                    -- 예약 알림 분단위(optional)
      grade TEXT NOT NULL DEFAULT '해당없음',        -- 자동계산: 전원 동일 학년 or '혼합'
      gender TEXT NOT NULL DEFAULT '해당없음' CHECK(gender IN ('해당없음', '남', '여', '혼성')),
      session_title TEXT NOT NULL,
      session_content TEXT NOT NULL,
      session_hour INTEGER NOT NULL DEFAULT 0,
      session_minute INTEGER NOT NULL DEFAULT 0,
      counselor_affil TEXT NOT NULL CHECK(counselor_affil IN ('전문상담교사', '전문상담순회교사', 'Wee카운슬러', '학생상담자원봉사자', '교사', '전문상담사', '임상심리사', '사회복지사', '교육복지사', '그외')),
      medium TEXT NOT NULL DEFAULT '면담' CHECK(medium IN ('면담', '전화상담', '사이버상담')),
      session_number INTEGER,
      internal_notes TEXT,
      summary_short TEXT,                          -- AI 자동 회기 요약(암호화). 80자 한 줄.
      summary_status TEXT NOT NULL DEFAULT 'pending' CHECK(summary_status IN ('pending', 'done', 'failed')),
      summary_generated_at TEXT,                   -- 요약 생성 완료 시각
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE INDEX IF NOT EXISTS idx_sessions_case_id ON sessions(case_id);
    CREATE INDEX IF NOT EXISTS idx_sessions_date ON sessions(session_date);
    CREATE INDEX IF NOT EXISTS idx_sessions_category ON sessions(category_large, category_medium, category_detail);
    CREATE INDEX IF NOT EXISTS idx_sessions_academic_year ON sessions(academic_year);

    CREATE TABLE IF NOT EXISTS session_students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      UNIQUE(session_id, student_id)
    );

    CREATE INDEX IF NOT EXISTS idx_session_students_session ON session_students(session_id);
    CREATE INDEX IF NOT EXISTS idx_session_students_student ON session_students(student_id);

    CREATE TABLE IF NOT EXISTS case_conceptualizations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      case_id INTEGER NOT NULL UNIQUE REFERENCES cases(id) ON DELETE CASCADE,
      template_type TEXT NOT NULL DEFAULT 'wee_standard',
      sections TEXT NOT NULL DEFAULT '{}',
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE INDEX IF NOT EXISTS idx_concept_case_id ON case_conceptualizations(case_id);

    CREATE TABLE IF NOT EXISTS crypto_meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);

  // Create triggers only if they don't exist
  const triggers = db.prepare(
    "SELECT name FROM sqlite_master WHERE type='trigger' AND name='cases_updated_at'"
  ).get();

  if (!triggers) {
    db.exec(`
      CREATE TRIGGER cases_updated_at
        AFTER UPDATE ON cases
        BEGIN
          UPDATE cases SET updated_at = datetime('now', 'localtime') WHERE id = NEW.id;
        END;

      CREATE TRIGGER sessions_updated_at
        AFTER UPDATE ON sessions
        BEGIN
          UPDATE sessions SET updated_at = datetime('now', 'localtime') WHERE id = NEW.id;
        END;

      CREATE TRIGGER students_updated_at
        AFTER UPDATE ON students
        BEGIN
          UPDATE students SET updated_at = datetime('now', 'localtime') WHERE id = NEW.id;
        END;

      CREATE TRIGGER student_enrollments_updated_at
        AFTER UPDATE ON student_enrollments
        BEGIN
          UPDATE student_enrollments SET updated_at = datetime('now', 'localtime') WHERE id = NEW.id;
        END;

      CREATE TRIGGER case_conceptualizations_updated_at
        AFTER UPDATE ON case_conceptualizations
        BEGIN
          UPDATE case_conceptualizations SET updated_at = datetime('now', 'localtime') WHERE id = NEW.id;
        END;
    `);
  }

  // Insert default settings
  const insertSetting = db.prepare(
    'INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)'
  );

  const defaultSettings: [string, string][] = [
    ['school_name', ''],
    ['academic_year', new Date().getFullYear().toString()],
    ['counselor_name', ''],
    ['counselor_affiliation', '전문상담교사'],
    ['wee_class', '일반'],
    ['next_case_seq', '1'],
    ['default_counseling_class', ''],
    ['calendar_view_mode', 'month'],
    // STT (feat/stt)
    ['stt_enabled', '1'],
    ['stt_engine', 'whisper-cli'],
    ['stt_model', 'ggml-small-q5_1'],
    ['stt_language', 'ko'],
    // AI 도우미 — 기본 활성. 사용자가 모델을 다운로드/로드해야 실제 기능이 동작하므로
    // 설정 토글 없이 '1'로 시작해도 비활성 사용자에게는 아무 비용이 없음.
    ['ai_enabled', '1'],
    ['ai_backend', 'local'],
  ];

  const insertMany = db.transaction((settings: [string, string][]) => {
    for (const [key, value] of settings) {
      insertSetting.run(key, value);
    }
  });

  insertMany(defaultSettings);

  // 공휴일 캐시 테이블 (민감 정보 없음, 공공 API 응답 저장용)
  db.exec(`
    CREATE TABLE IF NOT EXISTS public_holiday_cache (
      year INTEGER PRIMARY KEY,
      data TEXT NOT NULL,
      fetched_at TEXT NOT NULL
    );
  `);

  // 공지사항 캐시 테이블
  db.exec(`
    CREATE TABLE IF NOT EXISTS notice_cache (
      key  TEXT PRIMARY KEY,
      data TEXT NOT NULL,
      fetched_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS notice_read (
      notice_id TEXT PRIMARY KEY,
      read_at   TEXT NOT NULL
    );
  `);

  // 학사일정 캐시 테이블
  db.exec(`
    CREATE TABLE IF NOT EXISTS school_schedule_cache (
      schul_code TEXT NOT NULL,
      year       INTEGER NOT NULL,
      data       TEXT NOT NULL,
      fetched_at TEXT NOT NULL,
      PRIMARY KEY (schul_code, year)
    );
  `);

  // ── 보호자 동의서/접수양식 (E2E 영지식) ──────────────────────────────────────
  // 폼 스키마(질문)는 평문, 응답만 sealed-box 암호문으로 다룬다.
  db.exec(`
    CREATE TABLE IF NOT EXISTS consent_form_templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      schema TEXT NOT NULL,                 -- JSON ConsentFormSchema (평문 — PII 없음)
      is_default INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE TABLE IF NOT EXISTS consent_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
      student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
      template_name TEXT NOT NULL,          -- 발송 시점 템플릿명(이력 보존)
      token TEXT NOT NULL UNIQUE,           -- 1회용 접속 토큰
      public_key TEXT NOT NULL,             -- sealed-box 공개키(base64, 평문)
      form_schema TEXT,                     -- 발송 시점 폼 스키마 스냅샷(평문 질문, 라벨 보존)
      private_key TEXT NOT NULL,            -- 개인키(base64) — field-crypto로 암호화 저장
      status TEXT NOT NULL DEFAULT 'pending'
        CHECK(status IN ('pending', 'sent', 'responded', 'ingested', 'expired', 'failed')),
      channel TEXT NOT NULL DEFAULT 'link' CHECK(channel IN ('sms', 'link')),
      link TEXT,
      last_error TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      sent_at TEXT,
      responded_at TEXT,
      expires_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_consent_req_case ON consent_requests(case_id);
    CREATE INDEX IF NOT EXISTS idx_consent_req_student ON consent_requests(student_id);
    CREATE INDEX IF NOT EXISTS idx_consent_req_token ON consent_requests(token);
    CREATE INDEX IF NOT EXISTS idx_consent_req_status ON consent_requests(status);

    CREATE TABLE IF NOT EXISTS consent_responses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      request_id INTEGER NOT NULL UNIQUE REFERENCES consent_requests(id) ON DELETE CASCADE,
      answers TEXT NOT NULL,                -- 복호된 응답 JSON — field-crypto로 암호화 저장
      submitted_at TEXT NOT NULL,           -- 보호자 제출 시각(서버 기록)
      ingested_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    -- 감사 로그(Phase 6): 발송/수합/파기 이벤트의 비-PII 메타데이터만 기록.
    -- request_id에 FK를 두지 않는다 — 사례/요청이 삭제돼도 추적 이력은 보존(forensic).
    CREATE TABLE IF NOT EXISTS consent_audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event TEXT NOT NULL,                  -- CONSENT_AUDIT_EVENTS 중 하나(비-PII)
      request_id INTEGER,                   -- 연관 요청(없을 수 있음); FK 미설정(이력 보존)
      detail TEXT,                          -- 비-PII 메타(JSON) — buildAuditEvent가 PII 제거
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );

    CREATE INDEX IF NOT EXISTS idx_consent_audit_request ON consent_audit_log(request_id);
    CREATE INDEX IF NOT EXISTS idx_consent_audit_created ON consent_audit_log(created_at);
  `);

  // consent_form_templates updated_at 트리거
  const consentTrigger = db.prepare(
    "SELECT name FROM sqlite_master WHERE type='trigger' AND name='consent_form_templates_updated_at'"
  ).get();
  if (!consentTrigger) {
    db.exec(`
      CREATE TRIGGER consent_form_templates_updated_at
        AFTER UPDATE ON consent_form_templates
        BEGIN
          UPDATE consent_form_templates SET updated_at = datetime('now', 'localtime') WHERE id = NEW.id;
        END;
    `);
  }

  // 기본 동의서 템플릿 시드 — 기본 템플릿이 하나도 없을 때만.
  const hasDefault = db.prepare(
    'SELECT 1 FROM consent_form_templates WHERE is_default = 1 LIMIT 1'
  ).get();
  if (!hasDefault) {
    db.prepare(
      'INSERT INTO consent_form_templates (name, schema, is_default) VALUES (?, ?, 1)'
    ).run(DEFAULT_CONSENT_TEMPLATE_NAME, JSON.stringify(DEFAULT_CONSENT_SCHEMA));
  }

  // ── 멱등 마이그레이션 ───────────────────────────────────────────────────────
  // CREATE TABLE IF NOT EXISTS는 컬럼 변경을 감지하지 못한다. 신규 환경은 위 DDL이,
  // 기존 환경은 아래 ensureColumn이 컬럼을 채운다.
  ensureColumn(db, 'sessions', 'appointment_time', 'TEXT');
  ensureColumn(db, 'sessions', 'reminder_minutes', 'INTEGER');
  // Phase 4 — 회기 자동 요약 컬럼.
  ensureColumn(db, 'sessions', 'summary_short', 'TEXT');
  ensureColumn(
    db,
    'sessions',
    'summary_status',
    "TEXT NOT NULL DEFAULT 'pending' CHECK(summary_status IN ('pending', 'done', 'failed'))",
  );
  ensureColumn(db, 'sessions', 'summary_generated_at', 'TEXT');
  // 동의서 폼 스키마 스냅샷(응답 라벨 보존).
  ensureColumn(db, 'consent_requests', 'form_schema', 'TEXT');
}
