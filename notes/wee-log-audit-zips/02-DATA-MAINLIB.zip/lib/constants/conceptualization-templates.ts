/**
 * 사례개념화 양식 정의.
 *
 * **위치 이유**: 메인 프로세스(`lib/ai/context-sources.ts`)에서 LLM에 양식 섹션 구조를
 * 알려주기 위해 import 한다. 렌더러 측은 `src/lib/constants/conceptualization-templates.ts`
 * 의 re-export shim을 통해 그대로 사용한다 (기존 `@/lib/constants/...` import 호환).
 *
 * 데이터·타입을 한 파일에 인라인 — `src/types/conceptualization.ts`의 DB 타입과 분리해
 * lib/src 경계를 깨끗하게 유지.
 */

/** 템플릿 한 섹션의 정의 (코드 상수) */
export interface TemplateSectionDef {
  key: string;
  label: string;
  placeholder: string;
}

export interface ConceptualizationTemplate {
  type: string;
  label: string;
  description: string;
  sections: TemplateSectionDef[];
}

export const CONCEPTUALIZATION_TEMPLATES: ConceptualizationTemplate[] = [
  {
    type: 'wee_standard',
    label: 'Wee 표준',
    description: '교육부 Wee 프로젝트 표준 사례관리 양식 (생태체계 + 위기개입)',
    sections: [
      { key: 'family_info', label: '가족 관계 및 환경', placeholder: '가족 구성, 양육환경, 경제 수준, 가족 내 특이사항' },
      { key: 'developmental_history', label: '발달력 및 병력', placeholder: '발달 과정상 특이사항, 과거 상담/치료 이력, 의료적 진단 유무' },
      { key: 'psychological_assessment', label: '심리검사 결과', placeholder: '표준화 검사(MMPI-A, K-CBCL, HTP, SCT 등) 실시 결과 요약' },
      { key: 'behavioral_observation', label: '행동 관찰', placeholder: '상담 중 관찰된 태도, 정서 상태, 비언어적 단서' },
      { key: 'risk_level', label: '위기 수준 평가', placeholder: '자살·자해 위험도, 학대·방임 여부, 위기 단계(관심군/주의군/위기군/고위기군)' },
      { key: 'problem_analysis', label: '문제 분석', placeholder: '촉발 요인, 유지 요인, 보호 요인을 생태체계적으로 분석 (개인·가정·학교·지역사회)' },
      { key: 'strengths_resources', label: '강점 및 자원', placeholder: '내담자 개인 강점, 지지체계, 활용 가능한 자원' },
      { key: 'goal', label: '상담 목표', placeholder: '장기 목표 + 단기 목표 (구체적·측정 가능한 형태)' },
      { key: 'intervention_plan', label: '개입 계획', placeholder: '상담 전략, 예상 회기 수, 연계 기관(정신건강센터, 청소년상담복지센터 등)' },
      { key: 'outcome_evaluation', label: '종결 및 평가', placeholder: '목표 달성도, 사후 관리 계획, 추수 상담 일정' },
    ],
  },
  {
    type: 'cbt',
    label: 'CBT (인지행동)',
    description: 'Beck 인지행동치료 사례 개념화 모델',
    sections: [
      { key: 'presenting_problem', label: '주 호소 문제', placeholder: '내담자가 보고하는 현재 어려움 (구체적 상황·빈도·강도)' },
      { key: 'early_experience', label: '초기 경험 및 성장 배경', placeholder: '핵심 신념 형성에 기여한 어린 시절 경험' },
      { key: 'core_belief', label: '핵심 신념', placeholder: '자기·타인·세상에 대한 근본적 믿음 (예: "나는 무능하다")' },
      { key: 'intermediate_belief', label: '중간 신념', placeholder: '핵심 신념에서 파생된 규칙·태도·가정 (예: "실수하면 끝이다")' },
      { key: 'automatic_thought', label: '자동적 사고', placeholder: '특정 상황에서 즉각적으로 떠오르는 부정적 사고' },
      { key: 'cognitive_distortion', label: '인지 왜곡 유형', placeholder: '흑백논리, 과잉일반화, 파국화, 독심술 등 왜곡 패턴 식별' },
      { key: 'triggering_situation', label: '촉발 상황', placeholder: '문제 행동/정서를 유발하는 구체적 상황' },
      { key: 'emotion', label: '정서 반응', placeholder: '촉발 상황에 대한 감정 (종류 + 강도 0-100%)' },
      { key: 'behavior', label: '행동 반응', placeholder: '회피, 공격, 철수 등 대처 행동' },
      { key: 'physiological_response', label: '신체 반응', placeholder: '두통, 복통, 수면 장애, 식욕 변화 등' },
      { key: 'coping_strategy', label: '기존 대처 전략', placeholder: '현재까지 사용해온 적응적/부적응적 대처 방식' },
      { key: 'working_hypothesis', label: '작업 가설', placeholder: '초기 경험 → 핵심 신념 → 중간 신념 → 자동적 사고 → 반응의 흐름도' },
      { key: 'treatment_goal', label: '치료 목표', placeholder: '인지 재구조화 목표, 행동 변화 목표' },
      { key: 'intervention_plan', label: '개입 전략', placeholder: '인지 재구조화, 행동 실험, 노출, 이완 훈련 등 CBT 기법' },
    ],
  },
  {
    type: 'sfbt',
    label: 'SFBT (해결중심)',
    description: '해결중심단기치료 사례 개념화 모델',
    sections: [
      { key: 'visitor_type', label: '내담자 유형 분류', placeholder: '고객형(Customer) / 불평형(Complainant) / 방문형(Visitor)' },
      { key: 'presenting_concern', label: '주 호소', placeholder: '내담자의 언어로 기술한 현재 어려움' },
      { key: 'exception', label: '예외 상황', placeholder: '문제가 일어나지 않았거나 덜했던 때 (언제, 어떤 상황, 무엇이 달랐는지)' },
      { key: 'miracle_question_response', label: '기적 질문 응답', placeholder: '"기적이 일어나 문제가 해결된다면 어떻게 알 수 있을까?"에 대한 응답' },
      { key: 'scaling_current', label: '척도 질문 (현재)', placeholder: '문제 심각도 또는 목표 달성도를 0-10 척도로 자기 평가' },
      { key: 'scaling_goal', label: '척도 질문 (목표)', placeholder: '만족스러운 수준의 척도 점수 (보통 +1~2점 향상)' },
      { key: 'strengths_resources', label: '강점 및 자원', placeholder: '내담자 강점, 과거 성공 경험, 지지 체계, 대처 자원' },
      { key: 'previous_solutions', label: '과거 해결 경험', placeholder: '이전에 비슷한 문제를 해결했던 방법 (성공/부분 성공 포함)' },
      { key: 'coping_question_response', label: '대처 질문 응답', placeholder: '"이렇게 힘든데 어떻게 여기까지 올 수 있었나?" — 이미 하고 있는 대처' },
      { key: 'relationship_question', label: '관계성 질문 응답', placeholder: '"부모님/선생님/친구는 당신이 어떻게 달라졌다고 말할까?"' },
      { key: 'small_step_goal', label: '작은 변화 목표', placeholder: '다음 회기까지 실행 가능한 구체적·작은 행동 목표' },
      { key: 'session_feedback', label: '회기 피드백', placeholder: '칭찬(이미 잘 하고 있는 것) + 브릿지(연결 메시지) + 과제' },
    ],
  },
];

export function getTemplateByType(type: string): ConceptualizationTemplate | undefined {
  return CONCEPTUALIZATION_TEMPLATES.find((t) => t.type === type);
}

/**
 * 의미적으로 동등한 필드 그룹.
 * 템플릿 변경 시 같은 그룹의 필드 값을 자동으로 이전한다.
 */
const FIELD_EQUIVALENCES: string[][] = [
  ['problem_analysis', 'presenting_problem', 'presenting_concern'],
  ['goal', 'treatment_goal'],
  ['behavioral_observation', 'behavior'],
  // strengths_resources, intervention_plan 은 key가 동일하므로 매핑 불필요
];

/** targetKey에 대응하는 값을 sourceData에서 찾아 반환 */
export function findEquivalentValue(
  targetKey: string,
  sourceData: Record<string, string>,
): string | undefined {
  const group = FIELD_EQUIVALENCES.find((g) => g.includes(targetKey));
  if (!group) return undefined;
  for (const key of group) {
    if (key !== targetKey && sourceData[key]?.trim()) {
      return sourceData[key];
    }
  }
  return undefined;
}
