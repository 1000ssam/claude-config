export const COUNSELING_CLASS_OPTIONS = ['일반상담', '전문상담', '순회상담'] as const;
export type CounselingClass = (typeof COUNSELING_CLASS_OPTIONS)[number];

export const WEE_CLASS_OPTIONS = ['일반', 'Wee센터'] as const;
export type WeeClass = (typeof WEE_CLASS_OPTIONS)[number];

export const GRADE_OPTIONS = [
  '해당없음', '1학년', '2학년', '3학년', '4학년', '5학년', '6학년', '혼합',
] as const;
export type Grade = (typeof GRADE_OPTIONS)[number];

export const GENDER_OPTIONS = ['해당없음', '남', '여', '혼성'] as const;
export type Gender = (typeof GENDER_OPTIONS)[number];

export const COUNSELOR_AFFILIATION_OPTIONS = [
  '전문상담교사', '전문상담순회교사', 'Wee카운슬러',
  '학생상담자원봉사자', '교사', '전문상담사', '임상심리사',
  '사회복지사', '교육복지사', '그외',
] as const;
export type CounselorAffiliation = (typeof COUNSELOR_AFFILIATION_OPTIONS)[number];

export const MEDIUM_OPTIONS = ['면담', '전화상담', '사이버상담'] as const;
export type Medium = (typeof MEDIUM_OPTIONS)[number];

export const CASE_STATUS_OPTIONS = ['active', 'closed'] as const;
export type CaseStatus = (typeof CASE_STATUS_OPTIONS)[number];

export const CASE_STATUS_LABELS: Record<CaseStatus, string> = {
  active: '진행중',
  closed: '종료',
};

export const CLOSE_REASON_OPTIONS = ['상담 목표 달성', '학적 변동', '기타'] as const;
export type CloseReason = (typeof CLOSE_REASON_OPTIONS)[number];

export const REFERRER_ROLE_OPTIONS = [
  '담임교사', '교과교사', '학부모', '자발적', '또래', '기타',
] as const;

export const GUARDIAN_RELATION_OPTIONS = ['부', '모', '조부', '조모', '기타'] as const;
