/**
 * 기본 동의서 템플릿 스키마.
 *
 * 데이터 주도(폼 빌더로 편집 가능)의 출발점. 코드가 아니라 스키마(JSON)이므로
 * 학교/기관 표준 양식으로 교체할 때 코드 수정이 불필요하다.
 *
 * 법적 요건: 개인정보 수집·이용 동의, 미성년자 법정대리인 동의 명시, 보관기간·목적 고지,
 * 전자서명 수집. (광고성 아님 → '(광고)' 표기 불요.)
 */

import type { ConsentFormSchema } from '@/types/consent';

export const DEFAULT_CONSENT_TEMPLATE_NAME = '상담 접수 및 개인정보 수집·이용 동의서';

export const DEFAULT_CONSENT_SCHEMA: ConsentFormSchema = {
  version: 1,
  title: '상담 접수 및 개인정보 수집·이용 동의서',
  intro:
    '본 동의서는 학생 상담 진행을 위해 보호자(법정대리인)의 동의를 받기 위한 것입니다. ' +
    '수집 항목은 보호자 성명·관계·연락처 및 본 동의 내역이며, 수집·이용 목적은 상담 접수 및 진행입니다. ' +
    '수집된 정보는 관련 법령에 따른 보관기간 동안 보관 후 파기하며, 상담 목적 외로 이용하지 않습니다. ' +
    '귀하는 동의를 거부할 권리가 있으나, 거부 시 상담 진행이 제한될 수 있습니다. ' +
    '미성년자의 경우 법정대리인의 동의가 필요합니다.',
  fields: [
    {
      key: 'guardian_name',
      type: 'text',
      label: '보호자(법정대리인) 성명',
      required: true,
      placeholder: '성명을 입력하세요',
    },
    {
      key: 'guardian_relation',
      type: 'select',
      label: '학생과의 관계',
      required: true,
      options: ['부', '모', '조부', '조모', '기타'],
    },
    {
      key: 'guardian_contact',
      type: 'text',
      label: '보호자 연락처',
      required: true,
      placeholder: '010-0000-0000',
    },
    {
      key: 'consent_privacy',
      type: 'consent',
      label: '개인정보 수집·이용에 동의합니다. (필수)',
      required: true,
      description:
        '[수집 항목] 보호자 성명, 학생과의 관계, 연락처, 동의 내역\n' +
        '[수집·이용 목적] 학생 상담 접수 및 진행\n' +
        '[보관기간] 관련 법령에 따른 보관기간 후 파기\n' +
        '동의를 거부할 수 있으며, 거부 시 상담 진행이 제한될 수 있습니다.',
    },
    {
      key: 'consent_counseling',
      type: 'consent',
      label: '학생 상담 진행에 동의합니다. (필수)',
      required: true,
      description: '법정대리인으로서 위 학생의 상담 진행에 동의합니다.',
    },
    {
      key: 'note',
      type: 'textarea',
      label: '상담 시 참고할 전달사항 (선택)',
      required: false,
      placeholder: '상담 교사에게 전하고 싶은 내용을 자유롭게 작성해 주세요.',
    },
    {
      key: 'signature',
      type: 'signature',
      label: '전자서명',
      required: true,
      description: '아래 칸에 서명해 주세요. 마우스 또는 손가락으로 작성할 수 있습니다.',
    },
  ],
};
