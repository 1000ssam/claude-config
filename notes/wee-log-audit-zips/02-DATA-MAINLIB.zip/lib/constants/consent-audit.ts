/**
 * 보호자 동의서 감사 로그 — 이벤트 정의 + PII-세이프 빌더(순수).
 *
 * 목적: 동의서의 "무엇이/언제" 일어났는지를 비-PII 메타데이터로만 남겨,
 * 미성년자 보호자 데이터 처리의 추적성(컴플라이언스)을 확보한다.
 *
 * 신뢰경계: 보호자 성명·연락처·응답 내용 등 PII는 절대 기록하지 않는다.
 * `buildAuditEvent`가 detail에서 PII 키를 강제 제거하고 전화번호 패턴을 마스킹한다
 * (fail-safe: 애매하면 과다 제거 — 감사 메타 한 필드가 빠질 뿐 무해).
 *
 * 이 모듈은 DB/네이티브 모듈에 의존하지 않는다 → WSL에서 단위 검증 가능.
 */

export const CONSENT_AUDIT_EVENTS = [
  'request_created',     // 요청 생성(로컬 저장, pending)
  'sent_to_server',      // 서버 등록(공개키 + 평문 스키마 + 만료)
  'delivered',           // SMS 실발송 완료(링크 채널은 수동 전달이라 미기록)
  'status_sent',         // 상태 sent 전이(발송 확정)
  'send_failed',         // 발송 실패(SMS 또는 서버 등록)
  'resend_invalidated',  // 재발송으로 이전 요청 무효화
  'poll_started',        // 수합 폴링 시작
  'response_recorded',   // 응답 복호 → 로컬 암호화 기록(ingested)
  'response_destroyed',  // 서버 암호문 파기(ack) 완료
  'decrypt_failed',      // 복호/파싱 영구 실패(변조 등)
  'requests_expired',    // 미수합 요청 만료 처리
] as const;

export type ConsentAuditEvent = (typeof CONSENT_AUDIT_EVENTS)[number];

/**
 * detail에서 절대 허용하지 않는 PII 연관 키(부분 일치, 소문자 비교).
 * 호출부는 비-PII 키만 넘기지만, 실수로 PII가 섞여도 여기서 차단한다(방어선).
 */
const PII_KEY_DENYLIST = [
  'name', 'contact', 'phone', 'tel', 'guardian', 'answers',
  'answer', 'signature', 'email', 'address', 'value',
];

/** 한국 휴대전화/유선 번호 대략 패턴(값에 숨어든 번호 마스킹용). */
const PHONE_RE = /\d{2,4}[-\s]?\d{3,4}[-\s]?\d{4}/g;

export interface AuditEventInput {
  event: ConsentAuditEvent;
  /** 연관 요청 ID. 요청과 무관한 이벤트(예: 일괄 만료)는 생략/null. */
  requestId?: number | null;
  /** 비-PII 메타데이터(평면 객체 권장). PII 키 자동 제거, 전화번호 자동 마스킹. */
  detail?: Record<string, unknown>;
}

/** 감사 로그 INSERT용 정제 레코드. */
export interface AuditEventRecord {
  event: ConsentAuditEvent;
  request_id: number | null;
  /** 직렬화된 detail(JSON) 또는 null. PII 제거 완료. */
  detail: string | null;
}

function isPiiKey(key: string): boolean {
  const k = key.toLowerCase();
  return PII_KEY_DENYLIST.some((d) => k.includes(d));
}

/** 문자열 내 전화번호 패턴을 [전화번호]로 치환. */
function maskPhones(s: string): string {
  return s.replace(PHONE_RE, '[전화번호]');
}

/**
 * detail 객체를 비-PII로 정제한다.
 *  - PII 연관 키 제거
 *  - 문자열/문자열 배열 값의 전화번호 패턴 마스킹
 *  - 중첩 객체는 통째로 버린다(평면 메타만 허용 — 레닥션 누락 위험 차단)
 */
function redactDetail(detail: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, val] of Object.entries(detail)) {
    if (isPiiKey(key)) continue;
    if (typeof val === 'string') {
      out[key] = maskPhones(val);
    } else if (typeof val === 'number' || typeof val === 'boolean' || val === null) {
      out[key] = val;
    } else if (Array.isArray(val)) {
      out[key] = val.map((v) => (typeof v === 'string' ? maskPhones(v) : v));
    }
    // 그 외(중첩 객체 등)는 버린다.
  }
  return out;
}

/**
 * 감사 이벤트 레코드를 만든다(순수, 부작용 없음).
 * 알 수 없는 이벤트는 throw(프로그래밍 오류 조기 노출).
 * detail은 PII 제거 후 JSON 직렬화하며, 남는 키가 없으면 null.
 */
export function buildAuditEvent(input: AuditEventInput): AuditEventRecord {
  if (!CONSENT_AUDIT_EVENTS.includes(input.event)) {
    throw new Error(`알 수 없는 감사 이벤트: ${String(input.event)}`);
  }

  let detail: string | null = null;
  if (input.detail && Object.keys(input.detail).length > 0) {
    const clean = redactDetail(input.detail);
    detail = Object.keys(clean).length > 0 ? JSON.stringify(clean) : null;
  }

  return {
    event: input.event,
    request_id: input.requestId ?? null,
    detail,
  };
}
