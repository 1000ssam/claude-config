import path from 'path';
import fs from 'fs';
import Database from 'better-sqlite3';
import { app } from 'electron';
import { getDb, closeDb } from './db';

const REQUIRED_TABLES = ['settings', 'students', 'cases', 'sessions'];

export function getDbPath(): string {
  return path.join(app.getPath('userData'), 'wee-log.db');
}

export async function createBackup(destPath: string): Promise<void> {
  const db = getDb();
  await db.backup(destPath);
}

export async function restoreFromBackup(srcPath: string): Promise<void> {
  validateBackupFile(srcPath);

  const dbPath = getDbPath();

  // 복원 전 현재 DB를 안전 백업
  const preRestorePath = dbPath + '.pre-restore';
  const db = getDb();
  await db.backup(preRestorePath);

  // DB 연결 닫기
  closeDb();

  // 소스 파일을 DB 경로로 복사
  fs.copyFileSync(srcPath, dbPath);

  // WAL/SHM 파일이 남아있으면 삭제 (새 DB와 불일치 방지)
  for (const ext of ['-wal', '-shm']) {
    const walPath = dbPath + ext;
    if (fs.existsSync(walPath)) {
      fs.unlinkSync(walPath);
    }
  }
}

export function resetAllData(): void {
  const db = getDb();
  db.exec(`
    DELETE FROM sessions;
    DELETE FROM cases;
    DELETE FROM students;
    UPDATE settings SET value = '1' WHERE key = 'next_case_seq';
  `);
}

function validateBackupFile(srcPath: string): void {
  if (!fs.existsSync(srcPath)) {
    throw new Error('백업 파일을 찾을 수 없습니다.');
  }

  let testDb: Database.Database | null = null;
  try {
    testDb = new Database(srcPath, { readonly: true });
    const tables = testDb
      .prepare("SELECT name FROM sqlite_master WHERE type='table'")
      .all() as { name: string }[];
    const tableNames = tables.map((t) => t.name);

    for (const required of REQUIRED_TABLES) {
      if (!tableNames.includes(required)) {
        throw new Error(`유효하지 않은 백업 파일입니다. '${required}' 테이블이 없습니다.`);
      }
    }
  } finally {
    testDb?.close();
  }
}
