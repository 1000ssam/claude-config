/**
 * 한국 학년도 산출 유틸리티.
 * 학년도는 3월 1일에 시작한다. (예: 2026.03.01 ~ 2027.02.28 = 2026학년도)
 */
export function getAcademicYear(date: Date): string {
  // Month is 0-indexed: 0=Jan, 1=Feb, 2=Mar
  return date.getMonth() >= 2
    ? String(date.getFullYear())
    : String(date.getFullYear() - 1);
}

/**
 * ISO date string ('YYYY-MM-DD')에서 학년도를 산출한다.
 * session_date 등 문자열 날짜 컬럼에서 바로 사용.
 */
export function getAcademicYearFromDateStr(dateStr: string): string {
  const [y, m] = dateStr.split('-').map(Number);
  return m >= 3 ? String(y) : String(y - 1);
}
