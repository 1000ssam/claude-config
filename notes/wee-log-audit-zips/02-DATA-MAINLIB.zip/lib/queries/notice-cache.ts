import type Database from 'better-sqlite3';
import type { Notice } from '../../electron/remote-data';

const CACHE_TTL_HOURS = 24;
const CACHE_KEY = 'latest';

interface CacheRow {
  data: string;
  fetched_at: string;
}

// ── 공지 목록 캐시 ────────────────────────────────────────────────────────────

export function getCachedNotices(db: Database.Database): Notice[] | null {
  const row = db.prepare(
    'SELECT data, fetched_at FROM notice_cache WHERE key = ?'
  ).get(CACHE_KEY) as CacheRow | undefined;

  if (!row) return null;

  const hoursDiff = (Date.now() - new Date(row.fetched_at).getTime()) / (1000 * 60 * 60);
  if (hoursDiff > CACHE_TTL_HOURS) return null;

  return JSON.parse(row.data) as Notice[];
}

export function setCachedNotices(db: Database.Database, notices: Notice[]): void {
  db.prepare(`
    INSERT OR REPLACE INTO notice_cache (key, data, fetched_at)
    VALUES (?, ?, datetime('now', 'localtime'))
  `).run(CACHE_KEY, JSON.stringify(notices));
}

// ── 읽음 처리 ─────────────────────────────────────────────────────────────────

export function getReadNoticeIds(db: Database.Database): string[] {
  const rows = db.prepare('SELECT notice_id FROM notice_read').all() as { notice_id: string }[];
  return rows.map((r) => r.notice_id);
}

export function markNoticeRead(db: Database.Database, noticeId: string): void {
  db.prepare(`
    INSERT OR IGNORE INTO notice_read (notice_id, read_at)
    VALUES (?, datetime('now', 'localtime'))
  `).run(noticeId);
}
