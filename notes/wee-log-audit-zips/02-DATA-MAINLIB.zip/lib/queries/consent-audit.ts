/**
 * 보호자 동의서 감사 로그 — 로컬 DB 쿼리(Phase 6).
 *
 * 쓰기(appendAuditEvent)는 best-effort다: 감사 기록 실패가 본래의 동의서
 * 발송/수합 흐름을 절대 깨뜨리지 않도록 내부에서 예외를 삼키고 로깅만 한다.
 * 정제(이벤트 검증 + PII 제거)는 순수 모듈 buildAuditEvent가 담당한다.
 */

import { getDb } from '@/lib/db';
import { getKey } from '@/lib/crypto/key-manager';
import { decryptValue } from '@/lib/crypto/field-crypto';
import { buildAuditEvent, type AuditEventInput } from '@/lib/constants/consent-audit';
import type { ConsentAuditRecord } from '@/types/consent';

/**
 * 감사 이벤트 1건을 기록한다. 실패해도 throw하지 않는다(사이드카 — 주 흐름 보호).
 * detail의 PII는 buildAuditEvent에서 제거된다.
 */
export function appendAuditEvent(input: AuditEventInput): void {
  try {
    const rec = buildAuditEvent(input);
    getDb()
      .prepare('INSERT INTO consent_audit_log (event, request_id, detail) VALUES (?, ?, ?)')
      .run(rec.event, rec.request_id, rec.detail);
  } catch (err) {
    console.error('[consent-audit] append 실패(무시):', err);
  }
}

export interface ListAuditOptions {
  /** 특정 요청의 이벤트만. */
  requestId?: number;
  /** 사례에 속한 요청들의 이벤트(+ request_id NULL인 일괄 이벤트 제외). */
  caseId?: number;
  /** 최대 행 수(기본 200, 상한 500). */
  limit?: number;
}

/**
 * 감사 로그 행(내부). 표시용 학생명/양식명은 저장하지 않고 읽기 시점 LEFT JOIN으로 결합한다
 * → 로그 자체는 비식별(#id) 유지, 화면에는 실명 표시. 요청/학생 삭제 시 결합값은 NULL.
 */
interface AuditRow {
  id: number;
  event: string;
  request_id: number | null;
  detail: string | null;
  created_at: string;
  template_name: string | null;
  student_name_enc: string | null;
}

const SELECT_AUDIT = `
  SELECT a.id, a.event, a.request_id, a.detail, a.created_at,
         r.template_name AS template_name,
         s.name AS student_name_enc
    FROM consent_audit_log a
    LEFT JOIN consent_requests r ON r.id = a.request_id
    LEFT JOIN students s ON s.id = r.student_id`;

function mapAuditRow(r: AuditRow, key: ReturnType<typeof getKey>): ConsentAuditRecord {
  // 학생 이름은 students에 암호화 저장 → 표시 시점에만 메모리에서 복호. 로그엔 PII 미저장.
  let student_name: string | undefined;
  if (r.student_name_enc) {
    try {
      student_name = decryptValue(r.student_name_enc, key);
    } catch {
      student_name = undefined; // 복호 불가 행 하나가 전체 목록을 깨지 않도록.
    }
  }
  return {
    id: r.id,
    event: r.event,
    request_id: r.request_id,
    detail: r.detail,
    created_at: r.created_at,
    student_name,
    template_name: r.template_name ?? undefined,
  };
}

/**
 * 감사 이벤트를 최신순으로 조회. 옵션 우선순위: requestId > caseId > 전체.
 * 학생명/양식명은 읽기 시점에 결합(저장은 비식별 유지). 항상 requireKey 게이트 뒤에서 호출.
 */
export function listAuditEvents(opts: ListAuditOptions = {}): ConsentAuditRecord[] {
  const db = getDb();
  const key = getKey();
  const limit = opts.limit && opts.limit > 0 ? Math.min(opts.limit, 500) : 200;

  let rows: AuditRow[];
  if (opts.requestId != null) {
    rows = db
      .prepare(`${SELECT_AUDIT} WHERE a.request_id = ? ORDER BY a.id DESC LIMIT ?`)
      .all(opts.requestId, limit) as AuditRow[];
  } else if (opts.caseId != null) {
    // r.case_id로 필터 → request_id가 NULL인 일괄 이벤트(poll_started 등)는 자연히 제외.
    rows = db
      .prepare(`${SELECT_AUDIT} WHERE r.case_id = ? ORDER BY a.id DESC LIMIT ?`)
      .all(opts.caseId, limit) as AuditRow[];
  } else {
    rows = db
      .prepare(`${SELECT_AUDIT} ORDER BY a.id DESC LIMIT ?`)
      .all(limit) as AuditRow[];
  }

  return rows.map((r) => mapAuditRow(r, key));
}
