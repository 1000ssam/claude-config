import ExcelJS from 'exceljs';
import { getDb } from '@/lib/db';
import { getKey } from '@/lib/crypto/key-manager';
import { encryptValue, decryptRow } from '@/lib/crypto/field-crypto';
import { upsertEnrollment, findStudentByPrevEnrollment, findStudentByNameAndBirth } from './enrollments';
import type { ExcelUploadResult, ExcelStudentRow, UploadStudentEntry } from '@/types/student';

/**
 * NEIS 반배정 엑셀(xlsx) 파일을 파싱한다.
 */
export async function parseNeisExcel(filePath: string): Promise<{
  academicYear: string;
  grade: string;
  rows: ExcelStudentRow[];
}> {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(filePath);
  const sheet = workbook.worksheets[0];

  // B5 셀에서 학년도 + 학년 파싱: "2026학년도  2학년"
  const headerCell = sheet.getCell('B5').value?.toString() || '';
  const yearMatch = headerCell.match(/(\d{4})학년도/);
  const gradeMatch = headerCell.match(/(\d+)학년/);

  if (!yearMatch) throw new Error('B5 셀에서 학년도를 파싱할 수 없습니다. NEIS 반배정 파일이 맞는지 확인해주세요.');

  const academicYear = yearMatch[1];
  const grade = gradeMatch ? `${gradeMatch[1]}학년` : '';

  const rows: ExcelStudentRow[] = [];

  for (let rowNum = 8; rowNum <= sheet.rowCount; rowNum++) {
    const row = sheet.getRow(rowNum);
    const nameCell = row.getCell(6).value; // F열 = 성명

    if (!nameCell) continue;
    const nameStr = nameCell.toString().trim();
    if (!nameStr) continue;

    const classRaw = row.getCell(4).value; // D열 = 반
    // D열이 없거나 숫자가 아니면 합계행·헤더 재출력행 → 스킵
    // ('명' 포함 여부로 판단하면 백명열·명성호 같은 이름도 걸림)
    if (classRaw == null || isNaN(Number(classRaw))) continue;

    const numberRaw = row.getCell(5).value; // E열 = 번호
    const className = String(Math.floor(Number(classRaw)));
    const number = numberRaw != null ? String(Math.floor(Number(numberRaw))) : '';

    // H열 = 생년월일 "2009.07.26." → "2009-07-26"
    const birthRaw = row.getCell(8).value?.toString() || '';
    const birthDate = birthRaw.replace(/\./g, '-').replace(/-$/, '');

    // J열 = 성별
    const gender = row.getCell(10).value?.toString().trim() || '';

    // B열 = 학년 (텍스트 "2학년" 형태)
    const gradeCell = row.getCell(2).value;
    const rowGrade = gradeCell ? gradeCell.toString().trim() : grade;

    // 이전학적: O=학년(15), S=반(19), T=번호(20)
    const prevGradeRaw = row.getCell(15).value;
    const prevClassRaw = row.getCell(19).value;
    const prevNumberRaw = row.getCell(20).value;

    const prevGrade = prevGradeRaw ? prevGradeRaw.toString().trim() : undefined;
    const prevClassName = prevClassRaw != null && Number(prevClassRaw) > 0
      ? String(Math.floor(Number(prevClassRaw)))
      : undefined;
    const prevNumber = prevNumberRaw != null && Number(prevNumberRaw) > 0
      ? String(Math.floor(Number(prevNumberRaw)))
      : undefined;

    rows.push({
      name: nameStr,
      grade: rowGrade,
      class_name: className,
      number,
      birth_date: birthDate,
      gender,
      prev_grade: prevGrade,
      prev_class_name: prevClassName,
      prev_number: prevNumber,
    });
  }

  return { academicYear, grade, rows };
}

/**
 * CSV 파일을 파싱한다. 헤더: 이름,학년,반,번호,성별,생년월일
 */
export async function parseCsv(filePath: string, academicYear: string): Promise<ExcelStudentRow[]> {
  const fs = await import('fs');
  const content = fs.readFileSync(filePath, 'utf-8');
  const lines = content.split('\n').filter((l) => l.trim());
  if (lines.length < 2) throw new Error('CSV 파일에 데이터가 없습니다.');

  const headers = lines[0].split(',').map((h) => h.trim());
  const nameIdx = headers.findIndex((h) => h === '이름' || h === '성명');
  const gradeIdx = headers.findIndex((h) => h === '학년');
  const classIdx = headers.findIndex((h) => h === '반');
  const numberIdx = headers.findIndex((h) => h === '번호');
  const genderIdx = headers.findIndex((h) => h === '성별');
  const birthIdx = headers.findIndex((h) => h === '생년월일');

  if (nameIdx === -1) throw new Error('CSV 헤더에 "이름" 또는 "성명" 컬럼이 없습니다.');

  const rows: ExcelStudentRow[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',').map((c) => c.trim());
    const name = cols[nameIdx];
    if (!name) continue;

    rows.push({
      name,
      grade: gradeIdx >= 0 ? cols[gradeIdx] || '' : '',
      class_name: classIdx >= 0 ? cols[classIdx] || '' : '',
      number: numberIdx >= 0 ? cols[numberIdx] || '' : '',
      gender: genderIdx >= 0 ? cols[genderIdx] || '' : '',
      birth_date: birthIdx >= 0 ? cols[birthIdx] || '' : '',
    });
  }

  return rows;
}

/**
 * 파싱된 학생 데이터를 DB에 반영한다.
 * 매칭 전략:
 *   1. 이전학적(prevYear enrollment)으로 매칭 (2학년+)
 *   2. name + birth_date로 매칭 (1학년/이전학적 없음)
 *   3. 매칭 실패 → 신규 학생 생성
 */
export function processUpload(
  academicYear: string,
  rows: ExcelStudentRow[],
): ExcelUploadResult {
  const db = getDb();
  const key = getKey();
  const prevYear = String(Number(academicYear) - 1);

  let created = 0;
  let updated = 0;
  let skipped = 0;
  const errors: string[] = [];
  const createdStudents: UploadStudentEntry[] = [];
  const uploadedStudentIds = new Set<number>();

  db.transaction(() => {
    for (const row of rows) {
      try {
        let studentId: number | undefined;

        // 전략 1: 이전학적으로 매칭
        if (row.prev_grade && row.prev_class_name && row.prev_number) {
          studentId = findStudentByPrevEnrollment(
            prevYear, row.prev_grade, row.prev_class_name, row.prev_number,
          );
        }

        // 전략 2: 이름+생년월일로 매칭
        if (!studentId && row.name && row.birth_date) {
          studentId = findStudentByNameAndBirth(row.name, row.birth_date);
        }

        if (studentId) {
          // 기존 학생 → enrollment upsert
          upsertEnrollment(studentId, academicYear, {
            grade: row.grade,
            class_name: row.class_name,
            number: row.number,
          });

          // gender 업데이트 (students 테이블)
          if (row.gender) {
            db.prepare('UPDATE students SET gender = ? WHERE id = ?').run(row.gender, studentId);
          }

          // birth_date 비어있으면 채움
          if (row.birth_date) {
            const existing = db.prepare('SELECT birth_date FROM students WHERE id = ?')
              .get(studentId) as { birth_date: string | null };
            const decrypted = existing.birth_date
              ? (decryptRow('students', { birth_date: existing.birth_date } as Record<string, unknown>, key) as { birth_date: string | null }).birth_date
              : null;
            if (!decrypted) {
              db.prepare('UPDATE students SET birth_date = ? WHERE id = ?')
                .run(encryptValue(row.birth_date, key), studentId);
            }
          }

          uploadedStudentIds.add(studentId);
          updated++;
        } else {
          // 신규 학생 생성 (학적은 enrollment에서 관리)
          const result = db.prepare(`
            INSERT INTO students (name, gender, birth_date)
            VALUES (?, ?, ?)
          `).run(
            encryptValue(row.name, key),
            row.gender || null,
            encryptValue(row.birth_date, key),
          );

          studentId = Number(result.lastInsertRowid);

          upsertEnrollment(studentId, academicYear, {
            grade: row.grade,
            class_name: row.class_name,
            number: row.number,
          });

          createdStudents.push({
            student_id: studentId,
            name: row.name,
            grade: row.grade,
            class_name: row.class_name,
            number: row.number,
          });

          uploadedStudentIds.add(studentId);
          created++;
        }

        // case_students/session_students는 student_id 기반이므로 별도 동기화 불필요

      } catch (err) {
        errors.push(`${row.name} (${row.grade}-${row.class_name}-${row.number}): ${(err as Error).message}`);
        skipped++;
      }
    }
  })();

  // 전년도 enrollment은 있으나 올해 파일에 없는 학생 (전학/자퇴 가능성)
  const missingStudents: UploadStudentEntry[] = [];
  const prevEnrollments = db.prepare(`
    SELECT e.student_id, e.grade, e.class_name, e.number
    FROM student_enrollments e
    WHERE e.academic_year = ?
  `).all(prevYear) as { student_id: number; grade: string | null; class_name: string | null; number: string | null }[];

  for (const pe of prevEnrollments) {
    if (uploadedStudentIds.has(pe.student_id)) continue;
    // 이미 올해 enrollment이 있으면 (다른 파일로 먼저 업로드됨) 스킵
    const hasCurrentEnrollment = db.prepare(
      'SELECT 1 FROM student_enrollments WHERE student_id = ? AND academic_year = ?'
    ).get(pe.student_id, academicYear);
    if (hasCurrentEnrollment) continue;

    const studentRow = db.prepare('SELECT * FROM students WHERE id = ?').get(pe.student_id) as Record<string, unknown> | undefined;
    if (!studentRow) continue;
    const d = decryptRow('students', studentRow, key) as { id: number; name: string };

    missingStudents.push({
      student_id: pe.student_id,
      name: d.name,
      grade: pe.grade || '',
      class_name: pe.class_name || '',
      number: pe.number || '',
    });
  }

  return {
    created,
    updated,
    skipped,
    errors,
    academic_year: academicYear,
    total_rows: rows.length,
    createdStudents,
    missingStudents,
  };
}
