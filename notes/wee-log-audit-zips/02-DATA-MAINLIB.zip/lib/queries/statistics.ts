import { getDb } from '@/lib/db';

export interface StatisticsParams {
  year?: string;
  from?: string;
  to?: string;
}

export interface Statistics {
  // 요약
  totalSessions: number;
  totalHours: number;
  totalCases: number;
  activeCases: number;
  closedCases: number;
  avgMinutesPerSession: number;

  // 상담 분류
  byLargeCategory: { category: string; count: number }[];
  byMediumCategory: { large: string; medium: string; count: number }[];
  byDetailCategory: { detail: string; large: string; count: number }[];
  byMedium: { category: string; count: number }[];
  byGrade: { grade: string; count: number }[];

  // 시간 흐름
  byMonth: { month: string; count: number }[];
  byNewCaseMonth: { month: string; count: number }[];
  byWeekday: { weekday: string; count: number }[];

  // 유입·종결
  byReferrerRole: { role: string; count: number }[];
  byCloseReason: { reason: string; count: number }[];
  bySessionRange: { range: string; count: number }[];
}

/** sessions 테이블 WHERE 절 */
function buildSessionWhere(params: StatisticsParams): { sql: string; args: unknown[] } {
  let sql = 'WHERE 1=1';
  const args: unknown[] = [];
  if (params.year) { sql += ' AND academic_year = ?'; args.push(params.year); }
  if (params.from) { sql += ' AND session_date >= ?'; args.push(params.from); }
  if (params.to)   { sql += ' AND session_date <= ?'; args.push(params.to); }
  return { sql, args };
}

/** cases 테이블 WHERE 절 (year만 사용)
 * @param tableAlias JOIN 시 컬럼 모호성 방지용 별칭 (예: 'c') */
function buildCaseWhere(params: StatisticsParams, tableAlias = ''): { sql: string; args: unknown[] } {
  const prefix = tableAlias ? `${tableAlias}.` : '';
  let sql = 'WHERE 1=1';
  const args: unknown[] = [];
  if (params.year) { sql += ` AND ${prefix}academic_year = ?`; args.push(params.year); }
  return { sql, args };
}

export function getStatistics(params: StatisticsParams): Statistics {
  const db = getDb();
  const { sql: sw, args: sa } = buildSessionWhere(params);
  const { sql: cw, args: ca } = buildCaseWhere(params);
  const { sql: cwJoin, args: caJoin } = buildCaseWhere(params, 'c');

  // ── 요약 ─────────────────────────────────────────────────────────────────
  const totalSessionsRow = db.prepare(
    `SELECT COUNT(*) as count FROM sessions ${sw}`
  ).get(...sa) as { count: number };

  const totalHoursRow = db.prepare(
    `SELECT SUM(session_hour + session_minute / 60.0) as total FROM sessions ${sw}`
  ).get(...sa) as { total: number | null };

  const caseStatusRows = db.prepare(
    `SELECT status, COUNT(*) as count FROM cases ${cw} GROUP BY status`
  ).all(...ca) as { status: string; count: number }[];
  const totalCases = caseStatusRows.reduce((s, r) => s + r.count, 0);
  const activeCases = caseStatusRows.find(r => r.status === 'active')?.count ?? 0;
  const closedCases = caseStatusRows.find(r => r.status === 'closed')?.count ?? 0;

  const avgMinutesRow = db.prepare(
    `SELECT AVG(session_hour * 60.0 + session_minute) as avg FROM sessions ${sw}`
  ).get(...sa) as { avg: number | null };

  // ── 상담 분류 ─────────────────────────────────────────────────────────────
  const byLargeCategory = db.prepare(
    `SELECT category_large as category, COUNT(*) as count
     FROM sessions ${sw} GROUP BY category_large ORDER BY count DESC`
  ).all(...sa) as { category: string; count: number }[];

  const byMediumCategory = db.prepare(
    `SELECT category_large as large, category_medium as medium, COUNT(*) as count
     FROM sessions ${sw} GROUP BY category_large, category_medium ORDER BY count DESC`
  ).all(...sa) as { large: string; medium: string; count: number }[];

  const byDetailCategory = db.prepare(
    `SELECT category_detail as detail, category_large as large, COUNT(*) as count
     FROM sessions ${sw} GROUP BY category_detail, category_large ORDER BY count DESC`
  ).all(...sa) as { detail: string; large: string; count: number }[];

  const byMedium = db.prepare(
    `SELECT medium as category, COUNT(*) as count
     FROM sessions ${sw} GROUP BY medium ORDER BY count DESC`
  ).all(...sa) as { category: string; count: number }[];

  const byGrade = db.prepare(
    `SELECT COALESCE(NULLIF(grade,''),'미기재') as grade, COUNT(*) as count
     FROM sessions ${sw} GROUP BY grade ORDER BY grade`
  ).all(...sa) as { grade: string; count: number }[];

  // ── 시간 흐름 ─────────────────────────────────────────────────────────────
  const byMonth = db.prepare(
    `SELECT substr(session_date, 1, 7) as month, COUNT(*) as count
     FROM sessions ${sw} GROUP BY month ORDER BY month`
  ).all(...sa) as { month: string; count: number }[];

  const byNewCaseMonth = db.prepare(
    `SELECT substr(created_at, 1, 7) as month, COUNT(*) as count
     FROM cases ${cw} GROUP BY month ORDER BY month`
  ).all(...ca) as { month: string; count: number }[];

  const WEEKDAY_KR = ['일', '월', '화', '수', '목', '금', '토'];
  const weekdayRaw = db.prepare(
    `SELECT strftime('%w', session_date) as wd, COUNT(*) as count
     FROM sessions ${sw} GROUP BY wd ORDER BY wd`
  ).all(...sa) as { wd: string; count: number }[];
  const byWeekday = weekdayRaw.map(r => ({
    weekday: WEEKDAY_KR[parseInt(r.wd)] ?? r.wd,
    count: r.count,
  }));

  // ── 유입·종결 ─────────────────────────────────────────────────────────────
  const byReferrerRole = db.prepare(
    `SELECT COALESCE(NULLIF(referrer_role,''),'미기재') as role, COUNT(*) as count
     FROM cases ${cw} GROUP BY role ORDER BY count DESC`
  ).all(...ca) as { role: string; count: number }[];

  const byCloseReason = db.prepare(
    `SELECT COALESCE(NULLIF(close_reason,''),'미기재') as reason, COUNT(*) as count
     FROM cases ${cw} AND status = 'closed' GROUP BY reason ORDER BY count DESC`
  ).all(...ca) as { reason: string; count: number }[];

  const sessionRangeRaw = db.prepare(`
    SELECT
      CASE
        WHEN cnt = 1 THEN '1회'
        WHEN cnt BETWEEN 2 AND 5 THEN '2~5회'
        WHEN cnt BETWEEN 6 AND 10 THEN '6~10회'
        ELSE '10회 이상'
      END as range,
      COUNT(*) as count
    FROM (
      SELECT c.id, COUNT(s.id) as cnt
      FROM cases c
      LEFT JOIN sessions s ON s.case_id = c.id
      ${cwJoin}
      GROUP BY c.id
    )
    GROUP BY range
  `).all(...caJoin) as { range: string; count: number }[];

  const RANGE_ORDER = ['1회', '2~5회', '6~10회', '10회 이상'];
  const bySessionRange = RANGE_ORDER
    .map(range => ({ range, count: sessionRangeRaw.find(r => r.range === range)?.count ?? 0 }))
    .filter(r => r.count > 0);

  return {
    totalSessions: Number(totalSessionsRow.count),
    totalHours: totalHoursRow.total ?? 0,
    totalCases,
    activeCases,
    closedCases,
    avgMinutesPerSession: avgMinutesRow.avg ?? 0,
    byLargeCategory,
    byMediumCategory,
    byDetailCategory,
    byMedium,
    byGrade,
    byMonth,
    byNewCaseMonth,
    byWeekday,
    byReferrerRole,
    byCloseReason,
    bySessionRange,
  };
}
