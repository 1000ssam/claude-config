import { getDb } from '@/lib/db';
import { getKey } from '@/lib/crypto/key-manager';
import { decryptValue } from '@/lib/crypto/field-crypto';

export interface CalendarSession {
  id: number;
  case_id: number;
  case_number: string;
  student_names: string;
  session_date: string;
  appointment_time: string | null;
  reminder_minutes: number | null;
  session_title: string;
  category_large: string;
  session_hour: number | null;
  session_minute: number | null;
}

/**
 * case_students → students를 JOIN하여 학생 이름을 결합한다.
 * 1명이면 이름, 2명 이상이면 "홍길동 외 N명"
 */
function buildStudentNames(caseId: number, key: Buffer): string {
  const db = getDb();
  const rows = db.prepare(`
    SELECT st.name
    FROM case_students cs
    JOIN students st ON st.id = cs.student_id
    WHERE cs.case_id = ?
  `).all(caseId) as { name: string }[];

  if (rows.length === 0) return '(학생 없음)';

  const names = rows.map((r) => decryptValue(r.name, key));
  if (names.length === 1) return names[0];
  return `${names[0]} 외 ${names.length - 1}명`;
}

/**
 * 날짜 범위 내의 세션을 cases와 JOIN하여 반환한다.
 * 학생 이름은 case_students → students에서 조회/복호화.
 */
export function getCalendarSessions(from: string, to: string): CalendarSession[] {
  const db = getDb();
  const key = getKey();

  const rows = db.prepare(`
    SELECT
      s.id,
      s.case_id,
      s.session_date,
      s.appointment_time,
      s.reminder_minutes,
      s.session_title,
      s.category_large,
      s.session_hour,
      s.session_minute,
      c.case_number
    FROM sessions s
    JOIN cases c ON s.case_id = c.id
    WHERE s.session_date >= ? AND s.session_date <= ?
    ORDER BY s.session_date ASC, COALESCE(s.appointment_time, '99:99') ASC
  `).all(from, to) as Record<string, unknown>[];

  // case_id별 학생 이름을 캐시하여 중복 조회 방지
  const nameCache = new Map<number, string>();

  return rows.map((row) => {
    const caseId = row.case_id as number;
    if (!nameCache.has(caseId)) {
      nameCache.set(caseId, buildStudentNames(caseId, key));
    }

    return {
      id: row.id as number,
      case_id: caseId,
      case_number: row.case_number as string,
      student_names: nameCache.get(caseId)!,
      session_date: row.session_date as string,
      appointment_time: (row.appointment_time as string | null) ?? null,
      reminder_minutes: (row.reminder_minutes as number | null) ?? null,
      session_title: row.session_title as string,
      category_large: row.category_large as string,
      session_hour: (row.session_hour as number | null) ?? null,
      session_minute: (row.session_minute as number | null) ?? null,
    };
  });
}

/**
 * 오늘 날짜의 리마인더가 설정된 세션을 반환한다. (메인 프로세스 리마인더 스케줄링용)
 */
export function getTodayReminders(): CalendarSession[] {
  const today = new Date();
  const dateStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  const db = getDb();
  const key = getKey();

  const rows = db.prepare(`
    SELECT
      s.id,
      s.case_id,
      s.session_date,
      s.appointment_time,
      s.reminder_minutes,
      s.session_title,
      s.category_large,
      c.case_number
    FROM sessions s
    JOIN cases c ON s.case_id = c.id
    WHERE s.session_date = ?
      AND s.appointment_time IS NOT NULL
      AND s.reminder_minutes IS NOT NULL
    ORDER BY s.appointment_time ASC
  `).all(dateStr) as Record<string, unknown>[];

  const nameCache = new Map<number, string>();

  return rows.map((row) => {
    const caseId = row.case_id as number;
    if (!nameCache.has(caseId)) {
      nameCache.set(caseId, buildStudentNames(caseId, key));
    }

    return {
      id: row.id as number,
      case_id: caseId,
      case_number: row.case_number as string,
      student_names: nameCache.get(caseId)!,
      session_date: row.session_date as string,
      appointment_time: (row.appointment_time as string | null) ?? null,
      reminder_minutes: (row.reminder_minutes as number | null) ?? null,
      session_title: row.session_title as string,
      category_large: row.category_large as string,
    };
  });
}
