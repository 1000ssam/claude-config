import { getDb } from '@/lib/db';
import { getKey } from '@/lib/crypto/key-manager';
import { decryptRow, decryptValue } from '@/lib/crypto/field-crypto';

export interface ReportParams {
  startDate: string; // YYYY-MM-DD
  endDate: string;   // YYYY-MM-DD
}

export interface SessionCounts {
  total: number;
  counseling: number;
  inspection: number;
  consultation: number;
  education: number;
  research: number;
  referral: number;
}

export interface CounselingBreakdown {
  // 유형별
  individual: number;
  group: number;
  parent: number;
  // 매체별
  face: number;
  phone: number;
  cyber: number;
  // 분류별
  general: number;
  professional: number;
  outreach: number;
  // 개인상담 영역별
  individualAreas: { area: string; count: number }[];
}

export interface ReportCaseSummary {
  case_number: string;
  grade: string;
  student_names: string;
  first_session_date: string | null;
  last_session_date: string | null;
  status: string;
  main_complaint: string | null;
  counseling_goal: string | null;
  teacher_opinion: string | null;
}

export interface ReportData {
  startDate: string;
  endDate: string;
  sessionCounts: SessionCounts;
  counselingBreakdown: CounselingBreakdown;
  cases: ReportCaseSummary[];
}

/** case_students → students를 JOIN하여 학생 이름을 결합한다. */
function buildStudentNamesForCase(caseId: number, key: Buffer): string {
  const db = getDb();
  const rows = db.prepare(`
    SELECT st.name FROM case_students cs
    JOIN students st ON st.id = cs.student_id
    WHERE cs.case_id = ?
  `).all(caseId) as { name: string }[];

  if (rows.length === 0) return '(학생 없음)';
  const names = rows.map((r) => decryptValue(r.name, key));
  if (names.length === 1) return names[0];
  return `${names[0]} 외 ${names.length - 1}명`;
}

/** case_students의 학생들 학년을 결합하여 표시 문자열을 반환한다. */
function buildGradeForCase(caseId: number): string {
  const db = getDb();

  const rows = db.prepare(`
    SELECT e.grade
    FROM case_students cs
    JOIN cases c ON c.id = cs.case_id
    JOIN students st ON st.id = cs.student_id
    LEFT JOIN student_enrollments e ON e.student_id = st.id AND e.academic_year = c.academic_year
    WHERE cs.case_id = ?
  `).all(caseId) as { grade: string | null }[];

  const grades = new Set(rows.map((r) => r.grade).filter(Boolean));
  if (grades.size === 0) return '-';
  if (grades.size === 1) return [...grades][0]!;
  return '혼합';
}

export function generateReportData(params: ReportParams): ReportData {
  const db = getDb();
  const key = getKey();

  const { startDate, endDate } = params;

  // 기간 내 세션 전체
  const sessions = db.prepare(`
    SELECT * FROM sessions
    WHERE session_date >= ? AND session_date <= ?
  `).all(startDate, endDate) as Record<string, unknown>[];

  const counselingSessions = sessions.filter((s) => s.category_large === '상담');

  // 개인상담 영역별 집계
  const areaMap = new Map<string, number>();
  for (const s of counselingSessions) {
    if (s.category_medium === '개인상담' && s.category_detail && s.category_detail !== '-') {
      const area = s.category_detail as string;
      areaMap.set(area, (areaMap.get(area) ?? 0) + 1);
    }
  }
  const individualAreas = Array.from(areaMap.entries())
    .map(([area, count]) => ({ area, count }))
    .sort((a, b) => b.count - a.count);

  const sessionCounts: SessionCounts = {
    total: sessions.length,
    counseling: counselingSessions.length,
    inspection: sessions.filter((s) => s.category_large === '검사').length,
    consultation: sessions.filter((s) => s.category_large === '자문').length,
    education: sessions.filter((s) => s.category_large === '교육').length,
    research: sessions.filter((s) => s.category_large === '연구').length,
    referral: sessions.filter((s) => s.category_large === '의뢰').length,
  };

  const counselingBreakdown: CounselingBreakdown = {
    individual: counselingSessions.filter((s) => s.category_medium === '개인상담').length,
    group: counselingSessions.filter((s) => s.category_medium === '집단상담').length,
    parent: counselingSessions.filter((s) => s.category_medium === '학부모상담').length,
    face: counselingSessions.filter((s) => s.medium === '면담').length,
    phone: counselingSessions.filter((s) => s.medium === '전화상담').length,
    cyber: counselingSessions.filter((s) => s.medium === '사이버상담').length,
    general: counselingSessions.filter((s) => s.counseling_class === '일반상담').length,
    professional: counselingSessions.filter((s) => s.counseling_class === '전문상담').length,
    outreach: counselingSessions.filter((s) => s.counseling_class === '순회상담').length,
    individualAreas,
  };

  // 기간 내 세션이 있는 사례 목록
  const caseIdsInPeriod = [...new Set(sessions.map((s) => s.case_id as number))];

  const cases: ReportCaseSummary[] = [];
  for (const caseId of caseIdsInPeriod) {
    const row = db.prepare(`
      SELECT c.*,
        MIN(s.session_date) as first_session_date,
        MAX(s.session_date) as last_session_date
      FROM cases c
      LEFT JOIN sessions s ON s.case_id = c.id AND s.session_date >= ? AND s.session_date <= ?
      WHERE c.id = ?
      GROUP BY c.id
    `).get(startDate, endDate, caseId) as Record<string, unknown> | undefined;

    if (!row) continue;
    const dec = decryptRow('cases', row, key) as Record<string, unknown>;

    cases.push({
      case_number: dec.case_number as string,
      grade: buildGradeForCase(caseId),
      student_names: buildStudentNamesForCase(caseId, key),
      first_session_date: dec.first_session_date as string | null,
      last_session_date: dec.last_session_date as string | null,
      status: dec.status as string,
      main_complaint: (dec.main_complaint as string | null) || null,
      counseling_goal: (dec.counseling_goal as string | null) || null,
      teacher_opinion: (dec.teacher_opinion as string | null) || null,
    });
  }

  cases.sort((a, b) => a.case_number.localeCompare(b.case_number));

  return { startDate, endDate, sessionCounts, counselingBreakdown, cases };
}
