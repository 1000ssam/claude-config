import type Database from 'better-sqlite3';

export interface HolidayEntry {
  date: string;  // YYYY-MM-DD
  name: string;
}

interface CacheRow {
  data: string;
  fetched_at: string;
}

const CACHE_TTL_HOURS = 24;

export function getCachedHolidays(db: Database.Database, year: number): HolidayEntry[] | null {
  const row = db.prepare(
    'SELECT data, fetched_at FROM public_holiday_cache WHERE year = ?'
  ).get(year) as CacheRow | undefined;

  if (!row) return null;

  const fetchedAt = new Date(row.fetched_at);
  const hoursDiff = (Date.now() - fetchedAt.getTime()) / (1000 * 60 * 60);
  if (hoursDiff > CACHE_TTL_HOURS) return null;

  return JSON.parse(row.data) as HolidayEntry[];
}

export function setCachedHolidays(db: Database.Database, year: number, holidays: HolidayEntry[]): void {
  db.prepare(`
    INSERT OR REPLACE INTO public_holiday_cache (year, data, fetched_at)
    VALUES (?, ?, datetime('now', 'localtime'))
  `).run(year, JSON.stringify(holidays));
}
