import type Database from 'better-sqlite3';

export interface SchoolEvent {
  date: string;  // YYYY-MM-DD
  name: string;
}

interface CacheRow {
  data: string;
  fetched_at: string;
}

const CACHE_TTL_HOURS = 24;

export function getCachedSchedule(db: Database.Database, schulCode: string, year: number): SchoolEvent[] | null {
  const row = db.prepare(
    'SELECT data, fetched_at FROM school_schedule_cache WHERE schul_code = ? AND year = ?'
  ).get(schulCode, year) as CacheRow | undefined;

  if (!row) return null;

  const hoursDiff = (Date.now() - new Date(row.fetched_at).getTime()) / (1000 * 60 * 60);
  if (hoursDiff > CACHE_TTL_HOURS) return null;

  return JSON.parse(row.data) as SchoolEvent[];
}

export function setCachedSchedule(db: Database.Database, schulCode: string, year: number, events: SchoolEvent[]): void {
  db.prepare(`
    INSERT OR REPLACE INTO school_schedule_cache (schul_code, year, data, fetched_at)
    VALUES (?, ?, ?, datetime('now', 'localtime'))
  `).run(schulCode, year, JSON.stringify(events));
}
