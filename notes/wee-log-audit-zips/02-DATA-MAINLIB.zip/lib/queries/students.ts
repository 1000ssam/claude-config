import { getDb } from '@/lib/db';
import { getKey } from '@/lib/crypto/key-manager';
import { decryptRow, encryptValue } from '@/lib/crypto/field-crypto';
import { getEnrollmentsByStudentId } from '@/lib/queries/enrollments';
import { getCounselingNumberMap } from '@/lib/queries/sessions';
import { getAcademicYear } from '@/lib/academic-year';
import type { Student, StudentWithEnrollment, CreateStudentInput, UpdateStudentInput, StudentProfile, StudentProfileCase } from '@/types/student';

import type { StudentWithCaseCount } from '@/types/student';

export type { StudentWithCaseCount };

export function getAllStudents(params?: { search?: string; academic_year?: string; status?: string | null }): StudentWithCaseCount[] {
  const db = getDb();
  const key = getKey();

  // status가 null이면 전체, 없으면 기본값 '재학'
  const statusFilter = params?.status === null ? null : (params?.status ?? '재학');

  // 학년도 결정: 명시 > 현재 날짜 기준 자동 산출
  const year = params?.academic_year ?? getAcademicYear(new Date());

  let rows: Record<string, unknown>[];

  if (statusFilter !== null) {
    rows = db.prepare(`
      SELECT s.*,
        e.grade,
        e.class_name,
        e.number,
        COUNT(cs.case_id) as case_count
      FROM students s
      LEFT JOIN student_enrollments e ON e.student_id = s.id AND e.academic_year = ?
      LEFT JOIN case_students cs ON cs.student_id = s.id
      WHERE s.status = ?
      GROUP BY s.id
      ORDER BY e.grade ASC, e.class_name ASC, CAST(e.number AS INTEGER) ASC, s.updated_at DESC
    `).all(year, statusFilter) as Record<string, unknown>[];
  } else {
    rows = db.prepare(`
      SELECT s.*,
        e.grade,
        e.class_name,
        e.number,
        COUNT(cs.case_id) as case_count
      FROM students s
      LEFT JOIN student_enrollments e ON e.student_id = s.id AND e.academic_year = ?
      LEFT JOIN case_students cs ON cs.student_id = s.id
      GROUP BY s.id
      ORDER BY e.grade ASC, e.class_name ASC, CAST(e.number AS INTEGER) ASC, s.updated_at DESC
    `).all(year) as Record<string, unknown>[];
  }

  const decrypted = rows.map((r) => {
    const d = decryptRow('students', r, key) as StudentWithCaseCount;
    d.grade = r.grade as string | null;
    d.class_name = r.class_name as string | null;
    d.number = r.number as string | null;
    return d;
  });

  if (!params?.search) return decrypted;

  const q = params.search.toLowerCase();
  return decrypted.filter(
    (s) =>
      s.name?.toLowerCase().includes(q) ||
      s.grade?.toLowerCase().includes(q) ||
      s.class_name?.toLowerCase().includes(q),
  );
}

export function searchStudents(query: string): StudentWithEnrollment[] {
  const db = getDb();
  const key = getKey();

  const year = getAcademicYear(new Date());

  // 사례 생성 시 학생 검색 — 재학 중인 학생만 반환
  const rows = db.prepare(`
    SELECT s.*, e.grade, e.class_name, e.number
    FROM students s
    LEFT JOIN student_enrollments e ON e.student_id = s.id AND e.academic_year = ?
    WHERE s.status = '재학'
    ORDER BY s.name ASC, s.updated_at DESC
  `).all(year) as Record<string, unknown>[];

  const q = query.toLowerCase();
  return rows
    .map((r) => {
      const d = decryptRow('students', r, key) as StudentWithEnrollment;
      d.grade = r.grade as string | null;
      d.class_name = r.class_name as string | null;
      d.number = r.number as string | null;
      return d;
    })
    .filter((s) => s.name?.toLowerCase().includes(q))
    .slice(0, 20);
}

/**
 * 이름+학년+반+번호 조합으로 동일 학생 검색 (암호화로 인해 JS-side 비교).
 * 학적은 enrollment 기준.
 */
export function findStudentByIdentity(
  name: string,
  grade?: string | null,
  className?: string | null,
  number?: string | null,
): Student | undefined {
  const db = getDb();
  const key = getKey();

  const year = getAcademicYear(new Date());

  const rows = db.prepare(`
    SELECT s.*, e.grade, e.class_name, e.number
    FROM students s
    LEFT JOIN student_enrollments e ON e.student_id = s.id AND e.academic_year = ?
  `).all(year) as Record<string, unknown>[];

  for (const row of rows) {
    const d = decryptRow('students', row, key) as Student;
    if (
      d.name === name &&
      ((row.grade as string | null) || null) === (grade || null) &&
      ((row.class_name as string | null) || null) === (className || null) &&
      ((row.number as string | null) || null) === (number || null)
    ) {
      return d;
    }
  }
  return undefined;
}

export function getStudentById(id: number): Student | undefined {
  const db = getDb();
  const key = getKey();
  const row = db.prepare('SELECT * FROM students WHERE id = ?').get(id) as Record<string, unknown> | undefined;
  if (!row) return undefined;
  return decryptRow('students', row, key) as Student;
}

export function createStudent(input: CreateStudentInput): Student {
  const db = getDb();
  const key = getKey();

  const result = db.prepare(`
    INSERT INTO students (name, gender, birth_date, contact,
      guardian_name, guardian_relation, guardian_contact)
      VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    encryptValue(input.name, key),
    input.gender || null,
    encryptValue(input.birth_date, key),
    encryptValue(input.contact, key),
    encryptValue(input.guardian_name, key),
    input.guardian_relation || null,
    encryptValue(input.guardian_contact, key),
  );

  const studentId = Number(result.lastInsertRowid);

  // enrollment 생성 (현재 학년도)
  if (input.grade || input.class_name || input.number) {
    const currentYear = getAcademicYear(new Date());

    db.prepare(`
      INSERT OR IGNORE INTO student_enrollments (student_id, academic_year, grade, class_name, number)
      VALUES (?, ?, ?, ?, ?)
    `).run(studentId, currentYear, input.grade || null, input.class_name || null, input.number || null);
  }

  const newStudent = getStudentById(studentId);
  if (!newStudent) throw new Error('Failed to create student');
  return newStudent;
}

// UPDATE 시 허용되는 students 테이블 컬럼 (학적은 enrollments에서 관리)
const ALLOWED_STUDENT_UPDATE_FIELDS = new Set<string>([
  'name', 'gender',
  'birth_date', 'contact', 'guardian_name', 'guardian_relation', 'guardian_contact',
  'status',
]);

// 암호화 대상 업데이트 필드
const ENCRYPTED_STUDENT_UPDATE_FIELDS = new Set([
  'name', 'birth_date', 'contact', 'guardian_name', 'guardian_contact',
]);

// 학적 필드 (enrollment에서 관리)
const ENROLLMENT_FIELDS = new Set(['grade', 'class_name', 'number']);

export function updateStudent(id: number, input: UpdateStudentInput): Student | undefined {
  const db = getDb();
  const key = getKey();

  // 불변식: 보호자명이 비면 관계·연락처도 비운다(이름 없는 보호자 = 미등록).
  // 폼이 보호자 3필드를 항상 함께 전송하므로, guardian_name이 명시적으로 빈 경우에만 적용
  // (guardian_name을 보내지 않는 부분 업데이트는 건드리지 않음).
  if ('guardian_name' in input && !(input.guardian_name || '').trim()) {
    input.guardian_relation = '';
    input.guardian_contact = '';
  }

  const fields: string[] = [];
  const values: unknown[] = [];

  for (const [k, v] of Object.entries(input)) {
    if (ALLOWED_STUDENT_UPDATE_FIELDS.has(k)) {
      fields.push(`${k} = ?`);
      const raw = v === '' ? null : v as string | null;
      values.push(ENCRYPTED_STUDENT_UPDATE_FIELDS.has(k) ? encryptValue(raw, key) : raw);
    }
  }

  db.transaction(() => {
    if (fields.length > 0) {
      values.push(id);
      db.prepare(`UPDATE students SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    }

    // enrollment upsert (학적 변경 시)
    const hasEnrollmentChange = Object.keys(input).some((k) => ENROLLMENT_FIELDS.has(k));
    if (hasEnrollmentChange) {
      const currentYear = getAcademicYear(new Date());

      // 현재 enrollment 가져오기
      const existing = db.prepare(
        'SELECT grade, class_name, number FROM student_enrollments WHERE student_id = ? AND academic_year = ?'
      ).get(id, currentYear) as { grade: string | null; class_name: string | null; number: string | null } | undefined;

      const grade = input.grade !== undefined ? (input.grade || null) : (existing?.grade ?? null);
      const className = input.class_name !== undefined ? (input.class_name || null) : (existing?.class_name ?? null);
      const number = input.number !== undefined ? (input.number || null) : (existing?.number ?? null);

      db.prepare(`
        INSERT INTO student_enrollments (student_id, academic_year, grade, class_name, number)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(student_id, academic_year) DO UPDATE SET
          grade = excluded.grade,
          class_name = excluded.class_name,
          number = excluded.number
      `).run(id, currentYear, grade, className, number);
    }
  })();

  return getStudentById(id);
}

export function deleteStudent(id: number): void {
  const db = getDb();
  // case_students, session_students는 ON DELETE CASCADE로 자동 정리
  db.prepare('DELETE FROM students WHERE id = ?').run(id);
}

export function bulkDeleteStudents(ids: number[]): void {
  if (ids.length === 0) return;
  const db = getDb();
  const placeholders = ids.map(() => '?').join(',');
  // case_students, session_students는 ON DELETE CASCADE로 자동 정리
  db.prepare(`DELETE FROM students WHERE id IN (${placeholders})`).run(...ids);
}

export function bulkUpdateStudentStatus(ids: number[], status: string): void {
  if (ids.length === 0) return;
  const db = getDb();
  const placeholders = ids.map(() => '?').join(',');
  db.transaction(() => {
    db.prepare(`UPDATE students SET status = ? WHERE id IN (${placeholders})`).run(status, ...ids);
  })();
}

/** 학생 상세 프로필: 기본정보 + 학적이력 + 사례(세션 포함) */
export function getStudentProfile(studentId: number): StudentProfile | undefined {
  const db = getDb();
  const key = getKey();

  // 1. 학생 기본 정보
  const studentRow = db.prepare('SELECT * FROM students WHERE id = ?').get(studentId) as Record<string, unknown> | undefined;
  if (!studentRow) return undefined;
  const student = decryptRow('students', studentRow, key) as Student;

  // 2. 학적 이력 (enrollments.ts 재사용)
  const enrollments = getEnrollmentsByStudentId(studentId);

  // 3. 해당 학생의 모든 사례 조회
  const caseRows = db.prepare(`
    SELECT c.*,
      COUNT(s.id) as session_count,
      MAX(s.session_date) as last_session_date
    FROM case_students cs
    JOIN cases c ON c.id = cs.case_id
    LEFT JOIN sessions s ON s.case_id = c.id
    WHERE cs.student_id = ?
    GROUP BY c.id
    ORDER BY c.academic_year DESC, c.created_at DESC
  `).all(studentId) as Record<string, unknown>[];

  const cases: StudentProfileCase[] = [];

  for (const cr of caseRows) {
    const dec = decryptRow('cases', cr, key);
    const caseId = cr.id as number;

    // 4. 이 학생이 참여한 세션만 조회
    const sessionRows = db.prepare(`
      SELECT s.id, s.case_id, s.session_date, s.session_title,
        s.session_content, s.internal_notes,
        s.counseling_class, s.category_large, s.category_medium, s.category_detail,
        s.session_number, s.session_hour, s.session_minute
      FROM sessions s
      JOIN session_students ss ON ss.session_id = s.id
      WHERE s.case_id = ? AND ss.student_id = ?
      ORDER BY s.session_date DESC
    `).all(caseId, studentId) as Record<string, unknown>[];

    // 사례 내 상담 세션의 동적 회차 번호 맵
    const numberMap = getCounselingNumberMap(caseId);

    const sessions = sessionRows.map((sr) => {
      const sd = decryptRow('sessions', sr, key);
      const sessionId = sr.id as number;
      return {
        id: sessionId,
        case_id: sr.case_id as number,
        session_date: sr.session_date as string,
        session_title: sd.session_title as string,
        session_content: sd.session_content as string,
        internal_notes: (sd.internal_notes as string | null) || null,
        counseling_class: sr.counseling_class as string,
        category_large: sr.category_large as string,
        category_medium: sr.category_medium as string,
        category_detail: sr.category_detail as string,
        session_number: numberMap.get(sessionId) ?? null,
        session_hour: sr.session_hour as number,
        session_minute: sr.session_minute as number,
      };
    });

    cases.push({
      id: caseId,
      case_number: (dec.case_number as string) || '',
      academic_year: cr.academic_year as string,
      main_complaint: (dec.main_complaint as string | null) || null,
      status: cr.status as 'active' | 'closed',
      session_count: cr.session_count as number,
      last_session_date: (cr.last_session_date as string | null) || null,
      created_at: cr.created_at as string,
      sessions,
    });
  }

  return { student, enrollments, cases };
}
