import { getDb } from '@/lib/db';
import { getKey } from '@/lib/crypto/key-manager';
import { decryptRow } from '@/lib/crypto/field-crypto';
import type { StudentEnrollment } from '@/types/student';

export function getEnrollmentsByStudentId(studentId: number): StudentEnrollment[] {
  const db = getDb();
  return db.prepare(
    'SELECT * FROM student_enrollments WHERE student_id = ? ORDER BY academic_year DESC'
  ).all(studentId) as StudentEnrollment[];
}

export function getEnrollment(studentId: number, academicYear: string): StudentEnrollment | undefined {
  const db = getDb();
  return db.prepare(
    'SELECT * FROM student_enrollments WHERE student_id = ? AND academic_year = ?'
  ).get(studentId, academicYear) as StudentEnrollment | undefined;
}

export function upsertEnrollment(
  studentId: number,
  academicYear: string,
  data: { grade?: string | null; class_name?: string | null; number?: string | null },
): StudentEnrollment {
  const db = getDb();

  db.prepare(`
    INSERT INTO student_enrollments (student_id, academic_year, grade, class_name, number)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(student_id, academic_year) DO UPDATE SET
      grade = excluded.grade,
      class_name = excluded.class_name,
      number = excluded.number
  `).run(
    studentId,
    academicYear,
    data.grade || null,
    data.class_name || null,
    data.number || null,
  );

  return getEnrollment(studentId, academicYear)!;
}

/**
 * 이전학적(전년도 enrollment)으로 학생 매칭. 비암호화 필드 → SQL 직접 매칭.
 */
export function findStudentByPrevEnrollment(
  prevYear: string,
  prevGrade: string,
  prevClassName: string,
  prevNumber: string,
): number | undefined {
  const db = getDb();
  const row = db.prepare(`
    SELECT student_id FROM student_enrollments
    WHERE academic_year = ? AND grade = ? AND class_name = ? AND number = ?
  `).get(prevYear, prevGrade, prevClassName, prevNumber) as { student_id: number } | undefined;
  return row?.student_id;
}

/**
 * 이름+생년월일로 학생 매칭 (1학년 신입생용). 암호화 필드 → 전체 로드 후 JS 비교.
 */
export function findStudentByNameAndBirth(
  name: string,
  birthDate: string,
): number | undefined {
  const db = getDb();
  const key = getKey();
  const rows = db.prepare('SELECT * FROM students').all() as Record<string, unknown>[];

  for (const row of rows) {
    const d = decryptRow('students', row, key) as { id: number; name: string; birth_date: string | null };
    if (d.name === name && d.birth_date === birthDate) {
      return d.id;
    }
  }
  return undefined;
}

export interface GraduationEligibilityResult {
  eligible: number[];   // 졸업 대상 student id
  ineligible: { id: number; name: string; grade: string; reason: string }[];
}

/**
 * 선택된 학생들의 졸업 대상 여부를 판정한다.
 *
 * 판정 기준: 가장 최근 enrollment 학년 + (currentYear - enrollment 학년도) == graduationGrade
 * 예) 2026년 기준 3학년 졸업 → 2025년 2학년, 2024년 1학년도 해당.
 */
export function checkGraduationEligibility(
  studentIds: number[],
  currentYear: string,
  graduationGrade: string,
): GraduationEligibilityResult {
  const db = getDb();
  const key = getKey();

  const gradNum = parseInt(graduationGrade.replace('학년', ''), 10);
  const curYearNum = parseInt(currentYear, 10);

  const eligible: number[] = [];
  const ineligible: GraduationEligibilityResult['ineligible'] = [];

  for (const id of studentIds) {
    const raw = db.prepare('SELECT id, name FROM students WHERE id = ?').get(id) as Record<string, unknown> | undefined;
    const student = raw ? decryptRow('students', raw, key) as { id: number; name: string } : undefined;
    const displayName = student?.name ?? `ID ${id}`;

    // currentYear 이하의 가장 최근 enrollment
    const enrollment = db.prepare(`
      SELECT academic_year, grade FROM student_enrollments
      WHERE student_id = ? AND CAST(academic_year AS INTEGER) <= ?
      ORDER BY CAST(academic_year AS INTEGER) DESC
      LIMIT 1
    `).get(id, curYearNum) as { academic_year: string; grade: string | null } | undefined;

    if (!enrollment || !enrollment.grade) {
      ineligible.push({ id, name: displayName, grade: '기록 없음', reason: '학적 기록 없음' });
      continue;
    }

    const enrollGradeNum = parseInt(enrollment.grade.replace('학년', ''), 10);
    if (isNaN(enrollGradeNum)) {
      ineligible.push({ id, name: displayName, grade: enrollment.grade, reason: `학년 형식 불명확(${enrollment.grade})` });
      continue;
    }

    const expectedGradeNum = enrollGradeNum + (curYearNum - parseInt(enrollment.academic_year, 10));

    if (expectedGradeNum === gradNum) {
      eligible.push(id);
    } else if (expectedGradeNum < gradNum) {
      ineligible.push({
        id, name: displayName, grade: `${expectedGradeNum}학년`,
        reason: `${currentYear}년 기준 예상 학년: ${expectedGradeNum}학년 (졸업학년 ${graduationGrade} 아님)`,
      });
    } else {
      // 이미 졸업학년을 지남 (유급 등 특수 케이스) — 경고하되 eligible 처리
      eligible.push(id);
    }
  }

  return { eligible, ineligible };
}

/**
 * enrollment이 존재하는 학년도 목록 (내림차순).
 */
export function getDistinctEnrollmentYears(): string[] {
  const db = getDb();
  const rows = db.prepare(
    'SELECT DISTINCT academic_year FROM student_enrollments ORDER BY academic_year DESC'
  ).all() as { academic_year: string }[];
  return rows.map((r) => r.academic_year);
}
