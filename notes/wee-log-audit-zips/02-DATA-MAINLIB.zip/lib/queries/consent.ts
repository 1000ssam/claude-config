/**
 * 보호자 동의서/접수양식 — 로컬 DB 쿼리.
 *
 * 암호화 경계:
 *  - consent_requests.private_key : sealed-box 개인키(base64) → field-crypto(AES-256-GCM) 암호화 저장.
 *  - consent_responses.answers    : 복호된 응답 JSON → field-crypto 암호화 저장.
 *  - public_key/token/link/schema : 평문(민감정보 아님).
 *
 * 키쌍 생성·서버 통신은 비동기라 메인 프로세스(electron/*)가 담당하고,
 * 이 모듈은 동기 DB 입출력 + 필드 암호화만 책임진다.
 */

import { randomBytes } from 'crypto';
import { getDb } from '@/lib/db';
import { getKey } from '@/lib/crypto/key-manager';
import { encryptValue, decryptValue } from '@/lib/crypto/field-crypto';
import { buildActiveRequestsQuery } from '@/lib/queries/consent-active-query';
import type {
  ConsentTemplate,
  ConsentFormSchema,
  ConsentRequest,
  ConsentStatus,
  ConsentChannel,
  ConsentResponseRecord,
  UpsertConsentTemplateInput,
} from '@/types/consent';

// ── 템플릿 ──────────────────────────────────────────────────────────────────────

interface TemplateRow {
  id: number;
  name: string;
  schema: string;
  is_default: number;
  created_at: string;
  updated_at: string;
}

function mapTemplate(r: TemplateRow): ConsentTemplate {
  return {
    id: r.id,
    name: r.name,
    schema: JSON.parse(r.schema) as ConsentFormSchema,
    is_default: r.is_default ? 1 : 0,
    created_at: r.created_at,
    updated_at: r.updated_at,
  };
}

export function listConsentTemplates(): ConsentTemplate[] {
  const db = getDb();
  const rows = db.prepare(
    'SELECT * FROM consent_form_templates ORDER BY is_default DESC, updated_at DESC'
  ).all() as TemplateRow[];
  return rows.map(mapTemplate);
}

export function getConsentTemplate(id: number): ConsentTemplate | undefined {
  const db = getDb();
  const row = db.prepare('SELECT * FROM consent_form_templates WHERE id = ?').get(id) as
    | TemplateRow
    | undefined;
  return row ? mapTemplate(row) : undefined;
}

export function createConsentTemplate(input: UpsertConsentTemplateInput): ConsentTemplate {
  const db = getDb();
  const tx = db.transaction(() => {
    if (input.is_default) {
      db.prepare('UPDATE consent_form_templates SET is_default = 0').run();
    }
    const res = db.prepare(
      'INSERT INTO consent_form_templates (name, schema, is_default) VALUES (?, ?, ?)'
    ).run(input.name, JSON.stringify(input.schema), input.is_default ? 1 : 0);
    return Number(res.lastInsertRowid);
  });
  const id = tx();
  return getConsentTemplate(id)!;
}

export function updateConsentTemplate(
  id: number,
  input: UpsertConsentTemplateInput,
): ConsentTemplate | undefined {
  const db = getDb();
  const tx = db.transaction(() => {
    if (input.is_default) {
      db.prepare('UPDATE consent_form_templates SET is_default = 0').run();
    }
    db.prepare(
      'UPDATE consent_form_templates SET name = ?, schema = ?, is_default = ? WHERE id = ?'
    ).run(input.name, JSON.stringify(input.schema), input.is_default ? 1 : 0, id);
  });
  tx();
  return getConsentTemplate(id);
}

export function deleteConsentTemplate(id: number): void {
  const db = getDb();
  const row = db.prepare('SELECT is_default FROM consent_form_templates WHERE id = ?').get(id) as
    | { is_default: number }
    | undefined;
  if (row?.is_default) {
    throw new Error('기본 템플릿은 삭제할 수 없습니다.');
  }
  db.prepare('DELETE FROM consent_form_templates WHERE id = ?').run(id);
}

// ── 요청 ───────────────────────────────────────────────────────────────────────

interface RequestRow {
  id: number;
  case_id: number;
  student_id: number;
  template_name: string;
  form_schema: string | null;
  token: string;
  public_key: string;
  private_key: string;
  status: ConsentStatus;
  channel: ConsentChannel;
  link: string | null;
  last_error: string | null;
  created_at: string;
  sent_at: string | null;
  responded_at: string | null;
  expires_at: string;
  student_name?: string;
}

/** 외부 노출용 매핑 — private_key는 절대 포함하지 않는다. */
function mapRequest(r: RequestRow): ConsentRequest {
  let schema: ConsentFormSchema | undefined;
  if (r.form_schema) {
    try { schema = JSON.parse(r.form_schema) as ConsentFormSchema; } catch { schema = undefined; }
  }
  return {
    id: r.id,
    case_id: r.case_id,
    student_id: r.student_id,
    template_name: r.template_name,
    form_schema: schema,
    token: r.token,
    public_key: r.public_key,
    status: r.status,
    channel: r.channel,
    link: r.link,
    last_error: r.last_error,
    created_at: r.created_at,
    sent_at: r.sent_at,
    responded_at: r.responded_at,
    expires_at: r.expires_at,
    student_name: r.student_name,
  };
}

function uniqueToken(db: ReturnType<typeof getDb>): string {
  for (let i = 0; i < 8; i++) {
    const token = randomBytes(18).toString('base64url'); // URL-safe, 24자
    const exists = db.prepare('SELECT 1 FROM consent_requests WHERE token = ?').get(token);
    if (!exists) return token;
  }
  throw new Error('토큰 생성에 실패했습니다.');
}

export interface CreateConsentRequestArgs {
  case_id: number;
  student_id: number;
  template_name: string;
  /** 폼 스키마 JSON 문자열(라벨 보존 스냅샷, 평문) */
  form_schema: string;
  public_key: string;
  private_key: string;
  channel: ConsentChannel;
  expiry_days: number;
}

/** sealed-box 키쌍은 호출자가 생성해 넘긴다. 토큰·만료는 여기서 결정. */
export function createConsentRequest(args: CreateConsentRequestArgs): ConsentRequest {
  const db = getDb();
  const key = getKey();
  const token = uniqueToken(db);
  const expiresAt = new Date(Date.now() + args.expiry_days * 86_400_000).toISOString();

  const res = db.prepare(
    `INSERT INTO consent_requests
       (case_id, student_id, template_name, form_schema, token, public_key, private_key, status, channel, expires_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)`
  ).run(
    args.case_id,
    args.student_id,
    args.template_name,
    args.form_schema,
    token,
    args.public_key,
    encryptValue(args.private_key, key),
    args.channel,
    expiresAt,
  );
  return getConsentRequestById(Number(res.lastInsertRowid))!;
}

/**
 * 동일 사례·학생의 진행 중(pending/sent) 요청 — 재발송 시 무효화 대상.
 *
 * templateName을 주면 **같은 양식**의 진행 중 요청만 반환한다(여러 양식을 동시에
 * 발송할 때 서로 다른 양식이 서로를 무효화하지 않도록 범위를 좁힘). 생략하면 양식
 * 구분 없이 전부 반환(레거시 동작 — 단일 발송 가정).
 *
 * SQL 빌드는 buildActiveRequestsQuery(순수·DB비의존)로 분리해 회귀 테스트가 검증한다.
 */
export function getActiveRequestsForStudent(
  caseId: number,
  studentId: number,
  templateName?: string,
): Array<{ id: number; token: string }> {
  const db = getDb();
  const { sql, params } = buildActiveRequestsQuery(caseId, studentId, templateName);
  return db.prepare(sql).all(...params) as Array<{ id: number; token: string }>;
}

export function getConsentRequestById(id: number): ConsentRequest | undefined {
  const db = getDb();
  const row = db.prepare('SELECT * FROM consent_requests WHERE id = ?').get(id) as
    | RequestRow
    | undefined;
  return row ? mapRequest(row) : undefined;
}

export function listConsentRequestsByCase(caseId: number): ConsentRequest[] {
  const db = getDb();
  const key = getKey();
  const rows = db.prepare(
    `SELECT r.*, s.name AS student_name
       FROM consent_requests r
       JOIN students s ON s.id = r.student_id
      WHERE r.case_id = ?
      ORDER BY r.created_at DESC`
  ).all(caseId) as RequestRow[];
  return rows.map((r) => {
    // 학생 이름은 students에서 암호화 저장 → 복호.
    const decryptedName = r.student_name ? decryptValue(r.student_name, key) : undefined;
    return mapRequest({ ...r, student_name: decryptedName });
  });
}

/** 개인키(복호)를 포함한 내부 조회 — 수합(복호) 전용. */
export function getConsentRequestWithPrivateKey(
  id: number,
): { request: ConsentRequest; privateKey: string } | undefined {
  const db = getDb();
  const key = getKey();
  const row = db.prepare('SELECT * FROM consent_requests WHERE id = ?').get(id) as
    | RequestRow
    | undefined;
  if (!row) return undefined;
  return { request: mapRequest(row), privateKey: decryptValue(row.private_key, key) };
}

/**
 * 토큰으로 요청의 복호 키·상태를 조회한다(상태·만료 무관).
 * 수합(poll)은 서버가 '응답완료'로 돌려준 토큰을 만료 여부와 무관하게 수합해야
 * 만료 직전 제출분 유실을 막을 수 있으므로, getPollableRequests 대신 이걸 쓴다.
 */
export function getRequestCryptoByToken(token: string): {
  id: number;
  status: ConsentStatus;
  public_key: string;
  private_key: string;
} | undefined {
  const db = getDb();
  const key = getKey();
  const row = db.prepare(
    'SELECT id, status, public_key, private_key FROM consent_requests WHERE token = ?'
  ).get(token) as
    | { id: number; status: ConsentStatus; public_key: string; private_key: string }
    | undefined;
  if (!row) return undefined;
  return { id: row.id, status: row.status, public_key: row.public_key, private_key: decryptValue(row.private_key, key) };
}

/** 폴링 대상: 서버에 살아있는 요청(발송됨/응답대기). 만료 제외. */
export function getPollableRequests(): Array<{
  id: number;
  token: string;
  public_key: string;
  private_key: string;
  expires_at: string;
}> {
  const db = getDb();
  const key = getKey();
  const nowIso = new Date().toISOString();
  const rows = db.prepare(
    `SELECT id, token, public_key, private_key, expires_at
       FROM consent_requests
      WHERE status IN ('sent', 'responded') AND expires_at > ?`
  ).all(nowIso) as Array<{
    id: number;
    token: string;
    public_key: string;
    private_key: string;
    expires_at: string;
  }>;
  return rows.map((r) => ({ ...r, private_key: decryptValue(r.private_key, key) }));
}

export interface UpdateRequestFields {
  status?: ConsentStatus;
  link?: string | null;
  last_error?: string | null;
  sent_at?: string | null;
  responded_at?: string | null;
}

export function updateConsentRequest(id: number, fields: UpdateRequestFields): void {
  const db = getDb();
  const sets: string[] = [];
  const vals: unknown[] = [];
  for (const [k, v] of Object.entries(fields)) {
    if (v === undefined) continue;
    sets.push(`${k} = ?`);
    vals.push(v);
  }
  if (sets.length === 0) return;
  vals.push(id);
  db.prepare(`UPDATE consent_requests SET ${sets.join(', ')} WHERE id = ?`).run(...vals);
}

/** 만료 처리: 기한 지난 미완료 요청을 expired로. 반환=처리 건수. */
export function expireStaleRequests(): number {
  const db = getDb();
  const nowIso = new Date().toISOString();
  const res = db.prepare(
    `UPDATE consent_requests SET status = 'expired'
      WHERE status IN ('pending', 'sent', 'responded') AND expires_at <= ?`
  ).run(nowIso);
  return res.changes;
}

// ── 응답 ───────────────────────────────────────────────────────────────────────

/** 복호된 응답을 로컬 암호화 저장하고 요청 상태를 ingested로. */
export function recordConsentResponse(
  requestId: number,
  answers: Record<string, unknown>,
  submittedAt: string,
): void {
  const db = getDb();
  const key = getKey();
  const tx = db.transaction(() => {
    db.prepare(
      `INSERT INTO consent_responses (request_id, answers, submitted_at)
       VALUES (?, ?, ?)
       ON CONFLICT(request_id) DO UPDATE SET answers = excluded.answers, submitted_at = excluded.submitted_at`
    ).run(requestId, encryptValue(JSON.stringify(answers), key), submittedAt);
    db.prepare(
      `UPDATE consent_requests SET status = 'ingested', responded_at = COALESCE(responded_at, ?) WHERE id = ?`
    ).run(submittedAt, requestId);
  });
  tx();
}

export function getConsentResponse(requestId: number): ConsentResponseRecord | undefined {
  const db = getDb();
  const key = getKey();
  const row = db.prepare('SELECT * FROM consent_responses WHERE request_id = ?').get(requestId) as
    | { id: number; request_id: number; answers: string; submitted_at: string; ingested_at: string }
    | undefined;
  if (!row) return undefined;
  return {
    id: row.id,
    request_id: row.request_id,
    answers: JSON.parse(decryptValue(row.answers, key)) as Record<string, unknown>,
    submitted_at: row.submitted_at,
    ingested_at: row.ingested_at,
  };
}

/** 발송용: 학생의 보호자 연락처(복호). 본문엔 절대 넣지 않고 게이트웨이 수신번호로만 사용. */
export function getGuardianContact(studentId: number): string | null {
  const db = getDb();
  const key = getKey();
  const row = db.prepare('SELECT guardian_contact FROM students WHERE id = ?').get(studentId) as
    | { guardian_contact: string | null }
    | undefined;
  if (!row?.guardian_contact) return null;
  return decryptValue(row.guardian_contact, key);
}
