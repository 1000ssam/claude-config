/**
 * 재발송 무효화 대상(진행 중 요청) 조회 SQL 빌더 — DB/암호화 비의존 순수 모듈.
 *
 * consent.ts 본체는 `@/lib/db` 등 electron 의존 모듈을 import하므로 node 단위
 * 테스트로 직접 불러올 수 없다. 무효화 "범위" 로직만 이 파일로 분리해, in-memory
 * SQLite로 회귀 테스트(scripts/consent-resend-scope.check.mts)가 검증한다.
 */

/**
 * 동일 사례·학생의 진행 중(pending/sent) 요청을 찾는 SQL/파라미터.
 * templateName을 주면 같은 양식만 대상으로 좁힌다(여러 양식 동시 발송 시 상호 무효화 방지).
 */
export function buildActiveRequestsQuery(
  caseId: number,
  studentId: number,
  templateName?: string,
): { sql: string; params: Array<string | number> } {
  const conds = ['case_id = ?', 'student_id = ?'];
  const params: Array<string | number> = [caseId, studentId];
  if (templateName !== undefined) {
    conds.push('template_name = ?');
    params.push(templateName);
  }
  conds.push("status IN ('pending', 'sent')");
  return {
    sql: `SELECT id, token FROM consent_requests WHERE ${conds.join(' AND ')}`,
    params,
  };
}
