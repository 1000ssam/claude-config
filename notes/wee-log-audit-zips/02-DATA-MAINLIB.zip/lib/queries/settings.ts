import { getDb } from '@/lib/db';
import { isKeyLoaded, getKey } from '@/lib/crypto/key-manager';
import { ENCRYPTED_SETTING_KEYS, decryptValue } from '@/lib/crypto/field-crypto';
import { encrypt, isEncrypted } from '@/lib/crypto/engine';
import type { AppSettings, SettingKey } from '@/types/settings';

export function getAllSettings(): AppSettings {
  const db = getDb();
  const rows = db.prepare('SELECT key, value FROM settings').all() as { key: string; value: string }[];
  const settings: Record<string, string> = {};

  for (const row of rows) {
    settings[row.key] = row.value;
  }

  // API 키는 암호화 저장 — 키가 로드된 경우에만 복호화 (잠금 상태에서는 빈 문자열)
  if (isKeyLoaded()) {
    const key = getKey();
    for (const settingKey of ENCRYPTED_SETTING_KEYS) {
      if (settings[settingKey]) {
        settings[settingKey] = decryptValue(settings[settingKey], key);
      }
    }
  } else {
    for (const settingKey of ENCRYPTED_SETTING_KEYS) {
      settings[settingKey] = '';
    }
  }

  return settings as unknown as AppSettings;
}

export function getSetting(key: SettingKey): string {
  const db = getDb();
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as { value: string } | undefined;
  const raw = row?.value ?? '';

  // API 키는 복호화 — 키가 없으면 빈 문자열 반환
  if (ENCRYPTED_SETTING_KEYS.has(key)) {
    if (!raw || !isKeyLoaded()) return '';
    return decryptValue(raw, getKey());
  }

  return raw;
}

export function updateSettings(updates: Partial<AppSettings>): void {
  const db = getDb();
  const stmt = db.prepare(
    "INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now', 'localtime'))"
  );

  const updateMany = db.transaction((data: Partial<AppSettings>) => {
    for (const [k, v] of Object.entries(data)) {
      if (v !== undefined) {
        let storeValue = v;
        // API 키는 암호화 후 저장
        if (ENCRYPTED_SETTING_KEYS.has(k) && v && isKeyLoaded()) {
          const encKey = getKey();
          storeValue = isEncrypted(v) ? v : encrypt(v, encKey);
        }
        stmt.run(k, storeValue);
      }
    }
  });

  updateMany(updates);
}
