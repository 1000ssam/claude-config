import { getDb } from '@/lib/db';
import { getKey } from '@/lib/crypto/key-manager';
import { decryptValue } from '@/lib/crypto/field-crypto';

export interface ReportsParams {
  year?: string;
}

export interface MonthlyTrend {
  month: string;
  count: number;
  hours: number;
}

export interface CaseSessionSummary {
  case_id: number;
  case_number: string;
  student_names: string;
  status: string;
  session_count: number;
  total_hours: number;
  first_session_date: string | null;
  last_session_date: string | null;
}

export interface CategoryDistribution {
  category: string;
  count: number;
  percentage: number;
}

export interface RecentSession {
  session_id: number;
  case_id: number;
  case_number: string;
  student_names: string;
  session_date: string;
  session_title: string;
  category_large: string;
  category_medium: string;
  medium: string;
  session_hour: number;
  session_minute: number;
}

export interface ReportsData {
  monthlyTrend: MonthlyTrend[];
  caseSessionSummary: CaseSessionSummary[];
  categoryDistribution: CategoryDistribution[];
  mediumDistribution: CategoryDistribution[];
  recentSessions: RecentSession[];
  totalCases: number;
  activeCases: number;
  avgSessionsPerCase: number;
}

function buildSessionWhere(params: ReportsParams, alias = 's'): { sql: string; args: unknown[] } {
  let sql = 'WHERE 1=1';
  const args: unknown[] = [];
  if (params.year) {
    sql += ` AND ${alias}.academic_year = ?`;
    args.push(params.year);
  }
  return { sql, args };
}

function toDistribution(rows: { category: string; count: number }[]): CategoryDistribution[] {
  const total = rows.reduce((sum, r) => sum + r.count, 0) || 1;
  return rows.map((r) => ({
    category: r.category,
    count: r.count,
    percentage: Math.round((r.count / total) * 1000) / 10,
  }));
}

export function getReportsData(params: ReportsParams): ReportsData {
  const db = getDb();
  const { sql: sessionWhere, args } = buildSessionWhere(params);

  const monthlyTrend = db.prepare(`
    SELECT
      substr(s.session_date, 1, 7) as month,
      COUNT(*) as count,
      ROUND(SUM(s.session_hour + s.session_minute / 60.0), 1) as hours
    FROM sessions s
    ${sessionWhere}
    GROUP BY month
    ORDER BY month
  `).all(...args) as MonthlyTrend[];

  // 세션도 연도 필터 적용 — 다른 연도 세션이 합산되지 않도록
  const sessionJoinCondition = params.year
    ? 'LEFT JOIN sessions s ON s.case_id = c.id AND s.academic_year = ?'
    : 'LEFT JOIN sessions s ON s.case_id = c.id';
  const caseWhere = params.year ? 'WHERE c.academic_year = ?' : 'WHERE 1=1';
  const caseArgs = params.year ? [params.year, params.year] : [];

  const caseSessionSummaryRaw = db.prepare(`
    SELECT
      c.id as case_id,
      c.case_number,
      c.status,
      COUNT(s.id) as session_count,
      ROUND(COALESCE(SUM(s.session_hour + s.session_minute / 60.0), 0), 1) as total_hours,
      MIN(s.session_date) as first_session_date,
      MAX(s.session_date) as last_session_date
    FROM cases c
    ${sessionJoinCondition}
    ${caseWhere}
    GROUP BY c.id
    ORDER BY session_count DESC
  `).all(...caseArgs) as (Omit<CaseSessionSummary, 'student_names'> & { case_id: number })[];

  const categoryDistribution = toDistribution(
    db.prepare(`
      SELECT s.category_large as category, COUNT(*) as count
      FROM sessions s
      ${sessionWhere}
      AND s.category_large IS NOT NULL AND s.category_large != ''
      GROUP BY s.category_large
      ORDER BY count DESC
    `).all(...args) as { category: string; count: number }[]
  );

  const mediumDistribution = toDistribution(
    db.prepare(`
      SELECT s.medium as category, COUNT(*) as count
      FROM sessions s
      ${sessionWhere}
      AND s.medium IS NOT NULL AND s.medium != ''
      GROUP BY s.medium
      ORDER BY count DESC
    `).all(...args) as { category: string; count: number }[]
  );

  const recentSessionsRaw = db.prepare(`
    SELECT
      s.id as session_id,
      s.case_id,
      c.case_number,
      s.session_date,
      s.session_title,
      s.category_large,
      s.category_medium,
      s.medium,
      s.session_hour,
      s.session_minute
    FROM sessions s
    JOIN cases c ON c.id = s.case_id
    ${sessionWhere}
    ORDER BY s.session_date DESC, s.created_at DESC
    LIMIT 10
  `).all(...args) as (Omit<RecentSession, 'student_names'> & { case_id: number })[];

  // case_students → students JOIN으로 학생 이름 조회
  const key = getKey();

  function buildStudentNames(caseId: number): string {
    const rows = db.prepare(`
      SELECT st.name FROM case_students cs
      JOIN students st ON st.id = cs.student_id
      WHERE cs.case_id = ?
    `).all(caseId) as { name: string }[];
    if (rows.length === 0) return '(학생 없음)';
    const names = rows.map((r) => decryptValue(r.name, key));
    return names.length === 1 ? names[0] : `${names[0]} 외 ${names.length - 1}명`;
  }

  const nameCache = new Map<number, string>();
  function getCachedNames(caseId: number): string {
    if (!nameCache.has(caseId)) nameCache.set(caseId, buildStudentNames(caseId));
    return nameCache.get(caseId)!;
  }

  const caseSessionSummary: CaseSessionSummary[] = caseSessionSummaryRaw.map((row) => ({
    ...row,
    student_names: getCachedNames(row.case_id),
  }));

  const recentSessions: RecentSession[] = recentSessionsRaw.map((row) => ({
    ...row,
    student_names: getCachedNames(row.case_id),
  }));

  // totalCases/activeCases는 caseSessionSummary에서 파생 (별도 쿼리 불필요)
  const totalCases = caseSessionSummary.length;
  const activeCases = caseSessionSummary.filter(c => c.status === 'active').length;
  const avgSessionsPerCase = totalCases > 0
    ? Math.round((caseSessionSummary.reduce((sum, c) => sum + c.session_count, 0) / totalCases) * 10) / 10
    : 0;

  return {
    monthlyTrend,
    caseSessionSummary,
    categoryDistribution,
    mediumDistribution,
    recentSessions,
    totalCases,
    activeCases,
    avgSessionsPerCase,
  };
}
