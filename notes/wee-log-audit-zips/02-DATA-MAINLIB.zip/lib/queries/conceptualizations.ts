import { getDb } from '@/lib/db';
import { getKey } from '@/lib/crypto/key-manager';
import { encryptValue, decryptValue } from '@/lib/crypto/field-crypto';
import { isEncrypted } from '@/lib/crypto/engine';
import type { CaseConceptualization, UpsertConceptualizationInput } from '@/types/conceptualization';

function decryptSections(raw: string, key: Buffer): Record<string, string> {
  const plainJson = isEncrypted(raw) ? decryptValue(raw, key) : raw;
  try {
    return JSON.parse(plainJson || '{}');
  } catch {
    return {};
  }
}

export function getConceptualization(caseId: number): CaseConceptualization | undefined {
  const db = getDb();
  const key = getKey();
  const row = db.prepare(
    'SELECT * FROM case_conceptualizations WHERE case_id = ?'
  ).get(caseId) as Record<string, unknown> | undefined;
  if (!row) return undefined;

  return {
    id: row.id as number,
    case_id: row.case_id as number,
    template_type: row.template_type as string,
    sections: decryptSections(row.sections as string, key),
    created_at: row.created_at as string,
    updated_at: row.updated_at as string,
  };
}

export function upsertConceptualization(
  caseId: number,
  input: UpsertConceptualizationInput,
): CaseConceptualization {
  const db = getDb();
  const key = getKey();

  // 값 검증: Record<string, string> 구조만 허용
  const cleanSections: Record<string, string> = {};
  for (const [k, v] of Object.entries(input.sections)) {
    if (typeof k !== 'string' || typeof v !== 'string') continue;
    if (v.trim()) {
      cleanSections[k] = v;
    }
  }

  const encryptedSections = encryptValue(JSON.stringify(cleanSections), key);

  const existing = db.prepare(
    'SELECT id FROM case_conceptualizations WHERE case_id = ?'
  ).get(caseId) as { id: number } | undefined;

  if (existing) {
    db.prepare(
      'UPDATE case_conceptualizations SET template_type = ?, sections = ? WHERE id = ?'
    ).run(input.template_type, encryptedSections, existing.id);
  } else {
    db.prepare(
      'INSERT INTO case_conceptualizations (case_id, template_type, sections) VALUES (?, ?, ?)'
    ).run(caseId, input.template_type, encryptedSections);
  }

  const result = getConceptualization(caseId);
  if (!result) throw new Error('Failed to upsert conceptualization');
  return result;
}

export function deleteConceptualization(caseId: number): void {
  const db = getDb();
  db.prepare('DELETE FROM case_conceptualizations WHERE case_id = ?').run(caseId);
}
