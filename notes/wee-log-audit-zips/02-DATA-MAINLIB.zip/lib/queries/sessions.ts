import { getDb } from '@/lib/db';
import { getKey } from '@/lib/crypto/key-manager';
import { decryptRow, decryptValue, encryptValue } from '@/lib/crypto/field-crypto';
import { getAcademicYearFromDateStr } from '@/lib/academic-year';
import type { Session, SessionStudent, CreateSessionInput, UpdateSessionInput } from '@/types/session';

/** session_students + students를 JOIN하여 참여 학생 목록을 반환한다. */
function getSessionStudents(sessionId: number): SessionStudent[] {
  const db = getDb();
  const key = getKey();

  const rows = db.prepare(`
    SELECT st.id as student_id, st.name
    FROM session_students ss
    JOIN students st ON st.id = ss.student_id
    WHERE ss.session_id = ?
  `).all(sessionId) as Record<string, unknown>[];

  return rows.map((r) => ({
    student_id: r.student_id as number,
    name: decryptValue(r.name as string, key),
  }));
}

/** 여러 session의 학생 목록을 한 번에 조회한다. */
function getSessionStudentsBatch(sessionIds: number[]): Map<number, SessionStudent[]> {
  if (sessionIds.length === 0) return new Map();

  const db = getDb();
  const key = getKey();

  const placeholders = sessionIds.map(() => '?').join(',');
  const rows = db.prepare(`
    SELECT ss.session_id, st.id as student_id, st.name
    FROM session_students ss
    JOIN students st ON st.id = ss.student_id
    WHERE ss.session_id IN (${placeholders})
  `).all(...sessionIds) as Record<string, unknown>[];

  const map = new Map<number, SessionStudent[]>();
  for (const r of rows) {
    const sid = r.session_id as number;
    if (!map.has(sid)) map.set(sid, []);
    map.get(sid)!.push({
      student_id: r.student_id as number,
      name: decryptValue(r.name as string, key),
    });
  }
  return map;
}

/**
 * student_ids로부터 sessions에 저장할 grade/gender/headcount를 자동 계산한다.
 * [의도적 비정규화] session_students JOIN으로 매번 계산할 수 있지만,
 * NEIS 엑셀 내보내기 포맷이 sessions 행에 이 값들을 요구하므로 저장한다.
 * 세션 생성/수정 시 이 함수가 호출되어 자동으로 채운다.
 *
 * - grade: 전원 동일 → 해당 학년 / 다르면 → '혼합'
 * - gender: 전원 동일 → 해당 성별 / 다르면 → '혼성'
 * - headcount: studentIds.length
 */
function computeDemographics(studentIds: number[], academicYear: string): { grade: string; gender: string; headcount: number } {
  if (studentIds.length === 0) {
    return { grade: '해당없음', gender: '해당없음', headcount: 0 };
  }

  const db = getDb();
  const placeholders = studentIds.map(() => '?').join(',');
  const rows = db.prepare(`
    SELECT
      st.gender,
      e.grade
    FROM students st
    LEFT JOIN student_enrollments e ON e.student_id = st.id AND e.academic_year = ?
    WHERE st.id IN (${placeholders})
  `).all(academicYear, ...studentIds) as { gender: string | null; grade: string | null }[];

  const grades = new Set(rows.map((r) => r.grade).filter(Boolean));
  const genders = new Set(rows.map((r) => r.gender).filter(Boolean));

  const grade = grades.size === 1 ? [...grades][0]! : grades.size === 0 ? '해당없음' : '혼합';
  const gender = genders.size === 1 ? [...genders][0]! : genders.size === 0 ? '해당없음' : '혼성';

  return { grade, gender, headcount: studentIds.length };
}

/**
 * 사례 내 상담 세션(category_large='상담')의 동적 회차 번호 맵을 반환한다.
 * 날짜 오름차순 기준으로 1, 2, 3... 부여. 비상담 세션은 맵에 포함되지 않음.
 */
export function getCounselingNumberMap(caseId: number): Map<number, number> {
  const db = getDb();
  const rows = db.prepare(
    `SELECT id FROM sessions WHERE case_id = ? AND category_large = '상담'
     ORDER BY session_date ASC, created_at ASC, id ASC`
  ).all(caseId) as { id: number }[];
  return new Map(rows.map((r, i) => [r.id, i + 1]));
}

export function getSessionsByCaseId(caseId: number): Session[] {
  const db = getDb();
  const key = getKey();
  const rows = db.prepare(
    'SELECT * FROM sessions WHERE case_id = ? ORDER BY session_date DESC, created_at DESC'
  ).all(caseId) as Record<string, unknown>[];

  const sessionIds = rows.map((r) => r.id as number);
  const studentsMap = getSessionStudentsBatch(sessionIds);
  const numberMap = getCounselingNumberMap(caseId);

  return rows.map((r) => {
    const dec = decryptRow('sessions', r, key) as Session;
    dec.students = studentsMap.get(dec.id) || [];
    dec.session_number = numberMap.get(dec.id) ?? null;
    return dec;
  });
}

export function getSessionById(sessionId: number): Session | undefined {
  const db = getDb();
  const key = getKey();
  const row = db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId) as Record<string, unknown> | undefined;
  if (!row) return undefined;
  const dec = decryptRow('sessions', row, key) as Session;
  dec.students = getSessionStudents(sessionId);
  const numberMap = getCounselingNumberMap(dec.case_id);
  dec.session_number = numberMap.get(dec.id) ?? null;
  return dec;
}

export function createSession(caseId: number, input: CreateSessionInput): Session {
  const db = getDb();
  const key = getKey();

  // 연구 카테고리는 학생 없이 등록 가능, 나머지 5개 대분류는 학생 필수
  const studentIds = input.student_ids ?? [];
  if (studentIds.length === 0 && input.category_large !== '연구') {
    throw new Error('최소 1명의 참여 학생을 선택해야 합니다.');
  }

  // [의도적 비정규화] grade/gender/headcount는 session_students에서 매번 계산 가능하지만,
  // NEIS 엑셀 내보내기(neis-columns.ts)가 sessions 행 단위로 이 값들을 요구하므로 저장한다.
  // counselor_affil도 settings.counselor_affiliation에서 참조 가능하지만,
  // 세션 시점의 상담사 소속을 보존하기 위해 세션별로 저장한다. (소속 변경 시 기존 기록 유지)
  const sessionAcademicYear = getAcademicYearFromDateStr(input.session_date);
  const { grade, gender, headcount } = computeDemographics(studentIds, sessionAcademicYear);

  const newId = db.transaction(() => {
    // session_number는 저장하지 않음 — 조회 시 날짜순으로 동적 계산 (getCounselingNumberMap)
    const insertResult = db.prepare(`
      INSERT INTO sessions (
        case_id, counseling_class, wee_class, category_large, category_medium,
        category_detail, headcount, academic_year, session_date, appointment_time,
        reminder_minutes, grade, gender, session_title, session_content,
        session_hour, session_minute, counselor_affil, medium, session_number, internal_notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      caseId,
      input.counseling_class,
      input.wee_class,
      input.category_large,
      input.category_medium,
      input.category_detail,
      headcount,
      input.academic_year,
      input.session_date,
      input.appointment_time ?? null,
      input.reminder_minutes ?? null,
      grade,
      gender,
      input.session_title,
      // session_content는 NOT NULL이므로 빈 문자열은 '' 그대로 저장, 값이 있으면 암호화
      input.session_content ? encryptValue(input.session_content, key) : '',
      input.session_hour,
      input.session_minute,
      input.counselor_affil,
      input.medium,
      null,
      encryptValue(input.internal_notes, key),
    );

    const sessionId = Number(insertResult.lastInsertRowid);

    // session_students 관계 등록
    const insertSS = db.prepare(
      'INSERT INTO session_students (session_id, student_id) VALUES (?, ?)'
    );
    for (const sid of studentIds) {
      insertSS.run(sessionId, sid);
    }

    return sessionId;
  })();

  const newSession = getSessionById(newId);
  if (!newSession) throw new Error('Failed to create session');
  return newSession;
}

// UPDATE 시 허용되는 컬럼 목록 (컬럼 인젝션 방지)
const ALLOWED_SESSION_UPDATE_FIELDS = new Set<string>([
  'counseling_class', 'wee_class', 'category_large', 'category_medium', 'category_detail',
  'academic_year', 'session_date', 'appointment_time', 'reminder_minutes',
  'session_title', 'session_content', 'session_hour', 'session_minute',
  'counselor_affil', 'medium', 'internal_notes',
]);

/** session_content가 변경되면 요약을 stale 처리할 때 함께 비울 컬럼들. */
const SUMMARY_RESET_SQL = `summary_short = NULL,
  summary_status = 'pending',
  summary_generated_at = NULL`;

// 암호화 대상 업데이트 필드
const ENCRYPTED_SESSION_UPDATE_FIELDS = new Set([
  'session_content', 'internal_notes',
]);

export function updateSession(sessionId: number, input: UpdateSessionInput): Session | undefined {
  const db = getDb();
  const key = getKey();

  db.transaction(() => {
    // session_date 변경 시 academic_year를 자동 산출하여 반영
    if (input.session_date) {
      input.academic_year = getAcademicYearFromDateStr(input.session_date);
    }

    // student_ids 변경 시: 연구 외 카테고리는 학생 필수 검증
    if (input.student_ids && input.student_ids.length === 0) {
      // category_large가 업데이트에 포함되어 있으면 그 값을, 아니면 DB 기존 값을 기준으로 판단
      const effectiveCategory = input.category_large
        ?? (db.prepare('SELECT category_large FROM sessions WHERE id = ?').get(sessionId) as { category_large: string }).category_large;
      if (effectiveCategory !== '연구') {
        throw new Error('최소 1명의 참여 학생을 선택해야 합니다.');
      }
    }

    // student_ids 변경 시: 관계 재구성 + demographics 재계산 (의도적 비정규화 값 갱신)
    if (input.student_ids) {
      db.prepare('DELETE FROM session_students WHERE session_id = ?').run(sessionId);
      const insertSS = db.prepare(
        'INSERT INTO session_students (session_id, student_id) VALUES (?, ?)'
      );
      for (const studentId of input.student_ids) {
        insertSS.run(sessionId, studentId);
      }

      // 세션의 session_date로 학년도 결정 (업데이트된 값 또는 기존 값)
      const effectiveDate = input.session_date
        ?? (db.prepare('SELECT session_date FROM sessions WHERE id = ?').get(sessionId) as { session_date: string }).session_date;
      const academicYear = getAcademicYearFromDateStr(effectiveDate);
      const { grade, gender, headcount } = computeDemographics(input.student_ids, academicYear);
      db.prepare(
        'UPDATE sessions SET grade = ?, gender = ?, headcount = ? WHERE id = ?'
      ).run(grade, gender, headcount, sessionId);
    }

    // 나머지 컬럼 업데이트
    const fields: string[] = [];
    const values: unknown[] = [];
    // session_content가 실제로 바뀌면 기존 요약은 stale → 큐가 재요약하도록 마킹.
    let resetSummary = false;

    for (const [k, v] of Object.entries(input)) {
      if (k === 'student_ids') continue;
      if (v !== undefined && ALLOWED_SESSION_UPDATE_FIELDS.has(k)) {
        fields.push(`${k} = ?`);
        const raw = v as string | null;
        let stored: unknown;
        if (ENCRYPTED_SESSION_UPDATE_FIELDS.has(k)) {
          // session_content는 NOT NULL — 빈 문자열은 '' 유지. 그 외(internal_notes)는 기존대로 null 허용
          if (k === 'session_content' && !raw) stored = '';
          else stored = encryptValue(raw, key);
        } else {
          stored = raw;
        }
        values.push(stored);
        if (k === 'session_content') resetSummary = true;
      }
    }

    if (fields.length > 0) {
      values.push(sessionId);
      const setClause = resetSummary
        ? `${fields.join(', ')}, ${SUMMARY_RESET_SQL}`
        : fields.join(', ');
      db.prepare(`UPDATE sessions SET ${setClause} WHERE id = ?`).run(...values);
    }
  })();

  return getSessionById(sessionId);
}

export function deleteSession(sessionId: number): void {
  const db = getDb();
  db.prepare('DELETE FROM sessions WHERE id = ?').run(sessionId);
}

export function getSessionsForExport(params: {
  year?: string;
  from?: string;
  to?: string;
  caseIds?: number[];
}): Session[] {
  const db = getDb();
  const key = getKey();

  let sql = 'SELECT * FROM sessions WHERE 1=1';
  const args: unknown[] = [];

  if (params.year) {
    sql += ' AND academic_year = ?';
    args.push(params.year);
  }
  if (params.from) {
    sql += ' AND session_date >= ?';
    args.push(params.from);
  }
  if (params.to) {
    sql += ' AND session_date <= ?';
    args.push(params.to);
  }
  if (params.caseIds && params.caseIds.length > 0) {
    sql += ` AND case_id IN (${params.caseIds.map(() => '?').join(',')})`;
    args.push(...params.caseIds);
  }
  sql += ' ORDER BY session_date ASC';

  const rows = db.prepare(sql).all(...args) as Record<string, unknown>[];
  return rows.map((r) => {
    const dec = decryptRow('sessions', r, key) as Session;
    dec.students = [];
    return dec;
  });
}

export function updateSessionDate(sessionId: number, newDate: string): void {
  const db = getDb();
  db.prepare('UPDATE sessions SET session_date = ? WHERE id = ?').run(newDate, sessionId);
}

// ─── 회기 요약 (Phase 4 — summary-queue 전용) ────────────────────────────────

/**
 * AI가 생성한 요약을 저장한다. summary_short는 암호화, status='done', generated_at=now.
 * - 빈 문자열은 거부 (의미 없는 마킹 방지).
 */
export function setSessionSummary(sessionId: number, summaryText: string): void {
  const trimmed = (summaryText || '').trim();
  if (!trimmed) {
    throw new Error('setSessionSummary: empty summary');
  }
  const db = getDb();
  const key = getKey();
  const encrypted = encryptValue(trimmed, key);
  db.prepare(
    `UPDATE sessions
       SET summary_short = ?,
           summary_status = 'done',
           summary_generated_at = datetime('now', 'localtime')
     WHERE id = ?`,
  ).run(encrypted, sessionId);
}

/**
 * 요약 상태만 변경한다. 큐가 재시도 한도에 도달하면 'failed'로, 사용자가 갱신을
 * 다시 트리거하면 'pending'으로 되돌릴 때 사용.
 */
export function markSessionSummaryStatus(
  sessionId: number,
  status: 'pending' | 'failed',
): void {
  const db = getDb();
  db.prepare('UPDATE sessions SET summary_status = ? WHERE id = ?').run(status, sessionId);
}

/**
 * 요약이 필요한(pending/failed) 회기 ID 목록. 큐 부트스트랩과 사이드패널의
 * "요약 N건 누락" 카운터에서 사용.
 */
export function listSessionsNeedingSummary(caseId?: number): number[] {
  const db = getDb();
  const args: unknown[] = [];
  let sql = `SELECT id FROM sessions
             WHERE summary_status IN ('pending', 'failed')
               AND session_content <> ''`;
  if (caseId !== undefined) {
    sql += ' AND case_id = ?';
    args.push(caseId);
  }
  sql += ' ORDER BY session_date ASC, id ASC';
  const rows = db.prepare(sql).all(...args) as { id: number }[];
  return rows.map((r) => r.id);
}
