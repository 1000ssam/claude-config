import { getDb } from '@/lib/db';
import { getKey } from '@/lib/crypto/key-manager';
import { encryptRow, decryptRow, encryptValue, decryptValue } from '@/lib/crypto/field-crypto';
import { getAcademicYear } from '@/lib/academic-year';
import type { Case, CaseStudent, CaseWithSessionCount, CreateCaseInput, UpdateCaseInput } from '@/types/case';

/** case_students + students + enrollments를 JOIN하여 사례의 학생 목록을 반환한다. */
function getCaseStudents(caseId: number): CaseStudent[] {
  const db = getDb();
  const key = getKey();

  const rows = db.prepare(`
    SELECT
      st.id as student_id,
      st.name,
      st.gender,
      st.guardian_name,
      st.guardian_relation,
      st.guardian_contact,
      e.grade,
      e.class_name,
      e.number
    FROM case_students cs
    JOIN cases c ON c.id = cs.case_id
    JOIN students st ON st.id = cs.student_id
    LEFT JOIN student_enrollments e ON e.student_id = st.id AND e.academic_year = c.academic_year
    WHERE cs.case_id = ?
    ORDER BY e.grade ASC, e.class_name ASC, e.number ASC
  `).all(caseId) as Record<string, unknown>[];

  return rows.map((r) => {
    const dec = decryptRow('students', r, key);
    return {
      student_id: r.student_id as number,
      name: dec.name as string,
      grade: (r.grade as string | null) || null,
      class_name: (r.class_name as string | null) || null,
      number: (r.number as string | null) || null,
      gender: (r.gender as string | null) || null,
      guardian_name: (dec.guardian_name as string | null) || null,
      guardian_relation: (r.guardian_relation as string | null) || null,
      guardian_contact: (dec.guardian_contact as string | null) || null,
    };
  });
}

/** 여러 case의 학생 목록을 한 번에 조회한다. */
function getCaseStudentsBatch(caseIds: number[]): Map<number, CaseStudent[]> {
  if (caseIds.length === 0) return new Map();

  const db = getDb();
  const key = getKey();

  const placeholders = caseIds.map(() => '?').join(',');
  const rows = db.prepare(`
    SELECT
      cs.case_id,
      st.id as student_id,
      st.name,
      st.gender,
      st.guardian_name,
      st.guardian_relation,
      st.guardian_contact,
      e.grade,
      e.class_name,
      e.number
    FROM case_students cs
    JOIN cases c ON c.id = cs.case_id
    JOIN students st ON st.id = cs.student_id
    LEFT JOIN student_enrollments e ON e.student_id = st.id AND e.academic_year = c.academic_year
    WHERE cs.case_id IN (${placeholders})
    ORDER BY e.grade ASC, e.class_name ASC, e.number ASC
  `).all(...caseIds) as Record<string, unknown>[];

  const map = new Map<number, CaseStudent[]>();
  for (const r of rows) {
    const caseId = r.case_id as number;
    if (!map.has(caseId)) map.set(caseId, []);
    const dec = decryptRow('students', r, key);
    map.get(caseId)!.push({
      student_id: r.student_id as number,
      name: dec.name as string,
      grade: (r.grade as string | null) || null,
      class_name: (r.class_name as string | null) || null,
      number: (r.number as string | null) || null,
      gender: (r.gender as string | null) || null,
      guardian_name: (dec.guardian_name as string | null) || null,
      guardian_relation: (r.guardian_relation as string | null) || null,
      guardian_contact: (dec.guardian_contact as string | null) || null,
    });
  }
  return map;
}

export function getCases(params: {
  year?: string;
  status?: string;
  search?: string;
}): CaseWithSessionCount[] {
  const db = getDb();
  const key = getKey();

  let sql = `
    SELECT c.*,
      COUNT(s.id) as session_count,
      MAX(s.session_date) as last_session_date
    FROM cases c
    LEFT JOIN sessions s ON s.case_id = c.id
    WHERE 1=1
  `;
  const args: unknown[] = [];

  if (params.year) {
    sql += ' AND c.academic_year = ?';
    args.push(params.year);
  }
  if (params.status && params.status !== 'all') {
    sql += ' AND c.status = ?';
    args.push(params.status);
  }
  sql += ' GROUP BY c.id ORDER BY c.created_at DESC';

  const rows = db.prepare(sql).all(...args) as Record<string, unknown>[];
  const caseIds = rows.map((r) => r.id as number);
  const studentsMap = getCaseStudentsBatch(caseIds);

  const decrypted = rows.map((r) => {
    const dec = decryptRow('cases', r, key) as CaseWithSessionCount;
    dec.students = studentsMap.get(dec.id) || [];
    return dec;
  });

  if (!params.search) return decrypted;

  const q = params.search.toLowerCase();
  return decrypted.filter(
    (c) =>
      c.students.some((st) => st.name.toLowerCase().includes(q)) ||
      c.case_number?.toLowerCase().includes(q) ||
      c.main_complaint?.toLowerCase().includes(q),
  );
}

export function getCaseById(id: number): Case | undefined {
  const db = getDb();
  const key = getKey();
  const row = db.prepare('SELECT * FROM cases WHERE id = ?').get(id) as Record<string, unknown> | undefined;
  if (!row) return undefined;
  const dec = decryptRow('cases', row, key) as Case;
  dec.students = getCaseStudents(id);
  return dec;
}

export function createCase(input: CreateCaseInput): Case {
  const db = getDb();
  const key = getKey();

  if (!input.student_ids || input.student_ids.length === 0) {
    throw new Error('최소 1명의 학생을 선택해야 합니다.');
  }

  const year = input.academic_year || getAcademicYear(new Date());

  const maxRow = db.prepare(
    'SELECT case_number FROM cases WHERE academic_year = ? ORDER BY case_number DESC LIMIT 1'
  ).get(year) as { case_number: string } | undefined;

  let seq = 1;
  if (maxRow) {
    const parts = maxRow.case_number.split('-');
    const lastSeq = parseInt(parts[parts.length - 1], 10);
    if (!isNaN(lastSeq)) seq = lastSeq + 1;
  }
  const caseNumber = `${year}-${String(seq).padStart(3, '0')}`;

  const newId = db.transaction(() => {
    // [의도적 비정규화] referrer_name/role/contact는 케이스별로 저장한다.
    // 같은 교사라도 케이스마다 역할(담임/교과 등)이 다를 수 있고,
    // name/contact은 암호화 대상이라 마스터 테이블로 분리해도 DB 레벨 중복 검사가 불가능하다.
    // referrer_role은 CHECK 제약으로 허용 값을 제한한다. (db-init.ts 참조)
    const insertResult = db.prepare(`
      INSERT INTO cases (
        case_number, academic_year,
        referrer_name, referrer_role, referrer_contact,
        main_complaint, counseling_goal, teacher_opinion, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      caseNumber, year,
      encryptValue(input.referrer_name, key),
      input.referrer_role || null,
      encryptValue(input.referrer_contact, key),
      encryptValue(input.main_complaint, key),
      encryptValue(input.counseling_goal, key),
      encryptValue(input.teacher_opinion, key),
      encryptValue(input.notes, key),
    );

    const caseId = Number(insertResult.lastInsertRowid);

    // case_students 관계 등록
    const insertCS = db.prepare(
      'INSERT INTO case_students (case_id, student_id) VALUES (?, ?)'
    );
    for (const studentId of input.student_ids) {
      insertCS.run(caseId, studentId);
    }

    return caseId;
  })();

  const newCase = getCaseById(newId);
  if (!newCase) throw new Error('Failed to create case');
  return newCase;
}

// UPDATE 시 허용되는 컬럼 목록 (컬럼 인젝션 방지)
const ALLOWED_CASE_UPDATE_FIELDS = new Set<string>([
  'referrer_name', 'referrer_role', 'referrer_contact',
  'main_complaint', 'counseling_goal', 'teacher_opinion', 'notes',
  'status', 'close_reason', 'close_reason_detail',
]);

// 암호화 대상 업데이트 필드
const ENCRYPTED_CASE_UPDATE_FIELDS = new Set([
  'referrer_name', 'referrer_contact',
  'main_complaint', 'counseling_goal', 'teacher_opinion', 'notes',
]);

export function updateCase(id: number, input: UpdateCaseInput): Case | undefined {
  const db = getDb();
  const key = getKey();

  db.transaction(() => {
    // student_ids 변경 처리
    if (input.student_ids) {
      db.prepare('DELETE FROM case_students WHERE case_id = ?').run(id);
      const insertCS = db.prepare(
        'INSERT INTO case_students (case_id, student_id) VALUES (?, ?)'
      );
      for (const studentId of input.student_ids) {
        insertCS.run(id, studentId);
      }
    }

    // 나머지 컬럼 업데이트
    const fields: string[] = [];
    const values: unknown[] = [];

    for (const [k, v] of Object.entries(input)) {
      if (k === 'student_ids') continue;
      if (v !== undefined && ALLOWED_CASE_UPDATE_FIELDS.has(k)) {
        fields.push(`${k} = ?`);
        const raw = v === '' ? null : v as string | null;
        values.push(ENCRYPTED_CASE_UPDATE_FIELDS.has(k) ? encryptValue(raw, key) : raw);
      }
    }

    if (fields.length > 0) {
      values.push(id);
      db.prepare(`UPDATE cases SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    }
  })();

  return getCaseById(id);
}

export function deleteCase(id: number): void {
  const db = getDb();
  db.prepare('DELETE FROM cases WHERE id = ?').run(id);
}
