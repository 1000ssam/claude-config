import ExcelJS from 'exceljs';
import { NEIS_COLUMNS } from '@/lib/constants/neis-columns';
import type { Session } from '@/types/session';

const DEFAULT_FONT: Partial<ExcelJS.Font> = { name: '맑은 고딕', size: 10 };

export async function generateXlsx(sessions: Session[]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('입력');

  // Set column definitions with widths
  worksheet.columns = NEIS_COLUMNS.map((col) => ({
    key: col.key,
    width: col.width,
  }));

  // Add header row with prefixed required fields
  const headerRow = worksheet.addRow(
    NEIS_COLUMNS.map((col) => (col.required ? `*${col.header}` : col.header))
  );

  // Style header row
  headerRow.font = { ...DEFAULT_FONT, bold: true };
  headerRow.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: 'FFE0E0E0' },
  };

  // Add data rows
  sessions.forEach((session) => {
    const rowData: Record<string, unknown> = {};
    NEIS_COLUMNS.forEach((col) => {
      rowData[col.key] = session[col.key as keyof Session];
    });
    const row = worksheet.addRow(rowData);
    row.font = DEFAULT_FONT;
  });

  // Generate buffer
  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}
