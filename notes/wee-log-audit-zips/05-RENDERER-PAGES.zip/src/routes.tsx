import type { RouteObject } from 'react-router-dom';

import DashboardPage from './pages/DashboardPage';
import CasesPage from './pages/CasesPage';
import NewCasePage from './pages/NewCasePage';
import CaseDetailPage from './pages/CaseDetailPage';
import NewSessionPage from './pages/NewSessionPage';
import SessionDetailPage from './pages/SessionDetailPage';
import StatisticsPage from './pages/StatisticsPage';
import SettingsPage from './pages/SettingsPage';
import ReportsPage from './pages/ReportsPage';
import StudentsPage from './pages/StudentsPage';
import StudentDetailPage from './pages/StudentDetailPage';
import { NoticesPage } from './pages/NoticesPage';
import { CommunityPage } from './pages/CommunityPage';

/**
 * 탭별 독립 MemoryRouter가 공유하는 라우트 정의.
 * App.tsx의 단일 <Routes>를 대체하며, 각 탭은 이 라우트로
 * createMemoryRouter를 만들어 독립 네비게이션 스택을 가진다.
 */
export const appRoutes: RouteObject[] = [
  { path: '/', element: <DashboardPage /> },
  { path: '/cases', element: <CasesPage /> },
  { path: '/cases/new', element: <NewCasePage /> },
  { path: '/cases/:caseId', element: <CaseDetailPage /> },
  { path: '/cases/:caseId/sessions/new', element: <NewSessionPage /> },
  { path: '/cases/:caseId/sessions/:sessionId', element: <SessionDetailPage /> },
  { path: '/students', element: <StudentsPage /> },
  { path: '/students/:studentId', element: <StudentDetailPage /> },
  { path: '/statistics', element: <StatisticsPage /> },
  { path: '/settings', element: <SettingsPage /> },
  { path: '/reports', element: <ReportsPage /> },
  { path: '/notices', element: <NoticesPage /> },
  { path: '/community', element: <CommunityPage /> },
];
