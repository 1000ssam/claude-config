import { useEffect, useState, useMemo } from 'react';
import { Search, X, Pencil, Trash2, Plus, Save, RefreshCw, Upload, GraduationCap, Check } from 'lucide-react';
import { useTabNav } from '@/hooks/use-tab-nav';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { FilterPopover } from '@/components/ui/filter-popover';
import { SortPopover } from '@/components/ui/sort-popover';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { StudentUploadDialog, type UploadPreview } from '@/components/students/student-upload-dialog';
import { StudentFormFields } from '@/components/students/student-form-fields';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { LoadingState, ErrorState } from '@/components/ui/states';
import { useToast } from '@/hooks/use-toast';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { getGraduationGrade } from '@/lib/constants/options';
import { cn } from '@/lib/utils';
import { applyFiltersAndSort, getDistinctValues } from '@/lib/filter-sort';
import { useStudentForm } from '@/hooks/use-student-form';
import { Switch } from '@/components/ui/switch';
import type { Student, StudentWithCaseCount, CreateStudentInput, UpdateStudentInput } from '@/types/student';

// ── 필터 / 정렬 타입 ─────────────────────────────────────────────────────────

const STUDENT_FILTER_COLUMNS = [
  { key: 'grade', label: '학년' },
  { key: 'class_name', label: '반' },
  { key: 'gender', label: '성별' },
] as const;
type StudentFilterKey = typeof STUDENT_FILTER_COLUMNS[number]['key'];
type StudentFilters = Partial<Record<StudentFilterKey, string[]>>;

type StudentSortKey = 'name' | 'grade' | 'class_name' | 'number' | 'case_count';
type StudentSort = { col: StudentSortKey; dir: 'asc' | 'desc' } | null;

const STUDENT_SORT_COLUMNS = [
  { key: 'name', label: '이름' },
  { key: 'grade', label: '학년' },
  { key: 'class_name', label: '반' },
  { key: 'number', label: '번호' },
  { key: 'case_count', label: '사례' },
] as const;

const TABLE_COLUMNS = [
  { key: 'name', label: '이름', sortable: true, filterable: false },
  { key: 'grade', label: '학년', sortable: true, filterable: true },
  { key: 'class_name', label: '반', sortable: true, filterable: true },
  { key: 'number', label: '번호', sortable: true, filterable: false },
  { key: 'gender', label: '성별', sortable: false, filterable: true },
  { key: 'case_count', label: '사례', sortable: true, filterable: false },
] as const;

// ── 헤더 팝오버 콘텐츠 ───────────────────────────────────────────────────────
function HeaderPopoverContent({
  colKey,
  sortable,
  filterable,
  sort,
  onSort,
  values,
  activeFilters,
  onFilterToggle,
  onFilterClear,
}: {
  colKey: string;
  sortable: boolean;
  filterable: boolean;
  sort: StudentSort;
  onSort: (dir: 'asc' | 'desc' | null) => void;
  values: string[];
  activeFilters: string[];
  onFilterToggle: (val: string) => void;
  onFilterClear: () => void;
}) {
  const [search, setSearch] = useState('');
  const filtered = search ? values.filter((v) => v.toLowerCase().includes(search.toLowerCase())) : values;

  return (
    <>
      {sortable && (
        <div className="py-1">
          {(['asc', 'desc'] as const).map((dir) => {
            const active = sort?.col === colKey && sort.dir === dir;
            return (
              <button
                key={dir}
                className="flex w-full items-center px-3 py-1.5 text-sm hover:bg-muted/50"
                onClick={() => onSort(active ? null : dir)}
              >
                <span className="flex-1 text-left">{dir === 'asc' ? '오름차순' : '내림차순'}</span>
                {active && <Check className="h-3.5 w-3.5 text-primary" />}
              </button>
            );
          })}
        </div>
      )}
      {sortable && filterable && <div className="border-t" />}
      {filterable && (
        <div className="py-1">
          <div className="px-3 py-1">
            <Input
              placeholder="검색..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="h-7 text-xs"
              autoFocus
            />
          </div>
          <div className="max-h-32 overflow-y-auto py-1">
            {filtered.map((v) => (
              <label key={v} className="flex items-center gap-2 px-3 py-1 text-sm hover:bg-muted/50 cursor-pointer">
                <Checkbox
                  checked={activeFilters.includes(v)}
                  onCheckedChange={() => onFilterToggle(v)}
                />
                {v}
              </label>
            ))}
            {filtered.length === 0 && (
              <p className="px-3 py-1 text-xs text-muted-foreground">결과 없음</p>
            )}
          </div>
          {activeFilters.length > 0 && (
            <div className="border-t px-3 py-1.5">
              <button
                className="text-xs text-muted-foreground hover:text-destructive"
                onClick={onFilterClear}
              >
                필터 초기화
              </button>
            </div>
          )}
        </div>
      )}
    </>
  );
}

interface StudentDiffField {
  label: string;
  existing: string;
  incoming: string;
}

const STUDENT_DIFF_FIELDS: { key: keyof CreateStudentInput; label: string }[] = [
  { key: 'gender', label: '성별' },
  { key: 'contact', label: '연락처' },
  { key: 'guardian_name', label: '보호자명' },
  { key: 'guardian_relation', label: '보호자 관계' },
  { key: 'guardian_contact', label: '보호자 연락처' },
];


export default function StudentsPage() {
  const { go } = useTabNav();
  const { addToast } = useToast();
  const [students, setStudents] = useState<StudentWithCaseCount[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<StudentWithCaseCount | null>(null);
  const [editTarget, setEditTarget] = useState<StudentWithCaseCount | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const editHook = useStudentForm();
  const [saving, setSaving] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const createHook = useStudentForm();
  const [creating, setCreating] = useState(false);
  const [dupDialogOpen, setDupDialogOpen] = useState(false);
  const [dupDiffs, setDupDiffs] = useState<StudentDiffField[]>([]);
  const [dupExisting, setDupExisting] = useState<Student | null>(null);
  const [hasCasesOnly, setHasCasesOnly] = useLocalStorage<boolean>('wee-log:students:hasCasesOnly', false);
  const [filters, setFilters] = useLocalStorage<StudentFilters>('wee-log:students:filters', {});
  const [sort, setSort] = useLocalStorage<StudentSort>('wee-log:students:sort', null);
  const [academicYear, setAcademicYear] = useLocalStorage<string>('wee-log:students:year', '');
  const [availableYears, setAvailableYears] = useState<string[]>([]);
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [uploadPreview, setUploadPreview] = useState<UploadPreview | null>(null);
  const [hideGraduates, setHideGraduates] = useLocalStorage<boolean>('wee-log:students:hideGraduates', true);

  // ── 다중 선택 상태 ────────────────────────────────────────────────────────
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const hasSelection = selectedIds.size > 0;
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);
  const [bulkGraduateOpen, setBulkGraduateOpen] = useState(false);
  const [bulkRestoreOpen, setBulkRestoreOpen] = useState(false);
  const [schoolType, setSchoolType] = useState('');
  const [graduationWarning, setGraduationWarning] = useState<string | null>(null);

  const filteredStudents = useMemo(
    () => {
      const base = hasCasesOnly ? students.filter(s => s.case_count > 0) : students;
      return applyFiltersAndSort(base, filters, sort);
    },
    [students, filters, sort, hasCasesOnly],
  );

  // 선택된 학생들의 사례 합산
  const selectedCaseCount = useMemo(
    () => filteredStudents.filter((s) => selectedIds.has(s.id)).reduce((sum, s) => sum + s.case_count, 0),
    [filteredStudents, selectedIds],
  );

  useEffect(() => {
    window.api.settings.get().then((s) => {
      if (!academicYear) setAcademicYear(s.academic_year || new Date().getFullYear().toString());
      setSchoolType(s.school_type || '');
    });
    window.api.enrollments.years().then(setAvailableYears);
  }, []);

  useEffect(() => {
    fetchStudents();
  }, [hideGraduates]);

  // hideGraduates가 바뀌면 선택 초기화
  useEffect(() => {
    setSelectedIds(new Set());
  }, [hideGraduates]);

  function getStatusParam(): string | null {
    return hideGraduates ? '재학' : null;
  }

  useEffect(() => {
    fetchStudents();
  }, [academicYear]);

  async function fetchStudents(searchTerm?: string) {
    setLoading(true);
    setFetchError(false);
    try {
      const data = await window.api.students.list({
        search: searchTerm || undefined,
        academic_year: academicYear || undefined,
        status: getStatusParam(),
      });
      setStudents(data);
    } catch {
      setFetchError(true);
    } finally {
      setLoading(false);
    }
  }

  async function handleUploadExcel() {
    try {
      const result = await window.api.students.uploadExcel();
      if (result.canceled) return;
      if (!result.success) {
        addToast({ title: result.message || '파일 파싱 실패', variant: 'destructive' });
        return;
      }
      setUploadPreview({
        academicYear: result.academicYear!,
        grade: result.grade!,
        rowCount: result.rowCount!,
        filePath: result.filePath!,
        sampleRows: result.sampleRows!,
      });
      setUploadDialogOpen(true);
    } catch (err) {
      console.error('[handleUploadExcel]', err);
      addToast({ title: '파일 업로드 중 오류 발생', variant: 'destructive' });
    }
  }

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    fetchStudents(search);
  }

  function toggleSelect(id: number) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  const allSelected = filteredStudents.length > 0 && filteredStudents.every((s) => selectedIds.has(s.id));
  const someSelected = filteredStudents.some((s) => selectedIds.has(s.id));

  function toggleSelectAll() {
    if (allSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredStudents.map((s) => s.id)));
    }
  }

  function handleHeaderSort(col: string, dir: 'asc' | 'desc' | null) {
    if (dir === null) setSort(null);
    else setSort({ col, dir } as StudentSort);
  }

  function handleFilterToggle(col: string, val: string) {
    const current = (filters[col as StudentFilterKey]) || [];
    const next = current.includes(val) ? current.filter((v) => v !== val) : [...current, val];
    setFilters({ ...filters, [col]: next } as StudentFilters);
  }

  function handleFilterClear(col: string) {
    setFilters({ ...filters, [col]: [] } as StudentFilters);
  }

  // ── 생성 ──
  function openCreateDialog() {
    createHook.reset();
    setCreateOpen(true);
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    const err = createHook.validate();
    if (err) { addToast({ title: err, variant: 'destructive' }); return; }
    setCreating(true);
    try {
      const existing = await window.api.students.findByIdentity(
        createHook.form.name.trim(),
        createHook.form.grade || undefined,
        createHook.form.class_name || undefined,
        createHook.form.number || undefined,
      );
      if (existing) {
        const diffs: StudentDiffField[] = [];
        for (const { key, label } of STUDENT_DIFF_FIELDS) {
          const existingVal = (existing[key as keyof Student] as string | null) || '';
          const incomingVal = (createHook.form[key] as string | undefined) || '';
          if (existingVal !== incomingVal && (existingVal || incomingVal)) {
            diffs.push({ label, existing: existingVal || '(없음)', incoming: incomingVal || '(없음)' });
          }
        }
        setDupExisting(existing);
        if (diffs.length > 0) {
          setDupDiffs(diffs);
          setDupDialogOpen(true);
        } else {
          addToast({ title: '동일한 학생이 이미 등록되어 있습니다.', variant: 'destructive' });
        }
        return;
      }
      await window.api.students.create(createHook.form);
      addToast({ title: '학생이 등록되었습니다.', variant: 'success' });
      setCreateOpen(false);
      fetchStudents(search || undefined);
    } catch {
      addToast({ title: '등록에 실패했습니다.', variant: 'destructive' });
    } finally {
      setCreating(false);
    }
  }

  async function handleDupChoice(update: boolean) {
    setDupDialogOpen(false);
    if (!dupExisting) return;
    if (update) {
      try {
        await window.api.students.update(dupExisting.id, createHook.form);
        addToast({ title: '학생 정보가 업데이트되었습니다.', variant: 'success' });
        setCreateOpen(false);
        fetchStudents(search || undefined);
      } catch {
        addToast({ title: '업데이트에 실패했습니다.', variant: 'destructive' });
      }
    }
    setDupExisting(null);
    setDupDiffs([]);
  }

  // ── 수정 ──
  function openEditDialog(student: StudentWithCaseCount) {
    setEditTarget(student);
    editHook.reset({
      name: student.name,
      grade: student.grade || '',
      class_name: student.class_name || '',
      number: student.number || '',
      gender: student.gender || '',
      contact: student.contact || '',
      guardian_name: student.guardian_name || '',
      guardian_relation: student.guardian_relation || '',
      guardian_contact: student.guardian_contact || '',
    });
    setEditDialogOpen(true);
  }

  async function handleEditSave(e: React.FormEvent) {
    e.preventDefault();
    if (!editTarget) return;
    const err = editHook.validate();
    if (err) { addToast({ title: err, variant: 'destructive' }); return; }
    setSaving(true);
    try {
      await window.api.students.update(editTarget.id, editHook.form);
      addToast({ title: '학생 정보가 수정되었습니다.', variant: 'success' });
      setEditDialogOpen(false);
      setEditTarget(null);
      fetchStudents(search || undefined);
    } catch {
      addToast({ title: '수정에 실패했습니다.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  // ── 삭제 (단건) ──
  async function handleDelete() {
    if (!deleteTarget) return;
    try {
      await window.api.students.delete(deleteTarget.id);
      addToast({ title: '학생이 삭제되었습니다.', variant: 'success' });
      fetchStudents(search || undefined);
    } catch {
      addToast({ title: '삭제에 실패했습니다.', variant: 'destructive' });
    } finally {
      setDeleteTarget(null);
    }
  }

  // ── 일괄 삭제 ──
  async function handleBulkDelete() {
    const ids = Array.from(selectedIds);
    try {
      await window.api.students.bulkDelete(ids);
      addToast({ title: `${ids.length}명이 삭제되었습니다.`, variant: 'success' });
      setSelectedIds(new Set());
      fetchStudents(search || undefined);
    } catch (err) {
      console.error('[handleBulkDelete]', err);
      addToast({ title: '삭제에 실패했습니다.', variant: 'destructive' });
    }
  }

  // ── 일괄 졸업 처리 ──
  async function handleBulkGraduate() {
    const ids = Array.from(selectedIds);
    try {
      await window.api.students.bulkUpdateStatus(ids, '졸업');
      addToast({ title: `${ids.length}명을 졸업 처리했습니다.`, variant: 'success' });
      setSelectedIds(new Set());
      fetchStudents(search || undefined);
    } catch (err) {
      console.error('[handleBulkGraduate]', err);
      addToast({ title: '졸업 처리에 실패했습니다.', variant: 'destructive' });
    }
  }

  // ── 일괄 재학 복원 ──
  async function handleBulkRestore() {
    const ids = Array.from(selectedIds);
    try {
      await window.api.students.bulkUpdateStatus(ids, '재학');
      addToast({ title: `${ids.length}명을 재학으로 변경했습니다.`, variant: 'success' });
      setSelectedIds(new Set());
      fetchStudents(search || undefined);
    } catch (err) {
      console.error('[handleBulkRestore]', err);
      addToast({ title: '상태 변경에 실패했습니다.', variant: 'destructive' });
    }
  }

  // ── 졸업 대상 확인 ──
  async function handleGraduateCheck() {
    if (!schoolType) {
      addToast({
        title: '학교급 설정이 필요합니다.',
        description: '설정 > 기본 정보에서 학교급을 선택해주세요.',
        variant: 'destructive',
      });
      return;
    }
    if (schoolType === '특수학교') {
      setGraduationWarning('특수학교는 학부(초등부/중학부/고등부) 구조가 달라 졸업학년 자동 검증이 지원되지 않습니다. 직접 확인 후 진행해주세요.');
      setBulkGraduateOpen(true);
      return;
    }
    const graduationGrade = getGraduationGrade(schoolType);
    const ids = Array.from(selectedIds);
    try {
      const result = await window.api.students.checkGraduationEligibility(ids, academicYear, graduationGrade);
      if (result.ineligible.length > 0) {
        const list = result.ineligible.map((s) => `${s.name}(${s.grade})`).join(', ');
        addToast({
          title: '졸업 대상이 아닌 학생이 포함되어 있습니다.',
          description: list,
          variant: 'destructive',
        });
        return;
      }
      setGraduationWarning(null);
      setBulkGraduateOpen(true);
    } catch (err) {
      console.error('[checkGraduationEligibility]', err);
      addToast({ title: '졸업 대상 확인 중 오류가 발생했습니다.', variant: 'destructive' });
    }
  }

  return (
    <>
      <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
        {/* Header */}
        <div className="px-4 lg:px-6">
          <h1 className="text-2xl font-bold">학생 DB</h1>
        </div>
        <div className="flex items-center justify-between px-4 lg:px-6">
          <div className="flex items-center gap-3">
            <Select value={academicYear} onValueChange={setAcademicYear}>
              <SelectTrigger className="w-[140px] h-9">
                <SelectValue placeholder="학년도 선택" />
              </SelectTrigger>
              <SelectContent>
                {availableYears.map((y) => (
                  <SelectItem key={y} value={y}>{y}학년도</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-sm text-muted-foreground">
              {!loading && (
                filteredStudents.length === students.length
                  ? `총 ${students.length}명`
                  : `${filteredStudents.length}명 / 전체 ${students.length}명`
              )}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={handleUploadExcel}>
              <Upload className="mr-1.5 h-3.5 w-3.5" />
              반배정 업로드
            </Button>
            <Button size="sm" onClick={openCreateDialog}>
              <Plus className="mr-1.5 h-3.5 w-3.5" />
              새 학생 등록
            </Button>
          </div>
        </div>

        {/* Floating bulk action bar */}
        {hasSelection && (
          <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 rounded-xl border bg-background px-5 py-2.5 shadow-lg">
            <span className="text-sm font-medium whitespace-nowrap">{selectedIds.size}명 선택됨</span>
            <div className="h-4 w-px bg-border" />
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={handleGraduateCheck}>
                <GraduationCap className="mr-1.5 h-3.5 w-3.5" />
                졸업 처리
              </Button>
              {!hideGraduates && (
                <Button size="sm" variant="outline" onClick={() => setBulkRestoreOpen(true)}>
                  재학으로 변경
                </Button>
              )}
              <Button size="sm" variant="destructive" onClick={() => setBulkDeleteOpen(true)}>
                <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                삭제
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setSelectedIds(new Set())}>
                취소
              </Button>
            </div>
          </div>
        )}

        {/* Search + Filter + Sort + 상태 탭 */}
        <div className="flex flex-wrap items-center gap-2 px-4 lg:px-6">
          <form onSubmit={handleSearch} className="flex gap-2 flex-1 min-w-0 max-w-md">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="이름으로 검색..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 h-9"
              />
              {search && (
                <button
                  type="button"
                  onClick={() => { setSearch(''); fetchStudents(); }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            <Button type="submit" variant="secondary" size="sm"><Search className="mr-1.5 h-3.5 w-3.5" />검색</Button>
          </form>
          <FilterPopover
            columns={STUDENT_FILTER_COLUMNS}
            getValues={(col) => getDistinctValues(students, col as StudentFilterKey)}
            filters={filters as Record<string, string[]>}
            onFiltersChange={(f) => setFilters(f as StudentFilters)}
          />
          <SortPopover
            columns={STUDENT_SORT_COLUMNS}
            sort={sort}
            onSortChange={(s) => setSort(s as StudentSort)}
          />
          <div className="h-5 w-px bg-border mx-0.5" />
          <label className="flex items-center gap-1.5 cursor-pointer select-none">
            <Switch checked={hasCasesOnly} onCheckedChange={setHasCasesOnly} />
            <span className={cn('text-xs', hasCasesOnly ? 'text-foreground font-medium' : 'text-muted-foreground')}>사례 있는 학생만</span>
          </label>
          <label className="flex items-center gap-1.5 cursor-pointer select-none">
            <Switch checked={hideGraduates} onCheckedChange={setHideGraduates} />
            <span className={cn('text-xs', hideGraduates ? 'text-foreground font-medium' : 'text-muted-foreground')}>재학생만</span>
          </label>
        </div>

        {/* Student List */}
        <div className="px-4 lg:px-6">
          {loading ? (
            <LoadingState message="학생 목록을 불러오는 중..." />
          ) : fetchError ? (
            <ErrorState message="학생 목록을 불러오는데 실패했습니다." onRetry={() => fetchStudents(search)} />
          ) : filteredStudents.length === 0 ? (
            <Card className="shadow-sm">
              <CardContent className="flex flex-col items-center justify-center py-12 text-center">
                <p className="text-sm text-muted-foreground">
                  {hasCasesOnly || Object.values(filters).some((v) => v && v.length > 0)
                    ? '필터 조건에 맞는 학생이 없습니다.'
                    : '등록된 학생이 없습니다'}
                </p>
                {!hasCasesOnly && !Object.values(filters).some((v) => v && v.length > 0) && (
                  <p className="text-xs text-muted-foreground mt-1">
                    위의 "새 학생 등록" 버튼을 누르거나, 사례를 등록하면 자동으로 학생이 추가됩니다.
                  </p>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card className="shadow-sm overflow-hidden">
              <table className="w-full">
                <thead>
                  <tr className="group/header border-b">
                    <th className="w-10 py-2 pl-3 font-normal">
                      <div className={cn(
                        'flex items-center justify-center transition-opacity duration-150',
                        hasSelection ? 'opacity-100' : 'opacity-0 group-hover/header:opacity-100',
                      )}>
                        <Checkbox
                          checked={allSelected ? true : someSelected ? 'indeterminate' : false}
                          onCheckedChange={toggleSelectAll}
                        />
                      </div>
                    </th>
                    {TABLE_COLUMNS.map((col) => {
                      const isSorted = sort?.col === col.key;
                      const hasFilter = (filters[col.key as StudentFilterKey]?.length ?? 0) > 0;
                      return (
                        <th key={col.key} className={cn('py-2 px-4 font-medium text-left', col.key === 'name' && 'pl-3')}>
                          <Popover>
                            <PopoverTrigger asChild>
                              <button className={cn(
                                'text-xs select-none transition-colors',
                                isSorted || hasFilter ? 'text-primary font-semibold' : 'text-muted-foreground hover:text-foreground',
                              )}>
                                {col.label}
                                {isSorted && (sort!.dir === 'asc' ? ' ↑' : ' ↓')}
                                {hasFilter && ' •'}
                              </button>
                            </PopoverTrigger>
                            <PopoverContent align="start" className="p-0 w-44">
                              <HeaderPopoverContent
                                colKey={col.key}
                                sortable={col.sortable}
                                filterable={col.filterable}
                                sort={sort}
                                onSort={(dir) => handleHeaderSort(col.key, dir)}
                                values={col.filterable ? getDistinctValues(students, col.key) : []}
                                activeFilters={(filters[col.key as StudentFilterKey]) || []}
                                onFilterToggle={(val) => handleFilterToggle(col.key, val)}
                                onFilterClear={() => handleFilterClear(col.key)}
                              />
                            </PopoverContent>
                          </Popover>
                        </th>
                      );
                    })}
                    <th className="w-16 py-2 pr-3" />
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filteredStudents.map((s) => (
                    <tr
                      key={s.id}
                      className={cn(
                        'group transition-colors hover:bg-muted/50 cursor-pointer',
                        hasSelection && selectedIds.has(s.id) && 'bg-primary/5',
                      )}
                      onClick={hasSelection ? () => toggleSelect(s.id) : (e) => go(e, `/students/${s.id}`)}
                      onAuxClick={hasSelection ? undefined : (e) => go(e, `/students/${s.id}`)}
                    >
                      <td
                        className="py-2 pl-3 pr-1 cursor-pointer"
                        onClick={(e) => { e.stopPropagation(); toggleSelect(s.id); }}
                      >
                        <div className={cn(
                          'flex items-center justify-center transition-opacity duration-150',
                          hasSelection ? 'opacity-100' : 'opacity-0 group-hover:opacity-100',
                        )}>
                          <Checkbox
                            checked={selectedIds.has(s.id)}
                            tabIndex={-1}
                          />
                        </div>
                      </td>
                      <td className="py-2 px-4 pl-3 text-sm font-medium text-left whitespace-nowrap">
                        {s.name}
                        {s.status === '졸업' && <span className="ml-1 text-xs font-normal text-muted-foreground">졸업</span>}
                      </td>
                      <td className="py-2 px-4 text-xs text-muted-foreground text-left">{s.grade || ''}</td>
                      <td className="py-2 px-4 text-xs text-muted-foreground text-left">{s.class_name ? `${s.class_name}반` : ''}</td>
                      <td className="py-2 px-4 text-xs text-muted-foreground text-left tabular-nums">{s.number ? `${s.number}번` : ''}</td>
                      <td className="py-2 px-4 text-xs text-muted-foreground text-left">{s.gender || ''}</td>
                      <td className="py-2 px-4 text-xs text-muted-foreground text-left tabular-nums">{s.case_count}건</td>
                      <td className="py-2 pr-3">
                        <div className={cn(
                          'flex items-center justify-end gap-1 transition-opacity duration-150',
                          hasSelection ? 'invisible' : 'opacity-0 group-hover:opacity-100',
                        )} onClick={(e) => e.stopPropagation()}>
                            {s.status === '졸업' ? (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-7 text-xs text-muted-foreground hover:text-foreground"
                                title="재학으로 변경"
                                onClick={async () => {
                                  try {
                                    await window.api.students.update(s.id, { status: '재학' } as UpdateStudentInput);
                                    addToast({ title: '재학으로 변경되었습니다.', variant: 'success' });
                                    fetchStudents(search || undefined);
                                  } catch {
                                    addToast({ title: '상태 변경에 실패했습니다.', variant: 'destructive' });
                                  }
                                }}
                              >
                                재학으로 변경
                              </Button>
                            ) : (
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-muted-foreground hover:text-foreground"
                                title="수정"
                                onClick={() => openEditDialog(s)}
                              >
                                <Pencil className="h-3.5 w-3.5" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 text-muted-foreground hover:text-destructive"
                              title="삭제"
                              onClick={() => setDeleteTarget(s)}
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          )}
        </div>
      </div>

      {/* 학생 등록 다이얼로그 */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="sm:max-w-[480px] max-h-[85vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>새 학생 등록</DialogTitle>
            <DialogDescription>학생 정보를 입력하세요. 이름은 필수입니다.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreate} className="space-y-4 overflow-y-auto px-1 flex-1">
            <StudentFormFields hook={createHook} idPrefix="create" />
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}><X className="mr-2 h-4 w-4" />취소</Button>
              <Button type="submit" disabled={creating}>
                <Plus className="mr-2 h-4 w-4" />{creating ? '등록 중...' : '등록'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* 학생 수정 다이얼로그 */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="sm:max-w-[480px] max-h-[85vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>학생 정보 수정</DialogTitle>
            <DialogDescription>{editTarget?.name} 학생의 정보를 수정합니다.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditSave} className="space-y-4 overflow-y-auto px-1 flex-1">
            <StudentFormFields hook={editHook} idPrefix="edit" />
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setEditDialogOpen(false)}><X className="mr-2 h-4 w-4" />취소</Button>
              <Button type="submit" disabled={saving}><Save className="mr-2 h-4 w-4" />{saving ? '저장 중...' : '저장'}</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* 학생 중복 diff 다이얼로그 */}
      <Dialog open={dupDialogOpen} onOpenChange={setDupDialogOpen}>
        <DialogContent className="sm:max-w-[560px]">
          <DialogHeader>
            <DialogTitle>기존 학생 정보와 다릅니다</DialogTitle>
            <DialogDescription>
              <strong>{createHook.form.name}</strong> 학생이 이미 DB에 있습니다. 아래 항목이 다릅니다.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="rounded-lg border overflow-hidden">
              <div className="bg-secondary px-3 py-1.5 text-xs font-semibold text-muted-foreground border-b">기존 DB</div>
              {dupDiffs.map((d) => (
                <div key={d.label} className="px-3 py-2 border-b last:border-b-0">
                  <p className="text-xs text-muted-foreground mb-0.5">{d.label}</p>
                  <p className="font-medium">{d.existing}</p>
                </div>
              ))}
            </div>
            <div className="rounded-lg border border-primary/30 overflow-hidden">
              <div className="bg-primary/10 px-3 py-1.5 text-xs font-semibold text-primary border-b border-primary/20">새 입력값</div>
              {dupDiffs.map((d) => (
                <div key={d.label} className="px-3 py-2 border-b last:border-b-0 border-primary/20">
                  <p className="text-xs text-muted-foreground mb-0.5">{d.label}</p>
                  <p className="font-medium text-primary">{d.incoming}</p>
                </div>
              ))}
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => handleDupChoice(false)}><Check className="mr-2 h-4 w-4" />기존 정보 유지</Button>
            <Button onClick={() => handleDupChoice(true)}><RefreshCw className="mr-2 h-4 w-4" />학생 DB 업데이트</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 단건 삭제 확인 */}
      <ConfirmDialog
        open={deleteTarget !== null}
        onOpenChange={(open) => { if (!open) setDeleteTarget(null); }}
        title="학생을 삭제하시겠습니까?"
        description={
          deleteTarget && deleteTarget.case_count > 0
            ? `이 학생에 연결된 사례가 ${deleteTarget.case_count}건 있습니다. 삭제하면 해당 사례의 학생 연결이 해제됩니다.`
            : '이 학생 정보가 영구적으로 삭제됩니다.'
        }
        confirmLabel="삭제"
        variant="destructive"
        onConfirm={handleDelete}
      />

      <StudentUploadDialog
        open={uploadDialogOpen}
        preview={uploadPreview}
        onClose={() => { setUploadDialogOpen(false); setUploadPreview(null); }}
        onSuccess={(newYears, pickedYear) => {
          setAvailableYears(newYears);
          if (!academicYear || !newYears.includes(academicYear)) setAcademicYear(pickedYear);
          fetchStudents();
          setUploadDialogOpen(false);
          setUploadPreview(null);
        }}
      />

      {/* 일괄 삭제 확인 */}
      <ConfirmDialog
        open={bulkDeleteOpen}
        onOpenChange={setBulkDeleteOpen}
        title={`${selectedIds.size}명을 삭제하시겠습니까?`}
        description={
          selectedCaseCount > 0
            ? `선택한 학생 중 사례가 ${selectedCaseCount}건 연결되어 있습니다. 삭제하면 해당 사례의 학생 연결이 해제되며, 이 작업은 되돌릴 수 없습니다.`
            : '선택한 학생 정보가 영구적으로 삭제됩니다. 이 작업은 되돌릴 수 없습니다.'
        }
        confirmLabel="삭제"
        variant="destructive"
        onConfirm={handleBulkDelete}
      />

      {/* 일괄 졸업 처리 확인 */}
      <ConfirmDialog
        open={bulkGraduateOpen}
        onOpenChange={setBulkGraduateOpen}
        title={`${selectedIds.size}명을 졸업 처리하시겠습니까?`}
        description={
          graduationWarning
            ? `${graduationWarning}\n\n졸업 처리된 학생은 기본 목록에서 숨겨지며, 언제든지 다시 조회할 수 있습니다.`
            : "졸업 처리된 학생은 기본 목록에서 숨겨지며, 언제든지 다시 조회할 수 있습니다."
        }
        confirmLabel="졸업 처리"
        onConfirm={handleBulkGraduate}
      />

      {/* 일괄 재학 복원 확인 */}
      <ConfirmDialog
        open={bulkRestoreOpen}
        onOpenChange={setBulkRestoreOpen}
        title={`${selectedIds.size}명을 재학으로 변경하시겠습니까?`}
        description="선택한 학생들이 재학 상태로 변경되어 기본 목록에 다시 표시됩니다."
        confirmLabel="재학으로 변경"
        onConfirm={handleBulkRestore}
      />
    </>
  );
}
