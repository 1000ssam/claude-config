import { useState, useEffect } from 'react';
import { Unlock, ShieldAlert, KeyRound } from 'lucide-react';
import { WeeStoryLogo } from '@/components/logo-wee-story';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface LockScreenProps {
  onUnlock: () => void;
}

type Mode = 'password' | 'recovery';

export default function LockScreen({ onUnlock }: LockScreenProps) {
  const [mode, setMode] = useState<Mode>('password');

  // Password mode
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [hint, setHint] = useState('');
  const [showHint, setShowHint] = useState(false);
  const [hasRecovery, setHasRecovery] = useState(false);

  // Recovery mode
  const [recoveryCode, setRecoveryCode] = useState('');
  const [recoveryError, setRecoveryError] = useState('');
  const [recoveryLoading, setRecoveryLoading] = useState(false);
  const [recoverySuccess, setRecoverySuccess] = useState(false);

  useEffect(() => {
    window.api.auth.getHint().then(setHint).catch((e) => console.error('[LockScreen] getHint', e));
    window.api.auth.hasRecovery().then(setHasRecovery).catch((e) => console.error('[LockScreen] hasRecovery', e));
  }, []);

  async function handleUnlock() {
    if (!password) return;
    setError('');
    setLoading(true);

    try {
      const result = await window.api.auth.unlock(password);
      if (result.success) {
        onUnlock();
      } else {
        const next = attempts + 1;
        setAttempts(next);
        setError('비밀번호가 올바르지 않습니다.');
        setPassword('');
        if (next >= 3 && hint) setShowHint(true);
      }
    } catch {
      setError('오류가 발생했습니다. 다시 시도해주세요.');
    } finally {
      setLoading(false);
    }
  }

  async function handleUseRecovery() {
    if (!recoveryCode.trim()) return;
    setRecoveryError('');
    setRecoveryLoading(true);

    try {
      const result = await window.api.auth.useRecovery(recoveryCode.trim());
      if (result.success) {
        setRecoverySuccess(true);
        setTimeout(() => onUnlock(), 2000);
      } else {
        setRecoveryError('복구 코드가 올바르지 않습니다.');
      }
    } catch {
      setRecoveryError('오류가 발생했습니다. 다시 시도해주세요.');
    } finally {
      setRecoveryLoading(false);
    }
  }

  async function handleFactoryReset() {
    await window.api.auth.factoryReset();
    // main process handles confirm dialog + reload
  }

  // ── Recovery Mode ──────────────────────────────────────────────────────────
  if (mode === 'recovery') {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-muted/40 via-background to-muted/20">
        <div className="w-full max-w-md px-8">
          <div className="flex flex-col items-center gap-4 text-center mb-10">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
              <KeyRound className="h-8 w-8 text-primary" />
            </div>
            <div className="space-y-1.5">
              <h1 className="text-2xl font-semibold tracking-tight">복구 코드로 접근</h1>
              <p className="text-sm text-muted-foreground">저장해둔 복구 코드를 입력하세요.</p>
            </div>
          </div>

          {recoverySuccess ? (
            <Card className="shadow-sm border-green-200 bg-green-50">
              <CardContent className="pt-6 text-center space-y-1">
                <p className="text-sm font-medium text-green-800">복구 성공!</p>
                <p className="text-xs text-green-700">설정 &gt; 보안에서 비밀번호를 즉시 변경해주세요.</p>
              </CardContent>
            </Card>
          ) : (
            <Card className="shadow-sm">
              <CardContent className="pt-6 space-y-5">
                <div className="space-y-1.5">
                  <Label htmlFor="recovery-code">복구 코드</Label>
                  <Input
                    id="recovery-code"
                    type="text"
                    placeholder="XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX"
                    value={recoveryCode}
                    onChange={(e) => setRecoveryCode(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleUseRecovery()}
                    className="font-mono text-sm h-11"
                    autoFocus
                  />
                </div>

                {recoveryError && (
                  <p className="text-sm text-destructive">{recoveryError}</p>
                )}

                <Button className="w-full h-11" onClick={handleUseRecovery} disabled={recoveryLoading || !recoveryCode.trim()}>
                  {recoveryLoading ? '확인 중...' : '복구하기'}
                </Button>
              </CardContent>
            </Card>
          )}

          <button
            onClick={() => setMode('password')}
            className="w-full text-center text-xs text-muted-foreground hover:text-foreground transition-colors mt-6"
          >
            ← 비밀번호로 잠금 해제
          </button>
        </div>
      </div>
    );
  }

  // ── Password Mode ──────────────────────────────────────────────────────────
  const showHelp = attempts >= 3;

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-muted/40 via-background to-muted/20">
      <div className="w-full max-w-md px-8">
        {/* Logo */}
        <div className="flex flex-col items-center gap-3 text-center mb-10">
          <WeeStoryLogo height={48} />
          <p className="text-sm text-muted-foreground">비밀번호를 입력해 잠금을 해제하세요.</p>
        </div>

        {/* Form */}
        <Card className="shadow-sm">
          <CardContent className="pt-6 space-y-5">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">비밀번호</Label>
                {hint && !showHint && attempts > 0 && (
                  <button
                    onClick={() => setShowHint(true)}
                    className="text-xs text-muted-foreground hover:text-foreground transition-colors"
                  >
                    힌트 보기
                  </button>
                )}
              </div>
              <Input
                id="password"
                type="password"
                placeholder="비밀번호 입력"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleUnlock()}
                className="h-11"
                autoFocus
              />
            </div>

            {showHint && hint && (
              <div className="rounded-md border border-border bg-muted/30 px-3 py-2.5">
                <p className="text-xs text-muted-foreground">힌트: <span className="text-foreground">{hint}</span></p>
              </div>
            )}

            {error && (
              <p className="text-sm text-destructive">{error}</p>
            )}

            <Button className="w-full h-11" onClick={handleUnlock} disabled={loading || !password}>
              <Unlock className="mr-2 h-4 w-4" />
              {loading ? '확인 중...' : '잠금 해제'}
            </Button>
          </CardContent>
        </Card>

        {/* Help section after 3 failed attempts */}
        {showHelp && (
          <div className="mt-6 space-y-3 pt-4 border-t border-border">
            <p className="text-center text-xs text-muted-foreground font-medium">비밀번호를 잊으셨나요?</p>
            <div className="flex flex-col gap-2">
              {hasRecovery && (
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => setMode('recovery')}
                >
                  <KeyRound className="mr-2 h-4 w-4" />
                  복구 코드로 접근
                </Button>
              )}
              <Button
                variant="outline"
                size="sm"
                className="w-full text-destructive hover:text-destructive border-destructive/30 hover:border-destructive/60"
                onClick={handleFactoryReset}
              >
                <ShieldAlert className="mr-2 h-4 w-4" />
                앱 초기화 (데이터 전체 삭제)
              </Button>
            </div>
            {!hasRecovery && (
              <p className="text-center text-xs text-muted-foreground">
                복구 코드가 없습니다. 초기화 외에 다른 방법이 없습니다.
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
