import { useEffect, useState, useRef } from 'react';
import { Save, Download, Upload, RotateCcw, Eye, EyeOff, Copy, Check, ShieldCheck, Search, TriangleAlert, X } from 'lucide-react';
import type { SchoolInfo } from '@/types/electron.d';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { COUNSELOR_AFFILIATION_OPTIONS, WEE_CLASS_OPTIONS, COUNSELING_CLASS_OPTIONS, SCHOOL_TYPE_OPTIONS } from '@/lib/constants/options';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { LoadingState, ErrorState } from '@/components/ui/states';
import { useToast } from '@/hooks/use-toast';
import { getAcademicYear } from '@/lib/academic-year';
import { PALETTES, DEFAULT_PALETTE_ID } from '@/lib/constants/palettes';
import { applyPalette } from '@/lib/theme';
import type { AppSettings } from '@/types/settings';
import { STALE_CASE_DAYS } from '@/lib/case-staleness';
import { SttModelDownloadCard } from '@/components/stt/stt-model-download-card';
import { AiSettingsSection } from '@/components/ai/ai-settings-section';

export default function SettingsPage() {
  const { addToast } = useToast();
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [saving, setSaving] = useState(false);
  const [loadError, setLoadError] = useState(false);

  // 학교 검색
  const [schoolQuery, setSchoolQuery] = useState('');
  const [schoolResults, setSchoolResults] = useState<SchoolInfo[]>([]);
  const [schoolSearching, setSchoolSearching] = useState(false);
  const schoolSearchRef = useRef<HTMLDivElement>(null);

  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [changingPw, setChangingPw] = useState(false);

  // Hint
  const [hint, setHintValue] = useState('');
  const [savingHint, setSavingHint] = useState(false);

  // Password visibility
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showNewPw, setShowNewPw] = useState(false);
  const [showConfirmPw, setShowConfirmPw] = useState(false);

  // Reset
  const [resetStep, setResetStep] = useState<'closed' | 'password' | 'confirm'>('closed');
  const [resetPw, setResetPw] = useState('');
  const [showResetPw, setShowResetPw] = useState(false);
  const [resetPwError, setResetPwError] = useState('');
  const [resetting, setResetting] = useState(false);

  // Recovery
  const [hasRecovery, setHasRecovery] = useState(false);
  const [recoveryPhrase, setRecoveryPhrase] = useState('');
  const [generatingRecovery, setGeneratingRecovery] = useState(false);
  const [recoveryCopied, setRecoveryCopied] = useState(false);
  const [recoveryConfirmed, setRecoveryConfirmed] = useState(false);
  const [showRecoveryCode, setShowRecoveryCode] = useState(true);

  function loadSettings() {
    setLoadError(false);
    window.api.settings.get()
      .then(setSettings)
      .catch(() => setLoadError(true));
  }

  function loadSecurityInfo() {
    window.api.auth.getHint().then(setHintValue).catch((e) => console.error('[Settings] getHint', e));
    window.api.auth.hasRecovery().then(setHasRecovery).catch((e) => console.error('[Settings] hasRecovery', e));
  }

  useEffect(() => {
    loadSettings();
    loadSecurityInfo();
  }, []);

  async function handleSave() {
    if (!settings) return;
    setSaving(true);
    try {
      await window.api.settings.update(settings);
      addToast({ title: '설정이 저장되었습니다.', variant: 'success' });
    } catch {
      addToast({ title: '설정 저장에 실패했습니다. 다시 시도해주세요.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  async function handleBackup() {
    try {
      const result = await window.api.backup.create();
      if (result.success) {
        addToast({ title: '백업이 완료되었습니다.', variant: 'success' });
      } else if (result.message !== '취소되었습니다.') {
        addToast({ title: result.message || '백업에 실패했습니다.', variant: 'destructive' });
      }
    } catch {
      addToast({ title: '백업에 실패했습니다. 다시 시도해주세요.', variant: 'destructive' });
    }
  }

  async function handleRestore() {
    try {
      const result = await window.api.backup.restore();
      if (!result.success && result.message !== '취소되었습니다.') {
        addToast({ title: result.message || '복원에 실패했습니다.', variant: 'destructive' });
      }
      // 성공 시 앱이 자동 재시작되므로 토스트 불필요
    } catch {
      addToast({ title: '복원에 실패했습니다. 다시 시도해주세요.', variant: 'destructive' });
    }
  }

  async function handleChangePassword() {
    if (newPw.length < 8) {
      addToast({ title: '새 비밀번호는 8자 이상이어야 합니다.', variant: 'destructive' });
      return;
    }
    if (newPw !== confirmPw) {
      addToast({ title: '새 비밀번호가 일치하지 않습니다.', variant: 'destructive' });
      return;
    }
    setChangingPw(true);
    try {
      const result = await window.api.auth.changePassword(currentPw, newPw);
      if (result.success) {
        setCurrentPw(''); setNewPw(''); setConfirmPw('');
        setHasRecovery(true);
        setRecoveryPhrase(result.recoveryPhrase ?? '');
        setRecoveryConfirmed(false);
        setShowRecoveryCode(true);
        addToast({ title: '비밀번호가 변경되었습니다. 새 복구 코드를 반드시 저장해주세요.', variant: 'success' });
        setRecoveryConfirmed(false);
      } else {
        addToast({ title: '현재 비밀번호가 올바르지 않습니다.', variant: 'destructive' });
      }
    } catch {
      addToast({ title: '비밀번호 변경에 실패했습니다.', variant: 'destructive' });
    } finally {
      setChangingPw(false);
    }
  }

  async function handleSaveHint() {
    setSavingHint(true);
    try {
      const result = await window.api.auth.setHint(hint);
      if (result.success) {
        addToast({ title: hint.trim() ? '힌트가 저장되었습니다.' : '힌트가 삭제되었습니다.', variant: 'success' });
      } else {
        addToast({ title: '힌트 저장에 실패했습니다.', variant: 'destructive' });
      }
    } catch {
      addToast({ title: '힌트 저장에 실패했습니다.', variant: 'destructive' });
    } finally {
      setSavingHint(false);
    }
  }

  async function handleGenerateRecovery() {
    setGeneratingRecovery(true);
    setRecoveryPhrase('');
    setRecoveryConfirmed(false);
    setRecoveryCopied(false);
    setShowRecoveryCode(true);
    try {
      const result = await window.api.auth.generateRecovery();
      if (result.success && result.phrase) {
        setRecoveryPhrase(result.phrase);
        setHasRecovery(true);
      } else {
        addToast({ title: result.error || '복구 코드 생성에 실패했습니다.', variant: 'destructive' });
      }
    } catch {
      addToast({ title: '복구 코드 생성에 실패했습니다.', variant: 'destructive' });
    } finally {
      setGeneratingRecovery(false);
    }
  }

  function handleCopyRecovery() {
    navigator.clipboard.writeText(recoveryPhrase);
    setRecoveryCopied(true);
    setTimeout(() => setRecoveryCopied(false), 2000);
  }

  function openResetDialog() {
    setResetStep('password');
    setResetPw('');
    setShowResetPw(false);
    setResetPwError('');
    setResetting(false);
  }

  async function handleResetVerify() {
    setResetPwError('');
    // 비밀번호 검증은 최종 확인 단계에서 IPC로 수행
    // 여기서는 빈 입력만 차단
    if (!resetPw.trim()) {
      setResetPwError('비밀번호를 입력해주세요.');
      return;
    }
    setResetStep('confirm');
  }

  async function handleResetConfirm() {
    setResetting(true);
    try {
      const result = await window.api.backup.reset(resetPw);
      if (!result.success) {
        if (result.message === '비밀번호가 올바르지 않습니다.') {
          setResetPwError(result.message);
          setResetStep('password');
        } else {
          addToast({ title: result.message || '초기화에 실패했습니다.', variant: 'destructive' });
          setResetStep('closed');
        }
      }
      // 성공 시 main process가 리로드하므로 별도 처리 불필요
    } catch {
      addToast({ title: '초기화에 실패했습니다. 다시 시도해주세요.', variant: 'destructive' });
      setResetStep('closed');
    } finally {
      setResetting(false);
    }
  }

  if (loadError) return <ErrorState message="설정을 불러오는데 실패했습니다." onRetry={loadSettings} />;
  if (!settings) return <LoadingState message="설정을 불러오는 중..." />;

  return (
    <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
      <div className="px-4 lg:px-6">
        <h1 className="text-2xl font-bold">설정</h1>
      </div>
      <div className="space-y-6 max-w-2xl px-4 lg:px-6">
        <Card className="shadow-sm">
          <CardHeader><CardTitle>기본 정보</CardTitle></CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2" ref={schoolSearchRef}>
              <Label htmlFor="st-school-name">학교명</Label>
              <div className="relative">
                <div className="flex gap-1.5">
                  <Input
                    id="st-school-name"
                    value={settings.neis_schul_code ? settings.school_name : schoolQuery}
                    onChange={(e) => {
                      if (settings.neis_schul_code) {
                        // 이미 선택된 상태에서 수정 시 선택 초기화
                        setSettings({ ...settings, school_name: '', neis_atpt_code: '', neis_schul_code: '' });
                        setSchoolQuery(e.target.value);
                      } else {
                        setSchoolQuery(e.target.value);
                      }
                      setSchoolResults([]);
                    }}
                    placeholder="학교명으로 검색"
                    className={settings.neis_schul_code ? 'bg-muted' : ''}
                  />
                  {settings.neis_schul_code ? (
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        setSettings({ ...settings, school_name: '', neis_atpt_code: '', neis_schul_code: '', school_type: '' });
                        setSchoolQuery('');
                        setSchoolResults([]);
                      }}
                      title="학교 선택 해제"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      disabled={schoolSearching || !schoolQuery.trim()}
                      onClick={async () => {
                        if (!schoolQuery.trim()) return;
                        setSchoolSearching(true);
                        try {
                          const results = await window.api.school.search(schoolQuery.trim());
                          setSchoolResults(results);
                        } finally {
                          setSchoolSearching(false);
                        }
                      }}
                    >
                      <Search className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                {schoolResults.length > 0 && (
                  <div className="absolute z-20 top-full mt-1 left-0 right-0 bg-popover border border-border rounded-md shadow-lg max-h-52 overflow-y-auto">
                    {schoolResults.map((s) => (
                      <button
                        key={s.schulCode}
                        type="button"
                        className="w-full text-left px-3 py-2 text-sm hover:bg-accent transition-colors"
                        onClick={() => {
                          setSettings({
                            ...settings,
                            school_name: s.schulName,
                            neis_atpt_code: s.atptCode,
                            neis_schul_code: s.schulCode,
                          });
                          setSchoolQuery('');
                          setSchoolResults([]);
                        }}
                      >
                        <span className="font-medium">{s.schulName}</span>
                        <span className="text-muted-foreground text-xs ml-2">{s.schulKind} · {s.addr}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {settings.neis_schul_code && (
                <p className="text-xs text-muted-foreground">학교 코드: {settings.neis_schul_code}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="st-school-type">
                학교급
                {!settings.school_type && (
                  <span className="ml-1.5 text-xs text-destructive font-normal">* 필수</span>
                )}
              </Label>
              <Select
                value={settings.school_type || ''}
                onValueChange={(v) => setSettings({ ...settings, school_type: v })}
              >
                <SelectTrigger id="st-school-type" className={!settings.school_type ? 'border-destructive' : ''}>
                  <SelectValue placeholder="학교급 선택" />
                </SelectTrigger>
                <SelectContent>
                  {SCHOOL_TYPE_OPTIONS.map((o) => (
                    <SelectItem key={o} value={o}>{o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="st-academic-year">학년도 (자동)</Label>
              <Input
                id="st-academic-year"
                value={getAcademicYear(new Date())}
                readOnly
                tabIndex={-1}
                className="bg-muted text-muted-foreground cursor-default"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="st-counselor-name">상담사 이름</Label>
              <Input
                id="st-counselor-name"
                value={settings.counselor_name}
                onChange={(e) => setSettings({ ...settings, counselor_name: e.target.value })}
                placeholder="상담사 이름"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="st-counselor-affil">상담사 소속</Label>
              <Select
                value={settings.counselor_affiliation}
                onValueChange={(v) => setSettings({ ...settings, counselor_affiliation: v })}
              >
                <SelectTrigger id="st-counselor-affil"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {COUNSELOR_AFFILIATION_OPTIONS.map((o) => (
                    <SelectItem key={o} value={o}>{o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="st-wee-class">Wee설치여부</Label>
              <Select
                value={settings.wee_class}
                onValueChange={(v) => setSettings({ ...settings, wee_class: v })}
              >
                <SelectTrigger id="st-wee-class"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {WEE_CLASS_OPTIONS.map((o) => (
                    <SelectItem key={o} value={o}>{o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="st-default-class">상담분류 기본값</Label>
              <Select
                value={settings.default_counseling_class || ''}
                onValueChange={(v) => setSettings({ ...settings, default_counseling_class: v })}
              >
                <SelectTrigger id="st-default-class"><SelectValue placeholder="선택 안 함" /></SelectTrigger>
                <SelectContent>
                  {COUNSELING_CLASS_OPTIONS.map((o) => (
                    <SelectItem key={o} value={o}>{o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="st-stale-days">장기 미접촉 기준일</Label>
              <Input
                id="st-stale-days"
                type="number"
                min={1}
                inputMode="numeric"
                value={settings.stale_case_days ?? ''}
                onChange={(e) => setSettings({ ...settings, stale_case_days: e.target.value })}
                placeholder={`기본 ${STALE_CASE_DAYS}일`}
              />
              <p className="text-xs text-muted-foreground">
                진행 중 사례가 이 일수 이상 상담 없으면 홈에서 경고로 표시됩니다. 비우면 {STALE_CASE_DAYS}일.
              </p>
            </div>
            <div className="md:col-span-2">
              <Button variant="outline" onClick={handleSave} disabled={saving}>
                <Save className="mr-2 h-4 w-4" />
                {saving ? '저장 중...' : '기본 정보 저장'}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>컬러 팔레트</CardTitle>
            <CardDescription>앱 전체의 포인트 색상을 변경합니다.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap gap-3">
              {PALETTES.map((p) => {
                const isActive = (settings.color_palette || DEFAULT_PALETTE_ID) === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    className={`flex items-center gap-2.5 rounded-lg border-2 px-3.5 py-2.5 transition-all ${
                      isActive
                        ? 'border-foreground bg-accent shadow-sm'
                        : 'border-transparent bg-muted/50 hover:bg-muted'
                    }`}
                    onClick={async () => {
                      setSettings({ ...settings, color_palette: p.id });
                      applyPalette(p.id);
                      try {
                        await window.api.settings.update({ color_palette: p.id });
                        addToast({ title: `${p.name} 팔레트가 적용되었습니다.`, variant: 'success' });
                      } catch {
                        addToast({ title: '팔레트 저장에 실패했습니다.', variant: 'destructive' });
                      }
                    }}
                  >
                    <span
                      className="h-5 w-5 rounded-full shrink-0 ring-1 ring-black/10"
                      style={{ background: p.hex }}
                    />
                    <span className="text-sm font-medium">{p.name}</span>
                  </button>
                );
              })}
            </div>

            {/* 미니 프리뷰 */}
            <div className="rounded-lg border overflow-hidden" style={{ height: 160 }}>
              <div className="flex h-full">
                {/* Sidebar */}
                <div className="w-28 shrink-0 bg-sidebar border-r border-sidebar-border p-2.5 flex flex-col gap-0.5">
                  <span className="text-[10px] font-bold text-sidebar-foreground/70 px-2 pb-2 tracking-tight">WEE-STORY</span>
                  <div className="rounded-md bg-primary px-2 py-1 text-[11px] font-medium text-primary-foreground">사례 관리</div>
                  <div className="rounded-md px-2 py-1 text-[11px] text-sidebar-foreground/60">학생 관리</div>
                  <div className="rounded-md px-2 py-1 text-[11px] text-sidebar-foreground/60">통계/보고</div>
                  <div className="rounded-md px-2 py-1 text-[11px] text-sidebar-foreground/60">설정</div>
                </div>
                {/* Main */}
                <div className="flex-1 bg-background p-3 flex flex-col gap-2">
                  <span className="text-xs font-semibold text-foreground">사례 목록</span>
                  {/* Card */}
                  <div className="rounded-md border bg-card p-2.5 flex-1">
                    <div className="text-[11px] font-semibold text-card-foreground">김OO — 학교 부적응</div>
                    <div className="text-[10px] text-muted-foreground mt-1 leading-relaxed">주호소: 또래관계 어려움</div>
                    <div className="flex items-center gap-2 mt-2.5">
                      <span className="inline-flex items-center h-5 px-2 rounded text-[10px] font-medium bg-primary text-primary-foreground">세션 추가</span>
                      <span className="inline-flex items-center h-5 px-2 rounded text-[10px] font-medium border border-input text-muted-foreground">상세보기</span>
                    </div>
                  </div>
                  {/* Tabs */}
                  <div className="flex gap-0 border-b">
                    <span className="text-[10px] font-semibold text-primary border-b-2 border-primary px-2 pb-1">기본 정보</span>
                    <span className="text-[10px] text-muted-foreground px-2 pb-1">상담 기록</span>
                    <span className="text-[10px] text-muted-foreground px-2 pb-1">사례개념화</span>
                  </div>
                </div>
              </div>
            </div>

          </CardContent>
        </Card>

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>보안 설정</CardTitle>
            <CardDescription>
              상담 기록은 암호화되어 저장됩니다.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* 비밀번호 변경 */}
            <div className="space-y-3">
              <p className="text-sm font-medium">비밀번호 변경</p>
              <div className="space-y-2">
                <Label htmlFor="st-current-pw">현재 비밀번호</Label>
                <div className="relative">
                  <Input id="st-current-pw" type={showCurrentPw ? 'text' : 'password'} value={currentPw} onChange={(e) => setCurrentPw(e.target.value)} placeholder="현재 비밀번호" className="pr-10" />
                  <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 text-muted-foreground hover:text-foreground" onClick={() => setShowCurrentPw((v) => !v)}>
                    {showCurrentPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="st-new-pw">새 비밀번호</Label>
                <div className="relative">
                  <Input id="st-new-pw" type={showNewPw ? 'text' : 'password'} value={newPw} onChange={(e) => setNewPw(e.target.value)} placeholder="8자 이상" className="pr-10" />
                  <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 text-muted-foreground hover:text-foreground" onClick={() => setShowNewPw((v) => !v)}>
                    {showNewPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="st-confirm-pw">새 비밀번호 확인</Label>
                <div className="relative">
                  <Input id="st-confirm-pw" type={showConfirmPw ? 'text' : 'password'} value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} placeholder="새 비밀번호 재입력" className="pr-10" />
                  <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 text-muted-foreground hover:text-foreground" onClick={() => setShowConfirmPw((v) => !v)}>
                    {showConfirmPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <Button variant="outline" onClick={handleChangePassword} disabled={changingPw || !currentPw || !newPw || !confirmPw}>
                <Save className="mr-2 h-4 w-4" />
                {changingPw ? '저장 중...' : '비밀번호 변경'}
              </Button>
            </div>

            <div className="border-t border-border" />

            {/* 비밀번호 힌트 */}
            <div className="space-y-3">
              <div>
                <p className="text-sm font-medium">비밀번호 힌트</p>
                <p className="text-xs text-muted-foreground mt-0.5">잠금 화면에서 비밀번호를 잊었을 때 표시됩니다.</p>
              </div>
              <div className="flex gap-2">
                <Input
                  type="text"
                  value={hint}
                  onChange={(e) => setHintValue(e.target.value)}
                  placeholder="기억을 도울 힌트 (비밀번호 자체는 입력하지 마세요)"
                  className="flex-1"
                />
                <Button variant="outline" onClick={handleSaveHint} disabled={savingHint}>
                  <Save className="mr-2 h-4 w-4" />{savingHint ? '저장 중...' : '힌트 저장'}
                </Button>
              </div>
            </div>

            <div className="border-t border-border" />

            {/* 복구 코드 */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">복구 코드</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {hasRecovery ? '복구 코드가 설정되어 있습니다.' : '복구 코드가 없습니다. 비밀번호 분실 시 복구가 불가능합니다.'}
                  </p>
                </div>
              </div>

              {recoveryPhrase && (
                <div className="rounded-lg border border-border bg-muted/30 p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">
                    {recoveryConfirmed ? '복구 코드' : '새 복구 코드'}
                  </p>
                    {recoveryConfirmed && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6"
                        onClick={() => setShowRecoveryCode((v) => !v)}
                      >
                        {showRecoveryCode
                          ? <EyeOff className="h-3.5 w-3.5 text-muted-foreground" />
                          : <Eye className="h-3.5 w-3.5 text-muted-foreground" />
                        }
                      </Button>
                    )}
                  </div>

                  {showRecoveryCode ? (
                    <>
                      <p className="font-mono text-sm font-semibold tracking-widest text-foreground break-all leading-relaxed">
                        {recoveryPhrase}
                      </p>
                      <Button variant="outline" size="sm" onClick={handleCopyRecovery}>
                        {recoveryCopied ? (
                          <><Check className="mr-2 h-4 w-4 text-green-600" />복사 완료</>
                        ) : (
                          <><Copy className="mr-2 h-4 w-4" />코드 복사</>
                        )}
                      </Button>
                    </>
                  ) : (
                    <p className="text-xs text-muted-foreground italic">코드가 숨겨졌습니다. 눈 아이콘으로 다시 볼 수 있습니다.</p>
                  )}

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={recoveryConfirmed}
                      onChange={(e) => {
                        setRecoveryConfirmed(e.target.checked);
                        if (e.target.checked) setShowRecoveryCode(false);
                      }}
                      className="h-4 w-4 accent-primary"
                    />
                    <span className="text-xs text-foreground">안전한 곳에 보관했습니다.</span>
                  </label>
                </div>
              )}

              <Button
                variant="outline"
                onClick={handleGenerateRecovery}
                disabled={generatingRecovery}
              >
                <ShieldCheck className="mr-2 h-4 w-4" />{generatingRecovery ? '생성 중...' : hasRecovery ? '복구 코드 재생성' : '복구 코드 생성'}
              </Button>
              {hasRecovery && !recoveryPhrase && (
                <p className="text-xs text-muted-foreground">
                  재생성하면 기존 복구 코드는 즉시 무효화됩니다.
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        <AiSettingsSection />

        <Card className="shadow-sm">
          <CardHeader>
            <CardTitle>데이터 백업 / 복원</CardTitle>
            <CardDescription>
              모든 상담 데이터를 파일로 백업하거나, 백업 파일에서 복원할 수 있습니다.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex gap-3">
            <Button variant="outline" onClick={handleBackup}>
              <Download className="mr-2 h-4 w-4" />
              백업하기
            </Button>
            <Button variant="outline" onClick={handleRestore}>
              <Upload className="mr-2 h-4 w-4" />
              복원하기
            </Button>
            <Button variant="destructive" onClick={openResetDialog}>
              <RotateCcw className="mr-2 h-4 w-4" />
              데이터 초기화
            </Button>
          </CardContent>
        </Card>

        <SttModelDownloadCard />
      </div>

      {/* 데이터 초기화 2단계 모달 */}
      <Dialog open={resetStep !== 'closed'} onOpenChange={(open) => { if (!open) setResetStep('closed'); }}>
        <DialogContent className="max-w-sm">
          {resetStep === 'password' && (
            <>
              <DialogHeader>
                <DialogTitle>데이터 초기화</DialogTitle>
                <DialogDescription>
                  본인 확인을 위해 비밀번호를 입력해주세요.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-2">
                <Label htmlFor="reset-pw">비밀번호</Label>
                <div className="relative">
                  <Input
                    id="reset-pw"
                    type={showResetPw ? 'text' : 'password'}
                    value={resetPw}
                    onChange={(e) => { setResetPw(e.target.value); setResetPwError(''); }}
                    onKeyDown={(e) => { if (e.key === 'Enter') handleResetVerify(); }}
                    placeholder="현재 비밀번호"
                    className="pr-10"
                    autoFocus
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 text-muted-foreground hover:text-foreground"
                    onClick={() => setShowResetPw((v) => !v)}
                  >
                    {showResetPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                {resetPwError && (
                  <p className="text-sm text-destructive">{resetPwError}</p>
                )}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setResetStep('closed')}>취소</Button>
                <Button variant="destructive" onClick={handleResetVerify} disabled={!resetPw.trim()}>
                  다음
                </Button>
              </DialogFooter>
            </>
          )}

          {resetStep === 'confirm' && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-2">
                  <TriangleAlert className="h-5 w-5 text-destructive shrink-0" />
                  <DialogTitle>정말 초기화하시겠습니까?</DialogTitle>
                </div>
                <DialogDescription className="pt-2 space-y-2 text-left">
                  <span className="block font-semibold text-destructive">이 작업은 되돌릴 수 없습니다.</span>
                  <span className="block">다음 데이터가 영구 삭제됩니다:</span>
                  <span className="block pl-2">- 모든 상담 사례 및 세션 기록</span>
                  <span className="block pl-2">- 모든 학생 정보</span>
                  <span className="block pl-2">- 학교명, 상담사 등 설정 정보</span>
                  <span className="block pl-2">- 암호화 설정 (비밀번호 재설정 필요)</span>
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline" onClick={() => setResetStep('closed')} disabled={resetting}>취소</Button>
                <Button variant="destructive" onClick={handleResetConfirm} disabled={resetting}>
                  {resetting ? '초기화 중...' : '모든 데이터 삭제'}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
