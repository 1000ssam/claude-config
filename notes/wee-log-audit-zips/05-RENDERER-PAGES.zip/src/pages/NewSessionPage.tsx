import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useTabNav } from '@/hooks/use-tab-nav';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { SessionForm } from '@/components/sessions/session-form';
import { LoadingState, ErrorState, NotFoundState } from '@/components/ui/states';
import type { Case } from '@/types/case';

export default function NewSessionPage() {
  const { caseId } = useParams<{ caseId: string }>();
  const { linkProps } = useTabNav();
  const [caseData, setCaseData] = useState<Case | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCase = () => {
    setLoading(true);
    setError(null);
    window.api.cases.get(Number(caseId))
      .then((data) => { setCaseData(data ?? null); setLoading(false); })
      .catch((e) => { console.error('[NewSession] load case', e); setError('사례 정보를 불러오는데 실패했습니다.'); setLoading(false); });
  };

  useEffect(() => { fetchCase(); }, [caseId]);

  if (loading) return <LoadingState message="사례 정보를 불러오는 중..." />;
  if (error) return <ErrorState message={error} onRetry={fetchCase} />;
  if (!caseData) return <NotFoundState message="사례를 찾을 수 없습니다." backHref="/cases" backLabel="사례 목록으로" />;

  return (
    <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
      <div className="px-4 lg:px-6">
        <h1 className="text-base font-medium">새 상담 기록 작성</h1>
      </div>
      <div className="flex flex-col gap-4 px-4 lg:px-6">
        <Button variant="ghost" size="sm" className="w-fit" {...linkProps(`/cases/${caseId}`)}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          사례로 돌아가기
        </Button>
        <SessionForm caseId={caseId!} />
      </div>
    </div>
  );
}
