import { useEffect } from 'react';
import { format, parseISO } from 'date-fns';
import { ko } from 'date-fns/locale';
import { Megaphone, Info, AlertTriangle, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNotices } from '@/hooks/use-notices';
import type { Notice } from '@/types/electron.d';

const TYPE_CONFIG = {
  info:    { icon: Info,          label: '안내',   className: 'text-blue-500' },
  warning: { icon: AlertTriangle, label: '주의',   className: 'text-amber-500' },
  update:  { icon: Zap,           label: '업데이트', className: 'text-primary' },
} satisfies Record<Notice['type'], { icon: React.ElementType; label: string; className: string }>;

export function NoticesPage() {
  const { notices, loading, markAllRead } = useNotices();

  // 페이지 진입 시 전체 읽음 처리
  useEffect(() => {
    markAllRead();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 pt-4 lg:px-6 md:pt-6">
        <h1 className="text-2xl font-bold">공지사항</h1>
      </div>
      <div className="flex-1 overflow-y-auto p-6">
        {loading ? (
          <p className="text-sm text-muted-foreground">불러오는 중...</p>
        ) : notices.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-muted-foreground gap-3">
            <Megaphone className="h-10 w-10 opacity-20" />
            <p className="text-sm">공지사항이 없습니다.</p>
          </div>
        ) : (
          <ul className="space-y-3 max-w-2xl">
            {notices.map((notice) => {
              const cfg = TYPE_CONFIG[notice.type] ?? TYPE_CONFIG.info;
              const Icon = cfg.icon;
              return (
                <li
                  key={notice.id}
                  className={cn(
                    'rounded-lg border border-border bg-card p-4',
                    !notice.isRead && 'border-primary/30 bg-primary/3',
                  )}
                >
                  <div className="flex items-start gap-3">
                    <Icon className={cn('h-4 w-4 mt-0.5 shrink-0', cfg.className)} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-semibold">{notice.title}</span>
                        {!notice.isRead && (
                          <span className="text-[0.625rem] font-bold text-primary bg-primary/10 px-1.5 py-0.5 rounded-full leading-none">
                            NEW
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground whitespace-pre-line">{notice.body}</p>
                      <p className="text-xs text-muted-foreground/60 mt-2">
                        {format(parseISO(notice.publishedAt), 'yyyy년 M월 d일', { locale: ko })}
                      </p>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
