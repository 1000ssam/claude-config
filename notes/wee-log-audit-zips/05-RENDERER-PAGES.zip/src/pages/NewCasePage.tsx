import { CaseForm } from '@/components/cases/case-form';

export default function NewCasePage() {
  return (
    <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
      <div className="px-4 lg:px-6">
        <h1 className="text-base font-medium">새 사례 등록</h1>
      </div>
      <div className="max-w-2xl px-4 lg:px-6">
        <CaseForm />
      </div>
    </div>
  );
}
