import { UsersRound } from 'lucide-react';

const COMMUNITY_URL = import.meta.env.VITE_COMMUNITY_URL as string | undefined;

export function CommunityPage() {
  if (!COMMUNITY_URL) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-3">
        <UsersRound className="h-10 w-10 opacity-20" />
        <p className="text-sm">커뮤니티 URL이 설정되지 않았습니다.</p>
        <p className="text-xs text-muted-foreground/60">
          환경변수 VITE_COMMUNITY_URL을 설정해주세요.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 pt-4 lg:px-6 md:pt-6">
        <h1 className="text-2xl font-bold">커뮤니티</h1>
      </div>
      <iframe
        src={COMMUNITY_URL}
        className="flex-1 w-full border-0"
        title="커뮤니티"
        sandbox="allow-scripts allow-same-origin allow-popups allow-forms"
      />
    </div>
  );
}
