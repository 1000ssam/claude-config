import { useState } from 'react';
import { FileSpreadsheet, FileText, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { DateTimePicker } from '@/components/ui/date-time-picker';
import { PrintPopover } from '@/components/ui/print-popover';
import { useToast } from '@/hooks/use-toast';
import { BlockEditor } from '@/components/reports/block-editor';
import { buildReportBlocks } from '@/components/reports/report-blocks-builder';
import type { ReportBlock } from '@/components/reports/block-editor';

type Tab = 'excel' | 'pdf';

// ── 엑셀 내보내기 탭 ─────────────────────────────────────────────────────────
function ExcelTab() {
  const { addToast } = useToast();
  const [loading, setLoading] = useState(false);
  const currentYear = new Date().getFullYear().toString();
  const [from, setFrom] = useState(`${currentYear}-03-01`);
  const [to, setTo] = useState(`${currentYear}-12-31`);

  async function handleExport() {
    setLoading(true);
    try {
      const result = await window.api.export.xlsx({ from, to });
      if (result.success) {
        addToast({ title: '엑셀 파일이 저장되었습니다.', variant: 'success' });
      } else if (result.message) {
        addToast({ title: result.message, variant: 'destructive' });
      }
    } catch {
      addToast({ title: '내보내기에 실패했습니다.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="pt-6 space-y-4">
          <p className="text-sm text-muted-foreground">
            나이스(NEIS) 업로드 양식에 맞는 엑셀 파일을 생성합니다.
          </p>
          <div className="flex gap-4 items-end flex-wrap">
            <div className="space-y-1.5">
              <Label htmlFor="rp-export-from">시작일</Label>
              <DateTimePicker id="rp-export-from" date={from} onDateChange={setFrom} placeholder="시작일 선택" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="rp-export-to">종료일</Label>
              <DateTimePicker id="rp-export-to" date={to} onDateChange={setTo} placeholder="종료일 선택" />
            </div>
            <Button onClick={handleExport} disabled={loading} className="h-9">
              <FileSpreadsheet className="mr-2 h-4 w-4" />
              {loading ? '생성 중...' : '엑셀 내보내기'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ── PDF 보고서 탭 ─────────────────────────────────────────────────────────────
function PdfReportTab() {
  const { addToast } = useToast();
  const currentYear = new Date().getFullYear().toString();
  const [from, setFrom] = useState(`${currentYear}-03-01`);
  const [to, setTo] = useState(`${currentYear}-12-31`);
  const [blocks, setBlocks] = useState<ReportBlock[]>([]);
  const [generating, setGenerating] = useState(false);
  const [isPrintMode] = useState(false);
  const [schoolName, setSchoolName] = useState('');
  const [counselorName, setCounselorName] = useState('');

  // 설정에서 학교명/담당자 불러오기
  useState(() => {
    window.api.settings.get().then((s) => {
      setSchoolName(s.school_name || '');
      setCounselorName(s.counselor_name || '');
    }).catch((e) => console.error('[Reports] settings prefetch', e));
  });

  async function handleGenerate() {
    setGenerating(true);
    try {
      const data = await window.api.reports.generate({ startDate: from, endDate: to });
      setBlocks(buildReportBlocks(data));
    } catch {
      addToast({ title: '보고서 생성에 실패했습니다.', variant: 'destructive' });
    } finally {
      setGenerating(false);
    }
  }

  function getPdfDefaultName() {
    const f = from.replace(/-/g, '');
    const t = to.replace(/-/g, '');
    return f && t ? `상담활동보고서_${f}-${t}.pdf` : `상담활동보고서_${new Date().getFullYear()}.pdf`;
  }

  return (
    <div className="space-y-4">
      {/* 기간 선택 + 생성 */}
      <Card className="print:hidden">
        <CardContent className="pt-6 space-y-4">
          <p className="text-sm text-muted-foreground">
            보고 기간을 설정하고 보고서를 자동 생성한 뒤, 내용을 편집하여 PDF로 저장하세요.
          </p>
          <div className="flex gap-4 items-end flex-wrap">
            <div className="space-y-1.5">
              <Label htmlFor="rp-report-from">시작일</Label>
              <DateTimePicker id="rp-report-from" date={from} onDateChange={setFrom} placeholder="시작일 선택" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="rp-report-to">종료일</Label>
              <DateTimePicker id="rp-report-to" date={to} onDateChange={setTo} placeholder="종료일 선택" />
            </div>
            <Button onClick={handleGenerate} disabled={generating} className="h-9">
              <Sparkles className="mr-2 h-4 w-4" />
              {generating ? '생성 중...' : '보고서 자동 생성'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {blocks.length > 0 && (
        <>
          {/* PDF 액션 버튼 */}
          <div className="flex gap-2 justify-end print:hidden">
            <PrintPopover defaultName={getPdfDefaultName()} />
          </div>

          {/* A4 프리뷰 */}
          <div className="flex justify-center print:block">
            <div
              id="report-preview"
              className="bg-white shadow-lg print:shadow-none"
              style={{
                width: '210mm',
                minHeight: '297mm',
                padding: '20mm',
                boxSizing: 'border-box',
              }}
            >
              {/* 보고서 헤더 */}
              <div className="text-center mb-8 pb-4 border-b-2 border-foreground print:mb-6">
                <h1 className="text-2xl font-bold mb-2">상담 활동 보고서</h1>
                <div className="flex justify-center gap-8 text-sm text-muted-foreground">
                  <span>
                    <input
                      className="bg-transparent outline-none text-center border-b border-transparent hover:border-border focus:border-primary print:border-none"
                      value={schoolName}
                      onChange={(e) => setSchoolName(e.target.value)}
                      placeholder="학교명"
                      readOnly={isPrintMode}
                    />
                  </span>
                  <span>
                    <input
                      className="bg-transparent outline-none text-center border-b border-transparent hover:border-border focus:border-primary print:border-none"
                      value={counselorName}
                      onChange={(e) => setCounselorName(e.target.value)}
                      placeholder="담당자"
                      readOnly={isPrintMode}
                    />
                  </span>
                </div>
              </div>

              {/* 블록 에디터 */}
              <BlockEditor
                blocks={blocks}
                onChange={setBlocks}
                isPrintMode={isPrintMode}
              />
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// ── 메인 페이지 ──────────────────────────────────────────────────────────────
export default function ReportsPage() {
  const [tab, setTab] = useState<Tab>('excel');

  return (
    <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
      <div className="px-4 lg:px-6">
        <h1 className="text-2xl font-bold">보고서</h1>
      </div>
      {/* 탭 */}
      <div className="flex gap-1 border-b border-border px-4 lg:px-6 print:hidden">
        <button
          onClick={() => setTab('excel')}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
            tab === 'excel'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <FileSpreadsheet className="h-4 w-4" />
          나이스 엑셀 내보내기
        </button>
        <button
          onClick={() => setTab('pdf')}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
            tab === 'pdf'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          <FileText className="h-4 w-4" />
          관리자 보고서
        </button>
      </div>

      <div className="px-4 lg:px-6">
        {tab === 'excel' && <ExcelTab />}
        {tab === 'pdf' && <PdfReportTab />}
      </div>
    </div>
  );
}
