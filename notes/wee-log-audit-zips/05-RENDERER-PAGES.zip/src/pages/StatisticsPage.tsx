import { useState, useEffect, useCallback } from 'react';
import { Search, RefreshCw } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, Cell,
} from 'recharts';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { DateTimePicker } from '@/components/ui/date-time-picker';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PrintableHeader } from '@/components/ui/printable-header';
import { PrintPopover } from '@/components/ui/print-popover';
import { useToast } from '@/hooks/use-toast';
import { formatDuration } from '@/lib/utils';
import { getChartColors } from '@/lib/chart-palette';
import { ProportionBar } from '@/components/statistics/proportion-bar';
import type { Statistics } from '../../lib/queries/statistics';

// 차트 색상 — chart-palette.ts에서 런타임 resolve (primary + 고정 9색)
function ensureColors() {
  return getChartColors();
}

/** 항목 수에 따라 막대 두께를 동적 계산 (최소 6px, 최대 14px) */
function hBarSize(itemCount: number): number {
  if (itemCount <= 3) return 14;
  if (itemCount <= 6) return 12;
  if (itemCount <= 10) return 10;
  if (itemCount <= 20) return 8;
  return 6;
}

// 공통 Tooltip 스타일
const TOOLTIP_STYLE = {
  contentStyle: {
    fontSize: 11,
    padding: '6px 10px',
    borderRadius: 6,
    border: '1px solid rgba(0,0,0,0.08)',
    boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
  },
  isAnimationActive: false,
};

function NoData() {
  return <p className="text-center text-sm text-muted-foreground py-10">조회된 데이터가 없습니다.</p>;
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2 pt-5 px-6">
        <CardTitle className="text-base font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent className="px-4 pb-5">{children}</CardContent>
    </Card>
  );
}

function KpiCard({ label, value, sub, color }: { label: string; value: string; sub?: string; color?: string }) {
  return (
    <Card className="shadow-sm">
      <CardHeader className="pb-2">
        <CardDescription>{label}</CardDescription>
        <CardTitle className="text-3xl font-extrabold tabular-nums tracking-tight" style={color ? { color } : undefined}>
          {value}
        </CardTitle>
      </CardHeader>
      {sub && (
        <CardFooter className="text-sm text-muted-foreground">{sub}</CardFooter>
      )}
    </Card>
  );
}

// ── 인쇄용 데이터 테이블 ─────────────────────────────────────────────────────
function PrintDataTable({ rows, nameHeader = '항목', valueHeader = '건수' }: {
  rows: { name: string; value: number }[];
  nameHeader?: string;
  valueHeader?: string;
}) {
  if (rows.length === 0) return null;
  const total = rows.reduce((s, r) => s + r.value, 0);
  return (
    <table className="w-full text-xs border-collapse mt-2 mb-1 table-fixed">
      <colgroup>
        <col />
        <col className="w-24" />
        <col className="w-20" />
      </colgroup>
      <thead>
        <tr className="border-b">
          <th className="text-left py-1 px-2 font-medium">{nameHeader}</th>
          <th className="text-right py-1 px-2 font-medium">{valueHeader}</th>
          <th className="text-right py-1 px-2 font-medium">비율</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={i} className="border-b border-gray-200">
            <td className="py-1 px-2">{r.name}</td>
            <td className="text-right py-1 px-2 tabular-nums">{r.value.toLocaleString()}</td>
            <td className="text-right py-1 px-2 tabular-nums">
              {total > 0 ? `${((r.value / total) * 100).toFixed(1)}%` : '-'}
            </td>
          </tr>
        ))}
        <tr className="font-medium">
          <td className="py-1 px-2">합계</td>
          <td className="text-right py-1 px-2 tabular-nums">{total.toLocaleString()}</td>
          <td className="text-right py-1 px-2 tabular-nums">100%</td>
        </tr>
      </tbody>
    </table>
  );
}

// ── 인쇄 전용 전체 섹션 렌더링 ──────────────────────────────────────────────
function PrintAllSections({ stats }: { stats: Statistics }) {
  const c = ensureColors();

  const avgMin = Math.round(stats.avgMinutesPerSession);
  const avgH = Math.floor(avgMin / 60);
  const avgM = avgMin % 60;
  const avgLabel = avgH > 0 ? `${avgH}시간 ${avgM}분` : `${avgM}분`;
  const closureRate = stats.totalCases > 0
    ? `${Math.round((stats.closedCases / stats.totalCases) * 100)}%`
    : '-';

  // 시간 흐름 데이터
  const allMonths = [...new Set([
    ...stats.byMonth.map(r => r.month),
    ...stats.byNewCaseMonth.map(r => r.month),
  ])].sort();
  const monthData = allMonths.map(month => ({
    month: month.slice(5),
    상담건수: stats.byMonth.find(r => r.month === month)?.count ?? 0,
    신규사례: stats.byNewCaseMonth.find(r => r.month === month)?.count ?? 0,
  }));
  const WEEKDAY_ORDER = ['월', '화', '수', '목', '금', '토', '일'];
  const weekdaySorted = WEEKDAY_ORDER
    .map(wd => ({ weekday: wd, count: stats.byWeekday.find(r => r.weekday === wd)?.count ?? 0 }))
    .filter(r => r.count > 0);

  return (
    <div className="space-y-6">
      {/* ═══ 1. 요약 ═══ */}
      <div className="print-section">
        <h2 className="text-base font-bold mb-3 border-b pb-1">1. 요약</h2>
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="border-b">
              <th className="text-left py-2 px-3 font-medium">항목</th>
              <th className="text-right py-2 px-3 font-medium">값</th>
              <th className="text-left py-2 px-3 font-medium">비고</th>
            </tr>
          </thead>
          <tbody>
            <tr className="border-b border-gray-200">
              <td className="py-2 px-3">총 상담 건수</td>
              <td className="text-right py-2 px-3 tabular-nums font-semibold">{stats.totalSessions.toLocaleString()}건</td>
              <td className="py-2 px-3"></td>
            </tr>
            <tr className="border-b border-gray-200">
              <td className="py-2 px-3">총 상담 시간</td>
              <td className="text-right py-2 px-3 tabular-nums font-semibold">{formatDuration(stats.totalHours)}</td>
              <td className="py-2 px-3"></td>
            </tr>
            <tr className="border-b border-gray-200">
              <td className="py-2 px-3">총 사례 수</td>
              <td className="text-right py-2 px-3 tabular-nums font-semibold">{stats.totalCases.toLocaleString()}건</td>
              <td className="py-2 px-3 text-xs text-muted-foreground">진행중 {stats.activeCases} / 종결 {stats.closedCases}</td>
            </tr>
            <tr className="border-b border-gray-200">
              <td className="py-2 px-3">회당 평균 상담 시간</td>
              <td className="text-right py-2 px-3 tabular-nums font-semibold">{avgLabel}</td>
              <td className="py-2 px-3"></td>
            </tr>
            <tr className="border-b border-gray-200">
              <td className="py-2 px-3">종결율</td>
              <td className="text-right py-2 px-3 tabular-nums font-semibold">{closureRate}</td>
              <td className="py-2 px-3 text-xs text-muted-foreground">종결 {stats.closedCases} / 전체 {stats.totalCases}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* ═══ 2. 상담 분류 ═══ */}
      <div>
        <h2 className="text-base font-bold mb-3 border-b pb-1">2. 상담 분류</h2>

        {/* 대분류 */}
        <div className="mb-5 print-section">
          <h3 className="text-sm font-semibold mb-2">2-1. 대분류별</h3>
          {stats.byLargeCategory.length === 0 ? <NoData /> : (
            <>
              <BarChart width={600} height={Math.max(180, stats.byLargeCategory.length * 32)}
                data={stats.byLargeCategory} layout="vertical" barSize={hBarSize(stats.byLargeCategory.length)}
                margin={{ top: 16, right: 48, left: 8, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 12 }} allowDecimals={false} />
                <YAxis type="category" dataKey="category" interval={0} tick={{ fontSize: 12 }} width={56} />
                <Bar dataKey="count" name="건수" radius={[0, 3, 3, 0]}>
                  {stats.byLargeCategory.map((_, i) => <Cell key={i} fill={c[i % c.length]} />)}
                </Bar>
              </BarChart>
              <PrintDataTable rows={stats.byLargeCategory.map(r => ({ name: r.category, value: r.count }))} />
            </>
          )}
        </div>

        {/* 중분류 */}
        <div className="mb-5 print-section">
          <h3 className="text-sm font-semibold mb-2">2-2. 중분류별</h3>
          {stats.byMediumCategory.length === 0 ? <NoData /> : (
            <>
              <BarChart width={600} height={Math.max(180, stats.byMediumCategory.length * 28)}
                data={stats.byMediumCategory} layout="vertical" barSize={hBarSize(stats.byMediumCategory.length)}
                margin={{ top: 16, right: 48, left: 8, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 12 }} allowDecimals={false} />
                <YAxis type="category" dataKey="medium" interval={0} tick={{ fontSize: 12 }} width={100} />
                <Bar dataKey="count" name="건수" radius={[0, 3, 3, 0]}>
                  {stats.byMediumCategory.map((_, i) => <Cell key={i} fill={c[i % c.length]} />)}
                </Bar>
              </BarChart>
              <PrintDataTable
                rows={stats.byMediumCategory.map(r => ({ name: `${r.large} > ${r.medium}`, value: r.count }))}
              />
            </>
          )}
        </div>

          {/* 소분류 */}
        <div className="mb-5 print-section">
          <h3 className="text-sm font-semibold mb-2">2-3. 소분류별 (호소문제)</h3>
          {stats.byDetailCategory.length === 0 ? <NoData /> : (
            <>
              <BarChart width={600} height={Math.min(500, Math.max(200, stats.byDetailCategory.length * 28))}
                data={stats.byDetailCategory} layout="vertical" barSize={hBarSize(stats.byDetailCategory.length)}
                margin={{ top: 16, right: 56, left: 8, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 12 }} allowDecimals={false} />
                <YAxis type="category" dataKey="detail" interval={0} tick={{ fontSize: 12 }} width={150} />
                <Bar dataKey="count" name="건수" radius={[0, 3, 3, 0]}>
                  {stats.byDetailCategory.map((_, i) => <Cell key={i} fill={c[i % c.length]} />)}
                </Bar>
              </BarChart>
              <PrintDataTable
                rows={stats.byDetailCategory.map(r => ({ name: `${r.large} > ${r.detail}`, value: r.count }))}
              />
            </>
          )}
        </div>

        {/* 매체별 + 학년별 (반폭 → 인쇄 시 1열) */}
        <div className="grid grid-cols-2 print:grid-cols-1 gap-4 mb-4">
          <div className="print-section">
            <h3 className="text-sm font-semibold mb-2">2-4. 매체별 (면담/전화/사이버)</h3>
            {stats.byMedium.length === 0 ? <NoData /> : (
              <>
                <ProportionBar data={stats.byMedium.map(r => ({ name: r.category, value: r.count }))} />
                <PrintDataTable rows={stats.byMedium.map(r => ({ name: r.category, value: r.count }))} />
              </>
            )}
          </div>

          <div className="print-section">
            <h3 className="text-sm font-semibold mb-2">2-5. 학년별 상담 건수</h3>
            {stats.byGrade.length === 0 ? <NoData /> : (
              <>
                <BarChart width={300} height={Math.max(160, stats.byGrade.length * 28)}
                  data={stats.byGrade} layout="vertical" barSize={hBarSize(stats.byGrade.length)}
                  margin={{ top: 16, right: 48, left: 8, bottom: 4 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 12 }} allowDecimals={false} />
                  <YAxis type="category" dataKey="grade" interval={0} tick={{ fontSize: 12 }} width={56} />
                  <Bar dataKey="count" name="상담 건수" radius={[0, 3, 3, 0]}>
                    {stats.byGrade.map((_, i) => <Cell key={i} fill={c[i % c.length]} />)}
                  </Bar>
                </BarChart>
                <PrintDataTable
                  rows={stats.byGrade.map(r => ({ name: r.grade, value: r.count }))}
                  nameHeader="학년"
                />
              </>
            )}
          </div>
        </div>
      </div>

      {/* ═══ 3. 시간 흐름 ═══ */}
      <div className="print-section">
        <h2 className="text-base font-bold mb-3 border-b pb-1">3. 시간 흐름</h2>

        {/* 월별 추이 */}
        <div className="mb-5">
          <h3 className="text-sm font-semibold mb-2">3-1. 월별 추이 (상담 건수 / 신규 사례)</h3>
          {monthData.length === 0 ? <NoData /> : (
            <>
              <LineChart width={600} height={280} data={monthData}
                margin={{ top: 8, right: 24, left: -10, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
                <Legend />
                <Line type="monotone" dataKey="상담건수" stroke={c[0]} strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="신규사례" stroke={c[1]} strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
              <table className="w-full text-xs border-collapse mt-2 mb-1 table-fixed">
                <colgroup>
                  <col />
                  <col className="w-24" />
                  <col className="w-24" />
                </colgroup>
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-1 px-2 font-medium">월</th>
                    <th className="text-right py-1 px-2 font-medium">상담 건수</th>
                    <th className="text-right py-1 px-2 font-medium">신규 사례</th>
                  </tr>
                </thead>
                <tbody>
                  {monthData.map((r, i) => (
                    <tr key={i} className="border-b border-gray-200">
                      <td className="py-1 px-2">{r.month}</td>
                      <td className="text-right py-1 px-2 tabular-nums">{r.상담건수}</td>
                      <td className="text-right py-1 px-2 tabular-nums">{r.신규사례}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}
        </div>

        {/* 요일별 */}
        <div className="mb-5 print-section">
          <h3 className="text-sm font-semibold mb-2">3-2. 요일별 상담 건수</h3>
          {weekdaySorted.length === 0 ? <NoData /> : (
            <>
              <BarChart width={600} height={220} data={weekdaySorted} barSize={24}
                margin={{ top: 16, right: 16, left: -10, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
                <XAxis dataKey="weekday" tick={{ fontSize: 13 }} />
                <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
                <Bar dataKey="count" name="상담 건수" radius={[3, 3, 0, 0]}>
                  {weekdaySorted.map((_, i) => <Cell key={i} fill={c[i % c.length]} />)}
                </Bar>
              </BarChart>
              <PrintDataTable
                rows={weekdaySorted.map(r => ({ name: r.weekday, value: r.count }))}
                nameHeader="요일"
              />
            </>
          )}
        </div>
      </div>

      {/* ═══ 4. 유입/종결 ═══ */}
      <div className="print-section">
        <h2 className="text-base font-bold mb-3 border-b pb-1">4. 유입 / 종결</h2>

        {/* 의뢰자 유형 + 종결 사유 (반폭 → 인쇄 시 1열) */}
        <div className="grid grid-cols-2 print:grid-cols-1 gap-4 mb-5">
          <div className="print-section">
            <h3 className="text-sm font-semibold mb-2">4-1. 의뢰자 유형별</h3>
            {stats.byReferrerRole.length === 0 ? <NoData /> : (
              <>
                <ProportionBar data={stats.byReferrerRole.map(r => ({ name: r.role, value: r.count }))} />
                <PrintDataTable
                  rows={stats.byReferrerRole.map(r => ({ name: r.role, value: r.count }))}
                  nameHeader="의뢰자"
                  valueHeader="사례 수"
                />
              </>
            )}
          </div>

          <div className="print-section">
            <h3 className="text-sm font-semibold mb-2">4-2. 종결 사유별</h3>
            {stats.byCloseReason.length === 0 ? (
              <p className="text-center text-sm text-muted-foreground py-10">종결된 사례가 없습니다.</p>
            ) : (
              <>
                <ProportionBar data={stats.byCloseReason.map(r => ({ name: r.reason, value: r.count }))} />
                <PrintDataTable
                  rows={stats.byCloseReason.map(r => ({ name: r.reason, value: r.count }))}
                  nameHeader="사유"
                  valueHeader="사례 수"
                />
              </>
            )}
          </div>
        </div>

        {/* 사례당 상담 횟수 구간 */}
        <div className="mb-5 print-section">
          <h3 className="text-sm font-semibold mb-2">4-3. 사례당 상담 횟수 구간</h3>
          {stats.bySessionRange.length === 0 ? <NoData /> : (
            <>
              <BarChart width={600} height={200} data={stats.bySessionRange} barSize={24}
                margin={{ top: 16, right: 16, left: -10, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
                <XAxis dataKey="range" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
                <Bar dataKey="count" name="사례 수" radius={[3, 3, 0, 0]}>
                  {stats.bySessionRange.map((_, i) => <Cell key={i} fill={c[i % c.length]} />)}
                </Bar>
              </BarChart>
              <PrintDataTable
                rows={stats.bySessionRange.map(r => ({ name: r.range, value: r.count }))}
                nameHeader="구간"
                valueHeader="사례 수"
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ── 요약 ───────────────────────────────────────────────────────────────────────
function SummaryTab({ stats }: { stats: Statistics }) {
  const avgMin = Math.round(stats.avgMinutesPerSession);
  const avgH = Math.floor(avgMin / 60);
  const avgM = avgMin % 60;
  const avgLabel = avgH > 0 ? `${avgH}시간 ${avgM}분` : `${avgM}분`;

  const c = ensureColors();
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      <KpiCard label="총 상담 건수" value={`${stats.totalSessions.toLocaleString()}건`} color={c[0]} />
      <KpiCard label="총 상담 시간" value={formatDuration(stats.totalHours)} color={c[1]} />
      <KpiCard label="총 사례 수" value={`${stats.totalCases.toLocaleString()}건`}
        sub={`진행중 ${stats.activeCases} · 종결 ${stats.closedCases}`} color={c[2]} />
      <KpiCard label="회당 평균 상담 시간" value={avgLabel} color={c[3]} />
      <KpiCard
        label="종결율"
        value={stats.totalCases > 0 ? `${Math.round((stats.closedCases / stats.totalCases) * 100)}%` : '—'}
        sub={`종결 ${stats.closedCases} / 전체 ${stats.totalCases}`}
        color={c[4]}
      />
    </div>
  );
}

// ── 상담 분류 ──────────────────────────────────────────────────────────────────
function ClassificationTab({ stats }: { stats: Statistics }) {
  const totalLarge = stats.byLargeCategory.reduce((s, r) => s + r.count, 0) || 1;
  const totalMedium = stats.byMediumCategory.reduce((s, r) => s + r.count, 0) || 1;
  const totalDetail = stats.byDetailCategory.reduce((s, r) => s + r.count, 0) || 1;

  return (
    <div className="space-y-5">
      {/* 행 1: 대분류 | 중분류 */}
      <div className="grid gap-5 md:grid-cols-2">
        <ChartCard title="대분류별">
          {stats.byLargeCategory.length === 0 ? <NoData /> : (
            <ResponsiveContainer width="100%" height={Math.max(180, stats.byLargeCategory.length * 32)}>
              <BarChart data={stats.byLargeCategory} layout="vertical" barSize={hBarSize(stats.byLargeCategory.length)}
                margin={{ top: 16, right: 48, left: 8, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 12 }} allowDecimals={false} />
                <YAxis type="category" dataKey="category" interval={0} tick={{ fontSize: 12 }} width={56} />
                <Tooltip
                  formatter={(v) => [`${v}건 (${((Number(v) / totalLarge) * 100).toFixed(1)}%)`, '건수']}
                  {...TOOLTIP_STYLE}
                />
                <Bar dataKey="count" name="건수" radius={[0, 3, 3, 0]}>
                  {stats.byLargeCategory.map((_, i) => <Cell key={i} fill={ensureColors()[i % ensureColors().length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>

        <ChartCard title="중분류별">
          {stats.byMediumCategory.length === 0 ? <NoData /> : (
            <ResponsiveContainer width="100%" height={Math.max(180, stats.byMediumCategory.length * 28)}>
              <BarChart data={stats.byMediumCategory} layout="vertical" barSize={hBarSize(stats.byMediumCategory.length)}
                margin={{ top: 16, right: 48, left: 8, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 12 }} allowDecimals={false} />
                <YAxis type="category" dataKey="medium" interval={0} tick={{ fontSize: 12 }} width={100} />
                <Tooltip
                  formatter={(v) => [`${v}건 (${((Number(v) / totalMedium) * 100).toFixed(1)}%)`, '건수']}
                  labelFormatter={(medium) => {
                    const item = stats.byMediumCategory.find(r => r.medium === medium);
                    return item ? `${item.large} > ${medium}` : medium;
                  }}
                  {...TOOLTIP_STYLE}
                />
                <Bar dataKey="count" name="건수" radius={[0, 3, 3, 0]}>
                  {stats.byMediumCategory.map((_, i) => <Cell key={i} fill={ensureColors()[i % ensureColors().length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
      </div>

      {/* 행 2: 소분류 (전체 폭) */}
      <ChartCard title="소분류별 (호소문제)">
        {stats.byDetailCategory.length === 0 ? <NoData /> : (
          <ResponsiveContainer width="100%" height={Math.max(200, stats.byDetailCategory.length * 28)}>
            <BarChart data={stats.byDetailCategory} layout="vertical" barSize={hBarSize(stats.byDetailCategory.length)}
              margin={{ top: 16, right: 56, left: 8, bottom: 4 }}>

              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 12 }} allowDecimals={false} />
              <YAxis type="category" dataKey="detail" interval={0} tick={{ fontSize: 12 }} width={150} />
              <Tooltip
                formatter={(v) => [`${v}건 (${((Number(v) / totalDetail) * 100).toFixed(1)}%)`, '건수']}
                labelFormatter={(detail) => {
                  const item = stats.byDetailCategory.find(r => r.detail === detail);
                  return item ? `${item.large} > ${detail}` : detail;
                }}
                {...TOOLTIP_STYLE}
              />
              <Bar dataKey="count" name="건수" radius={[0, 3, 3, 0]}>
                {stats.byDetailCategory.map((_, i) => <Cell key={i} fill={ensureColors()[i % ensureColors().length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </ChartCard>

      {/* 행 3: 매체 | 학년별 */}
      <div className="grid gap-5 md:grid-cols-2">
        <ChartCard title="매체별 (면담·전화·사이버)">
          {stats.byMedium.length === 0 ? <NoData /> : (
            <div className="py-4">
              <ProportionBar data={stats.byMedium.map(r => ({ name: r.category, value: r.count }))} />
            </div>
          )}
        </ChartCard>

        <ChartCard title="학년별 상담 건수">
          {stats.byGrade.length === 0 ? <NoData /> : (
            <ResponsiveContainer width="100%" height={Math.max(160, stats.byGrade.length * 28)}>
              <BarChart data={stats.byGrade} layout="vertical" barSize={hBarSize(stats.byGrade.length)}
                margin={{ top: 16, right: 48, left: 8, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 12 }} allowDecimals={false} />
                <YAxis type="category" dataKey="grade" interval={0} tick={{ fontSize: 12 }} width={56} />
                <Tooltip formatter={(v) => [`${v}건`, '상담 건수']} {...TOOLTIP_STYLE} />
                <Bar dataKey="count" name="상담 건수" radius={[0, 3, 3, 0]}>
                  {stats.byGrade.map((_, i) => <Cell key={i} fill={ensureColors()[i % ensureColors().length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
      </div>
    </div>
  );
}

// ── 시간 흐름 ──────────────────────────────────────────────────────────────────
function TimelineTab({ stats }: { stats: Statistics }) {
  const allMonths = [...new Set([
    ...stats.byMonth.map(r => r.month),
    ...stats.byNewCaseMonth.map(r => r.month),
  ])].sort();

  const monthData = allMonths.map(month => ({
    month: month.slice(5),
    상담건수: stats.byMonth.find(r => r.month === month)?.count ?? 0,
    신규사례: stats.byNewCaseMonth.find(r => r.month === month)?.count ?? 0,
  }));

  const WEEKDAY_ORDER = ['월', '화', '수', '목', '금', '토', '일'];
  const weekdaySorted = WEEKDAY_ORDER
    .map(wd => ({ weekday: wd, count: stats.byWeekday.find(r => r.weekday === wd)?.count ?? 0 }))
    .filter(r => r.count > 0);

  return (
    <div className="space-y-5">
      <ChartCard title="월별 추이 (상담 건수 · 신규 사례)">
        {monthData.length === 0 ? <NoData /> : (
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={monthData} margin={{ top: 8, right: 24, left: -10, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
              <Tooltip {...TOOLTIP_STYLE} />
              <Legend />
              <Line type="monotone" dataKey="상담건수" stroke={ensureColors()[0]} strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
              <Line type="monotone" dataKey="신규사례" stroke={ensureColors()[1]} strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </ChartCard>

      <ChartCard title="요일별 상담 건수">
        {weekdaySorted.length === 0 ? <NoData /> : (
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={weekdaySorted} barSize={24} margin={{ top: 16, right: 16, left: -10, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
              <XAxis dataKey="weekday" tick={{ fontSize: 13 }} />
              <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
              <Tooltip formatter={(v) => [`${v}건`, '상담 건수']} {...TOOLTIP_STYLE} />
              <Bar dataKey="count" name="상담 건수" radius={[3, 3, 0, 0]}>
                {weekdaySorted.map((_, i) => <Cell key={i} fill={ensureColors()[i % ensureColors().length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </ChartCard>
    </div>
  );
}

// ── 유입·종결 ──────────────────────────────────────────────────────────────────
function FlowTab({ stats }: { stats: Statistics }) {
  return (
    <div className="space-y-5">
      <div className="grid gap-5 md:grid-cols-2">
        <ChartCard title="의뢰자 유형별">
          {stats.byReferrerRole.length === 0 ? <NoData /> : (
            <div className="py-4">
              <ProportionBar data={stats.byReferrerRole.map(r => ({ name: r.role, value: r.count }))} />
            </div>
          )}
        </ChartCard>

        <ChartCard title="종결 사유별">
          {stats.byCloseReason.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground py-10">종결된 사례가 없습니다.</p>
          ) : (
            <div className="py-4">
              <ProportionBar data={stats.byCloseReason.map(r => ({ name: r.reason, value: r.count }))} />
            </div>
          )}
        </ChartCard>
      </div>

      <ChartCard title="사례당 상담 횟수 구간">
        {stats.bySessionRange.length === 0 ? <NoData /> : (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={stats.bySessionRange} barSize={24} margin={{ top: 16, right: 16, left: -10, bottom: 4 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" />
              <XAxis dataKey="range" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
              <Tooltip formatter={(v) => [`${v}건`, '사례 수']} {...TOOLTIP_STYLE} />
              <Bar dataKey="count" name="사례 수" radius={[3, 3, 0, 0]}>
                {stats.bySessionRange.map((_, i) => <Cell key={i} fill={ensureColors()[i % ensureColors().length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </ChartCard>
    </div>
  );
}

// ── 메인 ───────────────────────────────────────────────────────────────────────
export default function StatisticsPage() {
  const currentYear = new Date().getFullYear().toString();
  const [year, setYear] = useState(currentYear);
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const { addToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [fetchError, setFetchError] = useState(false);
  const [stats, setStats] = useState<Statistics | null>(null);

  const fetchStatistics = useCallback(async () => {
    setLoading(true);
    setFetchError(false);
    try {
      const params: { year?: string; from?: string; to?: string } = { year };
      if (fromDate) params.from = fromDate;
      if (toDate) params.to = toDate;
      const data = await window.api.statistics.get(params);
      setStats(data);
    } catch {
      setFetchError(true);
      addToast({ title: '통계 데이터를 불러오는데 실패했습니다.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  }, [year, fromDate, toDate, addToast]);

  useEffect(() => { fetchStatistics(); }, [fetchStatistics]);

  // 인쇄 헤더 자막 + PDF 파일명 생성
  const printSubtitle = (() => {
    let s = `${year}학년도`;
    if (fromDate || toDate) {
      s += ` ${fromDate || '?'} ~ ${toDate || '?'}`;
    }
    return s;
  })();
  const printDefaultName = (() => {
    const base = `통계_${year}학년도`;
    if (fromDate && toDate) return `${base}_${fromDate}_${toDate}`;
    if (fromDate) return `${base}_${fromDate}~`;
    if (toDate) return `${base}_~${toDate}`;
    return base;
  })();

  return (
    <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
      {/* 인쇄 전용 헤더 */}
      <PrintableHeader title="상담 통계 보고서" subtitle={printSubtitle} />

      <div className="flex flex-col gap-4 px-4 lg:px-6">
      <div className="flex items-center gap-3 print:hidden">
        <h1 className="text-2xl font-bold">통계</h1>
        {stats && !fetchError && (
          <PrintPopover defaultName={printDefaultName} />
        )}
      </div>
      <Card className="shadow-sm print:hidden">
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-4 items-end">
            <div className="flex-1 min-w-[120px]">
              <Label htmlFor="year">학년도</Label>
              <Select value={year} onValueChange={setYear}>
                <SelectTrigger id="year"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 5 }, (_, i) => {
                    const y = (parseInt(currentYear, 10) - 2 + i).toString();
                    return <SelectItem key={y} value={y}>{y}</SelectItem>;
                  })}
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1 min-w-[140px]">
              <Label htmlFor="stat-from">시작일 (상담일 기준)</Label>
              <DateTimePicker id="stat-from" date={fromDate} onDateChange={setFromDate} placeholder="시작일 선택" />
            </div>
            <div className="flex-1 min-w-[140px]">
              <Label htmlFor="stat-to">종료일</Label>
              <DateTimePicker id="stat-to" date={toDate} onDateChange={setToDate} placeholder="종료일 선택" />
            </div>
            <Button onClick={fetchStatistics} disabled={loading}>
              <Search className="mr-2 h-4 w-4" />
              {loading ? '조회 중...' : '조회'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {fetchError && (
        <Card className="shadow-sm">
          <CardContent className="py-8 text-center text-muted-foreground">
            <p>통계 데이터를 불러오는데 실패했습니다.</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={fetchStatistics}><RefreshCw className="mr-1.5 h-3.5 w-3.5" />다시 시도</Button>
          </CardContent>
        </Card>
      )}

      {stats && !fetchError && (
        <>
          <Tabs defaultValue="summary" className="print:hidden">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="summary">요약</TabsTrigger>
              <TabsTrigger value="classification">상담 분류</TabsTrigger>
              <TabsTrigger value="timeline">시간 흐름</TabsTrigger>
              <TabsTrigger value="flow">유입·종결</TabsTrigger>
            </TabsList>
            <TabsContent value="summary" className="mt-5"><SummaryTab stats={stats} /></TabsContent>
            <TabsContent value="classification" className="mt-5"><ClassificationTab stats={stats} /></TabsContent>
            <TabsContent value="timeline" className="mt-5"><TimelineTab stats={stats} /></TabsContent>
            <TabsContent value="flow" className="mt-5"><FlowTab stats={stats} /></TabsContent>
          </Tabs>
          {/* 인쇄 전용 — 항상 마운트하여 차트 렌더 타이밍 이슈 방지 */}
          <div className="hidden print:block">
            <PrintAllSections stats={stats} />
          </div>
        </>
      )}
      </div>
    </div>
  );
}
