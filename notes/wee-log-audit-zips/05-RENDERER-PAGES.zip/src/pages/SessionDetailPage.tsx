import { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Pencil, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { SessionForm } from '@/components/sessions/session-form';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { PrintPopover } from '@/components/ui/print-popover';
import { PrintableHeader } from '@/components/ui/printable-header';
import { LoadingState, NotFoundState } from '@/components/ui/states';
import { useToast } from '@/hooks/use-toast';
import type { Case } from '@/types/case';
import type { Session } from '@/types/session';
import { formatStudentFull, formatStudentNames } from '@/lib/format-student';
import { cn } from '@/lib/utils';

export default function SessionDetailPage() {
  const { caseId, sessionId } = useParams<{ caseId: string; sessionId: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { addToast } = useToast();
  const fromCalendar = (location.state as { from?: string } | null)?.from === 'calendar';
  const [caseData, setCaseData] = useState<Case | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  function refreshData() {
    setLoading(true);
    setError(false);
    Promise.all([
      window.api.cases.get(Number(caseId)),
      window.api.sessions.get(Number(sessionId)),
    ]).then(([c, s]) => {
      if (!c || !s) { setError(true); setLoading(false); return; }
      setCaseData(c);
      setSession(s);
      setLoading(false);
    }).catch((e) => {
      console.error('[SessionDetail] load', e);
      setError(true);
      setLoading(false);
    });
  }

  useEffect(() => {
    refreshData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [caseId, sessionId]);

  async function handleDelete() {
    try {
      await window.api.sessions.delete(Number(sessionId));
      addToast({ title: '상담 기록이 삭제되었습니다.', variant: 'success' });
      navigate(`/cases/${caseId}?tab=sessions`, { replace: true });
    } catch {
      addToast({ title: '삭제에 실패했습니다.', variant: 'destructive' });
    }
  }

  if (loading) return <LoadingState message="상담 기록을 불러오는 중..." />;
  if (error) return <NotFoundState message="데이터를 불러올 수 없습니다." backHref={`/cases/${caseId}`} backLabel="사례로 돌아가기" />;
  if (!caseData || !session) return <NotFoundState message="상담 기록을 찾을 수 없습니다." backHref={`/cases/${caseId}`} backLabel="사례로 돌아가기" />;

  if (isEditing) {
    return (
      <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
        <div className="px-4 lg:px-6">
          <h1 className="text-base font-medium">상담 기록 수정</h1>
        </div>
        <div className="flex flex-col gap-4 px-4 lg:px-6">
          <Button variant="ghost" size="sm" className="w-fit" onClick={() => { setIsEditing(false); refreshData(); }}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            상세로 돌아가기
          </Button>
          <SessionForm
            caseId={caseId!}
            initialData={session}
            isEdit
            onCancel={() => { setIsEditing(false); refreshData(); }}
          />
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
        {/* Header */}
        <div className="flex items-center justify-between px-4 lg:px-6 print:hidden">
          <h1 className="text-base font-medium">{session.session_number != null ? `${session.session_number}회차 상담` : session.category_large}</h1>
          <div className="flex gap-2">
            <PrintPopover
              defaultName={`${session.session_date}_${session.session_number != null ? `${session.session_number}회차` : session.category_large}`}
            />
            <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
              <Pencil className="mr-1.5 h-3.5 w-3.5" />
              수정
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setDeleteDialogOpen(true)}
              title="삭제"
              className="h-8 w-8 text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <PrintableHeader
          title={`${caseData ? `사례 ${caseData.case_number} — ` : ''}${session.session_number != null ? `${session.session_number}회차 상담` : session.category_large}`}
          subtitle={caseData?.students?.length ? formatStudentNames(caseData.students, 'full') : undefined}
        />

        {/* Content */}
        <div className="flex flex-col gap-4 px-4 lg:px-6">
          <Button
            variant="ghost"
            size="sm"
            className="w-fit print:hidden"
            onClick={() => {
              if (fromCalendar) {
                navigate('/');
              } else {
                navigate(-1);
              }
            }}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            {fromCalendar ? '캘린더로 돌아가기' : '사례로 돌아가기'}
          </Button>

          {/* 참여 학생 */}
          {session.students && session.students.length > 0 && (
            <Card className="shadow-sm">
              <CardHeader><CardTitle>참여 학생</CardTitle></CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {session.students.map((ss) => {
                    const cs = caseData?.students?.find(c => c.student_id === ss.student_id);
                    return (
                      <Badge key={ss.student_id} variant="secondary" className="text-sm py-1 px-2.5">
                        {cs ? formatStudentFull(cs) : ss.name}
                      </Badge>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          <Card className="shadow-sm">
            <CardHeader><CardTitle>분류 정보</CardTitle></CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">상담분류</p>
                  <p className="text-sm font-medium">{session.counseling_class}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">Wee클래스</p>
                  <p className="text-sm font-medium">{session.wee_class}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 mt-4">
                <Badge variant="outline">{session.category_large}</Badge>
                <span className="text-muted-foreground">›</span>
                <Badge variant="outline">{session.category_medium}</Badge>
                <span className="text-muted-foreground">›</span>
                <Badge variant="secondary">{session.category_detail}</Badge>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardHeader><CardTitle>기본 정보</CardTitle></CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3 print:grid-cols-2 text-sm">
                {[
                  { label: '학년도', value: session.academic_year },
                  {
                    label: '상담일자',
                    value: session.appointment_time
                      ? `${session.session_date} ${session.appointment_time}`
                      : session.session_date,
                  },
                  { label: '상담인원', value: `${session.headcount}명` },
                  { label: '학년', value: session.grade },
                  { label: '성별', value: session.gender },
                  { label: '상담매체', value: session.medium },
                  { label: '상담사소속', value: session.counselor_affil },
                  { label: '상담시간', value: `${session.session_hour}시간 ${session.session_minute}분` },
                  { label: '회차', value: session.session_number != null ? `${session.session_number}회차` : session.category_large },
                ].map(({ label, value }) => (
                  <div key={label} className="space-y-1">
                    <p className="text-xs text-muted-foreground">{label}</p>
                    <p className="font-medium">{value}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 인쇄 시 상담 내용은 새 페이지에서 시작 */}
          <div className="print-page-break">
            <Card className="shadow-sm print:border-0 print:rounded-none">
              <CardHeader><CardTitle>상담 내용</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">상담제목</p>
                  <p className={cn('text-sm font-medium', !session.session_title && 'italic text-muted-foreground')}>
                    {session.session_title || '(제목 없음)'}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">상담내용</p>
                  <p className={cn('text-sm whitespace-pre-wrap leading-relaxed', !session.session_content && 'italic text-muted-foreground')}>
                    {session.session_content || '(내용 없음)'}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {session.internal_notes && (
            <Card className="shadow-sm print:border-0 print:rounded-none">
              <CardHeader>
                <CardTitle>
                  내부 메모
                  <span className="ml-2 text-xs font-normal text-muted-foreground">(NEIS 미포함)</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm whitespace-pre-wrap leading-relaxed">{session.internal_notes}</p>
              </CardContent>
            </Card>
          )}

          <div className="text-xs text-muted-foreground space-y-1 print:hidden">
            <p>작성: {new Date(session.created_at).toLocaleString('ko-KR')}</p>
            <p>수정: {new Date(session.updated_at).toLocaleString('ko-KR')}</p>
          </div>
        </div>
      </div>

      <ConfirmDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        title="상담 기록을 삭제하시겠습니까?"
        description="이 상담 기록이 영구적으로 삭제됩니다. 이 작업은 되돌릴 수 없습니다."
        confirmLabel="삭제"
        variant="destructive"
        onConfirm={handleDelete}
      />
    </>
  );
}
