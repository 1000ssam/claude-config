import { useEffect, useState, useCallback, useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  Plus, Users, Activity, AlertTriangle, CheckCircle2, ArrowRight,
} from 'lucide-react';
import {
  startOfMonth, endOfMonth, startOfWeek, endOfWeek, format,
} from 'date-fns';
import { ko } from 'date-fns/locale';
import { parseISO } from 'date-fns';
import { isStaleCase, staleSortKey, STALE_CASE_DAYS } from '@/lib/case-staleness';
import { Button } from '@/components/ui/button';
import {
  Card, CardContent, CardHeader, CardTitle,
} from '@/components/ui/card';
import { CalendarView } from '@/components/calendar/CalendarView';
import { TodaySchedule } from '@/components/calendar/TodaySchedule';
import { CaseListDialog } from '@/components/dashboard/case-list-dialog';
import { SideSheet } from '@/components/ui/side-sheet';
import { DayTimeGrid } from '@/components/calendar/DayTimeGrid';
import { QuickSessionDialog } from '@/components/sessions/quick-session-dialog';
import { LoadingState, ErrorState } from '@/components/ui/states';
import type { CalendarSession } from '../../lib/queries/calendar';
import type { CaseWithSessionCount } from '@/types/case';
import { getHolidayName } from '@/lib/holidays';

function getInitialRange() {
  const today = new Date();
  const start = startOfWeek(startOfMonth(today), { weekStartsOn: 0 });
  const end = endOfWeek(endOfMonth(today), { weekStartsOn: 0 });
  return {
    from: format(start, 'yyyy-MM-dd'),
    to: format(end, 'yyyy-MM-dd'),
  };
}

export default function DashboardPage() {
  const [activeCases, setActiveCases] = useState<CaseWithSessionCount[]>([]);
  const [calendarSessions, setCalendarSessions] = useState<CalendarSession[]>([]);
  const [calendarRange, setCalendarRange] = useState(getInitialRange);
  const [savedViewMode, setSavedViewMode] = useState<string>('month');
  // '장기 미접촉' 기준일. 설정값(stale_case_days)이 없거나 잘못되면 기본값.
  const [staleDays, setStaleDays] = useState<number>(STALE_CASE_DAYS);
  const [panelDate, setPanelDate] = useState<string | null>(null);
  // 빠른 일정 등록 다이얼로그: null=닫힘, {date?}=열림(date 있으면 상담일자 프리필)
  const [quickAdd, setQuickAdd] = useState<{ date?: string } | null>(null);
  // 홈 카드 클릭 시 뜨는 사례 목록 팝업: null=닫힘
  const [caseDialog, setCaseDialog] = useState<null | 'active' | 'stale'>(null);
  const [todayHoliday, setTodayHoliday] = useState<string | undefined>(undefined);
  const [todaySchoolEvents, setTodaySchoolEvents] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // 진행 중 사례에서 파생: 장기 미접촉(오래된 순) + 건수.
  const staleCases = useMemo(() => {
    const now = Date.now();
    return activeCases
      .filter((c) => isStaleCase(c, now, staleDays))
      .sort((a, b) => staleSortKey(a) - staleSortKey(b));
  }, [activeCases, staleDays]);
  const activeCount = activeCases.length;
  const staleCount = staleCases.length;

  const fetchDashboardData = useCallback(() => {
    setLoading(true);
    setError(null);

    const now = new Date();

    window.api.settings.get().then((s) => {
      if (s.calendar_view_mode) setSavedViewMode(s.calendar_view_mode);
      const d = Number(s.stale_case_days);
      if (Number.isInteger(d) && d >= 1) setStaleDays(d);
    }).catch((e) => console.error('[Dashboard] settings prefetch', e));

    // 진행 중 사례 목록(최근 상담일 포함). 활성 수·장기 미접촉은 여기서 파생.
    const statsPromise = window.api.cases.list({ status: 'active' }).then(setActiveCases);

    const todayStr = format(now, 'yyyy-MM-dd');
    const year = now.getFullYear();

    const holidayPromise = window.api.holidays.getYear(year).then((data) => {
      const found = data.find((h) => h.date === todayStr);
      setTodayHoliday(found?.name ?? getHolidayName(todayStr));
    }).catch((e) => {
      console.error('[Dashboard] holiday fetch', e);
      setTodayHoliday(getHolidayName(todayStr));
    });

    const schoolPromise = window.api.school.getSchedule(year).then((data) => {
      const events = data.filter((e) => e.date === todayStr).map((e) => e.name);
      setTodaySchoolEvents(events);
    }).catch((e) => console.error('[Dashboard] school schedule fetch', e));

    Promise.all([statsPromise, holidayPromise, schoolPromise])
      .catch((e) => { console.error('[Dashboard] data load', e); setError('대시보드 데이터를 불러오는데 실패했습니다.'); })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  const loadCalendar = useCallback((from: string, to: string) => {
    window.api.sessions.calendar(from, to)
      .then(setCalendarSessions)
      .catch(console.error);
  }, []);

  useEffect(() => {
    loadCalendar(calendarRange.from, calendarRange.to);
  }, [calendarRange, loadCalendar]);

  function handleRangeChange(from: string, to: string) {
    setCalendarRange({ from, to });
  }

  function handleCalendarTimeUpdate(sessionId: number, time: string | null) {
    setCalendarSessions((prev) =>
      prev.map((s) => s.id === sessionId ? { ...s, appointment_time: time ?? undefined } : s)
    );
  }

  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} onRetry={fetchDashboardData} />;

  return (
    <>
    <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
      <div className="grid gap-4 px-4 lg:grid-cols-4 lg:px-6">
        {/* 좌: 캘린더 (최상단) */}
        <Card className="shadow-card lg:col-span-3">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-base font-medium">상담 일정</CardTitle>
            <div className="flex gap-2">
              <Link to="/cases/new">
                <Button size="sm">
                  <Plus className="mr-1.5 h-3.5 w-3.5" />
                  새 사례
                </Button>
              </Link>
              <Link to="/cases">
                <Button variant="outline" size="sm">
                  <Users className="mr-1.5 h-3.5 w-3.5" />
                  사례 목록
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            <CalendarView
              sessions={calendarSessions}
              onRangeChange={handleRangeChange}
              onSessionMoved={() => loadCalendar(calendarRange.from, calendarRange.to)}
              onTimeUpdate={handleCalendarTimeUpdate}
              onDateClick={(dateStr) => setPanelDate(dateStr)}
              onAddSession={(dateStr) => setQuickAdd({ date: dateStr })}
              initialViewMode={savedViewMode as 'month' | 'week'}
              onViewModeChange={(mode) => {
                window.api.settings.update({ calendar_view_mode: mode }).catch((e) => console.error('[Dashboard] save view mode', e));
              }}
            />
          </CardContent>
        </Card>

        {/* 우: 미니 카드 2(최소 크기) + 오늘의 일정 */}
        <div className="flex flex-col gap-4">
          {/* 진행 중 사례 — 클릭 시 목록 팝업 */}
          <button
            type="button"
            onClick={() => setCaseDialog('active')}
            className="group flex items-center justify-between rounded-xl border bg-card px-3.5 py-3 text-left shadow-card transition-all hover:border-border/80 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            <span className="flex items-center gap-2 text-xs text-muted-foreground">
              <Activity className="h-3.5 w-3.5" />
              진행 중 사례
            </span>
            <span className="flex items-center gap-1.5">
              <span className="text-xl font-bold tabular-nums">{activeCount}</span>
              <ArrowRight className="h-4 w-4 text-muted-foreground/40 transition-transform group-hover:translate-x-0.5 group-hover:text-foreground" />
            </span>
          </button>

          {/* 장기 미접촉 — 건수>0이면 앰버 경고(클릭=팝업), 0이면 정적 차분 상태 */}
          {staleCount > 0 ? (
            <button
              type="button"
              onClick={() => setCaseDialog('stale')}
              className="group flex items-center justify-between rounded-xl border border-amber-300 bg-card px-3.5 py-3 text-left shadow-card transition-all hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 focus-visible:ring-offset-2"
            >
              <span className="flex items-center gap-2 text-xs text-amber-700">
                <AlertTriangle className="h-3.5 w-3.5" />
                장기 미접촉
              </span>
              <span className="flex items-center gap-1.5">
                <span className="text-xl font-bold tabular-nums text-amber-700">{staleCount}</span>
                <ArrowRight className="h-4 w-4 text-amber-700/50 transition-transform group-hover:translate-x-0.5 group-hover:text-amber-800" />
              </span>
            </button>
          ) : (
            <div className="flex items-center justify-between rounded-xl border bg-card px-3.5 py-3">
              <span className="flex items-center gap-2 text-xs text-muted-foreground">
                <CheckCircle2 className="h-3.5 w-3.5" />
                장기 미접촉
              </span>
              <span className="text-xl font-bold tabular-nums text-muted-foreground">0</span>
            </div>
          )}

          {/* 오늘의 일정 */}
          <Card className="shadow-card">
            <CardContent className="pt-6">
              <TodaySchedule
                sessions={calendarSessions}
                holidayName={todayHoliday}
                schoolEvents={todaySchoolEvents}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>

    {/* 홈 카드 → 사례 목록 팝업 */}
    <CaseListDialog
      open={caseDialog === 'active'}
      onClose={() => setCaseDialog(null)}
      title="진행 중 사례"
      description="현재 진행 중인 케이스로드"
      cases={activeCases}
      emptyLabel="진행 중인 사례가 없습니다."
    />
    <CaseListDialog
      open={caseDialog === 'stale'}
      onClose={() => setCaseDialog(null)}
      title="장기 미접촉 사례"
      description={`${staleDays}일 이상 상담이 없는 진행 사례 · 오래된 순`}
      cases={staleCases}
      emptyLabel="방치된 사례가 없습니다."
      showLastSession
    />

    {/* 타임블로킹 사이드 패널 */}
    <SideSheet
      open={!!panelDate}
      onClose={() => setPanelDate(null)}
      title={panelDate ? format(parseISO(panelDate), 'M월 d일 EEEE', { locale: ko }) : ''}
    >
      {panelDate && (
        <DayTimeGrid
          date={panelDate}
          sessions={calendarSessions}
          onUpdate={() => loadCalendar(calendarRange.from, calendarRange.to)}
          onAddSession={(dateStr) => { setPanelDate(null); setQuickAdd({ date: dateStr }); }}
        />
      )}
    </SideSheet>

    {/* 빠른 일정 등록 (사례 선택 → 세션 폼) */}
    <QuickSessionDialog
      open={!!quickAdd}
      initialDate={quickAdd?.date}
      onClose={() => setQuickAdd(null)}
      onSuccess={() => { setQuickAdd(null); loadCalendar(calendarRange.from, calendarRange.to); }}
    />
    </>
  );
}
