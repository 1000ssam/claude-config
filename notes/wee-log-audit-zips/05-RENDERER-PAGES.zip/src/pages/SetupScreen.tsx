import { useState } from 'react';
import { Lock, Copy, Check, ShieldCheck } from 'lucide-react';
import { WeeStoryLogo } from '@/components/logo-wee-story';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface SetupScreenProps {
  onComplete: () => void;
}

type Step = 'password' | 'recovery';

export default function SetupScreen({ onComplete }: SetupScreenProps) {
  const [step, setStep] = useState<Step>('password');

  // Step 1: password
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [hint, setHint] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Step 2: recovery
  const [recoveryPhrase, setRecoveryPhrase] = useState('');
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [confirmed, setConfirmed] = useState(false);

  async function handleSetup() {
    setError('');
    if (password.length < 8) {
      setError('비밀번호는 최소 8자 이상이어야 합니다.');
      return;
    }
    if (password !== confirm) {
      setError('비밀번호가 일치하지 않습니다.');
      return;
    }

    setLoading(true);
    try {
      const result = await window.api.auth.setup(password, hint.trim() || undefined);
      if (result.success) {
        setStep('recovery');
      } else {
        setError(result.error || '비밀번호 설정에 실패했습니다.');
      }
    } catch {
      setError('오류가 발생했습니다. 다시 시도해주세요.');
    } finally {
      setLoading(false);
    }
  }

  async function handleGenerateRecovery() {
    setGenerating(true);
    try {
      const result = await window.api.auth.generateRecovery();
      if (result.success && result.phrase) {
        setRecoveryPhrase(result.phrase);
        setCopied(false);
        setConfirmed(false);
      }
    } finally {
      setGenerating(false);
    }
  }

  function handleCopy() {
    navigator.clipboard.writeText(recoveryPhrase);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  if (step === 'recovery') {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-muted/40 via-background to-muted/20">
        <div className="w-full max-w-md px-8">
          <div className="flex flex-col items-center gap-4 text-center mb-10">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
              <ShieldCheck className="h-8 w-8 text-primary" />
            </div>
            <div className="space-y-1.5">
              <h1 className="text-2xl font-semibold tracking-tight">복구 코드 생성</h1>
              <p className="text-sm text-muted-foreground">
                비밀번호를 잊었을 때 데이터를 복구하는 데 사용됩니다.
              </p>
            </div>
          </div>

          <Card className="shadow-sm">
            <CardContent className="pt-6 space-y-5">
              {!recoveryPhrase ? (
                <>
                  <div className="rounded-lg border border-border bg-muted/30 p-4 text-sm text-muted-foreground leading-relaxed">
                    복구 코드를 안전한 곳(메모장, 인쇄 등)에 보관하세요.
                    코드를 분실하면 비밀번호 분실 시 데이터를 복구할 수 없습니다.
                  </div>
                  <Button className="w-full h-11" onClick={handleGenerateRecovery} disabled={generating}>
                    {generating ? '생성 중...' : '복구 코드 생성하기'}
                  </Button>
                </>
              ) : (
                <>
                  <div className="rounded-lg border border-border bg-muted/30 p-4 space-y-3">
                    <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">복구 코드</p>
                    <p className="font-mono text-sm font-semibold tracking-widest text-foreground break-all leading-relaxed">
                      {recoveryPhrase}
                    </p>
                    <Button variant="outline" size="sm" className="w-full" onClick={handleCopy}>
                      {copied ? (
                        <><Check className="mr-2 h-4 w-4 text-green-600" />복사 완료</>
                      ) : (
                        <><Copy className="mr-2 h-4 w-4" />코드 복사</>
                      )}
                    </Button>
                  </div>

                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={confirmed}
                      onChange={(e) => setConfirmed(e.target.checked)}
                      className="h-4 w-4 accent-primary"
                    />
                    <span className="text-sm text-foreground">
                      안전한 곳에 보관했습니다.
                    </span>
                  </label>

                  <Button className="w-full h-11" onClick={onComplete} disabled={!confirmed}>
                    앱 시작
                  </Button>
                </>
              )}
            </CardContent>
          </Card>

          <button
            onClick={onComplete}
            className="w-full text-center text-xs text-muted-foreground hover:text-foreground transition-colors mt-6"
          >
            건너뛰기 (복구 코드 없이 사용)
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-muted/40 via-background to-muted/20">
      <div className="w-full max-w-md px-8">
        {/* Logo */}
        <div className="flex flex-col items-center gap-3 text-center mb-10">
          <WeeStoryLogo height={48} />
          <p className="text-sm text-muted-foreground">상담 기록을 보호할 비밀번호를 설정하세요.</p>
        </div>

        {/* Form */}
        <Card className="shadow-sm">
          <CardContent className="pt-6 space-y-5">
            <div className="space-y-1.5">
              <Label htmlFor="password">비밀번호</Label>
              <Input
                id="password"
                type="password"
                placeholder="8자 이상"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSetup()}
                className="h-11"
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="confirm">비밀번호 확인</Label>
              <Input
                id="confirm"
                type="password"
                placeholder="비밀번호 재입력"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSetup()}
                className="h-11"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="hint">
                비밀번호 힌트 <span className="text-muted-foreground font-normal">(선택)</span>
              </Label>
              <Input
                id="hint"
                type="text"
                placeholder="기억을 도울 힌트 (비밀번호 자체는 입력하지 마세요)"
                value={hint}
                onChange={(e) => setHint(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSetup()}
                className="h-11"
              />
            </div>

            {error && (
              <p className="text-sm text-destructive">{error}</p>
            )}

            <Button className="w-full h-11" onClick={handleSetup} disabled={loading}>
              <Lock className="mr-2 h-4 w-4" />
              {loading ? '설정 중...' : '비밀번호 설정'}
            </Button>
          </CardContent>
        </Card>

        <p className="text-center text-xs text-muted-foreground leading-relaxed mt-6">
          비밀번호를 분실하면 복구 코드가 없는 경우 데이터를 복구할 수 없습니다.
        </p>
      </div>
    </div>
  );
}
