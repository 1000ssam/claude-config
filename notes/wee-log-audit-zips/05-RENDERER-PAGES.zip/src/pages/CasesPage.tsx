import { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useTabNav } from '@/hooks/use-tab-nav';
import { Plus, Search, X, Pencil, Trash2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { LoadingState, ErrorState } from '@/components/ui/states';
import { FilterPopover } from '@/components/ui/filter-popover';
import { SortPopover } from '@/components/ui/sort-popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useLocalStorage } from '@/hooks/use-local-storage';
import type { CaseWithSessionCount } from '@/types/case';
import { CASE_STATUS_LABELS } from '@/lib/constants/options';
import { cn } from '@/lib/utils';
import { formatStudentEnrollment } from '@/lib/format-student';
import { applyFiltersAndSort, getDistinctValues } from '@/lib/filter-sort';
import { Switch } from '@/components/ui/switch';
import { getAcademicYear } from '@/lib/academic-year';

// ── 상수 ─────────────────────────────────────────────────────────────────────

const STATUS_DISPLAY: Record<string, string> = { active: '진행 중', closed: '종결' };

const FILTER_COLUMNS = [
  { key: 'status', label: '상태' },
] as const;
type FilterColumnKey = typeof FILTER_COLUMNS[number]['key'];

const SORT_COLUMNS = [
  { key: 'created_at', label: '등록일' },
  { key: 'session_count', label: '상담 횟수' },
  { key: 'last_session_date', label: '최근 상담일' },
] as const;
type SortColumnKey = typeof SORT_COLUMNS[number]['key'];

type CaseSortState = { col: SortColumnKey; dir: 'asc' | 'desc' } | null;
type FiltersState = Partial<Record<FilterColumnKey, string[]>>;

// ── CasesPage ────────────────────────────────────────────────────────────────

export default function CasesPage() {
  const { go } = useTabNav();
  const { addToast } = useToast();
  const [cases, setCases] = useState<CaseWithSessionCount[]>([]);
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useLocalStorage<FiltersState>('wee-log:cases:filters', {});
  const [sort, setSort] = useLocalStorage<CaseSortState>('wee-log:cases:sort', null);
  const [activeOnly, setActiveOnly] = useLocalStorage<boolean>('wee-log:cases:activeOnly', false);
  const [academicYear, setAcademicYear] = useLocalStorage<string>('wee-log:cases:year', '');
  const [availableYears, setAvailableYears] = useState<string[]>([]);
  const currentAcademicYear = getAcademicYear(new Date());
  const isNonCurrentYear = academicYear !== '' && academicYear !== currentAcademicYear;
  const [loading, setLoading] = useState(true);
  const [fetchError, setFetchError] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<number | null>(null);

  const displayedCases = useMemo(() => {
    const base = applyFiltersAndSort(cases, filters, sort);
    return activeOnly ? base.filter((c) => c.status === 'active') : base;
  }, [cases, filters, sort, activeOnly]);

  useEffect(() => {
    window.api.settings.get().then((s) => {
      if (!academicYear) setAcademicYear(s.academic_year || getAcademicYear(new Date()));
    });
    window.api.enrollments.years().then(setAvailableYears);
  }, []);

  useEffect(() => {
    if (academicYear) fetchCases();
  }, [academicYear]);

  async function fetchCases(searchTerm?: string) {
    setLoading(true);
    setFetchError(false);
    try {
      const params: { search?: string; year?: string } = {};
      if (searchTerm) params.search = searchTerm;
      if (academicYear) params.year = academicYear;
      const data = await window.api.cases.list(params);
      setCases(data);
    } catch {
      setFetchError(true);
    } finally {
      setLoading(false);
    }
  }

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    fetchCases(search);
  }

  async function handleDelete() {
    if (deleteTarget === null) return;
    try {
      await window.api.cases.delete(deleteTarget);
      addToast({ title: '사례가 삭제되었습니다.', variant: 'success' });
      fetchCases(search || undefined);
    } catch {
      addToast({ title: '삭제에 실패했습니다.', variant: 'destructive' });
    } finally {
      setDeleteTarget(null);
    }
  }

  return (
    <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
      {/* Header */}
      <div className="flex flex-col gap-4 px-4 lg:px-6">
        <h1 className="text-2xl font-bold">사례 관리</h1>
      </div>
      <div className="flex items-center justify-between px-4 lg:px-6">
        <div className="flex items-center gap-3 flex-wrap">
          <Select value={academicYear} onValueChange={setAcademicYear}>
            <SelectTrigger
              className={cn(
                'w-[140px] h-9',
                isNonCurrentYear && 'border-amber-500 text-amber-700',
              )}
            >
              <SelectValue placeholder="학년도 선택" />
            </SelectTrigger>
            <SelectContent>
              {availableYears.map((y) => (
                <SelectItem key={y} value={y}>{y}학년도</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-sm text-muted-foreground">
            {!loading && `총 ${displayedCases.length}건${displayedCases.length !== cases.length ? ` / ${cases.length}건` : ''}`}
          </p>
          {isNonCurrentYear && (
            <div className="flex items-center gap-1.5 text-amber-700">
              <AlertTriangle className="h-4 w-4 shrink-0" />
              <p className="text-xs">
                주의: 현재 학년도({currentAcademicYear})와 일치하지 않는 값입니다. 이 상태로 새 사례를 등록하면 {academicYear}학년도로 저장됩니다.
              </p>
            </div>
          )}
        </div>
        <Link to="/cases/new">
          <Button size="sm">
            <Plus className="mr-1.5 h-3.5 w-3.5" />
            새 사례 등록
          </Button>
        </Link>
      </div>

      {/* Search + Filter + Sort */}
      <div className="flex flex-wrap items-center gap-2 px-4 lg:px-6">
        <form onSubmit={handleSearch} className="flex gap-2 flex-1 min-w-0 max-w-md">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="이름, 사례번호, 주호소 검색..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 h-9"
            />
            {search && (
              <button
                type="button"
                onClick={() => { setSearch(''); fetchCases(); }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <Button type="submit" variant="secondary" size="sm">
            <Search className="mr-1.5 h-3.5 w-3.5" />검색
          </Button>
        </form>
        <FilterPopover
          columns={FILTER_COLUMNS}
          getValues={(col) => getDistinctValues(cases, col as FilterColumnKey)}
          filters={filters as Record<string, string[]>}
          onFiltersChange={(f) => setFilters(f as FiltersState)}
          displayValue={(col, val) => col === 'status' ? STATUS_DISPLAY[val] ?? val : val}
        />
        <SortPopover
          columns={SORT_COLUMNS}
          sort={sort}
          onSortChange={(s) => setSort(s as CaseSortState)}
        />
        <div className="h-5 w-px bg-border mx-0.5" />
        <label className="flex items-center gap-1.5 cursor-pointer select-none">
          <Switch checked={activeOnly} onCheckedChange={setActiveOnly} />
          <span className={cn('text-xs', activeOnly ? 'text-foreground font-medium' : 'text-muted-foreground')}>진행 중인 사례만</span>
        </label>
      </div>

      {/* Cases List */}
      <div className="px-4 lg:px-6">
        {loading ? (
          <LoadingState message="사례 목록을 불러오는 중..." />
        ) : fetchError ? (
          <ErrorState message="사례 목록을 불러오는데 실패했습니다." onRetry={() => fetchCases(search)} />
        ) : displayedCases.length === 0 ? (
          <Card className="shadow-sm">
            <CardContent className="flex flex-col items-center justify-center py-12 text-center">
              <p className="text-sm text-muted-foreground">
                {cases.length === 0 ? '등록된 사례가 없습니다' : '조건에 맞는 사례가 없습니다'}
              </p>
              {cases.length === 0 && (
                <Link to="/cases/new" className="mt-3">
                  <Button variant="outline" size="sm">
                    <Plus className="mr-1.5 h-3.5 w-3.5" />
                    첫 사례 등록하기
                  </Button>
                </Link>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {displayedCases.map((c) => (
              <CaseCard
                key={c.id}
                c={c}
                onNavigate={(e) => go(e, `/cases/${c.id}`)}
                onEdit={(e) => { e.stopPropagation(); go(e, `/cases/${c.id}?edit=true`); }}
                onDelete={(e) => { e.stopPropagation(); setDeleteTarget(c.id); }}
              />
            ))}
          </div>
        )}
      </div>

      <ConfirmDialog
        open={deleteTarget !== null}
        onOpenChange={(open) => { if (!open) setDeleteTarget(null); }}
        title="사례를 삭제하시겠습니까?"
        description="이 사례와 모든 상담 기록이 영구적으로 삭제됩니다. 이 작업은 되돌릴 수 없습니다."
        confirmLabel="삭제"
        variant="destructive"
        onConfirm={handleDelete}
      />
    </div>
  );
}

// ── CaseCard ─────────────────────────────────────────────────────────────────

interface CaseCardProps {
  c: CaseWithSessionCount;
  onNavigate: (e: React.MouseEvent) => void;
  onEdit: (e: React.MouseEvent) => void;
  onDelete: (e: React.MouseEvent) => void;
}

function CaseCard({ c, onNavigate, onEdit, onDelete }: CaseCardProps) {
  const student = c.students?.[0];
  const studentName = c.students?.length === 0
    ? '(학생 없음)'
    : c.students?.length === 1
      ? c.students[0].name
      : `${c.students[0].name} 외 ${c.students.length - 1}명`;
  const identity = student ? formatStudentEnrollment(student) : '';
  const statusColor = c.status === 'active' ? 'text-emerald-600' : 'text-muted-foreground';

  return (
    <div
      className="group relative flex flex-col rounded-lg border border-border bg-card p-4 shadow-sm cursor-pointer transition-[border-color,box-shadow] hover:border-border/80 hover:shadow-md"
      onClick={onNavigate}
      onAuxClick={onNavigate}
    >
      {/* 호버 시 액션 버튼 (우상단) */}
      <div className="absolute top-2.5 right-2.5 flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-foreground" title="수정" onClick={onEdit} onAuxClick={onEdit}>
          <Pencil className="h-3.5 w-3.5" />
        </Button>
        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" title="삭제" onClick={onDelete}>
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>

      {/* 1행: 이름 + 학적 + 성별 */}
      <div className="flex items-baseline gap-2 pr-14 mb-0.5">
        <span className="text-sm font-semibold truncate">{studentName}</span>
        {(identity || student?.gender) && (
          <span className="text-xs text-muted-foreground shrink-0">
            {[identity, student?.gender].filter(Boolean).join(' · ')}
          </span>
        )}
      </div>

      {/* 2행: 사례번호 + 상태 */}
      <div className="flex items-center gap-1.5 mb-3">
        <span className="font-mono text-xs text-muted-foreground">{c.case_number}</span>
        <span className="text-muted-foreground/40">·</span>
        <span className={cn('text-xs font-medium', statusColor)}>
          {CASE_STATUS_LABELS[c.status as keyof typeof CASE_STATUS_LABELS] || c.status}
        </span>
      </div>

      {/* 주호소 (있을 때만) */}
      {c.main_complaint && (
        <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed mb-3">
          {c.main_complaint}
        </p>
      )}

      {/* 하단: 상담 횟수 + 마지막 상담일 (항상 바닥 고정) */}
      <div className="flex items-center justify-between pt-2.5 mt-auto border-t border-border/60">
        <span className="text-xs text-muted-foreground">
          상담 <span className="font-medium text-foreground">{c.session_count}</span>회
        </span>
        {c.last_session_date && (
          <span className="text-xs text-muted-foreground">{c.last_session_date}</span>
        )}
      </div>
    </div>
  );
}
