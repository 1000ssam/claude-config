import { useEffect, useState } from 'react';
import { Link, useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { useTabNav } from '@/hooks/use-tab-nav';
import { Plus, ArrowLeft, Trash2, Pencil, Ban, RotateCcw, X, CheckCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CaseForm } from '@/components/cases/case-form';
import { ConceptualizationTab } from '@/components/cases/conceptualization-tab';
import { ConsentPanel } from '@/components/consent/consent-panel';
import { AiSummaryStatusBanner } from '@/components/ai/ai-summary-status-banner';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { PrintPopover } from '@/components/ui/print-popover';
import { PrintableHeader } from '@/components/ui/printable-header';
import { LoadingState, NotFoundState } from '@/components/ui/states';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import type { Case } from '@/types/case';
import type { Session } from '@/types/session';
import type { CaseConceptualization } from '@/types/conceptualization';
import { getTemplateByType } from '@/lib/constants/conceptualization-templates';
import { CASE_STATUS_LABELS, CLOSE_REASON_OPTIONS } from '@/lib/constants/options';
import { formatStudentFull, formatStudentNames } from '@/lib/format-student';
import { appendBackContext } from '@/lib/back-link';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

export default function CaseDetailPage() {
  const { caseId } = useParams<{ caseId: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { linkProps } = useTabNav();
  const { addToast } = useToast();
  const [caseData, setCaseData] = useState<Case | null>(null);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [conceptualization, setConceptualization] = useState<CaseConceptualization | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [isEditing, setIsEditing] = useState(searchParams.get('edit') === 'true');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteSessionTarget, setDeleteSessionTarget] = useState<number | null>(null);
  const [closeDialogOpen, setCloseDialogOpen] = useState(false);
  const [reopenDialogOpen, setReopenDialogOpen] = useState(false);
  const [closeReason, setCloseReason] = useState<string>('');
  const [closeReasonDetail, setCloseReasonDetail] = useState<string>('');
  const [closingCase, setClosingCase] = useState(false);

  function refreshData() {
    setLoading(true);
    setError(false);
    Promise.all([
      window.api.cases.get(Number(caseId)),
      window.api.sessions.list(Number(caseId)),
      window.api.conceptualizations.get(Number(caseId)),
    ]).then(([c, s, concept]) => {
      if (!c) { setError(true); setLoading(false); return; }
      setCaseData(c);
      setSessions(s);
      setConceptualization(concept ?? null);
      setLoading(false);
    }).catch((e) => {
      console.error('[CaseDetail] load', e);
      setError(true);
      setLoading(false);
    });
  }

  useEffect(() => {
    refreshData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [caseId]);

  async function handleDelete() {
    try {
      await window.api.cases.delete(Number(caseId));
      addToast({ title: '사례가 삭제되었습니다.', variant: 'success' });
      navigate('/cases');
    } catch {
      addToast({ title: '삭제에 실패했습니다.', variant: 'destructive' });
    }
  }

  async function handleDeleteSession() {
    if (deleteSessionTarget === null) return;
    try {
      await window.api.sessions.delete(deleteSessionTarget);
      addToast({ title: '상담 기록이 삭제되었습니다.', variant: 'success' });
      refreshData();
    } catch {
      addToast({ title: '삭제에 실패했습니다.', variant: 'destructive' });
    } finally {
      setDeleteSessionTarget(null);
    }
  }

  async function handleClose() {
    if (!closeReason) {
      addToast({ title: '종료 사유를 선택해주세요.', variant: 'destructive' });
      return;
    }
    if (closeReason === '기타' && !closeReasonDetail.trim()) {
      addToast({ title: '기타 사유를 입력해주세요.', variant: 'destructive' });
      return;
    }
    setClosingCase(true);
    try {
      await window.api.cases.update(Number(caseId), {
        status: 'closed',
        close_reason: closeReason,
        close_reason_detail: closeReason === '기타' ? closeReasonDetail.trim() : null,
      });
      setCaseData((prev) => prev ? {
        ...prev,
        status: 'closed' as const,
        close_reason: closeReason,
        close_reason_detail: closeReason === '기타' ? closeReasonDetail.trim() : null,
      } : null);
      setCloseDialogOpen(false);
      setCloseReason('');
      setCloseReasonDetail('');
      addToast({ title: '사례가 종료되었습니다.', variant: 'success' });
    } catch {
      addToast({ title: '상태 변경에 실패했습니다.', variant: 'destructive' });
    } finally {
      setClosingCase(false);
    }
  }

  async function handleReopen() {
    setClosingCase(true);
    try {
      await window.api.cases.update(Number(caseId), {
        status: 'active',
        close_reason: null,
        close_reason_detail: null,
      });
      setCaseData((prev) => prev ? {
        ...prev,
        status: 'active' as const,
        close_reason: null,
        close_reason_detail: null,
      } : null);
      addToast({ title: '사례가 재개되었습니다.', variant: 'success' });
    } catch {
      addToast({ title: '상태 변경에 실패했습니다.', variant: 'destructive' });
    } finally {
      setClosingCase(false);
    }
  }

  if (loading) return <LoadingState message="사례 정보를 불러오는 중..." />;
  if (error) return <NotFoundState message="사례를 불러올 수 없습니다." backHref="/cases" backLabel="사례 목록으로" />;
  if (!caseData) return <NotFoundState message="사례를 찾을 수 없습니다." backHref="/cases" backLabel="사례 목록으로" />;

  // Edit mode view
  function exitEditMode() {
    setIsEditing(false);
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      next.delete('edit');
      return next;
    }, { replace: true });
    refreshData();
  }

  if (isEditing) {
    return (
      <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
        <div className="px-4 lg:px-6">
          <h1 className="text-base font-medium">사례 수정</h1>
        </div>
        <div className="flex flex-col gap-4 px-4 lg:px-6">
          <Button
            variant="ghost"
            size="sm"
            className="w-fit"
            onClick={exitEditMode}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            상세로 돌아가기
          </Button>
          <CaseForm
            initialData={caseData}
            isEdit
            onCancel={exitEditMode}
          />
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
        {/* Header */}
        <div className="flex items-center justify-between px-4 lg:px-6 print:hidden">
          <div className="flex items-center gap-2">
            <h1 className="text-base font-medium">사례 {caseData.case_number}</h1>
            {caseData.academic_year && (
              <Badge variant="outline" className="text-xs font-normal">
                {caseData.academic_year}학년도
              </Badge>
            )}
          </div>
          <div className="flex gap-2">
            <PrintPopover
              defaultName={`사례_${caseData.case_number}`}
            />
            <Link to={`/cases/${caseId}/sessions/new`}>
              <Button size="sm">
                <Plus className="mr-1.5 h-3.5 w-3.5" />
                상담 기록 추가
              </Button>
            </Link>
            {caseData.status === 'active' && (
              <Button variant="outline" size="sm" onClick={() => setCloseDialogOpen(true)} disabled={closingCase}>
                {closingCase ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Ban className="mr-1.5 h-3.5 w-3.5" />}
                {closingCase ? '처리 중...' : '사례 종료'}
              </Button>
            )}
            {caseData.status === 'closed' && (
              <Button variant="outline" size="sm" onClick={() => setReopenDialogOpen(true)} disabled={closingCase}>
                {closingCase ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="mr-1.5 h-3.5 w-3.5" />}
                {closingCase ? '처리 중...' : '사례 재개'}
              </Button>
            )}
            <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
              <Pencil className="mr-1.5 h-3.5 w-3.5" />
              수정
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setDeleteDialogOpen(true)}
              title="사례 삭제"
              className="text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <PrintableHeader
          title={`사례 ${caseData.case_number}`}
          subtitle={`${formatStudentNames(caseData.students, 'full')} · ${caseData.academic_year}학년도`}
        />

        {/* Content */}
        <div className="flex flex-col gap-4 px-4 lg:px-6">
          <Button variant="ghost" size="sm" className="w-fit print:hidden" {...linkProps('/cases')}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            목록으로
          </Button>

          <AiSummaryStatusBanner
            caseId={Number(caseId)}
            sessions={sessions}
            onAfterRefresh={refreshData}
          />

          {/* ── 인쇄 전용: 사례 정보 + 전체 세션 내용 ── */}
          <div className="hidden print:block space-y-6">
            {/* 내담자 정보 */}
            <div className="space-y-1 text-sm">
              <h2 className="font-semibold text-base">내담자 정보</h2>
              {caseData.students.map(s => (
                <p key={s.student_id}>{formatStudentFull(s)}</p>
              ))}
            </div>
            {caseData.main_complaint && (
              <div className="space-y-1 text-sm">
                <h2 className="font-semibold text-base">주호소</h2>
                <p className="whitespace-pre-wrap leading-relaxed">{caseData.main_complaint}</p>
              </div>
            )}
            {/* 사례 개념화 */}
            {conceptualization && (() => {
              const tmpl = getTemplateByType(conceptualization.template_type);
              const hasContent = Object.values(conceptualization.sections).some((v) => !!v);
              if (!tmpl || !hasContent) return null;
              return (
                <div className="space-y-3">
                  <h2 className="font-semibold text-base">
                    사례 개념화
                    <span className="ml-2 text-xs font-normal text-muted-foreground">({tmpl.label})</span>
                  </h2>
                  {tmpl.sections.map((s) => {
                    const value = conceptualization.sections[s.key];
                    if (!value) return null;
                    return (
                      <div key={s.key} className="text-sm print:break-inside-avoid">
                        <p className="font-medium">{s.label}</p>
                        <p className="whitespace-pre-wrap leading-relaxed mt-0.5 pl-2">{value}</p>
                      </div>
                    );
                  })}
                </div>
              );
            })()}
            {/* 전체 세션 */}
            {sessions.length > 0 && (
              <div className="space-y-4">
                <h2 className="font-semibold text-base">상담 기록 ({sessions.length}건)</h2>
                {/* 인쇄는 시간순(오름차순) — 화면 최신순과 별개로 1회차→N회차로 읽히게. */}
                {[...sessions]
                  .sort((a, b) =>
                    a.session_date < b.session_date ? -1
                      : a.session_date > b.session_date ? 1
                      : (a.session_number ?? 0) - (b.session_number ?? 0) || a.id - b.id,
                  )
                  .map((s, idx) => (
                  <div key={s.id} className={`border-t pt-3${idx > 0 && idx % 5 === 0 ? ' print-page-break' : ''}`}>
                    {/* 제목+날짜: 페이지 분할 방지 */}
                    <div className="print:break-inside-avoid">
                      <div className="flex items-baseline gap-2">
                        <span className="font-medium text-sm">{s.session_number != null ? `${s.session_number}회차` : s.category_large}</span>
                        <span className="text-xs text-muted-foreground">
                          {s.session_date} · {s.category_large} › {s.category_medium} › {s.category_detail}
                        </span>
                      </div>
                      <p className={cn('text-sm font-medium mt-1', !s.session_title && 'italic text-muted-foreground')}>
                        {s.session_title || '(제목 없음)'}
                      </p>
                    </div>
                    {/* 본문: 자연 분할 허용 */}
                    <p className={cn('text-sm whitespace-pre-wrap leading-relaxed mt-1', !s.session_content && 'italic text-muted-foreground')}>
                      {s.session_content || '(내용 없음)'}
                    </p>
                    {s.internal_notes && (
                      <div className="mt-2 pl-3 border-l-2 border-muted-foreground/30 print:border-muted-foreground">
                        <p className="text-xs text-muted-foreground">[내부 메모]</p>
                        <p className="text-sm whitespace-pre-wrap">{s.internal_notes}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <Tabs
            value={searchParams.get('tab') ?? 'overview'}
            onValueChange={(v) => {
              setSearchParams((prev) => {
                const next = new URLSearchParams(prev);
                next.set('tab', v);
                return next;
              }, { replace: true });
            }}
            className="print:hidden"
          >
            <TabsList>
              <TabsTrigger value="overview">개요</TabsTrigger>
              <TabsTrigger value="conceptualization">사례 개념화</TabsTrigger>
              <TabsTrigger value="sessions">상담 기록 ({sessions.length})</TabsTrigger>
              <TabsTrigger value="consent">동의서</TabsTrigger>
            </TabsList>

            {/* ── 개요 탭 ── */}
            <TabsContent value="overview">
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="shadow-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      내담자 정보
                      <Badge variant={caseData.status === 'active' ? 'success' : 'secondary'}>
                        {CASE_STATUS_LABELS[caseData.status]}
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {caseData.students.length === 0 ? (
                      <p className="text-sm text-muted-foreground">(등록된 학생 없음)</p>
                    ) : caseData.students.length === 1 ? (
                      <div className="space-y-1.5 text-sm">
                        <p>
                          <span className="text-muted-foreground">이름:</span>{' '}
                          {caseData.students[0].student_id ? (
                            <Link
                              to={appendBackContext(
                                `/students/${caseData.students[0].student_id}`,
                                'case',
                                { caseId: Number(caseId) },
                              )}
                              className="font-medium text-primary hover:underline"
                            >
                              {caseData.students[0].name}
                            </Link>
                          ) : (
                            caseData.students[0].name
                          )}
                        </p>
                        {caseData.students[0].grade && <p><span className="text-muted-foreground">학년:</span> {caseData.students[0].grade}</p>}
                        {caseData.students[0].class_name && <p><span className="text-muted-foreground">반:</span> {caseData.students[0].class_name}</p>}
                        {caseData.students[0].number && <p><span className="text-muted-foreground">번호:</span> {caseData.students[0].number}</p>}
                        {caseData.students[0].gender && <p><span className="text-muted-foreground">성별:</span> {caseData.students[0].gender}</p>}
                      </div>
                    ) : (
                      <div className="overflow-x-auto rounded-md border">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b bg-muted/50">
                              <th className="px-3 py-1.5 text-left font-medium text-muted-foreground">이름</th>
                              <th className="px-3 py-1.5 text-left font-medium text-muted-foreground">학년</th>
                              <th className="px-3 py-1.5 text-left font-medium text-muted-foreground">반</th>
                              <th className="px-3 py-1.5 text-left font-medium text-muted-foreground">번호</th>
                              <th className="px-3 py-1.5 text-left font-medium text-muted-foreground">성별</th>
                            </tr>
                          </thead>
                          <tbody>
                            {caseData.students.map((s) => (
                              <tr key={s.student_id} className="border-b last:border-b-0">
                                <td className="px-3 py-1.5 font-medium">
                                  {s.student_id ? (
                                    <Link
                                      to={appendBackContext(`/students/${s.student_id}`, 'case', { caseId: Number(caseId) })}
                                      className="text-primary hover:underline"
                                    >
                                      {s.name}
                                    </Link>
                                  ) : (
                                    s.name
                                  )}
                                </td>
                                <td className="px-3 py-1.5">{s.grade || '-'}</td>
                                <td className="px-3 py-1.5">{s.class_name || '-'}</td>
                                <td className="px-3 py-1.5">{s.number || '-'}</td>
                                <td className="px-3 py-1.5">{s.gender || '-'}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card className="shadow-sm">
                  <CardHeader>
                    <CardTitle>보호자 / 의뢰 정보</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    {caseData.students.map((s) => (
                      <div key={s.student_id} className="space-y-1.5">
                        {s.guardian_name ? (
                          <>
                            <p>
                              <span className="text-muted-foreground">보호자:</span>{' '}
                              {s.guardian_name}{s.guardian_relation && `(${s.guardian_relation})`}
                            </p>
                            {s.guardian_contact && (
                              <p>
                                <span className="text-muted-foreground">연락처:</span>{' '}
                                {s.guardian_contact}
                              </p>
                            )}
                          </>
                        ) : (
                          <p className="text-muted-foreground">보호자 미등록</p>
                        )}
                      </div>
                    ))}
                    {caseData.students.length === 0 && (
                      <p className="text-muted-foreground">등록된 학생이 없습니다.</p>
                    )}
                    {caseData.referrer_name && (
                      <div className="pt-2 border-t">
                        <p><span className="text-muted-foreground">의뢰인:</span> {caseData.referrer_name} ({caseData.referrer_role})</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {caseData.main_complaint && (
                <Card className="shadow-sm mt-4">
                  <CardHeader><CardTitle>주호소</CardTitle></CardHeader>
                  <CardContent>
                    <p className="text-sm whitespace-pre-wrap leading-relaxed">{caseData.main_complaint}</p>
                  </CardContent>
                </Card>
              )}

              {caseData.counseling_goal && (
                <Card className="shadow-sm mt-4">
                  <CardHeader><CardTitle>상담 목표</CardTitle></CardHeader>
                  <CardContent>
                    <p className="text-sm whitespace-pre-wrap leading-relaxed">{caseData.counseling_goal}</p>
                  </CardContent>
                </Card>
              )}

              {caseData.teacher_opinion && (
                <Card className="shadow-sm mt-4">
                  <CardHeader><CardTitle>교사 의견</CardTitle></CardHeader>
                  <CardContent>
                    <p className="text-sm whitespace-pre-wrap leading-relaxed">{caseData.teacher_opinion}</p>
                  </CardContent>
                </Card>
              )}

              {caseData.notes && (
                <Card className="shadow-sm mt-4">
                  <CardHeader><CardTitle>메모</CardTitle></CardHeader>
                  <CardContent>
                    <p className="text-sm whitespace-pre-wrap leading-relaxed">{caseData.notes}</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* ── 사례 개념화 탭 ── */}
            <TabsContent value="conceptualization">
              <ConceptualizationTab caseId={Number(caseId)} />
            </TabsContent>

            {/* ── 동의서 탭 ── */}
            <TabsContent value="consent">
              <ConsentPanel caseId={Number(caseId)} students={caseData.students} />
            </TabsContent>

            {/* ── 상담 기록 탭 ── */}
            <TabsContent value="sessions">
              {sessions.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground">
                  <p>아직 상담 기록이 없습니다.</p>
                  <Link to={`/cases/${caseId}/sessions/new`}>
                    <Button variant="outline" className="mt-3">
                      <Plus className="mr-2 h-4 w-4" />
                      첫 상담 기록 작성
                    </Button>
                  </Link>
                </div>
              ) : (
                <Card className="shadow-sm overflow-hidden">
                  <div className="divide-y">
                    {sessions.map((s) => (
                      <div
                        key={s.id}
                        className="flex items-center gap-4 px-4 py-3 transition-colors hover:bg-muted/50"
                      >
                        <Link to={`/cases/${caseId}/sessions/${s.id}`} className="flex items-center gap-4 flex-1 min-w-0">
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-muted text-xs font-medium tabular-nums">
                            {s.session_number != null ? s.session_number : s.category_large.charAt(0)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className={cn('text-sm font-medium truncate', !s.session_title && 'italic text-muted-foreground')}>
                              {s.session_title || '(제목 없음)'}
                            </p>
                            <p className="mt-0.5 text-xs text-muted-foreground">
                              {s.session_date} · {s.category_large} › {s.category_medium}
                            </p>
                          </div>
                        </Link>
                        <div className="flex items-center gap-2 shrink-0">
                          <Badge variant="outline" className="text-xs tabular-nums">
                            {s.session_hour}h {s.session_minute}m
                          </Badge>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                            title="삭제"
                            onClick={() => setDeleteSessionTarget(s.id)}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              )}
              <ConfirmDialog
                open={deleteSessionTarget !== null}
                onOpenChange={(open) => { if (!open) setDeleteSessionTarget(null); }}
                title="상담 기록을 삭제하시겠습니까?"
                description="이 상담 기록이 영구적으로 삭제됩니다. 이 작업은 되돌릴 수 없습니다."
                confirmLabel="삭제"
                variant="destructive"
                onConfirm={handleDeleteSession}
              />
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Dialogs (outside main container) */}
      <ConfirmDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        title="사례를 삭제하시겠습니까?"
        description="이 사례와 모든 상담 기록이 영구적으로 삭제됩니다. 이 작업은 되돌릴 수 없습니다."
        confirmLabel="삭제"
        variant="destructive"
        onConfirm={handleDelete}
      />
      {/* 사례 종료 다이얼로그 */}
      <Dialog open={closeDialogOpen} onOpenChange={(open) => {
        setCloseDialogOpen(open);
        if (!open) { setCloseReason(''); setCloseReasonDetail(''); }
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>사례를 종료하시겠습니까?</DialogTitle>
            <DialogDescription>종료 사유를 선택해주세요.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <Select value={closeReason} onValueChange={(v) => { setCloseReason(v); if (v !== '기타') setCloseReasonDetail(''); }}>
              <SelectTrigger><SelectValue placeholder="종료 사유 선택" /></SelectTrigger>
              <SelectContent>
                {CLOSE_REASON_OPTIONS.map((o) => (
                  <SelectItem key={o} value={o}>{o}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {closeReason === '기타' && (
              <Input
                value={closeReasonDetail}
                onChange={(e) => setCloseReasonDetail(e.target.value)}
                placeholder="사유를 입력하세요"
              />
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCloseDialogOpen(false)} disabled={closingCase}><X className="mr-2 h-4 w-4" />취소</Button>
            <Button onClick={handleClose} disabled={closingCase}>
              {closingCase ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CheckCircle className="mr-2 h-4 w-4" />}
              {closingCase ? '처리 중...' : '종료'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 사례 재개 확인 다이얼로그 */}
      <ConfirmDialog
        open={reopenDialogOpen}
        onOpenChange={setReopenDialogOpen}
        title="사례를 재개하시겠습니까?"
        confirmLabel="재개"
        onConfirm={handleReopen}
      />
    </>
  );
}
