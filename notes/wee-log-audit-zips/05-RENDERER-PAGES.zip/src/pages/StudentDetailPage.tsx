import { useEffect, useState, useMemo } from 'react';
import { useParams } from 'react-router-dom';
import { useTabNav } from '@/hooks/use-tab-nav';
import { ArrowLeft, ChevronDown, ChevronRight, ArrowUpDown, Plus, Pencil, X, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LoadingState, NotFoundState } from '@/components/ui/states';
import { PrintPopover } from '@/components/ui/print-popover';
import { PrintableHeader } from '@/components/ui/printable-header';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { StudentFormFields } from '@/components/students/student-form-fields';
import { useStudentForm } from '@/hooks/use-student-form';
import { useToast } from '@/hooks/use-toast';
import { useLocalStorage } from '@/hooks/use-local-storage';
import type { StudentProfile, StudentProfileCase, StudentEnrollment } from '@/types/student';
import { formatStudentEnrollment } from '@/lib/format-student';
import { useBackLink } from '@/lib/back-link';
import { cn } from '@/lib/utils';

/** 학년도별로 enrollment + cases를 묶는 구조 */
interface YearSection {
  year: string;
  enrollment: StudentEnrollment | null;
  cases: StudentProfileCase[];
}

export default function StudentDetailPage() {
  const { studentId } = useParams<{ studentId: string }>();
  const { linkProps } = useTabNav();
  const backLink = useBackLink({ label: '학생 목록', href: '/students' });
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [sortAsc, setSortAsc] = useLocalStorage<boolean>('wee-log:student-detail:sortAsc', false);
  const [expandedYears, setExpandedYears] = useState<Set<string>>(new Set());
  const { addToast } = useToast();
  const [editOpen, setEditOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const editHook = useStudentForm();

  useEffect(() => {
    if (!studentId) return;
    setLoading(true);
    window.api.students.profile(Number(studentId)).then((data) => {
      if (!data) {
        setNotFound(true);
      } else {
        setProfile(data);
        // 최초 로드 시 가장 최근 학년도 자동 펼침
        const years = collectYears(data);
        if (years.length > 0) {
          const sorted = [...years].sort((a, b) => b.localeCompare(a));
          setExpandedYears(new Set([sorted[0]]));
        }
      }
    }).catch(() => {
      setNotFound(true);
    }).finally(() => {
      setLoading(false);
    });
  }, [studentId]);

  /** enrollment + cases에서 등장하는 모든 학년도 수집 */
  function collectYears(data: StudentProfile): string[] {
    const yearSet = new Set<string>();
    for (const e of data.enrollments) yearSet.add(e.academic_year);
    for (const c of data.cases) yearSet.add(c.academic_year);
    return [...yearSet];
  }

  /** 학년도별 섹션 생성 */
  const yearSections = useMemo((): YearSection[] => {
    if (!profile) return [];
    const years = collectYears(profile);
    const sections = years.map((year) => ({
      year,
      enrollment: profile.enrollments.find((e) => e.academic_year === year) || null,
      cases: profile.cases.filter((c) => c.academic_year === year),
    }));
    sections.sort((a, b) =>
      sortAsc ? a.year.localeCompare(b.year) : b.year.localeCompare(a.year),
    );
    return sections;
  }, [profile, sortAsc]);

  function toggleYear(year: string) {
    setExpandedYears((prev) => {
      const next = new Set(prev);
      if (next.has(year)) next.delete(year);
      else next.add(year);
      return next;
    });
  }


  function formatDate(dateStr: string): string {
    const d = new Date(dateStr);
    return `${d.getMonth() + 1}/${d.getDate()}`;
  }

  function formatDateFull(dateStr: string): string {
    const d = new Date(dateStr);
    return `${d.getFullYear()}. ${d.getMonth() + 1}. ${d.getDate()}.`;
  }

  /** 저장 후 프로필만 다시 불러온다(펼침 상태·로딩 스피너는 건드리지 않음). */
  async function reloadProfile() {
    if (!studentId) return;
    const data = await window.api.students.profile(Number(studentId));
    if (data) setProfile(data);
  }

  /**
   * 편집 다이얼로그를 연다. 학생 레코드(`Student`)에는 학적(학년·반·번호)이 없으므로
   * 코어 필드만 폼에 채운다. 학적은 학년도별(enrollment) 데이터라 여기서 다루지 않는다.
   */
  function openEdit() {
    if (!profile) return;
    const s = profile.student;
    editHook.reset({
      name: s.name,
      gender: s.gender || '',
      contact: s.contact || '',
      guardian_name: s.guardian_name || '',
      guardian_relation: s.guardian_relation || '',
      guardian_contact: s.guardian_contact || '',
    });
    setEditOpen(true);
  }

  async function handleEditSave(e: React.FormEvent) {
    e.preventDefault();
    if (!profile) return;
    const err = editHook.validate();
    if (err) { addToast({ title: err, variant: 'destructive' }); return; }
    setSaving(true);
    try {
      // 학적 필드(grade/class_name/number)는 enrollment 소관이라 전송하지 않는다.
      const { name, gender, contact, guardian_name, guardian_relation, guardian_contact } = editHook.form;
      await window.api.students.update(profile.student.id, {
        name, gender, contact, guardian_name, guardian_relation, guardian_contact,
      });
      addToast({ title: '학생 정보가 수정되었습니다.', variant: 'success' });
      setEditOpen(false);
      await reloadProfile();
    } catch {
      addToast({ title: '학생 정보 수정 중 오류가 발생했습니다.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <LoadingState message="학생 정보를 불러오는 중..." />;
  if (notFound || !profile) return <NotFoundState message="학생을 찾을 수 없습니다." backHref="/students" backLabel="학생 목록으로" />;

  const { student } = profile;
  const totalCases = profile.cases.length;
  const totalSessions = profile.cases.reduce((sum, c) => sum + c.sessions.length, 0);

  return (
    <div className="flex flex-col gap-4 py-4 md:gap-6 md:py-6">
      {/* ── 헤더 ──────────────────────────────────────────────── */}
      <div className="flex items-center justify-between px-4 lg:px-6 print:hidden">
        <div className="flex items-center gap-2 flex-wrap text-sm text-muted-foreground">
          <h1 className="text-base font-medium text-foreground">{student.name}</h1>
          <span className="text-border">·</span>
          <span className={student.status === '재학' ? 'text-primary font-medium' : ''}>{student.status}</span>
          {student.gender && (
            <>
              <span className="text-border">·</span>
              <span>{student.gender}</span>
            </>
          )}
          {student.contact && (
            <>
              <span className="text-border">·</span>
              <span>{student.contact}</span>
            </>
          )}
          {student.guardian_name && (
            <>
              <span className="text-border">·</span>
              <span>
                보호자: {student.guardian_name}
                {student.guardian_relation && `(${student.guardian_relation})`}
                {student.guardian_contact && ` ${student.guardian_contact}`}
              </span>
            </>
          )}
          <span className="text-border">·</span>
          <span>사례 {totalCases}건</span>
          <span className="text-border">·</span>
          <span>상담 {totalSessions}회</span>
        </div>
        <div className="flex gap-2">
          <PrintPopover defaultName={`학생_${student.name}`} />
          <Button size="sm" {...linkProps(`/cases/new?student=${student.id}`)}>
            <Plus className="mr-1.5 h-3.5 w-3.5" />
            사례 추가
          </Button>
          <Button size="sm" variant="outline" onClick={openEdit}>
            <Pencil className="mr-1.5 h-3.5 w-3.5" />
            수정
          </Button>
        </div>
      </div>
      <PrintableHeader
        title={`${student.name} 상담 기록`}
        subtitle={`${student.gender ? `${student.gender} · ` : ''}사례 ${totalCases}건 · 상담 ${totalSessions}회`}
      />

      {/* ── 인쇄 전용: 학년도별 요약 테이블 ── */}
      {yearSections.length > 0 && (
        <div className="hidden print:block px-4 lg:px-6">
          <table className="text-sm border-collapse" style={{ tableLayout: 'fixed', width: '100%' }}>
            <colgroup>
              <col style={{ width: '80px' }} />
              <col />
              <col style={{ width: '72px' }} />
              <col style={{ width: '72px' }} />
            </colgroup>
            <thead>
              <tr className="bg-secondary">
                <th className="border border-border px-3 py-1.5 text-left font-semibold">학년도</th>
                <th className="border border-border px-3 py-1.5 text-left font-semibold">학적</th>
                <th className="border border-border px-3 py-1.5 text-center font-semibold">사례</th>
                <th className="border border-border px-3 py-1.5 text-center font-semibold">상담</th>
              </tr>
            </thead>
            <tbody>
              {yearSections.map(({ year, enrollment, cases: yCases }) => (
                <tr key={year}>
                  <td className="border border-border px-3 py-1 tabular-nums">{year}</td>
                  <td className="border border-border px-3 py-1">{formatStudentEnrollment(enrollment)}</td>
                  <td className="border border-border px-3 py-1 text-center tabular-nums">{yCases.length}건</td>
                  <td className="border border-border px-3 py-1 text-center tabular-nums">
                    {yCases.reduce((sum, c) => sum + c.sessions.length, 0)}회
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ── Content ──────────────────────────────────────────── */}
      <div className="flex flex-col gap-4 px-4 lg:px-6">
        <Button variant="ghost" size="sm" className="w-fit print:hidden" {...linkProps(backLink.href)}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          {backLink.label}
        </Button>

      {/* ── 정렬 토글 ────────────────────────────────────────── */}
      <div className="flex items-center justify-between print:hidden">
        <h2 className="text-sm font-medium text-muted-foreground">학년도별 상담 기록</h2>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setSortAsc(!sortAsc)}
          className="text-xs text-muted-foreground"
        >
          <ArrowUpDown className="mr-1 h-3.5 w-3.5" />
          {sortAsc ? '과거순' : '최신순'}
        </Button>
      </div>

      {/* ── 인쇄 전용: 학년도별 사례 + 세션 전체 ── */}
      <div className="hidden print:block space-y-6">
        {yearSections.map(({ year, enrollment, cases: yCases }, idx) => (
          <div key={year} className={yearSections.length >= 3 && idx > 0 ? 'print-page-break' : ''}>
            <h2 className="font-semibold text-base border-b pb-1 mb-3">
              {year}학년도
              {enrollment && ` — ${formatStudentEnrollment(enrollment)}`}
            </h2>
            {yCases.length === 0 ? (
              <p className="text-sm text-muted-foreground">사례 없음</p>
            ) : (
              yCases.map((c) => (
                <div key={c.id} className="mb-4 print:break-inside-avoid">
                  <h3 className="text-sm font-semibold">
                    사례 {c.case_number}
                    <Badge variant={c.status === 'active' ? 'default' : 'secondary'} className="ml-2 text-xs">
                      {c.status === 'active' ? '진행중' : '종결'}
                    </Badge>
                  </h3>
                  {c.main_complaint && (
                    <p className="text-sm text-muted-foreground mt-0.5">주호소: {c.main_complaint}</p>
                  )}
                  {c.sessions.length > 0 && (
                    <div className="mt-2 ml-3 space-y-3">
                      {c.sessions.map((s) => (
                        <div key={s.id} className="border-t pt-2 print:break-inside-avoid">
                          <div className="flex items-baseline gap-2 text-sm">
                            <span className="font-medium">{s.session_number != null ? `${s.session_number}회차` : s.category_large}</span>
                            <span className="text-xs text-muted-foreground">
                              {s.session_date} · {s.category_large} › {s.category_medium} › {s.category_detail}
                            </span>
                          </div>
                          <p className={cn('text-sm font-medium mt-1', !s.session_title && 'italic text-muted-foreground')}>
                            {s.session_title || '(제목 없음)'}
                          </p>
                          <p className={cn('text-sm whitespace-pre-wrap leading-relaxed mt-1', !s.session_content && 'italic text-muted-foreground')}>
                            {s.session_content || '(내용 없음)'}
                          </p>
                          {s.internal_notes && (
                            <div className="mt-1.5 pl-3 border-l-2 border-muted-foreground/30">
                              <p className="text-xs text-muted-foreground">[내부 메모]</p>
                              <p className="text-sm whitespace-pre-wrap">{s.internal_notes}</p>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        ))}
      </div>

      {/* ── 학년도별 아코디언 (화면용, 인쇄 시 숨김) ── */}
      {yearSections.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center text-sm text-muted-foreground">
            등록된 학적 및 상담 기록이 없습니다.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-5 print:hidden">
          {yearSections.map((section) => {
            const isExpanded = expandedYears.has(section.year);
            return (
              <div key={section.year}>
                {/* 학년도 헤더 — 카드 밖 */}
                <button
                  onClick={() => toggleYear(section.year)}
                  className="flex w-full items-center gap-2 py-1.5 text-left text-sm transition-colors hover:text-foreground"
                >
                  {isExpanded
                    ? <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    : <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                  }
                  <span className="font-semibold text-foreground">{section.year}학년도</span>
                  <span className="text-muted-foreground">{formatStudentEnrollment(section.enrollment)}</span>
                  {section.cases.length > 0 && (
                    <span className="ml-auto text-xs text-muted-foreground">
                      사례 {section.cases.length}건
                    </span>
                  )}
                </button>

                {/* 사례 카드 리스트 */}
                {isExpanded && (
                  <div className="mt-2 space-y-3">
                    {section.cases.length === 0 ? (
                      <p className="text-sm text-muted-foreground py-2">등록된 사례 없음</p>
                    ) : (
                      section.cases.map((c) => (
                        <CaseSection key={c.id} caseData={c} formatDate={formatDate} formatDateFull={formatDateFull} />
                      ))
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
      </div>{/* /Content wrapper */}

      {/* 학생 정보 수정 다이얼로그 (코어 필드만 — 학적은 학년도별 enrollment 소관) */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="sm:max-w-[480px] max-h-[85vh] flex flex-col print:hidden">
          <DialogHeader>
            <DialogTitle>학생 정보 수정</DialogTitle>
            <DialogDescription>{student.name} 학생의 정보를 수정합니다. 학년·반·번호는 학년도별 학적에서 관리됩니다.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditSave} className="space-y-4 overflow-y-auto px-1 flex-1">
            <StudentFormFields hook={editHook} idPrefix="detail-edit" showEnrollmentFields={false} />
            <div className="flex justify-end gap-2 pt-2">
              <Button type="button" variant="outline" onClick={() => setEditOpen(false)}>
                <X className="mr-2 h-4 w-4" />취소
              </Button>
              <Button type="submit" disabled={saving}>
                <Save className="mr-2 h-4 w-4" />{saving ? '저장 중...' : '저장'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/** 사례 카드 + 세션 리스트 */
function CaseSection({
  caseData,
  formatDateFull,
}: {
  caseData: StudentProfileCase;
  formatDate: (d: string) => string;
  formatDateFull: (d: string) => string;
}) {
  const { linkProps } = useTabNav();
  const [expanded, setExpanded] = useState(caseData.status === 'active');

  return (
    <div className="rounded-lg border bg-card">
      {/* 사례 헤더 */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center gap-2 px-3 py-2.5 text-left text-sm hover:bg-muted/50 transition-colors rounded-t-lg"
      >
        {expanded
          ? <ChevronDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
          : <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
        }
        <span className="font-medium">사례 {caseData.case_number}</span>
        {caseData.main_complaint && (
          <span className="truncate text-muted-foreground">주호소: {caseData.main_complaint}</span>
        )}
        <Badge
          variant={caseData.status === 'active' ? 'success' : 'secondary'}
          className="ml-auto shrink-0 text-[11px]"
        >
          {caseData.status === 'active' ? '진행중' : '종결'}
        </Badge>
        <span className="shrink-0 text-xs text-muted-foreground tabular-nums">
          상담 {caseData.sessions.length}회
        </span>
      </button>

      {/* 세션 리스트 — 인쇄 레이아웃 기준 풀 콘텐츠 */}
      {expanded && caseData.sessions.length > 0 && (
        <div className="border-t divide-y">
          {caseData.sessions.map((s) => (
            <div key={s.id} className="px-4 py-3 space-y-1.5">
              {/* 메타 행: 회차 · 날짜 · 분류 · 배지 */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-semibold tabular-nums">
                  {s.session_number != null ? `${s.session_number}회차` : s.category_large}
                </span>
                <span className="text-xs text-muted-foreground">{formatDateFull(s.session_date)}</span>
                <Badge variant="outline" className="text-[11px]">{s.counseling_class}</Badge>
                <span className="text-xs text-muted-foreground ml-auto">
                  {[s.category_large, s.category_medium, s.category_detail].filter(Boolean).join(' › ')}
                </span>
              </div>

              {/* 세션 제목 — 클릭 시 세션 상세 이동 */}
              <button
                {...linkProps(`/cases/${s.case_id}/sessions/${s.id}`)}
                className={cn(
                  'text-sm font-medium text-left w-full hover:text-primary transition-colors',
                  !s.session_title && 'italic text-muted-foreground',
                )}
              >
                {s.session_title || '(제목 없음)'}
              </button>

              {/* 세션 내용 */}
              <p className={cn(
                'text-sm whitespace-pre-wrap leading-relaxed',
                s.session_content ? 'text-muted-foreground' : 'italic text-muted-foreground',
              )}>
                {s.session_content || '(내용 없음)'}
              </p>

              {/* 내부 메모 */}
              {s.internal_notes && (
                <div className="pl-3 border-l-2 border-muted-foreground/25 mt-2">
                  <p className="text-xs text-muted-foreground mb-0.5">[내부 메모]</p>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{s.internal_notes}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* 세션 없는 사례 */}
      {expanded && caseData.sessions.length === 0 && (
        <div className="border-t px-3 py-2 text-sm text-muted-foreground">
          상담 기록 없음
        </div>
      )}

      {/* 사례 상세 바로가기 */}
      {expanded && (
        <div className="border-t px-3 py-2">
          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-muted-foreground"
            {...linkProps(`/cases/${caseData.id}`)}
          >
            사례 상세 보기 →
          </Button>
        </div>
      )}
    </div>
  );
}
