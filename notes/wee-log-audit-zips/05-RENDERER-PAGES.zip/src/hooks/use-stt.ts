// STT 훅 — 마이크 녹음 + 메인 프로세스 전사 요청 + 이벤트 구독.
// - getUserMedia + MediaRecorder 로 webm/opus 캡쳐
// - 녹음 종료 시 ArrayBuffer 로 메인에 전달 → 전사 결과 콜백 호출
// - 모델 상태(다운로드 진행률 포함)도 함께 추적

import { useCallback, useEffect, useRef, useState } from 'react';

import type {
  SttEvent,
  SttStatus,
  SttTranscribeResult,
} from '../../lib/stt/stt-types';

export interface UseSttOptions {
  /**
   * 전사 결과를 사용자가 받았을 때 호출. 결과 텍스트를 어디에 채울지는 호출자가 결정.
   */
  onTranscribed?: (result: SttTranscribeResult) => void;
  /**
   * 에러 발생 시 토스트 표시 등에 활용
   */
  onError?: (message: string) => void;
}

export type RecorderPhase =
  | 'idle'
  | 'requesting-mic'
  | 'recording'
  | 'uploading'    // 메인에 보내기 직전
  | 'converting'   // 메인에서 ffmpeg 변환 중
  | 'transcribing' // 메인에서 whisper 실행 중
  | 'error';

export interface UseSttReturn {
  status: SttStatus | null;
  refresh: () => Promise<void>;
  phase: RecorderPhase;
  errorMessage: string | null;
  recordingMs: number;       // 녹음 경과 시간 (ms)
  start: () => Promise<void>;
  stop: () => Promise<void>;
  cancel: () => Promise<void>;
  downloadModel: () => Promise<void>;
  cancelModelDownload: () => Promise<void>;
}

const MIME_CANDIDATES = [
  'audio/webm;codecs=opus',
  'audio/webm',
  'audio/ogg;codecs=opus',
  'audio/mp4',
];

function pickMimeType(): string {
  if (typeof MediaRecorder === 'undefined') return 'audio/webm';
  for (const m of MIME_CANDIDATES) {
    if (MediaRecorder.isTypeSupported(m)) return m;
  }
  return 'audio/webm';
}

export function useStt(opts: UseSttOptions = {}): UseSttReturn {
  const [status, setStatus] = useState<SttStatus | null>(null);
  const [phase, setPhase] = useState<RecorderPhase>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [recordingMs, setRecordingMs] = useState(0);

  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const startedAtRef = useRef<number>(0);
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const activeRequestIdRef = useRef<string | null>(null);

  // 콜백 stale closure 방지 — onTranscribed/onError 는 매 렌더 갱신되는 inline 함수일 수 있어
  // ref 로 최신값을 추적하고, 이벤트 리스너에서는 ref 를 거쳐 호출한다.
  const callbacksRef = useRef(opts);
  callbacksRef.current = opts;

  /* ───── 상태 조회 ──────────────────────────────────────────────────── */

  const refresh = useCallback(async () => {
    try {
      const s = await window.api.stt.getStatus();
      setStatus(s);
    } catch (err) {
      setErrorMessage((err as Error).message);
    }
  }, []);

  useEffect(() => {
    void refresh();
    const off = window.api.stt.onEvent((evt) => handleEvent(evt));
    return off;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ───── 이벤트 핸들러 ─────────────────────────────────────────────── */

  const handleEvent = (evt: SttEvent) => {
    switch (evt.type) {
      case 'model-state':
        setStatus((prev) => (prev ? { ...prev, model: evt.status } : prev));
        break;
      case 'service-state':
        setStatus((prev) => (prev ? { ...prev, serviceState: evt.state, errorMessage: evt.message } : prev));
        break;
      case 'request-state':
        if (evt.requestId !== activeRequestIdRef.current) return;
        if (evt.state === 'converting') setPhase('converting');
        if (evt.state === 'transcribing') setPhase('transcribing');
        break;
      case 'transcribed':
        if (evt.requestId !== activeRequestIdRef.current) return;
        activeRequestIdRef.current = null;
        setPhase('idle');
        callbacksRef.current.onTranscribed?.(evt.result);
        break;
      case 'request-error':
        if (evt.requestId !== activeRequestIdRef.current) return;
        activeRequestIdRef.current = null;
        setPhase('error');
        setErrorMessage(evt.message);
        callbacksRef.current.onError?.(evt.message);
        break;
      case 'request-cancelled':
        if (evt.requestId !== activeRequestIdRef.current) return;
        activeRequestIdRef.current = null;
        setPhase('idle');
        break;
    }
  };

  /* ───── 녹음 제어 ─────────────────────────────────────────────────── */

  const cleanupRecorder = () => {
    if (tickRef.current) {
      clearInterval(tickRef.current);
      tickRef.current = null;
    }
    if (recorderRef.current && recorderRef.current.state !== 'inactive') {
      try { recorderRef.current.stop(); } catch { /* noop */ }
    }
    recorderRef.current = null;
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    chunksRef.current = [];
  };

  const start = useCallback(async () => {
    setErrorMessage(null);
    if (!status?.enabled) {
      setErrorMessage('STT 기능이 비활성화되어 있습니다.');
      return;
    }
    if (status.model.state !== 'ready') {
      setErrorMessage('먼저 STT 모델을 다운로드해주세요.');
      return;
    }
    if (!status.binaryAvailable) {
      setErrorMessage('whisper-cli 바이너리가 설치되어 있지 않습니다.');
      return;
    }

    setPhase('requesting-mic');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const mimeType = pickMimeType();
      const recorder = new MediaRecorder(stream, { mimeType });
      recorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
      };

      recorder.start(250); // 250ms 단위 chunk
      startedAtRef.current = Date.now();
      setRecordingMs(0);
      setPhase('recording');

      tickRef.current = setInterval(() => {
        setRecordingMs(Date.now() - startedAtRef.current);
      }, 100);
    } catch (err) {
      cleanupRecorder();
      setPhase('error');
      const msg = (err as Error).message ?? '마이크에 접근할 수 없습니다.';
      setErrorMessage(msg);
      callbacksRef.current.onError?.(msg);
    }
  }, [status]);

  const stop = useCallback(async () => {
    if (!recorderRef.current || recorderRef.current.state === 'inactive') return;
    const mimeType = recorderRef.current.mimeType;
    const durationMs = Date.now() - startedAtRef.current;

    setPhase('uploading');
    if (tickRef.current) { clearInterval(tickRef.current); tickRef.current = null; }

    const finished = new Promise<Blob>((resolve) => {
      recorderRef.current!.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mimeType });
        resolve(blob);
      };
      try { recorderRef.current!.stop(); } catch { /* noop */ }
    });

    const blob = await finished;
    cleanupRecorder();

    try {
      const buffer = await blob.arrayBuffer();
      const { requestId } = await window.api.stt.transcribe({
        audio: buffer,
        mimeType,
        durationMs,
        language: 'ko',
      });
      activeRequestIdRef.current = requestId;
    } catch (err) {
      setPhase('error');
      const msg = (err as Error).message ?? '전사 요청 실패';
      setErrorMessage(msg);
      callbacksRef.current.onError?.(msg);
    }
  }, []);

  const cancel = useCallback(async () => {
    if (activeRequestIdRef.current) {
      await window.api.stt.cancel(activeRequestIdRef.current);
      activeRequestIdRef.current = null;
    }
    cleanupRecorder();
    setPhase('idle');
  }, []);

  /* ───── 모델 다운로드 ─────────────────────────────────────────────── */

  const downloadModel = useCallback(async () => {
    setErrorMessage(null);
    try {
      const res = await window.api.stt.downloadModel();
      if (!res.started && res.reason) setErrorMessage(res.reason);
    } catch (err) {
      setErrorMessage((err as Error).message);
    }
  }, []);

  const cancelModelDownload = useCallback(async () => {
    try {
      await window.api.stt.cancelDownload();
    } catch (err) {
      setErrorMessage((err as Error).message);
    }
  }, []);

  /* ───── unmount 정리 ──────────────────────────────────────────────── */

  useEffect(() => {
    return () => {
      cleanupRecorder();
    };
  }, []);

  return {
    status,
    refresh,
    phase,
    errorMessage,
    recordingMs,
    start,
    stop,
    cancel,
    downloadModel,
    cancelModelDownload,
  };
}
