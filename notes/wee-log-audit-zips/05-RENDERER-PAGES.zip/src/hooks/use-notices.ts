import { useState, useEffect } from 'react';
import type { Notice } from '@/types/electron.d';

export function useNotices() {
  const [notices, setNotices] = useState<Notice[]>([]);
  const [loading, setLoading] = useState(true);

  const reload = () => {
    setLoading(true);
    window.api.remote.getNotices()
      .then(setNotices)
      .catch((e) => { console.error('[useNotices] fetch', e); setNotices([]); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { reload(); }, []);

  const unreadCount = notices.filter((n) => !n.isRead).length;

  async function markAllRead() {
    const unread = notices.filter((n) => !n.isRead);
    await Promise.all(unread.map((n) => window.api.remote.markNoticeRead(n.id)));
    setNotices((prev) => prev.map((n) => ({ ...n, isRead: true })));
  }

  return { notices, loading, unreadCount, markAllRead, reload };
}
