import { useState, useCallback } from 'react';
import { formatPhoneNumber, validatePhoneNumber } from '@/lib/utils';
import type { CreateStudentInput } from '@/types/student';


const EMPTY_FORM: CreateStudentInput = {
  name: '',
  grade: '',
  class_name: '',
  number: '',
  gender: '',
  contact: '',
  guardian_name: '',
  guardian_relation: '',
  guardian_contact: '',
};

const PHONE_FIELDS: ReadonlySet<string> = new Set(['contact', 'guardian_contact']);

/** 학생 폼 필드 검증. 실패 시 에러 메시지, 성공 시 null. */
export function validateStudentFields(form: Partial<CreateStudentInput>): string | null {
  if (form.name !== undefined && !form.name.trim()) return '이름을 입력하세요.';
  if (form.contact) {
    const err = validatePhoneNumber(form.contact);
    if (err) return `학생 연락처: ${err}`;
  }
  if (form.guardian_contact) {
    const err = validatePhoneNumber(form.guardian_contact);
    if (err) return `보호자 연락처: ${err}`;
  }
  return null;
}

/** 학생 생성/수정 폼 상태 + 검증 + 전화번호 자동 포맷팅 */
export function useStudentForm(initialData?: Partial<CreateStudentInput>) {
  const [form, setForm] = useState<CreateStudentInput>({ ...EMPTY_FORM, ...initialData });

  const updateField = useCallback(<K extends keyof CreateStudentInput>(field: K, value: string) => {
    setForm(prev => ({
      ...prev,
      [field]: PHONE_FIELDS.has(field) ? formatPhoneNumber(value) : value,
    }));
  }, []);

  const validate = () => validateStudentFields(form);

  const reset = useCallback((data?: Partial<CreateStudentInput>) => {
    setForm({ ...EMPTY_FORM, ...data });
  }, []);

  return { form, updateField, validate, reset, setForm };
}
