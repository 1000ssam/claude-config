import { useCallback, type MouseEvent } from 'react';
import { useNavigate, type NavigateOptions } from 'react-router-dom';
import { useTabs } from '@/components/layout/tabs-context';

/**
 * 클릭 기반 네비게이션 헬퍼 — "모든 UI 링크에서 Ctrl/가운데버튼=새 탭".
 *
 * - 평클릭(왼쪽)         → 활성 탭 안에서 이동 (`navigate`)
 * - Ctrl/Cmd+클릭 · 가운데버튼 → 새 탭으로 열기 (`openTab`)
 * - 우클릭(button 2)     → 무시
 *
 * ⚠️ 저장/삭제 후 자동 리다이렉트나 `navigate(-1)`처럼 **클릭이 아닌 이동**에는
 *    쓰지 말 것 — 그 경우엔 기존대로 `useNavigate()`를 직접 사용한다.
 *
 * 사용:
 *   const { go, linkProps } = useTabNav();
 *   <button onClick={(e) => go(e, '/cases/1')} onAuxClick={(e) => go(e, '/cases/1')}>
 *   // 또는 한 번에:
 *   <Button {...linkProps('/cases/1')}>
 */
export function useTabNav() {
  const navigate = useNavigate();
  const { openTab } = useTabs();

  const go = useCallback(
    (e: MouseEvent, to: string, opts?: NavigateOptions) => {
      // button: 0=좌, 1=가운데, 2=우. onAuxClick은 비주요 버튼에서 발화.
      if (e.button === 1 || e.ctrlKey || e.metaKey) {
        e.preventDefault();
        openTab(to); // 새 탭은 해당 경로에서 시작 (location state는 미전달 — 새 히스토리)
      } else if (e.button === 0) {
        navigate(to, opts);
      }
    },
    [navigate, openTab],
  );

  /** onClick + onAuxClick(가운데버튼)을 한 번에 다는 props 생성기. */
  const linkProps = useCallback(
    (to: string, opts?: NavigateOptions) => ({
      onClick: (e: MouseEvent) => go(e, to, opts),
      onAuxClick: (e: MouseEvent) => go(e, to, opts),
    }),
    [go],
  );

  return { go, linkProps };
}
