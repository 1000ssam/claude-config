import { useCallback, useEffect, useRef, useState } from 'react';
import type {
  AiEvent,
  AiFinishReason,
  AiGenerateStartPayload,
  AiUsage,
} from '@/types/ai';

export type AiStreamStatus = 'idle' | 'streaming' | 'done' | 'error';

export interface AiStreamError {
  code: string;
  message: string;
}

export interface UseAiStreamResult {
  /** 누적된 응답 토큰. streaming 중에는 진행 중인 텍스트, done 후에는 최종 텍스트. */
  text: string;
  status: AiStreamStatus;
  error: AiStreamError | null;
  /** 종료 사유: 'stop' | 'length' | 'aborted' | 'error'. status='done' 일 때만 유의미. */
  finishReason: AiFinishReason | null;
  usage: AiUsage | null;
  /** 새 생성 시작. 이전 결과를 비우고 새 requestId로 ai:generate를 호출한다. */
  start: (
    payload: Omit<AiGenerateStartPayload, 'requestId'>,
  ) => Promise<{ requestId: string } | { error: AiStreamError }>;
  /** 진행 중인 생성을 취소한다. 부분 결과는 보존된다(메인 측 abort 설계). */
  cancel: () => Promise<void>;
  /** 텍스트·상태·오류를 초기 상태로 되돌린다. 진행 중이면 cancel도 수행한다. */
  reset: () => void;
  /** 현재 활성 requestId (없으면 null). 디버깅·외부 동기화용. */
  requestId: string | null;
}

/**
 * AI 토큰 스트리밍 훅.
 *
 * 책임:
 * - `window.api.ai.onEvent` 구독을 마운트 1회만 걸고, 자신의 `requestId`로 필터.
 * - 토큰을 ref에 누적하고 requestAnimationFrame으로 flush해 React re-render 스래싱 방지
 *   (CPU 추론 중 메인 스레드 부하를 줄이기 위함).
 * - 언마운트 시 구독 해제 + 스트리밍 중이면 cancel.
 */
export function useAiStream(): UseAiStreamResult {
  const [text, setText] = useState('');
  const [status, setStatus] = useState<AiStreamStatus>('idle');
  const [error, setError] = useState<AiStreamError | null>(null);
  const [finishReason, setFinishReason] = useState<AiFinishReason | null>(null);
  const [usage, setUsage] = useState<AiUsage | null>(null);
  const [requestId, setRequestId] = useState<string | null>(null);

  // 진행 중인 requestId — closure가 아니라 ref로 들고 다녀서 이벤트 핸들러가 항상 최신값을 본다.
  const requestIdRef = useRef<string | null>(null);

  // 토큰 버퍼: 도착 즉시 ref에 쌓고, RAF에서 setText로 일괄 반영.
  const bufferRef = useRef<string>('');
  const rafScheduledRef = useRef<boolean>(false);

  const flushBuffer = useCallback(() => {
    rafScheduledRef.current = false;
    const pending = bufferRef.current;
    if (!pending) return;
    bufferRef.current = '';
    setText((prev) => prev + pending);
  }, []);

  const scheduleFlush = useCallback(() => {
    if (rafScheduledRef.current) return;
    rafScheduledRef.current = true;
    // RAF가 가용한 환경(브라우저/렌더러)이면 RAF, 아니면 setTimeout 폴백.
    if (typeof requestAnimationFrame === 'function') {
      requestAnimationFrame(flushBuffer);
    } else {
      setTimeout(flushBuffer, 30);
    }
  }, [flushBuffer]);

  // 이벤트 구독 — 마운트 1회.
  useEffect(() => {
    const unsubscribe = window.api.ai.onEvent((evt: AiEvent) => {
      // 다운로드/모델 상태 이벤트(requestId='*')는 여기서 무시.
      if (evt.requestId === '*') return;

      const currentId = requestIdRef.current;
      if (!currentId || evt.requestId !== currentId) return;

      if (evt.type === 'token') {
        bufferRef.current += evt.token;
        scheduleFlush();
        return;
      }

      if (evt.type === 'done') {
        // 마지막 토큰까지 즉시 반영.
        if (bufferRef.current) {
          setText((prev) => prev + bufferRef.current);
          bufferRef.current = '';
          rafScheduledRef.current = false;
        }
        setFinishReason(evt.finishReason);
        setUsage(evt.usage);
        setStatus('done');
        // requestId는 finishReason 확인 후 reset에서 비운다 (UI에서 마지막 상태 추적 가능).
        return;
      }

      if (evt.type === 'error') {
        if (bufferRef.current) {
          setText((prev) => prev + bufferRef.current);
          bufferRef.current = '';
          rafScheduledRef.current = false;
        }
        setError({ code: evt.code, message: evt.message });
        setStatus('error');
        return;
      }
    });

    return () => {
      unsubscribe();
      // 언마운트 시점에 진행 중이면 베스트 에포트로 취소 요청.
      const id = requestIdRef.current;
      if (id) {
        void window.api.ai.cancel(id).catch(() => {
          /* 종료 중 — 무시 */
        });
      }
    };
    // scheduleFlush는 useCallback로 안정.
  }, [scheduleFlush]);

  const start = useCallback<UseAiStreamResult['start']>(async (payload) => {
    // 새 생성 직전: 이전 결과 클리어.
    bufferRef.current = '';
    rafScheduledRef.current = false;
    setText('');
    setError(null);
    setFinishReason(null);
    setUsage(null);

    const newId =
      typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
        ? crypto.randomUUID()
        : `req-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;

    requestIdRef.current = newId;
    setRequestId(newId);
    setStatus('streaming');

    try {
      const res = await window.api.ai.generate({ ...payload, requestId: newId });
      return { requestId: res.requestId };
    } catch (e) {
      // ai:generate 자체가 거부된 경우 (잠금/busy/no_model 등).
      const message = e instanceof Error ? e.message : String(e);
      // IPC 거부 메시지에서 code 추출은 어려우므로 표면 메시지 그대로.
      const err: AiStreamError = { code: 'start_failed', message };
      requestIdRef.current = null;
      setRequestId(null);
      setError(err);
      setStatus('error');
      return { error: err };
    }
  }, []);

  const cancel = useCallback<UseAiStreamResult['cancel']>(async () => {
    const id = requestIdRef.current;
    if (!id) return;
    try {
      await window.api.ai.cancel(id);
    } catch {
      /* 무시 — done 이벤트로 정리됨 */
    }
  }, []);

  const reset = useCallback<UseAiStreamResult['reset']>(() => {
    const id = requestIdRef.current;
    if (id && status === 'streaming') {
      void window.api.ai.cancel(id).catch(() => undefined);
    }
    bufferRef.current = '';
    rafScheduledRef.current = false;
    requestIdRef.current = null;
    setText('');
    setStatus('idle');
    setError(null);
    setFinishReason(null);
    setUsage(null);
    setRequestId(null);
  }, [status]);

  return {
    text,
    status,
    error,
    finishReason,
    usage,
    start,
    cancel,
    reset,
    requestId,
  };
}
