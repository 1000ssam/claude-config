import { useCallback, useEffect, useRef, useState } from 'react';
import type { AiEvent, AiStatus, AiModelState } from '@/types/ai';

export interface AiDownloadProgress {
  downloaded: number;
  total: number;
  percent: number;
}

export interface UseAiModelStatusResult {
  status: AiStatus | null;
  /** 초기 로드 진행 중 여부. status===null && loading일 때 스피너 표시. */
  loading: boolean;
  /** 마지막으로 본 다운로드 진행률. downloading 상태가 끝나면 null로 돌아간다. */
  downloadProgress: AiDownloadProgress | null;
  /** 마지막 다운로드 오류 메시지. error 표시용. */
  downloadError: string | null;
  /** 수동 새로고침 — `ai:get-status`를 다시 호출한다. */
  refresh: () => Promise<void>;
  /** 다운로드 시작. 성공 시 model-state→downloading로 자동 갱신. */
  download: () => Promise<{ started: boolean } | { error: string }>;
  /** 다운로드 취소. */
  cancelDownload: () => Promise<{ ok: boolean } | { error: string }>;
  /** Provider warm-up (모델 로드). 잠금 해제 후 1회만 필요. */
  warmUp: () => Promise<{ ok: boolean } | { error: string }>;
}

/**
 * AI 모델 상태 + 다운로드 진행률 구독 훅.
 *
 * - 마운트 시 `getStatus()`로 초기 상태 로드.
 * - `ai:event` 채널의 model-state/download-progress/download-done/download-error를 구독해 갱신.
 * - 컴포넌트별 1개 구독을 만들지만, 메모리·CPU 부담은 미미.
 *   (페이지 단위 단일 컨텍스트로 끌어올리고 싶으면 추후 Provider화)
 */
export function useAiModelStatus(): UseAiModelStatusResult {
  const [status, setStatus] = useState<AiStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [downloadProgress, setDownloadProgress] =
    useState<AiDownloadProgress | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);

  const mountedRef = useRef(true);

  const refresh = useCallback(async () => {
    try {
      const next = await window.api.ai.getStatus();
      if (!mountedRef.current) return;
      setStatus(next);
    } catch (e) {
      console.error('[useAiModelStatus] getStatus failed', e);
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    void refresh();

    // 부분 갱신 헬퍼: 기존 status를 깊은 머지 — model 필드만 교체.
    const patchModelState = (state: AiModelState) => {
      setStatus((prev) => {
        if (!prev) return prev;
        if (prev.model.state === state) return prev;
        return { ...prev, model: { ...prev.model, state } };
      });
    };

    const unsubscribe = window.api.ai.onEvent((evt: AiEvent) => {
      if (evt.requestId !== '*') return;

      if (evt.type === 'model-state') {
        patchModelState(evt.state);
        // 다운로딩이 끝나거나 에러로 전환되면 진행률 정리.
        if (evt.state !== 'downloading') {
          setDownloadProgress(null);
        }
        return;
      }

      if (evt.type === 'download-progress') {
        setDownloadProgress({
          downloaded: evt.downloaded,
          total: evt.total,
          percent: evt.percent,
        });
        // 첫 progress 도착 시 model.state가 아직 absent로 남아있을 수 있어 보강.
        patchModelState('downloading');
        return;
      }

      if (evt.type === 'download-done') {
        setDownloadProgress(null);
        setDownloadError(null);
        patchModelState('ready');
        // 사이즈/경로 등 정확한 정보를 위해 getStatus 다시 호출.
        void refresh();
        return;
      }

      if (evt.type === 'download-error') {
        setDownloadError(evt.message);
        setDownloadProgress(null);
        patchModelState('error');
        return;
      }
    });

    return () => {
      mountedRef.current = false;
      unsubscribe();
    };
  }, [refresh]);

  const download = useCallback<UseAiModelStatusResult['download']>(async () => {
    setDownloadError(null);
    try {
      const res = await window.api.ai.downloadModel();
      // started:false → 이미 진행 중. 별도 처리는 호출자가.
      return res;
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      setDownloadError(message);
      return { error: message };
    }
  }, []);

  const cancelDownload = useCallback<
    UseAiModelStatusResult['cancelDownload']
  >(async () => {
    try {
      return await window.api.ai.cancelDownload();
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      return { error: message };
    }
  }, []);

  const warmUp = useCallback<UseAiModelStatusResult['warmUp']>(async () => {
    try {
      const res = await window.api.ai.warmUp();
      // 성공 시 providerReady가 바뀌므로 상태 재조회.
      // refresh를 await해야 호출자가 토스트를 띄우는 시점에 status도 이미 ready로 반영된다.
      // (fire-and-forget이면 토스트는 즉시·setState는 한 박자 뒤 → 사용자가 두 번 누르는 듯한 체감)
      await refresh();
      return res;
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      return { error: message };
    }
  }, [refresh]);

  return {
    status,
    loading,
    downloadProgress,
    downloadError,
    refresh,
    download,
    cancelDownload,
    warmUp,
  };
}
