import { useEffect, useState } from 'react';
import { RouterProvider } from 'react-router-dom';
import { SidebarProvider, SidebarInset, SidebarTrigger } from '@/components/ui/sidebar';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { AppSidebar } from './components/layout/app-sidebar';
import { TabsProvider, useTabs } from './components/layout/tabs-context';
import { TabBar } from './components/layout/tab-bar';
import { Toaster } from './components/ui/toaster';
import { ToastProvider } from './hooks/use-toast';

// Auth screens
import SetupScreen from './pages/SetupScreen';
import LockScreen from './pages/LockScreen';
import ForcePasswordChangePage from './pages/ForcePasswordChangePage';

import { applyPalette } from './lib/theme';
import { appRoutes } from './routes';

/**
 * 탭별 뷰. 모든 탭을 동시에 마운트한 채 비활성 탭만 display:none(`hidden`)으로
 * 숨겨 상태(스크롤·폼 입력·필터)를 보존한다. 각 탭은 독립 MemoryRouter.
 */
function TabViews() {
  const { tabs, activeId } = useTabs();
  return (
    <>
      {tabs.map((tab) => (
        // 활성 탭(= activeId 일치)만 display:flex로 보이고, 비활성 탭은
        // hidden(display:none)으로 숨기되 마운트는 유지한다. 활성 정의·결과는
        // tabs-context.tsx 상단 주석 참고.
        <div
          key={tab.id}
          className={cn(
            'flex-1 flex-col gap-4 p-4',
            tab.id === activeId ? 'flex' : 'hidden',
          )}
        >
          <RouterProvider router={tab.router} />
        </div>
      ))}
    </>
  );
}

type AppState = 'loading' | 'setup' | 'locked' | 'unlocked' | 'force-pw-change';

export default function App() {
  const [appState, setAppState] = useState<AppState>('loading');

  useEffect(() => {
    window.api.auth.isSetup().then((setup) => {
      setAppState(setup ? 'locked' : 'setup');
    }).catch((e) => {
      console.error('[App] isSetup check failed', e);
      setAppState('setup');
    });
  }, []);

  // 팔레트 로드 — unlocked 진입 시
  useEffect(() => {
    if (appState !== 'unlocked') return;
    window.api.settings.get().then((s) => {
      if (s.color_palette) applyPalette(s.color_palette);
    }).catch(() => { /* ignore */ });
  }, [appState]);

  if (appState === 'loading') {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="text-sm text-muted-foreground">로딩 중...</p>
      </div>
    );
  }

  if (appState === 'setup') {
    return <SetupScreen onComplete={() => setAppState('unlocked')} />;
  }

  if (appState === 'locked') {
    return (
      <LockScreen
        onUnlock={async () => {
          const recoveryUsed = await window.api.auth.isRecoveryUsed();
          setAppState(recoveryUsed ? 'force-pw-change' : 'unlocked');
        }}
      />
    );
  }

  if (appState === 'force-pw-change') {
    return <ForcePasswordChangePage onComplete={() => setAppState('unlocked')} />;
  }

  return (
    <ToastProvider>
      <TabsProvider routes={appRoutes}>
        <SidebarProvider className="h-svh overflow-hidden print:h-auto print:overflow-visible">
          <AppSidebar />
          {/* 인셋을 뷰포트 높이로 고정하고 내부 스크롤만 허용 → 윈도우 스크롤바가
              헤더/탭바를 가로지르지 않도록 스크롤을 콘텐츠 영역에 한정한다.
              print: 변형으로 인쇄 시엔 높이/overflow 를 풀어 전체 콘텐츠 출력. */}
          <SidebarInset className="h-svh min-h-0 overflow-hidden print:h-auto print:overflow-visible">
            <header className="z-20 flex h-12 shrink-0 items-center gap-2 border-b border-sidebar-border bg-sidebar px-4 print:hidden">
              <SidebarTrigger className="-ml-1" />
              <Separator
                orientation="vertical"
                className="mr-2 data-[orientation=vertical]:h-4"
              />
              <TabBar />
            </header>
            {/* 실제 세로 스크롤 영역. scrollbar-gutter:stable 로 월간/주간 전환 시
                스크롤바 유무에 따른 너비 출렁임을 제거한다. */}
            <div className="flex min-h-0 flex-1 flex-col overflow-y-auto [scrollbar-gutter:stable] print:overflow-visible">
              <TabViews />
            </div>
          </SidebarInset>
        </SidebarProvider>
        <Toaster />
      </TabsProvider>
    </ToastProvider>
  );
}
