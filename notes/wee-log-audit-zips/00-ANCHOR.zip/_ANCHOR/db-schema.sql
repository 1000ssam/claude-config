-- wee-log.db (페이크 데이터) 스키마 덤프
-- 행수: cases: 2 rows, sessions: 5 rows, settings: 6 rows, students: 2 rows
-- 주의: ENC:v1:... 값은 AES-GCM 암호문, 컬럼명/구조만 참고

CREATE TABLE settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );
CREATE TABLE cases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      case_number TEXT NOT NULL UNIQUE,
      academic_year TEXT NOT NULL,
      counselee_name TEXT NOT NULL,
      counselee_grade TEXT,
      counselee_class TEXT,
      counselee_number TEXT,
      counselee_gender TEXT,
      counselee_birth TEXT,
      counselee_contact TEXT,
      guardian_name TEXT,
      guardian_relation TEXT,
      guardian_contact TEXT,
      referrer_name TEXT,
      referrer_role TEXT,
      referrer_contact TEXT,
      main_complaint TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    , student_id INTEGER REFERENCES students(id));
CREATE TABLE sqlite_sequence(name,seq);
CREATE INDEX idx_cases_academic_year ON cases(academic_year);
CREATE INDEX idx_cases_status ON cases(status);
CREATE INDEX idx_cases_case_number ON cases(case_number);
CREATE TABLE sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
      counseling_class TEXT NOT NULL,
      wee_class TEXT NOT NULL,
      category_large TEXT NOT NULL,
      category_medium TEXT NOT NULL,
      category_detail TEXT NOT NULL,
      headcount INTEGER NOT NULL DEFAULT 1,
      academic_year TEXT NOT NULL,
      session_date TEXT NOT NULL,
      grade TEXT NOT NULL DEFAULT '해당없음',
      gender TEXT NOT NULL DEFAULT '해당없음',
      session_title TEXT NOT NULL,
      session_content TEXT NOT NULL,
      session_hour INTEGER NOT NULL DEFAULT 0,
      session_minute INTEGER NOT NULL DEFAULT 0,
      counselor_affil TEXT NOT NULL,
      medium TEXT NOT NULL DEFAULT '면담',
      session_number INTEGER,
      voice_transcript TEXT,
      internal_notes TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );
CREATE INDEX idx_sessions_case_id ON sessions(case_id);
CREATE INDEX idx_sessions_date ON sessions(session_date);
CREATE INDEX idx_sessions_category ON sessions(category_large, category_medium, category_detail);
CREATE INDEX idx_sessions_academic_year ON sessions(academic_year);
CREATE TABLE students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      grade TEXT,
      class_name TEXT,
      number TEXT,
      gender TEXT,
      birth_date TEXT,
      contact TEXT,
      guardian_name TEXT,
      guardian_relation TEXT,
      guardian_contact TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
    );
CREATE INDEX idx_students_name ON students(name);
CREATE TRIGGER cases_updated_at
        AFTER UPDATE ON cases
        BEGIN
          UPDATE cases SET updated_at = datetime('now', 'localtime') WHERE id = NEW.id;
        END;
CREATE TRIGGER sessions_updated_at
        AFTER UPDATE ON sessions
        BEGIN
          UPDATE sessions SET updated_at = datetime('now', 'localtime') WHERE id = NEW.id;
        END;
CREATE TRIGGER students_updated_at
        AFTER UPDATE ON students
        BEGIN
          UPDATE students SET updated_at = datetime('now', 'localtime') WHERE id = NEW.id;
        END;
