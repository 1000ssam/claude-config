# _ANCHOR / MANIFEST — 먼저 읽어라

이 자료는 Electron(33) + Vite + React(18) 로컬우선 상담기록 데스크톱 앱 **wee-log(제품명 Wee-Story)**의
정적 감사를 위한 분할 업로드다. 너는 **코드를 실행할 수 없는 정적 리뷰어**다.

## 운영 방식
- 단일 대화. `00-ANCHOR.zip`(이 파일 포함)을 먼저 받았고, 이후 `01`~`08`을 순서대로 받는다.
- 매 청크 리포트의 마지막 섹션 "6) 청크 밖과 얽힌 의심점"에 교차 의심을 남겨라(마지막 종합 패스에서 대조).
- 외부 심볼은 `_ANCHOR/`의 타입(`types/`, `src/types/electron.d.ts`)·`electron/preload.ts`(Renderer↔Main 계약)로
  "계약"만 확인. 안 보이는 코드는 추측 말고 "확인 필요"로 표기. 환각 금지.

## 청크 지도 (총 8 + 앵커)
- **01-SECURITY-CORE.zip** — 12 파일
- **02-DATA-MAINLIB.zip** — 32 파일
- **03-MAIN-IPC.zip** — 5 파일
- **04-SERVICES-AI-STT.zip** — 34 파일
- **05-RENDERER-PAGES.zip** — 29 파일
- **06-RENDERER-FEATURES.zip** — 26 파일
- **07-RENDERER-UI-SHARED.zip** — 67 파일
- **08-EDGE-BACKEND.zip** — 21 파일

## 업로드(=감사) 순서 — 위험도 우선
01-SECURITY-CORE → 08-EDGE-BACKEND → 03-MAIN-IPC → 02-DATA-MAINLIB → 04-SERVICES → 05 → 06 → 07

## 아키텍처 한 줄 요약
- Main 프로세스(`electron/main.ts`)만 DB 접근. Renderer는 `window.api.*`(preload contextBridge)로 IPC.
- 암호화: AES-256-GCM, 포맷 `ENC:v1:{b64 iv}:{b64 ct+tag}`. `decrypt()`는 ENC 프리픽스 없으면 평문 반환(레거시 호환).
- 암호화 필드는 SQL WHERE 불가 → "전체 로드 후 JS 필터" 패턴(`lib/queries/`).
- 동의서: 별도 Cloudflare Worker가 호스팅, libsodium sealed box. 구독/엔타이틀먼트: Supabase + 서명.

## ⚠️ 모듈화 감사 핵심: lib/ ↔ src/lib/ 평행 중복
Main용 `lib/`와 Renderer용 `src/lib/`에 **이름이 같은 평행 모듈**이 존재한다. 단일출처화 대상인지 판단하라:
- `lib/academic-year.ts` ↔ `src/lib/academic-year.ts`
- `lib/utils.ts` ↔ `src/lib/utils.ts`
- `lib/constants/` ↔ `src/lib/constants/`
- `lib/export/` ↔ `src/lib/export/`
- `lib/queries/` ↔ `src/lib/queries/`
- `lib/ai/` ↔ `src/lib/ai/`
(주의: 분할상 main측은 02·04, renderer측은 05·07에 흩어져 있다. 각 청크 "섹션 6"에 중복 의심을 남겨라.)

## 제외된 것 (감사 범위 아님)
node_modules / 빌드산출물(.next·out·.wrangler) / 바이너리(binaries·ffmpeg) / **민감정보(.env·keys·실DB)**.
DB는 `_ANCHOR/db-schema.sql`로 스키마만 제공(페이크 데이터, 값은 암호문).

## 감사 5축 (각 청크 공통 출력 포맷)
1) 보안  2) 모듈화/아키텍처  3) 코드품질  4) 성능  5) 테스트 공백  6) 청크 밖과 얽힌 의심점
발견마다: [심각도 High/Med/Low] · 파일:라인 · 근거 · 구체적 수정안. 리팩토링은 의미 불변 전제 + 영향범위·순서.
