# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 백로그 관리 원칙

사용자가 BACKLOG.md에 추가를 요청한 항목 중, 즉시 반영하지 않으면 아키텍처가 꼬일 수 있는 것(예: DB 스키마 변경, 데이터 모델 분리 등)이 있다면 단순히 기록만 하지 말고 사용자에게 알리고 개발 우선순위 재조정을 제안할 것.

---

## 개발 환경

```bash
# WSL 터미널에서 실행 (WSLg로 GUI 표시됨)
cd /mnt/c/dev/wee-log
npm run dev        # 개발 서버 + Electron 앱 동시 시작 (hot reload 포함)
npm run build      # renderer + main 빌드
npm run package    # 배포용 인스톨러 패키징
npm run lint       # ESLint 실행
```

- **코드 수정은 `/mnt/c/dev/wee-log`에서 직접** — hot reload가 작동함
- DB 저장 경로: `%APPDATA%/wee-log/wee-log.db` (Windows) 또는 `~/.config/wee-log/wee-log.db` (Linux)

---

## 아키텍처 개요

### 프로세스 분리

```
electron/main.ts          ← Main process: IPC 핸들러 등록, DB 쿼리 호출
electron/preload.ts       ← contextBridge: window.api 노출 (contextIsolation + sandbox)
src/                      ← Renderer process: Vite + React 18
```

**모든 DB 접근은 Main process에서만** — Renderer는 `window.api.*`를 통해 IPC로 요청.

### IPC 패턴

`preload.ts` → `ipcRenderer.invoke('namespace:action', ...args)`
`main.ts` → `ipcMain.handle('namespace:action', handler)`

네임스페이스: `auth`, `cases`, `sessions`, `settings`, `statistics`, `reports`, `students`, `export`, `backup`, `stt`, `ai`

**잠금 가드**: 키가 로드되지 않은 상태에서 데이터 IPC 호출 시 `requireKey()` 헬퍼가 에러를 던짐.

### 암호화 레이어 (`lib/crypto/`)

| 파일 | 역할 |
|------|------|
| `engine.ts` | AES-256-GCM 암복호화, PBKDF2 키 파생 순수 함수 |
| `field-crypto.ts` | 테이블별 암호화 대상 필드 정의 + 행 단위 암복호화 |
| `key-manager.ts` | 메모리 내 키 관리, OS 키체인(safeStorage)에 salt 저장 |
| `migration.ts` | 평문 → 암호화 마이그레이션, 비밀번호 변경 시 전체 재암호화 |

암호화 포맷: `ENC:v1:{base64(iv)}:{base64(ciphertext+authTag)}`
`decrypt()`는 ENC 프리픽스 없으면 평문 그대로 반환 (레거시 데이터 호환).

**암호화된 필드는 SQL WHERE로 검색 불가** → 전체 로드 후 JS 필터링으로 처리 (`lib/queries/` 참고).

### DB 레이어 (`lib/`)

- `db.ts` — better-sqlite3 싱글톤 (`getDb()`)
- `db-init.ts` — 스키마 생성 + 마이그레이션 (앱 시작 시 자동 실행)
- `queries/*.ts` — 동기 쿼리 모듈 (better-sqlite3는 동기 API)

테이블: `settings`, `students`, `cases`, `sessions`, `crypto_meta`

### 앱 상태 흐름 (`src/App.tsx`)

```
loading → setup (최초 비밀번호 설정) → unlocked
        → locked (재시작 시)        → unlocked
```

`auth:is-setup` IPC 결과에 따라 `SetupScreen` / `LockScreen` / 메인 라우터 중 하나를 렌더링.

### 디자인 시스템

Notion 디자인 시스템 적용 (`design system/DESIGN.md` 참조).
- 컬러 토큰: `src/globals.css`의 CSS 변수
- Tailwind 확장: `tailwind.config.ts` (shadow, radius, color 커스텀)
- UI 컴포넌트: `src/components/ui/` (shadcn/ui 기반 커스터마이징)

Primary: `#0075de`, Alt background: `#f6f5f4`, Border: `1px solid rgba(0,0,0,0.1)`

---

## 주요 작업 시 주의사항

### DB 스키마 변경
`lib/db-init.ts`의 `initializeDatabase()`에 `ALTER TABLE` 마이그레이션 추가. 기존 데이터 손실 방지를 위해 `ADD COLUMN IF NOT EXISTS` 패턴 사용.

### 새 암호화 필드 추가
`lib/crypto/field-crypto.ts`의 `ENCRYPTED_FIELDS`에 필드명 추가 → `lib/crypto/migration.ts`의 `migrateToEncrypted()`도 업데이트.

### 새 IPC 핸들러 추가
1. `electron/preload.ts`에 `ipcRenderer.invoke()` 래퍼 추가
2. `src/types/electron.d.ts`에 타입 추가
3. `electron/main.ts`의 `registerIpcHandlers()`에 `ipcMain.handle()` 추가
4. 데이터 접근이면 `requireKey()` 헬퍼로 감싸기

### constants 중복
`lib/constants/`와 `src/lib/constants/`가 공존함. Main process용은 `lib/`, Renderer용은 `src/lib/`에 위치.
