/**
 * 초경량 테스트 하니스 (러너 미설치 환경).
 *
 * 기존 test:sanitize 와 동일하게 `node --experimental-strip-types` 로 구동한다.
 * 각 *.check.mts 파일은 자기 프로세스에서 단독 실행되므로 suite 상태 충돌이 없다.
 *
 *   const t = createSuite('filter-sort');
 *   t.eq('이름', got, want);
 *   t.report();   // 실패가 있으면 process.exit(1)
 */

export interface Suite {
  /** 깊은 동등 비교 (JSON 직렬화 기준). 배열/객체/원시값 모두 가능. */
  eq(name: string, got: unknown, want: unknown): void;
  /** 불리언 단언. */
  ok(name: string, cond: boolean): void;
  /** 콜백이 throw 하는지 단언. */
  throws(name: string, fn: () => unknown): void;
  /** 결과 출력. 실패가 하나라도 있으면 비정상 종료. */
  report(): void;
}

export function createSuite(name: string): Suite {
  let pass = 0;
  const failures: string[] = [];

  return {
    eq(t, got, want) {
      const g = JSON.stringify(got);
      const w = JSON.stringify(want);
      if (g === w) pass++;
      else failures.push(`  ❌ ${t}\n     want: ${w}\n     got : ${g}`);
    },
    ok(t, cond) {
      if (cond) pass++;
      else failures.push(`  ❌ ${t} (expected truthy)`);
    },
    throws(t, fn) {
      let threw = false;
      try {
        fn();
      } catch {
        threw = true;
      }
      if (threw) pass++;
      else failures.push(`  ❌ ${t} (expected to throw)`);
    },
    report() {
      if (failures.length > 0) {
        console.error(`✗ ${name}: ${failures.length} failed, ${pass} passed`);
        console.error(failures.join('\n'));
        process.exit(1);
      }
      console.log(`✓ ${name}: ${pass} passed`);
    },
  };
}
