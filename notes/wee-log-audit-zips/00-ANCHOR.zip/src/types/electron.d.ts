import type { CaseWithSessionCount, Case, CreateCaseInput, UpdateCaseInput } from './case';
import type { CaseConceptualization, UpsertConceptualizationInput } from './conceptualization';
import type { Session, CreateSessionInput, UpdateSessionInput } from './session';
import type { AppSettings } from './settings';
import type { Student, CreateStudentInput, UpdateStudentInput, StudentWithCaseCount, StudentEnrollment, StudentProfile, ExcelStudentRow, ExcelUploadResult } from './student';
import type { Statistics, StatisticsParams } from '../../lib/queries/statistics';
import type { ReportsData, ReportsParams } from '../../lib/queries/reports';
import type { ReportData, ReportParams } from '../../lib/queries/report-generator';
import type { CalendarSession } from '../../lib/queries/calendar';
import type {
  SttDownloadStartResult,
  SttEvent,
  SttModelId,
  SttStatus,
  SttTranscribePayload,
} from '../../lib/stt/stt-types';
import type {
  ConsentTemplate,
  ConsentRequest,
  ConsentResponseRecord,
  ConsentAuditRecord,
  UpsertConsentTemplateInput,
  ConsentChannel,
} from './consent';

export interface PrintOptions {
  pageSize?: 'A4' | 'A3' | 'Letter';
  landscape?: boolean;
  defaultName?: string;
}

export interface ElectronAPI {
  print: {
    save: (opts?: PrintOptions) => Promise<{ success: boolean; filePath?: string; message?: string }>;
    preview: (opts?: Omit<PrintOptions, 'defaultName'>) => Promise<{ success: boolean; message?: string }>;
    print: (opts?: Omit<PrintOptions, 'defaultName'>) => Promise<{ success: boolean }>;
  };
  auth: {
    isSetup: () => Promise<boolean>;
    setup: (password: string, hint?: string) => Promise<{ success: boolean; error?: string }>;
    unlock: (password: string) => Promise<{ success: boolean }>;
    changePassword: (currentPassword: string, newPassword: string) => Promise<{ success: boolean; recoveryPhrase?: string; error?: string }>;
    getHint: () => Promise<string>;
    setHint: (hint: string) => Promise<{ success: boolean; error?: string }>;
    hasRecovery: () => Promise<boolean>;
    generateRecovery: () => Promise<{ success: boolean; phrase?: string; error?: string }>;
    useRecovery: (code: string) => Promise<{ success: boolean }>;
    isRecoveryUsed: () => Promise<boolean>;
    resetPassword: (newPassword: string) => Promise<{ success: boolean; error?: string }>;
    factoryReset: () => Promise<{ success: boolean; message?: string }>;
  };
  cases: {
    list: (params?: { year?: string; status?: string; search?: string }) => Promise<CaseWithSessionCount[]>;
    get: (id: number) => Promise<Case | undefined>;
    create: (input: CreateCaseInput) => Promise<Case>;
    update: (id: number, input: UpdateCaseInput) => Promise<Case | undefined>;
    delete: (id: number) => Promise<void>;
  };
  conceptualizations: {
    get: (caseId: number) => Promise<CaseConceptualization | undefined>;
    upsert: (caseId: number, input: UpsertConceptualizationInput) => Promise<CaseConceptualization>;
    delete: (caseId: number) => Promise<void>;
  };
  sessions: {
    list: (caseId: number) => Promise<Session[]>;
    get: (sessionId: number) => Promise<Session | undefined>;
    create: (caseId: number, input: CreateSessionInput) => Promise<Session>;
    update: (sessionId: number, input: UpdateSessionInput) => Promise<Session | undefined>;
    delete: (sessionId: number) => Promise<void>;
    calendar: (from: string, to: string) => Promise<CalendarSession[]>;
    updateDate: (sessionId: number, newDate: string) => Promise<void>;
    refreshReminders: () => Promise<void>;
  };
  settings: {
    get: () => Promise<AppSettings>;
    update: (updates: Partial<AppSettings>) => Promise<AppSettings>;
  };
  statistics: {
    get: (params: StatisticsParams) => Promise<Statistics>;
  };
  reports: {
    get: (params: ReportsParams) => Promise<ReportsData>;
    generate: (params: ReportParams) => Promise<ReportData>;
    savePdf: (params?: { from?: string; to?: string }) => Promise<{ success: boolean; filePath?: string; message?: string }>;
    print: () => Promise<void>;
    previewPdf: () => Promise<{ success: boolean; message?: string }>;
  };
  students: {
    list: (params?: { search?: string; academic_year?: string; status?: string | null }) => Promise<StudentWithCaseCount[]>;
    profile: (id: number) => Promise<StudentProfile | undefined>;
    search: (query: string) => Promise<Student[]>;
    create: (input: CreateStudentInput) => Promise<Student>;
    update: (id: number, input: UpdateStudentInput) => Promise<Student | undefined>;
    delete: (id: number) => Promise<void>;
    findByIdentity: (name: string, grade?: string | undefined, className?: string | undefined, number?: string | undefined) => Promise<Student | undefined>;
    uploadExcel: () => Promise<{
      success: boolean;
      canceled?: boolean;
      message?: string;
      preview?: boolean;
      academicYear?: string;
      grade?: string;
      rowCount?: number;
      filePath?: string;
      sampleRows?: ExcelStudentRow[];
    }>;
    confirmUpload: (filePath: string) => Promise<{
      success: boolean;
      message?: string;
      result?: ExcelUploadResult;
    }>;
    bulkDelete: (ids: number[]) => Promise<void>;
    bulkUpdateStatus: (ids: number[], status: string) => Promise<void>;
    checkGraduationEligibility: (ids: number[], currentYear: string, graduationGrade: string) => Promise<{
      eligible: number[];
      ineligible: { id: number; name: string; grade: string; reason: string }[];
    }>;
  };
  enrollments: {
    byStudent: (studentId: number) => Promise<StudentEnrollment[]>;
    years: () => Promise<string[]>;
  };
  backup: {
    create: () => Promise<{ success: boolean; message?: string; filePath?: string }>;
    restore: () => Promise<{ success: boolean; message?: string }>;
    reset: (password: string) => Promise<{ success: boolean; message?: string }>;
  };
  export: {
    xlsx: (params: { year?: string; from?: string; to?: string }) => Promise<{ success: boolean; message?: string; filePath?: string }>;
  };
  holidays: {
    getYear: (year: number) => Promise<import('../../lib/queries/holiday-cache').HolidayEntry[] | null>;
  };
  remote: {
    getNotices: () => Promise<Notice[]>;
    markNoticeRead: (noticeId: string) => Promise<void>;
  };
  school: {
    search: (query: string) => Promise<SchoolInfo[]>;
    getSchedule: (year: number) => Promise<SchoolEvent[]>;
  };
  stt: {
    getStatus: () => Promise<SttStatus>;
    downloadModel: () => Promise<SttDownloadStartResult>;
    cancelDownload: () => Promise<{ ok: boolean }>;
    transcribe: (payload: SttTranscribePayload) => Promise<{ requestId: string }>;
    cancel: (requestId: string) => Promise<{ ok: boolean }>;
    updateSettings: (updates: Partial<{
      stt_enabled: '0' | '1';
      stt_engine: 'whisper-cli';
      stt_model: SttModelId;
      stt_language: 'ko';
    }>) => Promise<SttStatus>;
    onEvent: (cb: (evt: SttEvent) => void) => () => void;
  };
  ai: import('./ai').AiApi;
  consent: {
    capabilities: () => Promise<{ server: boolean; sms: boolean }>;
    templatesList: () => Promise<ConsentTemplate[]>;
    templateCreate: (input: UpsertConsentTemplateInput) => Promise<ConsentTemplate>;
    templateUpdate: (id: number, input: UpsertConsentTemplateInput) => Promise<ConsentTemplate | undefined>;
    templateDelete: (id: number) => Promise<void>;
    list: (caseId: number) => Promise<ConsentRequest[]>;
    response: (requestId: number) => Promise<ConsentResponseRecord | undefined>;
    send: (args: {
      case_id: number;
      student_id: number;
      template_id: number;
      channel: ConsentChannel;
      expiry_days?: number;
    }) => Promise<{
      success: boolean;
      error?: string;
      request?: ConsentRequest;
      link?: string;
      smsMessageId?: string | null;
    }>;
    sendBatch: (args: {
      case_id: number;
      student_id: number;
      template_ids: number[];
      channel: ConsentChannel;
      expiry_days?: number;
    }) => Promise<{
      success: boolean;
      error?: string;
      results: Array<{
        template_id: number;
        success: boolean;
        request?: ConsentRequest;
        link?: string;
        error?: string;
      }>;
      sentCount?: number;
      failedCount?: number;
      smsMessageId?: string | null;
    }>;
    poll: () => Promise<{ success: boolean; error?: string; ingested: number; expired: number; errors: number }>;
    auditList: (caseId: number) => Promise<ConsentAuditRecord[]>;
  };
}

export interface SchoolInfo {
  atptCode: string;
  schulCode: string;
  schulName: string;
  schulKind: string;
  addr: string;
}

export interface SchoolEvent {
  date: string;
  name: string;
}

export interface Notice {
  id: string;
  title: string;
  body: string;
  type: 'info' | 'warning' | 'update';
  publishedAt: string;
  isRead: boolean;
}

declare global {
  interface Window {
    api: ElectronAPI;
  }
  const __APP_VERSION__: string;
}
