export interface CaseStudent {
  student_id: number;
  name: string;
  grade: string | null;
  class_name: string | null;
  number: string | null;
  gender: string | null;
  guardian_name: string | null;
  guardian_relation: string | null;
  guardian_contact: string | null;
}

export interface Case {
  id: number;
  case_number: string;
  academic_year: string;
  students: CaseStudent[];
  referrer_name: string | null;
  referrer_role: string | null;
  referrer_contact: string | null;
  main_complaint: string | null;
  counseling_goal: string | null;
  teacher_opinion: string | null;
  status: 'active' | 'closed';
  close_reason: string | null;
  close_reason_detail: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface CaseWithSessionCount extends Case {
  session_count: number;
  last_session_date: string | null;
}

export interface CreateCaseInput {
  student_ids: number[];
  academic_year?: string;
  referrer_name?: string;
  referrer_role?: string;
  referrer_contact?: string;
  main_complaint?: string;
  counseling_goal?: string;
  teacher_opinion?: string;
  notes?: string;
}

export interface UpdateCaseInput {
  student_ids?: number[];
  referrer_name?: string;
  referrer_role?: string;
  referrer_contact?: string;
  main_complaint?: string;
  counseling_goal?: string;
  teacher_opinion?: string;
  notes?: string;
  status?: 'active' | 'closed';
  close_reason?: string | null;
  close_reason_detail?: string | null;
}
