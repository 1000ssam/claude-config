export interface AppSettings {
  school_name: string;
  school_type: string;   // 초등학교 | 중학교 | 고등학교 | 특수학교
  academic_year: string;
  counselor_name: string;
  counselor_affiliation: string;
  wee_class: string;
  next_case_seq: string;
  default_counseling_class: string;
  calendar_view_mode: string;
  stale_case_days?: string;  // '장기 미접촉' 판별 기준일 (기본: 14). 빈 값/미설정 시 기본값 적용
  neis_atpt_code: string;   // 교육청 코드
  neis_schul_code: string;  // 학교 코드
  color_palette?: string;   // 컬러 팔레트 ID (기본: 'calm-teal')

  // ── STT (Phase: feat/stt) ────────────────────────────────────────────
  stt_enabled?: string;       // '0' | '1' (default '1')
  stt_engine?: string;        // 'whisper-cli' (현재 단일)
  stt_model?: string;         // 'ggml-small-q5_1' | 'ggml-medium-q5_0'
  stt_language?: string;      // 'ko' (당분간 고정)

  // ── AI 도우미 (온디바이스 LLM) ───────────────────────────────────────────
  ai_enabled?: string;             // '0' | '1'
  ai_backend?: string;             // 'local' | 'remote'
  ai_model_status?: string;        // 'absent' | 'downloading' | 'ready' | 'error'
  ai_model_path?: string;          // 절대 경로 (사용자 직접 지정 시)
  ai_remote_base_url?: string;     // OpenAI 호환 엔드포인트 (국내 자체 서버/서버리스)
  ai_remote_model?: string;        // 원격 모델 이름
  ai_remote_api_key?: string;      // 암호화 저장
}

export type SettingKey = keyof AppSettings;
