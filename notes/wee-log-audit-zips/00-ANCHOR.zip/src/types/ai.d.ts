/**
 * 렌더러용 AI 타입. window.api.ai 표면의 페이로드/이벤트 형태를 정의한다.
 * (메인 측 lib/ai/types.ts와 의도적으로 분리 — 렌더러가 lib/ai를 직접 import하지 않게.)
 */

export type AiTask =
  | 'refine'
  | 'summarize'
  | 'continue'
  | 'conceptualize'
  | 'report'
  | 'qa'
  /** 시스템 task — 회기 저장 시 백그라운드 큐가 호출. UI 카탈로그에는 노출되지 않음. */
  | 'session-summary';

/** UI 카탈로그(AI_ACTIONS)에 노출되는 사용자용 task — 시스템 task 제외. */
export type UserFacingAiTask = Exclude<AiTask, 'session-summary'>;

export type AiBackend = 'local' | 'remote';
export type AiModelState = 'absent' | 'downloading' | 'ready' | 'error';
export type AiFinishReason = 'stop' | 'length' | 'aborted' | 'error';
export type AiErrorCode =
  | 'no_model'
  | 'busy'
  | 'context_overflow'
  | 'backend_error'
  | 'aborted'
  | 'locked'
  | 'not_initialized';

export interface AiChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface AiContextRequest {
  kind: 'session-form' | 'case-form' | 'conceptualization' | 'report-block';
  caseId: number;
  sessionId?: number;
  draft: Record<string, string>;
  templateType?: string;
  meta?: Record<string, unknown>;
}

export interface AiGenerateStartPayload {
  requestId: string;
  task: AiTask;
  contextRequest?: AiContextRequest;
  userInput?: string;
  selectionText?: string;
  history?: AiChatMessage[];
  /** 필드 의미·형식 힌트 (예: "회기 제목 — 명사구 한 줄"). user 메시지에 [지침]으로 박힘. */
  fieldHint?: string;
}

export interface AiUsage {
  promptTokens: number;
  completionTokens: number;
}

export interface AiModelStatus {
  state: AiModelState;
  path?: string;
  sizeBytes?: number;
  downloadedBytes?: number;
}

export interface AiCapabilities {
  contextWindow: number;
  maxOutputTokens: number;
}

export interface AiStatus {
  enabled: boolean;
  backend: AiBackend;
  model: AiModelStatus;
  providerReady: boolean;
  capabilities?: AiCapabilities;
}

export type AiEvent =
  | { requestId: string; type: 'token'; token: string }
  | {
      requestId: string;
      type: 'done';
      finishReason: AiFinishReason;
      usage: AiUsage;
    }
  | { requestId: string; type: 'error'; code: AiErrorCode; message: string }
  | {
      requestId: '*';
      type: 'download-progress';
      downloaded: number;
      total: number;
      percent: number;
    }
  | { requestId: '*'; type: 'download-done'; path: string }
  | { requestId: '*'; type: 'download-error'; message: string }
  | { requestId: '*'; type: 'model-state'; state: AiModelState };

export interface AiApi {
  getStatus: () => Promise<AiStatus>;
  downloadModel: () => Promise<{ started: boolean }>;
  cancelDownload: () => Promise<{ ok: boolean }>;
  generate: (payload: AiGenerateStartPayload) => Promise<{ requestId: string }>;
  cancel: (requestId: string) => Promise<{ ok: boolean }>;
  warmUp: () => Promise<{ ok: boolean }>;
  /** 사이드패널 "요약 갱신" — pending/failed 회기를 다시 큐에 넣는다. */
  refreshSummaries: (caseId?: number) => Promise<{ enqueued: number }>;
  /** 이벤트 구독. 반환된 함수로 구독 해제. */
  onEvent: (cb: (e: AiEvent) => void) => () => void;
}
