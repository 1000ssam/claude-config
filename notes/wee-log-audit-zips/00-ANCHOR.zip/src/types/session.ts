export interface SessionStudent {
  student_id: number;
  name: string;
}

export interface Session {
  id: number;
  case_id: number;
  counseling_class: string;
  wee_class: string;
  category_large: string;
  category_medium: string;
  category_detail: string;
  headcount: number;
  academic_year: string;
  session_date: string;
  appointment_time: string | null;
  reminder_minutes: number | null;
  grade: string;
  gender: string;
  session_title: string;
  session_content: string;
  session_hour: number;
  session_minute: number;
  counselor_affil: string;
  medium: string;
  session_number: number | null;
  students: SessionStudent[];
  internal_notes: string | null;
  /** AI가 생성한 80자 한 줄 요약(개조식). 미생성 시 null. */
  summary_short: string | null;
  /** 요약 상태. 회기 저장 직후 'pending', 큐 처리 완료 시 'done', 실패 누적 시 'failed'. */
  summary_status: 'pending' | 'done' | 'failed';
  /** 요약 생성 완료 시각. ISO-like local time. 미생성/실패 시 null. */
  summary_generated_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreateSessionInput {
  student_ids: number[];
  counseling_class: string;
  wee_class: string;
  category_large: string;
  category_medium: string;
  category_detail: string;
  academic_year: string;
  session_date: string;
  appointment_time?: string | null;
  reminder_minutes?: number | null;
  session_title: string;
  session_content: string;
  session_hour: number;
  session_minute: number;
  counselor_affil: string;
  medium: string;
  internal_notes?: string;
}

export interface UpdateSessionInput {
  student_ids?: number[];
  counseling_class?: string;
  wee_class?: string;
  category_large?: string;
  category_medium?: string;
  category_detail?: string;
  academic_year?: string;
  session_date?: string;
  appointment_time?: string | null;
  reminder_minutes?: number | null;
  session_title?: string;
  session_content?: string;
  session_hour?: number;
  session_minute?: number;
  counselor_affil?: string;
  medium?: string;
  internal_notes?: string;
}
