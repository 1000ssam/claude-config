export type StudentStatus = '재학' | '졸업';

export interface Student {
  id: number;
  name: string;
  gender: string | null;
  birth_date: string | null;
  contact: string | null;
  guardian_name: string | null;
  guardian_relation: string | null;
  guardian_contact: string | null;
  status: StudentStatus;
  created_at: string;
  updated_at: string;
}

export interface CreateStudentInput {
  name: string;
  grade?: string;
  class_name?: string;
  number?: string;
  gender?: string;
  birth_date?: string;
  contact?: string;
  guardian_name?: string;
  guardian_relation?: string;
  guardian_contact?: string;
}

/** enrollment 데이터가 포함된 Student (학적 표시용) */
export interface StudentWithEnrollment extends Student {
  grade: string | null;
  class_name: string | null;
  number: string | null;
}

export interface UpdateStudentInput extends Partial<CreateStudentInput> {
  status?: StudentStatus;
}

export interface StudentWithCaseCount extends Student {
  case_count: number;
  grade: string | null;
  class_name: string | null;
  number: string | null;
}

export interface StudentEnrollment {
  id: number;
  student_id: number;
  academic_year: string;
  grade: string | null;
  class_name: string | null;
  number: string | null;
  created_at: string;
  updated_at: string;
}

/** 학생 상세 페이지용 프로필 (학적 + 사례 + 세션 통합) */
export interface StudentProfileCase {
  id: number;
  case_number: string;
  academic_year: string;
  main_complaint: string | null;
  status: 'active' | 'closed';
  session_count: number;
  last_session_date: string | null;
  created_at: string;
  sessions: {
    id: number;
    case_id: number;
    session_date: string;
    session_title: string;
    session_content: string;
    internal_notes: string | null;
    counseling_class: string;
    category_large: string;
    category_medium: string;
    category_detail: string;
    session_number: number | null;
    session_hour: number;
    session_minute: number;
  }[];
}

export interface StudentProfile {
  student: Student;
  enrollments: StudentEnrollment[];
  cases: StudentProfileCase[];
}

export interface ExcelStudentRow {
  name: string;
  grade: string;
  class_name: string;
  number: string;
  birth_date: string;
  gender: string;
  prev_grade?: string;
  prev_class_name?: string;
  prev_number?: string;
}

export interface UploadStudentEntry {
  student_id: number;
  name: string;
  grade: string;
  class_name: string;
  number: string;
}

export interface ExcelUploadResult {
  created: number;
  updated: number;
  skipped: number;
  errors: string[];
  academic_year: string;
  total_rows: number;
  createdStudents: UploadStudentEntry[];
  missingStudents: UploadStudentEntry[];
}
