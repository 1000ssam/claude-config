/**
 * 보호자 동의서/접수양식 — 공유 타입.
 *
 * 신뢰경계: 폼 스키마(질문)는 평문으로 서버에 동봉되어도 무방(PII 없음).
 * 응답(answers)만 E2E sealed-box 암호문으로 다룬다.
 */

// ── 폼 스키마(데이터 주도) ──────────────────────────────────────────────────────

export type ConsentFieldType =
  | 'text'
  | 'textarea'
  | 'select'
  | 'radio'
  | 'checkbox'
  | 'date'
  | 'signature'
  | 'consent'; // 동의 문구 + 필수 체크

export interface ConsentField {
  /** 스키마 내 안정 식별자(영문 snake_case). 응답 JSON의 키가 된다. */
  key: string;
  type: ConsentFieldType;
  label: string;
  required: boolean;
  /** select/radio 선택지 */
  options?: string[];
  /** 다중 선택 허용(select). 켜지면 체크박스 다중선택(배열 응답), 끄면 단일선택. */
  multiple?: boolean;
  /** consent 동의 문구 본문, 또는 일반 필드의 안내 도움말(보호자 폼에 표시). */
  description?: string;
  /** 레거시 — 신규 템플릿은 description 사용. */
  placeholder?: string;
}

export interface ConsentFormSchema {
  version: 1;
  title: string;
  /** 상단 안내/법적 전문(개인정보 수집·이용, 미성년자 법정대리인 동의 등) */
  intro?: string;
  fields: ConsentField[];
}

// ── 템플릿(로컬 저장) ───────────────────────────────────────────────────────────

export interface ConsentTemplate {
  id: number;
  name: string;
  schema: ConsentFormSchema;
  is_default: 0 | 1;
  created_at: string;
  updated_at: string;
}

export interface UpsertConsentTemplateInput {
  name: string;
  schema: ConsentFormSchema;
  is_default?: boolean;
}

// ── 요청/상태 ───────────────────────────────────────────────────────────────────

/**
 * pending  : 로컬 생성, 아직 서버 미등록
 * sent     : 서버 등록 + (SMS 발송 또는 링크 발급) 완료, 응답 대기
 * responded: 보호자 제출 완료(서버에 암호문 존재), 앱 미수합
 * ingested : 앱이 복호·로컬 기록 후 서버 암호문 파기 완료
 * expired  : 만료
 * failed   : 발송 실패
 */
export type ConsentStatus =
  | 'pending'
  | 'sent'
  | 'responded'
  | 'ingested'
  | 'expired'
  | 'failed';

export type ConsentChannel = 'sms' | 'link';

export interface ConsentRequest {
  id: number;
  case_id: number;
  student_id: number;
  /** 발송 시점의 템플릿 이름(템플릿 삭제돼도 이력 보존) */
  template_name: string;
  token: string;
  /** sealed-box 공개키(base64) */
  public_key: string;
  /** 발송 시점 폼 스키마 스냅샷(질문 라벨 보존용, PII 아님). 응답 표시에 사용. */
  form_schema?: ConsentFormSchema;
  status: ConsentStatus;
  channel: ConsentChannel;
  /** 1회용 접속 링크(수동 링크 채널 또는 SMS 본문에 쓰인 URL) */
  link: string | null;
  /** 발송 실패/오류 메시지 */
  last_error: string | null;
  created_at: string;
  sent_at: string | null;
  responded_at: string | null;
  expires_at: string;
  /** 조인된 학생 표시용(쿼리에서 채움) */
  student_name?: string;
}

export interface ConsentResponseRecord {
  id: number;
  request_id: number;
  /** 복호된 응답(평문) */
  answers: Record<string, unknown>;
  submitted_at: string;
  ingested_at: string;
}

export interface CreateConsentRequestInput {
  case_id: number;
  student_id: number;
  template_id: number;
  channel: ConsentChannel;
  /** 만료까지 일수(기본 7) */
  expiry_days?: number;
}

/** 수합 결과 요약(IPC 반환) */
export interface ConsentPollResult {
  ingested: number;
  expired: number;
  errors: number;
}

// ── 감사 로그(Phase 6) ───────────────────────────────────────────────────────────

/**
 * 감사 로그 1행(읽기 전용).
 * 비-PII 메타데이터만 담는다(buildAuditEvent가 PII 제거·전화번호 마스킹).
 */
export interface ConsentAuditRecord {
  id: number;
  /** CONSENT_AUDIT_EVENTS 중 하나(문자열로 보존 — 이력 호환). */
  event: string;
  /** 연관 요청 ID(없을 수 있음). */
  request_id: number | null;
  /** 직렬화된 비-PII 메타(JSON) 또는 null. */
  detail: string | null;
  created_at: string;
  /** 표시용 — 읽기 시점 결합(저장 안 함). 요청/학생 삭제 시 undefined → UI '삭제됨' 표기. */
  student_name?: string;
  /** 표시용 양식명 — 읽기 시점 결합. */
  template_name?: string;
}
