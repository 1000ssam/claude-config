/** 템플릿 섹션 정의 (코드 상수) */
export interface TemplateSectionDef {
  key: string;
  label: string;
  placeholder: string;
}

export interface ConceptualizationTemplate {
  type: string;
  label: string;
  description: string;
  sections: TemplateSectionDef[];
}

/** DB에 저장되는 데이터 */
export interface CaseConceptualization {
  id: number;
  case_id: number;
  template_type: string;
  sections: Record<string, string>;
  created_at: string;
  updated_at: string;
}

export interface UpsertConceptualizationInput {
  template_type: string;
  sections: Record<string, string>;
}
