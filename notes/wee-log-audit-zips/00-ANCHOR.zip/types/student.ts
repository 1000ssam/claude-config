export interface Student {
  id: number;
  name: string;
  gender: string | null;
  birth_date: string | null;
  contact: string | null;
  guardian_name: string | null;
  guardian_relation: string | null;
  guardian_contact: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreateStudentInput {
  name: string;
  grade?: string;
  class_name?: string;
  number?: string;
  gender?: string;
  birth_date?: string;
  contact?: string;
  guardian_name?: string;
  guardian_relation?: string;
  guardian_contact?: string;
}

export interface UpdateStudentInput extends Partial<CreateStudentInput> {}

export interface StudentEnrollment {
  id: number;
  student_id: number;
  academic_year: string;
  grade: string | null;
  class_name: string | null;
  number: string | null;
  created_at: string;
  updated_at: string;
}

export interface ExcelStudentRow {
  name: string;
  grade: string;
  class_name: string;
  number: string;
  birth_date: string;
  gender: string;
  prev_grade?: string;
  prev_class_name?: string;
  prev_number?: string;
}

export interface UploadStudentEntry {
  student_id: number;
  name: string;
  grade: string;
  class_name: string;
  number: string;
}

export interface ExcelUploadResult {
  created: number;
  updated: number;
  skipped: number;
  errors: string[];
  academic_year: string;
  total_rows: number;
  /** 매칭 실패로 신규 생성된 학생 (기존 학생 개명/오타 가능성 → 확인 필요) */
  createdStudents: UploadStudentEntry[];
  /** 전년도 enrollment은 있으나 올해 파일에 없는 학생 (전학/자퇴 가능성 → 확인 필요) */
  missingStudents: UploadStudentEntry[];
}
