export interface AppSettings {
  school_name: string;
  school_type?: string;
  academic_year: string;
  counselor_name: string;
  counselor_affiliation: string;
  wee_class: string;
  next_case_seq: string;
  default_counseling_class: string;
  calendar_view_mode: string;
  neis_atpt_code?: string;
  neis_schul_code?: string;
  color_palette?: string;

  // ── STT (feat/stt) ───────────────────────────────────────────────────
  stt_enabled?: string;       // '0' | '1'
  stt_engine?: string;        // 'whisper-cli'
  stt_model?: string;         // 'ggml-small-q5_1' | 'ggml-medium-q5_1'
  stt_language?: string;      // 'ko'
}

export type SettingKey = keyof AppSettings;
