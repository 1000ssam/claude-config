export interface SessionStudent {
  student_id: number;
  name: string;
}

export interface Session {
  id: number;
  case_id: number;
  counseling_class: string;
  wee_class: string;
  category_large: string;
  category_medium: string;
  category_detail: string;
  headcount: number;
  academic_year: string;
  session_date: string;
  appointment_time: string | null;
  reminder_minutes: number | null;
  grade: string;
  gender: string;
  session_title: string;
  session_content: string;
  session_hour: number;
  session_minute: number;
  counselor_affil: string;
  medium: string;
  session_number: number | null;
  students: SessionStudent[];
  internal_notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreateSessionInput {
  student_ids: number[];
  counseling_class: string;
  wee_class: string;
  category_large: string;
  category_medium: string;
  category_detail: string;
  academic_year: string;
  session_date: string;
  appointment_time?: string | null;
  reminder_minutes?: number | null;
  session_title: string;
  session_content: string;
  session_hour: number;
  session_minute: number;
  counselor_affil: string;
  medium: string;
  internal_notes?: string;
}

export interface UpdateSessionInput {
  student_ids?: number[];
  counseling_class?: string;
  wee_class?: string;
  category_large?: string;
  category_medium?: string;
  category_detail?: string;
  academic_year?: string;
  session_date?: string;
  appointment_time?: string | null;
  reminder_minutes?: number | null;
  session_title?: string;
  session_content?: string;
  session_hour?: number;
  session_minute?: number;
  counselor_affil?: string;
  medium?: string;
  internal_notes?: string;
}
