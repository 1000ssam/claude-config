import { useState } from 'react';
import {
  startOfMonth, endOfMonth, startOfWeek, endOfWeek,
  eachDayOfInterval, format, isSameMonth, isSameDay, isToday,
  addMonths, subMonths,
} from 'date-fns';
import { ko } from 'date-fns/locale';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { getHolidayName } from '@/lib/holidays';

interface CalendarProps {
  selected?: Date | null;
  onSelect: (date: Date) => void;
  defaultMonth?: Date;
}

const DOW_LABELS = ['일', '월', '화', '수', '목', '금', '토'];

export function Calendar({ selected, onSelect, defaultMonth }: CalendarProps) {
  const [viewMonth, setViewMonth] = useState<Date>(() => defaultMonth ?? selected ?? new Date());

  const calDays = eachDayOfInterval({
    start: startOfWeek(startOfMonth(viewMonth), { weekStartsOn: 0 }),
    end: endOfWeek(endOfMonth(viewMonth), { weekStartsOn: 0 }),
  });

  return (
    <div className="p-3 select-none w-[280px]">
      {/* Month navigation */}
      <div className="flex items-center justify-between mb-3">
        <Button type="button" variant="ghost" size="icon" className="h-7 w-7 shrink-0"
          onClick={() => setViewMonth(m => subMonths(m, 1))}>
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold">
            {format(viewMonth, 'yyyy년 M월', { locale: ko })}
          </span>
          <button type="button"
            onClick={() => { const t = new Date(); setViewMonth(t); onSelect(t); }}
            className="text-xs text-muted-foreground hover:text-foreground transition-colors">
            오늘
          </button>
        </div>
        <Button type="button" variant="ghost" size="icon" className="h-7 w-7 shrink-0"
          onClick={() => setViewMonth(m => addMonths(m, 1))}>
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Day of week headers */}
      <div className="grid grid-cols-7 mb-1">
        {DOW_LABELS.map((d, i) => (
          <div key={d} className={cn(
            'text-center text-[0.6875rem] font-medium py-1',
            i === 0 ? 'text-rose-500' : i === 6 ? 'text-blue-500' : 'text-muted-foreground',
          )}>{d}</div>
        ))}
      </div>

      {/* Day grid */}
      <div className="grid grid-cols-7 gap-y-1">
        {calDays.map((day) => {
          const inMonth = isSameMonth(day, viewMonth);
          const isSelected = selected ? isSameDay(day, selected) : false;
          const isTodayDay = isToday(day);
          const dow = day.getDay();
          const dateStr = format(day, 'yyyy-MM-dd');
          const holidayName = getHolidayName(dateStr);
          const isHolidayDay = !!holidayName;
          return (
            <button key={day.toISOString()} type="button" onClick={() => onSelect(day)}
              title={holidayName}
              className={cn(
                'mx-auto flex h-8 w-8 items-center justify-center rounded-full text-[0.8125rem] transition-colors',
                !inMonth && 'text-muted-foreground/30 hover:bg-accent/50',
                inMonth && !isSelected && !isTodayDay && 'hover:bg-accent',
                inMonth && (dow === 0 || isHolidayDay) && !isSelected && 'text-rose-500',
                inMonth && dow === 6 && !isHolidayDay && !isSelected && 'text-blue-500',
                isTodayDay && !isSelected && 'border border-primary/60 font-semibold text-primary',
                isSelected && 'bg-primary text-primary-foreground font-semibold',
              )}>
              {format(day, 'd')}
            </button>
          );
        })}
      </div>
    </div>
  );
}
