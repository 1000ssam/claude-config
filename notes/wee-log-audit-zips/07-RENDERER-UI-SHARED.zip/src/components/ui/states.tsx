import { Loader2, AlertCircle, FileQuestion, Inbox, RefreshCw, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

interface LoadingStateProps {
  message?: string;
}

export function LoadingState({ message = '로딩 중...' }: LoadingStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
      <Loader2 className="h-8 w-8 animate-spin mb-3" />
      <p className="text-sm">{message}</p>
    </div>
  );
}

interface ErrorStateProps {
  message?: string;
  onRetry?: () => void;
}

export function ErrorState({
  message = '데이터를 불러오는데 실패했습니다.',
  onRetry,
}: ErrorStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
      <AlertCircle className="h-10 w-10 mb-3 text-red-400" />
      <p className="text-sm mb-4">{message}</p>
      {onRetry && (
        <Button variant="outline" size="sm" onClick={onRetry}>
          <RefreshCw className="mr-1.5 h-3.5 w-3.5" />다시 시도
        </Button>
      )}
    </div>
  );
}

interface NotFoundStateProps {
  message?: string;
  backHref?: string;
  backLabel?: string;
}

export function NotFoundState({
  message = '데이터를 찾을 수 없습니다.',
  backHref = '/',
  backLabel = '홈으로 돌아가기',
}: NotFoundStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
      <FileQuestion className="h-10 w-10 mb-3" />
      <p className="text-sm mb-4">{message}</p>
      <Button variant="outline" size="sm" asChild>
        <Link to={backHref}><ArrowLeft className="mr-1.5 h-3.5 w-3.5" />{backLabel}</Link>
      </Button>
    </div>
  );
}

interface EmptyStateProps {
  message?: string;
  actionLabel?: string;
  actionHref?: string;
}

export function EmptyState({
  message = '데이터가 없습니다.',
  actionLabel,
  actionHref,
}: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
      <Inbox className="h-10 w-10 mb-3" />
      <p className="text-sm mb-4">{message}</p>
      {actionLabel && actionHref && (
        <Button variant="outline" size="sm" asChild>
          <Link to={actionHref}>{actionLabel}</Link>
        </Button>
      )}
    </div>
  );
}
