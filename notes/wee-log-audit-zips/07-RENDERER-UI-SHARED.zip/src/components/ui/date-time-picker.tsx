import { useState } from 'react';
import { format, parse, isValid } from 'date-fns';
import { ko } from 'date-fns/locale';
import { CalendarIcon, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';

export interface DateTimePickerContentProps {
  date: string;           // YYYY-MM-DD
  time?: string | null;   // HH:MM or null
  onDateChange: (date: string) => void;
  onTimeChange?: (time: string | null) => void;
}

// ── 내부 유틸 ─────────────────────────────────────────────────────────────────

function parseDate(dateStr: string): Date | null {
  if (!dateStr) return null;
  const d = parse(dateStr, 'yyyy-MM-dd', new Date());
  return isValid(d) ? d : null;
}

function getCurrentTime(): string {
  const now = new Date();
  return `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
}

/** 자유 입력 → { date, time } 파싱. 실패 시 null 반환. */
function parseFullInput(text: string): { date: string; time: string | null } | null {
  const trimmed = text.trim();

  // 날짜: YYYY/MM/DD | YYYY-MM-DD | YYYY년 M월 D일
  const dateRe = /^(\d{4})[/\-년]\s*(\d{1,2})[/\-월]\s*(\d{1,2})일?/;
  const dm = trimmed.match(dateRe);
  if (!dm) return null;

  const [y, mo, d] = [parseInt(dm[1], 10), parseInt(dm[2], 10), parseInt(dm[3], 10)];
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  const date = `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}`;

  const rest = trimmed.slice(dm[0].length).trim();
  if (!rest) return { date, time: null };

  const time = parseTimeString(rest);
  return { date, time };
}

/**
 * 시간 문자열을 24h "HH:MM"으로 변환.
 * 허용 형식: 9:30 / 930 / 9 30 / 오전 9:30 / 오후 9 / 9AM / 21:30 / 2130
 */
export function parseTimeString(raw: string): string | null {
  const s = raw.trim().toLowerCase();
  const isPM = s.includes('pm') || s.includes('오후');
  const isAM = s.includes('am') || s.includes('오전');

  let h: number, m: number;

  // 콜론 또는 공백 구분: H:MM | HH:MM | H MM | HH MM
  const sepMatch = s.match(/(\d{1,2})[:　 ](\d{2})/);
  if (sepMatch) {
    h = parseInt(sepMatch[1], 10);
    m = parseInt(sepMatch[2], 10);
  } else {
    // 순수 숫자
    const digits = s.replace(/\D/g, '');
    if (digits.length === 0) return null;
    if (digits.length <= 2) { h = parseInt(digits, 10); m = 0; }
    else if (digits.length === 3) { h = parseInt(digits[0], 10); m = parseInt(digits.slice(1), 10); }
    else if (digits.length === 4) { h = parseInt(digits.slice(0, 2), 10); m = parseInt(digits.slice(2), 10); }
    else return null;
  }

  if (isPM && h !== 12) h += 12;
  if (isAM && h === 12) h = 0;
  if (h > 23 || m > 59) return null;

  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

// ── 시간 인풋 (자유 텍스트, blur 시 파싱) ─────────────────────────────────────

interface TimeInputProps {
  time: string | null;
  onChange: (time: string | null) => void;
}

function TimeInput({ time, onChange }: TimeInputProps) {
  const [draft, setDraft] = useState<string | null>(null);
  const isEditing = draft !== null;
  const displayValue = isEditing ? draft : (time ?? '');

  function handleFocus(e: React.FocusEvent<HTMLInputElement>) {
    setDraft(time ?? '');
    e.currentTarget.select();
  }

  function handleBlur() {
    const raw = draft?.trim() ?? '';
    setDraft(null);
    if (!raw) { onChange(null); return; }
    const parsed = parseTimeString(raw);
    if (parsed) onChange(parsed);
    // 파싱 실패 시 기존값 유지 (onChange 미호출)
  }

  return (
    <input
      type="text"
      inputMode="numeric"
      value={displayValue}
      onChange={(e) => setDraft(e.target.value)}
      onFocus={handleFocus}
      onBlur={handleBlur}
      onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
      placeholder="HH:MM"
      className="shrink-0 w-14 bg-transparent text-sm font-mono text-primary outline-none text-center placeholder:text-primary/30"
    />
  );
}

// ── 컴포넌트 ──────────────────────────────────────────────────────────────────

/** 캘린더 + 시간 토글. Popover 없이 단독 embed 가능. */
export function DateTimePickerContent({ date, time, onDateChange, onTimeChange }: DateTimePickerContentProps) {
  const [timeEnabled, setTimeEnabled] = useState(!!time);
  /** null = 계산값 표시, string = 사용자 편집 중 */
  const [editText, setEditText] = useState<string | null>(null);

  const selectedDate = parseDate(date);
  const displayDateText = editText ?? (selectedDate ? format(selectedDate, 'yyyy/MM/dd') : date);

  function handleInputFocus() {
    setEditText(selectedDate ? format(selectedDate, 'yyyy/MM/dd') : date);
  }

  function handleInputBlur() {
    if (editText === null) return;
    const parsed = parseFullInput(editText);
    if (parsed) {
      onDateChange(parsed.date);
      if (timeEnabled && onTimeChange && parsed.time) {
        onTimeChange(parsed.time);
      }
    }
    setEditText(null);
  }

  function handleToggleTime() {
    const next = !timeEnabled;
    setTimeEnabled(next);
    if (next) {
      // 토글 켜는 순간 현재 시간 자동 입력
      onTimeChange?.(getCurrentTime());
    } else {
      onTimeChange?.(null);
    }
  }

  return (
    <div>
      {/* 상단: 날짜 텍스트 + 시간 인풋 분리 */}
      <div className="px-3 pt-3 pb-2 border-b flex items-center gap-2">
        <input
          type="text"
          value={displayDateText}
          onChange={(e) => setEditText(e.target.value)}
          onFocus={handleInputFocus}
          onBlur={handleInputBlur}
          onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
          placeholder="날짜 입력..."
          spellCheck={false}
          className="flex-1 min-w-0 bg-transparent text-sm font-mono outline-none placeholder:text-muted-foreground/50"
        />
        {timeEnabled && onTimeChange && (
          <TimeInput time={time ?? null} onChange={onTimeChange} />
        )}
      </div>

      {/* 캘린더 */}
      <Calendar
        selected={selectedDate}
        defaultMonth={selectedDate ?? undefined}
        onSelect={(d) => onDateChange(format(d, 'yyyy-MM-dd'))}
      />

      {/* 시간 토글 */}
      {onTimeChange && (
        <div className="border-t px-3 py-2.5">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              시간 포함
            </span>
            <button
              type="button"
              role="switch"
              aria-checked={timeEnabled}
              onClick={handleToggleTime}
              className={cn(
                'relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors',
                'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2',
                timeEnabled ? 'bg-primary' : 'bg-input',
              )}
            >
              <span className={cn(
                'block h-4 w-4 rounded-full bg-white shadow-sm transition-transform',
                timeEnabled ? 'translate-x-4' : 'translate-x-0',
              )} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

interface DateTimePickerProps extends DateTimePickerContentProps {
  className?: string;
  placeholder?: string;
  id?: string;
}

/** 트리거 버튼 + Popover. session-form에서 사용. */
export function DateTimePicker({
  date, time, onDateChange, onTimeChange, className, placeholder = '날짜 선택', id,
}: DateTimePickerProps) {
  const [open, setOpen] = useState(false);
  const selectedDate = parseDate(date);

  const displayText = selectedDate
    ? (time
      ? `${format(selectedDate, 'yyyy년 M월 d일', { locale: ko })} ${time}`
      : format(selectedDate, 'yyyy년 M월 d일', { locale: ko }))
    : placeholder;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          id={id}
          type="button"
          variant="outline"
          className={cn('w-full justify-start text-left font-normal h-9', !selectedDate && 'text-muted-foreground', className)}
        >
          <CalendarIcon className="mr-2 h-4 w-4 shrink-0 opacity-60" />
          {displayText}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <DateTimePickerContent
          date={date}
          time={time}
          onDateChange={onDateChange}
          onTimeChange={onTimeChange}
        />
      </PopoverContent>
    </Popover>
  );
}
