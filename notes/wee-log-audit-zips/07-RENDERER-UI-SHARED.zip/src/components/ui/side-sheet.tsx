import { useEffect, useRef, useCallback } from 'react';
import { X } from 'lucide-react';
import { cn } from '@/lib/utils';

const STORAGE_KEY = 'side-sheet-width';
const DEFAULT_WIDTH = 420;
const MIN_WIDTH = 300;
const MAX_WIDTH_RATIO = 0.7;

interface SideSheetProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

export function SideSheet({ open, onClose, title, children }: SideSheetProps) {
  const panelRef = useRef<HTMLDivElement>(null);

  // Escape 키로 닫기
  useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose();
    }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  // localStorage에서 너비 복원
  useEffect(() => {
    if (!open || !panelRef.current) return;
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const w = parseInt(saved, 10);
      if (!isNaN(w)) panelRef.current.style.width = `${w}px`;
    }
  }, [open]);

  // 좌측 엣지 드래그 리사이즈
  const handleResizeStart = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    const panel = panelRef.current;
    if (!panel) return;

    const startX = e.clientX;
    const startWidth = panel.offsetWidth;

    function onMove(ev: PointerEvent) {
      const maxW = window.innerWidth * MAX_WIDTH_RATIO;
      const newWidth = Math.min(
        Math.max(startWidth + (startX - ev.clientX), MIN_WIDTH),
        maxW
      );
      panel.style.width = `${newWidth}px`;
    }

    function onUp() {
      if (panel) {
        localStorage.setItem(STORAGE_KEY, String(panel.offsetWidth));
      }
      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp);
    }

    document.addEventListener('pointermove', onMove);
    document.addEventListener('pointerup', onUp);
  }, []);

  return (
    <>
      {/* 패널 */}
      <div
        ref={panelRef}
        style={{ width: DEFAULT_WIDTH }}
        className={cn(
          'fixed right-0 top-0 bottom-0 z-40 flex flex-col',
          'bg-background border-l border-border shadow-xl',
          'transition-transform duration-200 ease-out',
          open ? 'translate-x-0' : 'translate-x-full'
        )}
      >
        {/* 리사이즈 핸들 */}
        <div
          className="absolute left-0 top-0 bottom-0 w-1.5 cursor-col-resize group z-10"
          onPointerDown={handleResizeStart}
        >
          <div className="absolute inset-y-0 left-0 w-full group-hover:bg-primary/20 transition-colors" />
        </div>

        {/* 헤더 */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border shrink-0">
          <h2 className="text-sm font-semibold text-foreground truncate pr-2">{title}</h2>
          <button
            onClick={onClose}
            className="rounded-md p-1 hover:bg-secondary text-muted-foreground transition-colors shrink-0"
            aria-label="닫기"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* 콘텐츠 */}
        <div className="flex-1 overflow-hidden">
          {children}
        </div>
      </div>
    </>
  );
}
