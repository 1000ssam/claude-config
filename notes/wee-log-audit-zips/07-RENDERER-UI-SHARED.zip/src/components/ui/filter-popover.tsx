import { useState } from 'react';
import { Filter, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';

interface FilterColumn {
  key: string;
  label: string;
}

export interface FilterPopoverProps {
  columns: readonly FilterColumn[];
  /** 특정 열에 대한 distinct 값 목록을 반환하는 함수 */
  getValues: (col: string) => string[];
  filters: Record<string, string[]>;
  onFiltersChange: (f: Record<string, string[]>) => void;
  /** 값 표시 변환 함수 (예: status → 한국어) */
  displayValue?: (col: string, val: string) => string;
}

export function FilterPopover({
  columns,
  getValues,
  filters,
  onFiltersChange,
  displayValue,
}: FilterPopoverProps) {
  const [open, setOpen] = useState(false);
  const [selectedCol, setSelectedCol] = useState<string | null>(null);

  const activeCount = Object.values(filters).reduce((n, v) => n + (v?.length ?? 0), 0);

  function toggleValue(col: string, val: string, checked: boolean) {
    const prev = filters[col] ?? [];
    const next = checked ? [...prev, val] : prev.filter((v) => v !== val);
    onFiltersChange({ ...filters, [col]: next });
  }

  function reset() {
    onFiltersChange({});
    setSelectedCol(null);
  }

  return (
    <Popover open={open} onOpenChange={(o) => { setOpen(o); if (!o) setSelectedCol(null); }}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className={cn(activeCount > 0 && 'border-primary text-primary')}>
          <Filter className="mr-1.5 h-3.5 w-3.5" />
          필터
          {activeCount > 0 && (
            <Badge variant="default" className="ml-1.5 h-4 min-w-4 px-1 text-[0.625rem]">{activeCount}</Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-52 p-0 overflow-hidden">
        {selectedCol ? (
          <>
            <div className="flex items-center gap-1 px-3 py-2 border-b">
              <button
                onClick={() => setSelectedCol(null)}
                className="flex items-center text-xs text-muted-foreground hover:text-foreground"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
                뒤로
              </button>
              <span className="ml-auto text-xs font-semibold">
                {columns.find((c) => c.key === selectedCol)?.label}
              </span>
            </div>
            <div className="py-1 max-h-60 overflow-y-auto">
              {getValues(selectedCol).map((val) => {
                const checked = filters[selectedCol]?.includes(val) ?? false;
                return (
                  <label
                    key={val}
                    className="flex items-center gap-2.5 px-3 py-2 text-sm cursor-pointer hover:bg-muted/50"
                  >
                    <Checkbox
                      checked={checked}
                      onCheckedChange={(c) => toggleValue(selectedCol, val, !!c)}
                    />
                    {displayValue ? displayValue(selectedCol, val) : val}
                  </label>
                );
              })}
            </div>
          </>
        ) : (
          <>
            <div className="py-1">
              {columns.map((col) => {
                const count = filters[col.key]?.length ?? 0;
                return (
                  <button
                    key={col.key}
                    className="flex w-full items-center px-3 py-2 text-sm hover:bg-muted/50"
                    onClick={() => setSelectedCol(col.key)}
                  >
                    <span className="flex-1 text-left">{col.label}</span>
                    {count > 0 && (
                      <Badge variant="secondary" className="mr-1.5 h-4 min-w-4 px-1 text-[0.625rem]">{count}</Badge>
                    )}
                    <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
                  </button>
                );
              })}
            </div>
            {activeCount > 0 && (
              <div className="border-t px-3 py-2">
                <button onClick={reset} className="text-xs text-muted-foreground hover:text-destructive w-full text-left">
                  필터 초기화
                </button>
              </div>
            )}
          </>
        )}
      </PopoverContent>
    </Popover>
  );
}
