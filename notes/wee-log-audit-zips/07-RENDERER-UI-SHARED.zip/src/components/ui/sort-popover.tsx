import { useState } from 'react';
import { ArrowUpDown, ChevronLeft, ChevronRight, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';

interface SortColumn {
  key: string;
  label: string;
}

export type SortState = { col: string; dir: 'asc' | 'desc' } | null;

export interface SortPopoverProps {
  columns: readonly SortColumn[];
  sort: SortState;
  onSortChange: (s: SortState) => void;
}

export function SortPopover({ columns, sort, onSortChange }: SortPopoverProps) {
  const [open, setOpen] = useState(false);
  const [selectedCol, setSelectedCol] = useState<string | null>(sort?.col ?? null);

  function selectDir(dir: 'asc' | 'desc') {
    if (!selectedCol) return;
    onSortChange({ col: selectedCol, dir });
    setOpen(false);
  }

  return (
    <Popover open={open} onOpenChange={(o) => { setOpen(o); if (!o) setSelectedCol(sort?.col ?? null); }}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className={cn(sort && 'border-primary text-primary')}>
          <ArrowUpDown className="mr-1.5 h-3.5 w-3.5" />
          정렬
          {sort && (
            <span className="ml-1 text-[0.6875rem] font-normal">
              {columns.find((c) => c.key === sort.col)?.label} {sort.dir === 'asc' ? '↑' : '↓'}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-44 p-0 overflow-hidden">
        {selectedCol ? (
          <>
            <div className="flex items-center gap-1 px-3 py-2 border-b">
              <button
                onClick={() => setSelectedCol(null)}
                className="flex items-center text-xs text-muted-foreground hover:text-foreground"
              >
                <ChevronLeft className="h-3.5 w-3.5" />
                뒤로
              </button>
              <span className="ml-auto text-xs font-semibold">
                {columns.find((c) => c.key === selectedCol)?.label}
              </span>
            </div>
            <div className="py-1">
              {(['asc', 'desc'] as const).map((dir) => {
                const active = sort?.col === selectedCol && sort.dir === dir;
                return (
                  <button
                    key={dir}
                    className="flex w-full items-center px-3 py-2 text-sm hover:bg-muted/50"
                    onClick={() => selectDir(dir)}
                  >
                    <span className="flex-1 text-left">{dir === 'asc' ? '오름차순' : '내림차순'}</span>
                    {active && <Check className="h-3.5 w-3.5 text-primary" />}
                  </button>
                );
              })}
            </div>
          </>
        ) : (
          <>
            <div className="py-1">
              {columns.map((col) => {
                const active = sort?.col === col.key;
                return (
                  <button
                    key={col.key}
                    className="flex w-full items-center px-3 py-2 text-sm hover:bg-muted/50"
                    onClick={() => setSelectedCol(col.key)}
                  >
                    <span className={cn('flex-1 text-left', active && 'font-medium text-primary')}>{col.label}</span>
                    {active && <span className="mr-1 text-xs text-primary">{sort!.dir === 'asc' ? '↑' : '↓'}</span>}
                    <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
                  </button>
                );
              })}
            </div>
            {sort && (
              <div className="border-t px-3 py-2">
                <button
                  onClick={() => { onSortChange(null); setOpen(false); }}
                  className="text-xs text-muted-foreground hover:text-destructive w-full text-left"
                >
                  정렬 초기화
                </button>
              </div>
            )}
          </>
        )}
      </PopoverContent>
    </Popover>
  );
}
