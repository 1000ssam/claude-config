import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  /* Pill badges — 9999px radius, tight padding, small tracking */
  "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold tracking-wide transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        /* Notion default badge — blue pill */
        default:
          "bg-primary/10 text-primary border border-primary/25",
        secondary:
          "bg-secondary text-secondary-foreground border border-transparent",
        destructive:
          "bg-red-50 text-red-700 border border-red-100",
        outline:
          "border border-input text-foreground bg-transparent",
        success:
          "bg-green-50 text-green-700 border border-green-100",
        warning:
          "bg-amber-50 text-amber-700 border border-amber-100",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return (
    <div className={cn(badgeVariants({ variant }), className)} {...props} />
  );
}

export { Badge, badgeVariants };
