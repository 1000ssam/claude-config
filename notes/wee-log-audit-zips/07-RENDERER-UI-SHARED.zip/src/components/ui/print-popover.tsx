import { useState } from 'react';
import { Printer, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverTrigger,
  PopoverContent,
} from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

type PageSize = 'A4' | 'A3';
type Orientation = 'portrait' | 'landscape';

export interface PrintPopoverProps {
  /** 기본 용지 크기 */
  defaultPageSize?: PageSize;
  /** 기본 방향 (true = 가로) */
  defaultLandscape?: boolean;
  /** PDF 저장 시 기본 파일명 */
  defaultName?: string;
  /** 커스텀 트리거 버튼 (생략 시 프린터 아이콘 버튼) */
  trigger?: React.ReactNode;
}

export function PrintPopover({
  defaultPageSize = 'A4',
  defaultLandscape = false,
  defaultName,
  trigger,
}: PrintPopoverProps) {
  const { addToast } = useToast();
  const [open, setOpen] = useState(false);
  const [pageSize, setPageSize] = useState<PageSize>(defaultPageSize);
  const [orientation, setOrientation] = useState<Orientation>(
    defaultLandscape ? 'landscape' : 'portrait',
  );
  const [saving, setSaving] = useState(false);

  const landscape = orientation === 'landscape';

  async function handleSave() {
    // PDF 변환 전에 팝오버를 닫아 잔재가 PDF에 들어가지 않게 한다.
    setOpen(false);
    setSaving(true);
    try {
      const result = await window.api.print.save({ pageSize, landscape, defaultName });
      if (result.success) {
        addToast({ title: 'PDF가 저장되었습니다.', variant: 'success' });
      } else if (result.message) {
        addToast({ title: result.message, variant: 'destructive' });
      }
    } catch {
      addToast({ title: 'PDF 저장에 실패했습니다.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  async function handlePrint() {
    // 미리보기는 현재 윈도우의 DOM을 캡처하므로, 팝오버 잔재가 PDF에 들어가지 않도록 먼저 닫는다.
    setOpen(false);
    try {
      await window.api.print.preview({ pageSize, landscape });
    } catch {
      addToast({ title: '인쇄 미리보기에 실패했습니다.', variant: 'destructive' });
    }
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        {trigger || (
          <Button variant="outline" size="sm" className="h-9">
            <Printer className="mr-2 h-4 w-4" />
            인쇄
          </Button>
        )}
      </PopoverTrigger>
      <PopoverContent align="end" className="w-56 space-y-4 print:hidden">
        {/* 용지 크기 */}
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">용지</Label>
          <Select value={pageSize} onValueChange={(v) => setPageSize(v as PageSize)}>
            <SelectTrigger className="h-8 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="A4">A4</SelectItem>
              <SelectItem value="A3">A3</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 방향 토글 */}
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">방향</Label>
          <div className="flex rounded-lg border">
            <button
              type="button"
              onClick={() => setOrientation('portrait')}
              className={`flex-1 px-3 py-1.5 text-sm rounded-l-lg transition-colors ${
                orientation === 'portrait'
                  ? 'bg-primary text-primary-foreground'
                  : 'hover:bg-muted'
              }`}
            >
              세로
            </button>
            <button
              type="button"
              onClick={() => setOrientation('landscape')}
              className={`flex-1 px-3 py-1.5 text-sm rounded-r-lg transition-colors ${
                orientation === 'landscape'
                  ? 'bg-primary text-primary-foreground'
                  : 'hover:bg-muted'
              }`}
            >
              가로
            </button>
          </div>
        </div>

        {/* 액션 버튼 */}
        <div className="flex gap-2 pt-1">
          <Button
            variant="outline"
            size="sm"
            className="flex-1 h-8 text-xs"
            onClick={handlePrint}
          >
            <Printer className="mr-1 h-3.5 w-3.5" />
            인쇄
          </Button>
          <Button
            size="sm"
            className="flex-1 h-8 text-xs"
            onClick={handleSave}
            disabled={saving}
          >
            <Download className="mr-1 h-3.5 w-3.5" />
            {saving ? '저장 중...' : 'PDF 저장'}
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
