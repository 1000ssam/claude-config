interface PrintableHeaderProps {
  title: string;
  subtitle?: string;
  meta?: string;
}

export function PrintableHeader({ title, subtitle, meta }: PrintableHeaderProps) {
  const printDate = meta ?? `인쇄일: ${new Date().toLocaleDateString('ko-KR')}`;

  return (
    <div className="hidden print:block px-4 lg:px-6 pb-4 border-b">
      <h1 className="text-lg font-bold">{title}</h1>
      <p className="text-sm text-muted-foreground mt-1">
        {subtitle && <>{subtitle} · </>}
        {printDate}
      </p>
    </div>
  );
}
