import { useSyncExternalStore } from 'react';
import { Plus, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useTabs, pathTitle, type Tab } from './tabs-context';

/** 탭 하나. 자기 라우터를 구독해 현재 경로 기반 제목을 실시간 표시. */
function TabChip({
  tab,
  active,
  canClose,
  onSelect,
  onClose,
}: {
  tab: Tab;
  active: boolean;
  canClose: boolean;
  onSelect: () => void;
  onClose: () => void;
}) {
  const pathname = useSyncExternalStore(
    tab.router.subscribe,
    () => tab.router.state.location.pathname,
  );
  const title = pathTitle(pathname);

  return (
    <div
      className={cn(
        'group flex items-center gap-1 rounded-md pl-2.5 py-1 text-xs font-medium transition-colors',
        // X(닫기) 버튼이 있을 때만 오른쪽을 좁게, 없으면 왼쪽과 대칭으로 보정.
        canClose ? 'pr-1' : 'pr-2.5',
        active
          // V2 틴트 액센트: 활성 탭 = 팔레트 강조색 틴트 배경 + 강조색 텍스트.
          // bg-primary/text-primary 는 hsl(var(--primary)) → 설정 컬러팔레트가 자동 매핑됨(하드코딩 X).
          ? 'bg-primary/10 text-primary font-semibold'
          : 'text-muted-foreground hover:text-foreground hover:bg-background/50',
      )}
    >
      <button type="button" onClick={onSelect} className="max-w-[12rem] truncate">
        {title}
      </button>
      {canClose && (
        <button
          type="button"
          onClick={onClose}
          aria-label="탭 닫기"
          className="rounded p-0.5 opacity-0 transition-opacity hover:bg-muted-foreground/10 group-hover:opacity-100"
        >
          <X className="h-3 w-3" />
        </button>
      )}
    </div>
  );
}

export function TabBar() {
  const { tabs, activeId, setActive, closeTab, openTab } = useTabs();

  return (
    <div className="no-scrollbar flex min-w-0 flex-1 items-center gap-1 overflow-x-auto">
      {tabs.map((tab) => (
        <TabChip
          key={tab.id}
          tab={tab}
          active={tab.id === activeId}
          canClose={tabs.length > 1}
          onSelect={() => setActive(tab.id)}
          onClose={() => closeTab(tab.id)}
        />
      ))}
      <button
        type="button"
        onClick={() => openTab()}
        aria-label="새 탭"
        className="shrink-0 rounded-md p-1 text-muted-foreground transition-colors hover:bg-background hover:text-foreground"
      >
        <Plus className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}
