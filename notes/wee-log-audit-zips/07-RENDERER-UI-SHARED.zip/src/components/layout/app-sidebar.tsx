import { useSyncExternalStore, type MouseEvent } from 'react';
import {
  Home,
  Users,
  SquareStack,
  BarChart3,
  FileText,
  Settings,
  Megaphone,
  UsersRound,
} from 'lucide-react';
import { WeeStoryLogo } from '@/components/logo-wee-story';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from '@/components/ui/sidebar';
import { useNotices } from '@/hooks/use-notices';
import { useTabs } from './tabs-context';

const navItems = [
  { href: '/', label: '홈', icon: Home },
  { href: '/cases', label: '사례 관리', icon: SquareStack },
  { href: '/students', label: '학생 DB', icon: Users },
  { href: '/statistics', label: '통계', icon: BarChart3 },
  { href: '/reports', label: '보고서', icon: FileText },
  { href: '/settings', label: '설정', icon: Settings },
];

export function AppSidebar() {
  const { activeRouter, navigateActive, openTab } = useTabs();
  // 활성 탭의 현재 경로를 구독해 메뉴 하이라이트를 동기화한다.
  const pathname = useSyncExternalStore(
    activeRouter.subscribe,
    () => activeRouter.state.location.pathname,
  );
  const { unreadCount } = useNotices();

  // 메뉴 클릭: 기본 = 활성 탭 이동, Ctrl/Cmd+클릭 = 새 탭으로 열기(브라우저 관습).
  const handleNav = (e: MouseEvent, to: string) => {
    if (e.ctrlKey || e.metaKey) openTab(to);
    else navigateActive(to);
  };

  return (
    <Sidebar>
      <SidebarHeader>
        <div className="px-4 py-4">
          <WeeStoryLogo height={34} className="text-sidebar-foreground" />
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarMenu>
            {navItems.map((item) => {
              const isActive =
                item.href === '/'
                  ? pathname === '/'
                  : pathname.startsWith(item.href);
              return (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton
                    isActive={isActive}
                    tooltip={item.label}
                    onClick={(e) => handleNav(e, item.href)}
                  >
                    <item.icon />
                    <span>{item.label}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              );
            })}
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              isActive={pathname === '/notices'}
              tooltip="공지사항"
              className="relative"
              onClick={(e) => handleNav(e, '/notices')}
            >
              <Megaphone />
              <span>공지사항</span>
              {unreadCount > 0 && (
                <span className="ml-auto text-[0.625rem] font-bold text-primary bg-primary/10 px-1.5 py-0.5 rounded-full leading-none">
                  NEW
                </span>
              )}
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton
              isActive={pathname === '/community'}
              tooltip="커뮤니티"
              onClick={(e) => handleNav(e, '/community')}
            >
              <UsersRound />
              <span>커뮤니티</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
        <p className="px-2 pt-1 text-xs text-sidebar-foreground/50">
          Wee-Story v0.1.0
        </p>
      </SidebarFooter>
    </Sidebar>
  );
}
