import {
  createContext,
  useCallback,
  useContext,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { createMemoryRouter, type RouteObject } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';

/**
 * ── 활성 / 비활성 탭의 정의 (중요) ───────────────────────────────
 *
 * - **활성 탭**: `activeId === tab.id`인 탭. 항상 정확히 **하나**.
 *   App.tsx에서 `display:flex`로 렌더되어 화면에 보인다.
 * - **비활성 탭**: 그 외 전부. App.tsx에서 `hidden`(`display:none`)으로
 *   숨겨지지만 **언마운트되지 않는다** — DOM·컴포넌트 트리·state가 그대로 유지됨.
 *
 * 활성 여부는 *오직* `activeId`와의 일치로만 결정된다 (포커스/가시성 API와 무관).
 * 탭은 최소 1개 보장(마지막 탭 닫기 불가), 활성 탭을 닫으면 이웃이 활성이 된다.
 *
 * ⚠️ 결과(BACKLOG #12 미결 A — 의도적으로 옵션 0 유지):
 * 비활성 탭도 마운트 상태이므로 그 안의 `useEffect`·`setInterval`·IPC 구독
 * (`window.api.*.onEvent`)이 **계속 동작**한다. 비활성이라고 해서 타이머/구독이
 * 멈추지 않는다. 자원 부담이 체감되면 "활성 탭만 동작" 게이팅을 핫스팟
 * (DayTimeGrid 시계 · use-stt · use-ai-stream)에 한정 적용할 것.
 * ─────────────────────────────────────────────────────────────
 */

/** 탭마다 독립 네비게이션 스택을 갖는 메모리 라우터 인스턴스. */
export type TabRouter = ReturnType<typeof createMemoryRouter>;

export interface Tab {
  id: string;
  router: TabRouter;
}

interface TabsContextValue {
  tabs: Tab[];
  activeId: string;
  /** 현재 활성 탭의 라우터 (사이드바·하이라이트가 구독). */
  activeRouter: TabRouter;
  /** 새 탭을 열고 활성화. `to` 미지정 시 홈(`/`)에서 시작(예: `+` 버튼). 지정 시 그 경로로 시작(예: 사이드바 Ctrl+클릭). */
  openTab: (to?: string) => void;
  closeTab: (id: string) => void;
  setActive: (id: string) => void;
  /** 활성 탭 내부에서 이동 (사이드바 클릭 등). */
  navigateActive: (to: string) => void;
}

const TabsContext = createContext<TabsContextValue | null>(null);

/** 동시에 열 수 있는 탭 상한. 초과 시 새 탭 열기는 무시된다. */
const MAX_TABS = 12;

let tabCounter = 0;
function createTab(routes: RouteObject[], initialPath = '/'): Tab {
  const router = createMemoryRouter(routes, { initialEntries: [initialPath] });
  return { id: `tab-${Date.now()}-${tabCounter++}`, router };
}

/**
 * `routes`는 App.tsx에서 `appRoutes`를 주입받는다. tabs-context가 `@/routes`를
 * 직접 import하면 `routes → 페이지 → use-tab-nav → tabs-context → routes` 순환이
 * 생겨 HMR 흰 화면을 유발하므로, 의존 방향을 App.tsx로 일원화한다(주입).
 */
export function TabsProvider({
  routes,
  children,
}: {
  routes: RouteObject[];
  children: ReactNode;
}) {
  const { addToast } = useToast();

  // 첫 탭은 한 번만 생성 (리렌더 시 재생성 방지).
  const firstTab = useRef<Tab>();
  if (!firstTab.current) firstTab.current = createTab(routes);

  const [tabs, setTabs] = useState<Tab[]>([firstTab.current]);
  const [activeId, setActiveId] = useState<string>(firstTab.current.id);

  // 이벤트 핸들러에서 최신 값을 읽기 위한 ref 미러.
  const tabsRef = useRef(tabs);
  tabsRef.current = tabs;
  const activeIdRef = useRef(activeId);
  activeIdRef.current = activeId;

  const setActive = useCallback((id: string) => setActiveId(id), []);

  const openTab = useCallback((to = '/') => {
    // 상한 초과 시 조용히 무시하지 않고 토스트로 안내(버그 오인 방지).
    // setTabs 업데이터 밖에서 ref로 사전 체크 → StrictMode 이중 호출 시 토스트 중복 방지.
    if (tabsRef.current.length >= MAX_TABS) {
      addToast({
        title: `탭은 최대 ${MAX_TABS}개까지 열 수 있어요`,
        description: '사용하지 않는 탭을 닫고 다시 시도하세요.',
      });
      return;
    }
    const tab = createTab(routes, to);
    setActiveId(tab.id);
    setTabs((prev) => [...prev, tab]);
  }, [addToast, routes]);

  const closeTab = useCallback((id: string) => {
    setTabs((prev) => {
      if (prev.length <= 1) return prev; // 마지막 탭은 닫지 않음
      const idx = prev.findIndex((t) => t.id === id);
      const next = prev.filter((t) => t.id !== id);
      if (id === activeIdRef.current) {
        // 닫힌 탭 자리의 오른쪽 → 없으면 왼쪽 → 첫 탭으로 활성 이동
        const neighbor = next[idx] ?? next[idx - 1] ?? next[0];
        setActiveId(neighbor.id);
      }
      return next;
    });
  }, []);

  const navigateActive = useCallback((to: string) => {
    const tab = tabsRef.current.find((t) => t.id === activeIdRef.current);
    tab?.router.navigate(to);
  }, []);

  const activeRouter =
    tabs.find((t) => t.id === activeId)?.router ?? tabs[0].router;

  return (
    <TabsContext.Provider
      value={{
        tabs,
        activeId,
        activeRouter,
        openTab,
        closeTab,
        setActive,
        navigateActive,
      }}
    >
      {children}
    </TabsContext.Provider>
  );
}

export function useTabs(): TabsContextValue {
  const ctx = useContext(TabsContext);
  if (!ctx) throw new Error('useTabs must be used within a TabsProvider');
  return ctx;
}

// ---- 경로 → 탭 제목 매핑 (app-breadcrumb과 동일 규칙) ----

const ROUTE_LABELS: Record<string, string> = {
  cases: '사례 관리',
  students: '학생 DB',
  statistics: '통계',
  reports: '보고서',
  settings: '설정',
  notices: '공지사항',
  community: '커뮤니티',
  new: '새 등록',
  sessions: '상담 기록',
};

function isDynamic(segment: string): boolean {
  return /^[0-9a-f-]{8,}$/i.test(segment) || /^\d+$/.test(segment);
}

/** 현재 경로명으로부터 탭에 표시할 짧은 제목을 만든다. */
export function pathTitle(pathname: string): string {
  const segments = pathname.split('/').filter(Boolean);
  if (segments.length === 0) return '홈';
  const last = segments[segments.length - 1];
  if (isDynamic(last)) {
    const prev = segments[segments.length - 2] ?? '';
    if (prev === 'cases') return '사례 상세';
    if (prev === 'sessions') return '상담 상세';
    if (prev === 'students') return '학생 상세';
    return '상세';
  }
  return ROUTE_LABELS[last] ?? last;
}
