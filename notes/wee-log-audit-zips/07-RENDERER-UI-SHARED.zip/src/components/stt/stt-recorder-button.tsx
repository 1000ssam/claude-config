// 회기 작성 폼에서 사용하는 STT 녹음/전사 버튼.
// - status idle: 마이크 아이콘
// - status recording: 빨간 점멸 + 녹음 시간 표시 + 정지 버튼
// - status uploading/converting/transcribing: 스피너 + 단계 라벨
// - 모델 미설치 시 클릭하면 다운로드 안내 다이얼로그

import { useCallback, useEffect, useState } from 'react';
import { Mic, MicOff, Loader2, Download, AlertCircle } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useStt, type UseSttReturn } from '@/hooks/use-stt';
import { useToast } from '@/hooks/use-toast';
import type { SttTranscribeResult } from '../../../lib/stt/stt-types';

interface SttRecorderButtonProps {
  /** 전사 결과를 폼에 어떻게 반영할지 호출자가 결정 */
  onTranscribed: (text: string, result: SttTranscribeResult) => void;
  /** 비활성화 (외부 조건으로 강제 끄기) */
  disabled?: boolean;
  className?: string;
  /** 접근성 라벨 */
  ariaLabel?: string;
}

function formatDuration(ms: number): string {
  const totalSec = Math.floor(ms / 1000);
  const m = String(Math.floor(totalSec / 60)).padStart(2, '0');
  const s = String(totalSec % 60).padStart(2, '0');
  return `${m}:${s}`;
}

export function SttRecorderButton({ onTranscribed, disabled, className, ariaLabel }: SttRecorderButtonProps) {
  const { addToast } = useToast();
  const stt = useStt({
    onTranscribed: (result) => onTranscribed(result.text, result),
    onError: (msg) => addToast({ title: 'STT 오류', description: msg, variant: 'destructive' }),
  });

  // 모델 미설치 안내 모달 (간단히 confirm-dialog 대신 toast로 시작)
  const [needsDownload, setNeedsDownload] = useState(false);
  useEffect(() => {
    if (stt.status?.model.state === 'absent' || stt.status?.model.state === 'error') {
      setNeedsDownload(true);
    } else {
      setNeedsDownload(false);
    }
  }, [stt.status?.model.state]);

  const onClick = useCallback(async () => {
    if (!stt.status) return;
    if (stt.status.model.state !== 'ready') {
      // 모델 다운로드 안내
      addToast({
        title: 'STT 모델 다운로드 필요',
        description: '설정 화면에서 STT 모델을 먼저 다운로드해주세요.',
      });
      return;
    }
    if (stt.phase === 'idle' || stt.phase === 'error') {
      await stt.start();
    } else if (stt.phase === 'recording') {
      await stt.stop();
    } else {
      // uploading/converting/transcribing — 진행 중. 클릭 시 취소
      await stt.cancel();
    }
  }, [stt, addToast]);

  const isBusy = stt.phase !== 'idle' && stt.phase !== 'error';
  const isDownloading = stt.status?.model.state === 'downloading';

  return (
    <SttRecorderInner
      stt={stt}
      isBusy={isBusy}
      isDownloading={isDownloading}
      needsDownload={needsDownload}
      onClick={onClick}
      disabled={disabled}
      className={className}
      ariaLabel={ariaLabel}
    />
  );
}

interface SttRecorderInnerProps {
  stt: UseSttReturn;
  isBusy: boolean;
  isDownloading: boolean;
  needsDownload: boolean;
  onClick: () => void;
  disabled?: boolean;
  className?: string;
  ariaLabel?: string;
}

function SttRecorderInner({
  stt,
  isBusy,
  isDownloading,
  needsDownload,
  onClick,
  disabled,
  className,
  ariaLabel,
}: SttRecorderInnerProps) {
  if (!stt.status?.enabled) return null;
  if (!stt.status?.binaryAvailable) {
    return (
      <Button type="button" variant="ghost" size="sm" disabled className={cn('h-7 gap-1.5 text-xs text-muted-foreground', className)}>
        <AlertCircle className="h-3.5 w-3.5" />
        STT 바이너리 없음
      </Button>
    );
  }

  // 모델 다운로드 중
  if (isDownloading) {
    const pct = Math.round((stt.status.model.progress ?? 0) * 100);
    return (
      <Button type="button" variant="ghost" size="sm" className={cn('h-7 gap-1.5 text-xs', className)} disabled>
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
        모델 받는 중 {pct}%
      </Button>
    );
  }

  // 모델 미설치
  if (needsDownload) {
    return (
      <Button
        type="button"
        variant="outline"
        size="sm"
        className={cn('h-7 gap-1.5 text-xs', className)}
        onClick={() => void stt.downloadModel()}
        disabled={disabled}
        aria-label="STT 모델 다운로드"
      >
        <Download className="h-3.5 w-3.5" />
        STT 모델 받기
      </Button>
    );
  }

  // 녹음 중
  if (stt.phase === 'recording') {
    return (
      <Button
        type="button"
        variant="destructive"
        size="sm"
        className={cn('h-7 gap-1.5 text-xs', className)}
        onClick={onClick}
        aria-label="녹음 정지"
      >
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white opacity-75" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-white" />
        </span>
        녹음 중 {formatDuration(stt.recordingMs)}
      </Button>
    );
  }

  // 업로드/변환/전사 진행 중
  if (isBusy) {
    const label =
      stt.phase === 'uploading' ? '전송 중'
      : stt.phase === 'converting' ? '변환 중'
      : '전사 중';
    return (
      <Button
        type="button"
        variant="ghost"
        size="sm"
        className={cn('h-7 gap-1.5 text-xs', className)}
        onClick={onClick}
        aria-label={`${label} — 클릭하면 취소`}
      >
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
        {label} (클릭 취소)
      </Button>
    );
  }

  // idle
  return (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      className={cn('h-7 gap-1.5 text-xs hover:text-primary', className)}
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel ?? '음성 받아쓰기'}
    >
      {stt.phase === 'error' ? <MicOff className="h-3.5 w-3.5" /> : <Mic className="h-3.5 w-3.5" />}
      음성 받아쓰기
    </Button>
  );
}
