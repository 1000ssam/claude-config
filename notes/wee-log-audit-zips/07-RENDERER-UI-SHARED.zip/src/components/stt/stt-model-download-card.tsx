// 설정 화면용 STT 모델 다운로드 카드.
// - 모델 상태 표시 (absent/downloading/ready/error)
// - 다운로드 / 취소 / 재다운로드 액션
// - 향후 small/medium 토글 UI 추가 위치

import { Loader2, Download, Check, X, AlertCircle } from 'lucide-react';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useStt } from '@/hooks/use-stt';
import { STT_MODEL_INFO } from '../../../lib/stt/stt-types';

function formatBytes(bytes: number | undefined): string {
  if (!bytes) return '0 MB';
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export function SttModelDownloadCard() {
  const stt = useStt();
  const status = stt.status;

  if (!status) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">음성 받아쓰기 (STT)</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">상태 로딩 중...</p>
        </CardContent>
      </Card>
    );
  }

  const modelInfo = STT_MODEL_INFO[status.model.id];
  const state = status.model.state;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">음성 받아쓰기 (STT)</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-1">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium">{modelInfo.label}</span>
            <span className="text-muted-foreground text-xs">{formatBytes(modelInfo.sizeBytes)}</span>
          </div>
          <p className="text-xs text-muted-foreground">{modelInfo.description}</p>
        </div>

        {!status.binaryAvailable && (
          <div className="flex items-start gap-2 rounded-md border border-destructive/50 bg-destructive/10 p-2 text-xs text-destructive">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>whisper-cli 바이너리가 설치되어 있지 않습니다. 앱을 재설치하거나 개발팀에 문의하세요.</span>
          </div>
        )}

        {state === 'ready' && (
          <div className="flex items-center gap-2 text-sm text-green-700 dark:text-green-400">
            <Check className="h-4 w-4" />
            모델 설치 완료 — 받아쓰기 사용 가능
          </div>
        )}

        {state === 'absent' && (
          <Button
            type="button"
            size="sm"
            onClick={() => void stt.downloadModel()}
            disabled={!status.binaryAvailable}
            className="gap-2"
          >
            <Download className="h-4 w-4" />
            모델 다운로드
          </Button>
        )}

        {state === 'downloading' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                다운로드 중...
              </span>
              <span>
                {formatBytes(status.model.bytesDownloaded)} / {formatBytes(status.model.totalBytes)}
                {' '}({Math.round((status.model.progress ?? 0) * 100)}%)
              </span>
            </div>
            <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
              <div
                className="h-full bg-primary transition-all duration-150"
                style={{ width: `${Math.round((status.model.progress ?? 0) * 100)}%` }}
              />
            </div>
            <Button type="button" size="sm" variant="outline" onClick={() => void stt.cancelModelDownload()} className="gap-2">
              <X className="h-4 w-4" />
              취소
            </Button>
          </div>
        )}

        {state === 'error' && (
          <div className="space-y-2">
            <div className="flex items-start gap-2 rounded-md border border-destructive/50 bg-destructive/10 p-2 text-xs text-destructive">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{status.model.errorMessage ?? '다운로드 실패'}</span>
            </div>
            <Button type="button" size="sm" onClick={() => void stt.downloadModel()} className="gap-2">
              <Download className="h-4 w-4" />
              다시 시도
            </Button>
          </div>
        )}

        <p className="text-xs text-muted-foreground">
          모델 파일은 사용자 데이터 폴더의 <code className="rounded bg-muted px-1">stt-models/</code>에 저장됩니다.
          음성 데이터는 외부로 전송되지 않으며, 전사 후 즉시 삭제됩니다.
        </p>
      </CardContent>
    </Card>
  );
}
