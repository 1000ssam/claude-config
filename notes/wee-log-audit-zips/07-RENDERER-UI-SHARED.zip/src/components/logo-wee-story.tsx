interface WeeStoryLogoProps {
  className?: string;
  height?: number;
}

const FONT =
  "'Inter', 'Pretendard Variable', 'Pretendard', -apple-system, BlinkMacSystemFont, system-ui, sans-serif"

export function WeeStoryLogo({ className, height = 34 }: WeeStoryLogoProps) {
  return (
    <svg
      height={height}
      viewBox="0 0 200 44"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label="Wee Story"
      style={{ display: 'block' }}
    >
      <title>Wee Story</title>

      {/* Brand dot — follows palette primary */}
      <circle cx="7" cy="22" r="5" fill="hsl(var(--primary))" />

      {/* WEE — large display */}
      <text x="20" y="36" fontFamily={FONT} fontSize="36" fontWeight="900" letterSpacing="-0.05em" fill="currentColor">
        WEE
      </text>

      {/* Vertical rule */}
      <line x1="103" y1="10" x2="103" y2="36" stroke="currentColor" strokeWidth="1" strokeLinecap="round" opacity="0.2" />

      {/* STORY — small, tracked, vertically centered */}
      <text x="115" y="27" fontFamily={FONT} fontSize="12" fontWeight="600" letterSpacing="0.38em" fill="currentColor" opacity="0.55">
        STORY
      </text>
    </svg>
  )
}
