/**
 * Weenote Typography Logo Component
 *
 * "Wee" — Bold, full opacity
 * "note" — Regular, muted opacity
 *
 * Uses currentColor (inherits from parent text color) for light/dark theme support.
 */

interface WeenoteLogoProps {
  className?: string;
  /** Font size in rem. Default: 1.25 (20px) */
  size?: number;
}

export function WeenoteLogo({ className, size = 1.25 }: WeenoteLogoProps) {
  return (
    <span
      className={className}
      style={{
        fontSize: `${size}rem`,
        fontFamily: "'Inter', 'Pretendard Variable', 'Pretendard', -apple-system, BlinkMacSystemFont, system-ui, sans-serif",
        letterSpacing: '-0.02em',
        lineHeight: 1,
        whiteSpace: 'nowrap',
      }}
      aria-label="Weenote"
    >
      <span style={{ fontWeight: 700 }}>Wee</span>
      <span style={{ fontWeight: 400, opacity: 0.55 }}>note</span>
    </span>
  );
}
