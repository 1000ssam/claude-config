import { useEffect, useMemo, useState } from 'react';
import { Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import type { AiEvent, AiStatus } from '@/types/ai';
import type { Session } from '@/types/session';

interface AiSummaryStatusBannerProps {
  caseId: number;
  sessions: Session[];
  /** 갱신 후 회기 데이터를 다시 불러올 콜백 (사례 상세 페이지의 refreshData 등) */
  onAfterRefresh?: () => void;
  className?: string;
}

/**
 * 사례 상세 화면 상단의 작은 알림 배너.
 *
 * - 모델 미준비/AI 비활성이면 자체적으로 숨김.
 * - pending/failed 회기가 0건이면 시각적 노이즈를 피하기 위해 숨김.
 * - "갱신" 클릭 시 ai:refresh-summaries 호출 → 토스트 + 호출자가 데이터 재로드.
 *
 * Phase 4에서는 이 작은 인디케이터만, Phase 5에서 전체 사이드패널의 일부로 흡수.
 */
export function AiSummaryStatusBanner({
  caseId,
  sessions,
  onAfterRefresh,
  className,
}: AiSummaryStatusBannerProps) {
  const { addToast } = useToast();
  const [busy, setBusy] = useState(false);
  const ready = useAiReadinessLite();

  const counts = useMemo(() => {
    let pending = 0;
    let failed = 0;
    for (const s of sessions) {
      if (!s.session_content || !s.session_content.trim()) continue;
      if (s.summary_status === 'pending') pending += 1;
      else if (s.summary_status === 'failed') failed += 1;
    }
    return { pending, failed };
  }, [sessions]);

  if (!ready) return null;
  if (counts.pending === 0 && counts.failed === 0) return null;

  const handleRefresh = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const res = await window.api.ai.refreshSummaries(caseId);
      addToast({
        title: `요약 갱신 시작 (${res.enqueued}건 큐에 추가)`,
        variant: 'success',
      });
      // 큐 처리에는 수초 걸리므로 즉시 fetch보단 약간 지연 후 데이터 재로드.
      setTimeout(() => onAfterRefresh?.(), 1500);
    } catch (e) {
      const msg = e instanceof Error ? e.message : '알 수 없는 오류';
      addToast({ title: `요약 갱신 실패: ${msg}`, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className={cn(
        'flex items-center justify-between gap-3 rounded-md border border-amber-500/30 bg-amber-500/5 px-3 py-2 print:hidden',
        className,
      )}
    >
      <div className="flex items-center gap-2 text-xs text-amber-900 dark:text-amber-200">
        <Sparkles className="h-3.5 w-3.5" />
        <span>
          회기 요약 누락{counts.pending > 0 ? ` ${counts.pending}건` : ''}
          {counts.failed > 0 ? ` · 실패 ${counts.failed}건` : ''} —
          AI 맥락 품질이 떨어질 수 있습니다.
        </span>
      </div>
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => void handleRefresh()}
        disabled={busy}
        className="h-7 px-2 text-xs"
      >
        {busy ? '갱신 중…' : '요약 갱신'}
      </Button>
    </div>
  );
}

/**
 * 모델 ready + AI 활성만 빠르게 확인. AiAssistButton의 useAiReadiness와 거의 같지만
 * 다른 파일이라 중복은 감수(import 그래프 단순). 추후 Provider화 시 같이 통합.
 */
function useAiReadinessLite(): boolean {
  const [status, setStatus] = useState<AiStatus | null>(null);
  useEffect(() => {
    let mounted = true;
    void window.api.ai.getStatus().then((s) => {
      if (mounted) setStatus(s);
    });
    const unsubscribe = window.api.ai.onEvent((evt: AiEvent) => {
      if (evt.requestId !== '*') return;
      if (evt.type === 'model-state' || evt.type === 'download-done') {
        setStatus((prev) =>
          prev
            ? {
                ...prev,
                model: {
                  ...prev.model,
                  state: evt.type === 'download-done' ? 'ready' : evt.state,
                },
              }
            : prev,
        );
      }
    });
    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);
  return Boolean(status?.enabled && status.model.state === 'ready');
}
