import { useMemo } from 'react';
import { Check, RotateCcw, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { collapseUnchanged, diffLines } from '@/lib/ai/text-diff';

export type AiDiffMode = 'replace' | 'append';

interface AiDiffViewProps {
  /** 원본 텍스트 (사용자가 폼에 입력해둔 값). */
  original: string;
  /** AI가 생성한 결과. */
  proposed: string;
  /**
   * replace: 줄단위 diff(추가 초록/삭제 취소선) — refine/summarize/qa.
   * append: 새 텍스트만 표시 — continue. 적용 시 호출자가 original 뒤에 이어 붙임.
   */
  mode: AiDiffMode;
  /** 적용. 호출자가 폼의 updateField를 호출. */
  onApply: () => void;
  /** 같은 task로 다시 생성. */
  onRegenerate: () => void;
  /** 닫기 / 취소. */
  onCancel: () => void;
  className?: string;
}

/**
 * AI 결과 검토 뷰. 사용자가 명시적으로 "적용" 누를 때까지 폼은 변경되지 않는다 —
 * 조용한 덮어쓰기 금지(원본 플랜 §7-3 + base-system 가드레일).
 */
export function AiDiffView({
  original,
  proposed,
  mode,
  onApply,
  onRegenerate,
  onCancel,
  className,
}: AiDiffViewProps) {
  const blocks = useMemo(() => {
    if (mode === 'append') return null;
    return collapseUnchanged(diffLines(original, proposed));
  }, [mode, original, proposed]);

  return (
    <div
      className={cn(
        'space-y-3 rounded-lg border border-border bg-background p-3',
        className,
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs font-medium text-muted-foreground">
          {mode === 'replace' ? '제안 결과 — 차이 검토' : '이어쓰기 결과'}
        </p>
        <div className="flex items-center gap-1.5">
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={onRegenerate}
            className="h-8 px-2 text-xs"
          >
            <RotateCcw className="mr-1 h-3.5 w-3.5" />
            다시 생성
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={onCancel}
            className="h-8 px-2 text-xs"
          >
            <X className="mr-1 h-3.5 w-3.5" />
            취소
          </Button>
          <Button
            type="button"
            size="sm"
            onClick={onApply}
            disabled={!proposed.trim()}
            className="h-8 px-3 text-xs"
          >
            <Check className="mr-1 h-3.5 w-3.5" />
            적용
          </Button>
        </div>
      </div>

      {mode === 'append' ? (
        <div className="rounded-md border border-emerald-500/30 bg-emerald-500/5 p-3">
          <p className="text-[10px] uppercase tracking-wide text-emerald-700 dark:text-emerald-400 mb-1.5">
            추가될 내용 (기존 본문 뒤에 이어 붙음)
          </p>
          <pre className="whitespace-pre-wrap break-words font-sans text-sm leading-relaxed text-foreground">
            {proposed.trim() || '(빈 결과)'}
          </pre>
        </div>
      ) : (
        <div className="max-h-72 overflow-y-auto rounded-md border border-border bg-muted/20 p-2 font-mono text-[13px] leading-relaxed">
          {blocks && blocks.length > 0 ? (
            blocks.map((b, idx) => {
              if (b.kind === 'unchanged') {
                return (
                  <pre
                    key={idx}
                    className="whitespace-pre-wrap break-words font-sans text-foreground/80"
                  >
                    {b.text}
                  </pre>
                );
              }
              if (b.kind === 'added') {
                return (
                  <pre
                    key={idx}
                    className="whitespace-pre-wrap break-words bg-emerald-500/10 px-1.5 py-0.5 font-sans text-emerald-700 dark:text-emerald-300"
                  >
                    + {b.text}
                  </pre>
                );
              }
              return (
                <pre
                  key={idx}
                  className="whitespace-pre-wrap break-words bg-rose-500/10 px-1.5 py-0.5 font-sans text-rose-700 line-through decoration-rose-500/60 dark:text-rose-300"
                >
                  - {b.text}
                </pre>
              );
            })
          ) : (
            <p className="text-xs text-muted-foreground">변경 사항이 없습니다.</p>
          )}
        </div>
      )}
    </div>
  );
}
