import { useCallback, useMemo, useState } from 'react';
import { Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { useAiStream } from '@/hooks/use-ai-stream';
import { AiStreamOutput } from './ai-stream-output';
import { AiDiffView, type AiDiffMode } from './ai-diff-view';
import { AI_ACTIONS } from '@/lib/ai/ai-actions';
import { sanitizeAiOutput } from '@/lib/ai/sanitize-output';
import type { AiContextRequest, UserFacingAiTask } from '@/types/ai';

interface AiFieldPopoverProps {
  /** 인라인 버튼에 마우스를 올렸을 때 보이는 툴팁/label 텍스트. 예: "회기 내용 다듬기" */
  buttonLabel: string;
  /** 사용 가능한 task 목록. 필드 의미에 맞게 호출자가 제한. */
  availableTasks: UserFacingAiTask[];
  /** 폼의 현재 값. refine/summarize/continue의 userInput으로 전달된다. */
  originalText: string;
  /** 메인이 DB 복호화 후 맥락을 만들기 위한 디스크립터. */
  contextRequest: AiContextRequest;
  /**
   * 사용자가 "적용"을 눌렀을 때 호출. mode='replace'면 폼 필드를 result로 교체,
   * mode='append'면 폼 필드 = `originalText + '\n' + result`로 호출자가 합치는 책임.
   */
  onApply: (result: string, mode: AiDiffMode) => void;
  /** 필드 의미/형식 힌트 — user 메시지 상단에 [지침]으로 박힘. */
  fieldHint?: string;
  /** 모델 미준비/AI 비활성 시 버튼 자체를 숨길지 결정 — 호출자가 미리 확인했으면 false. */
  disabled?: boolean;
  className?: string;
}

/** task → diff 모드. continue만 append, 나머지는 replace. */
function modeForTask(task: UserFacingAiTask): AiDiffMode {
  return task === 'continue' ? 'append' : 'replace';
}

/** task → user 메시지 본문. continue/refine는 originalText를 보냄, summarize는 selectionText, qa는 사용자 입력 X. */
function buildPayload(task: UserFacingAiTask, originalText: string) {
  switch (task) {
    case 'refine':
    case 'continue':
      return { userInput: originalText };
    case 'summarize':
      return { selectionText: originalText };
    case 'qa':
      return { userInput: originalText };
    case 'conceptualize':
    case 'report':
      return {};
  }
}

/**
 * 인라인 AI 도우미 팝오버.
 *
 * 사용 흐름:
 * 1. 사용자가 인접한 ghost 버튼 클릭 → 팝오버 열림.
 * 2. task 선택 → 즉시 generate. 토큰 스트리밍 표시.
 * 3. 완료 → diff/append 검토 → 적용/다시 생성/취소.
 * 4. 적용 시 onApply 호출. 호출자가 폼 필드 갱신.
 *
 * 팝오버를 닫을 때 진행 중이면 cancel + reset.
 */
export function AiFieldPopover({
  buttonLabel,
  availableTasks,
  originalText,
  contextRequest,
  onApply,
  fieldHint,
  disabled,
  className,
}: AiFieldPopoverProps) {
  const [open, setOpen] = useState(false);
  const [activeTask, setActiveTask] = useState<UserFacingAiTask | null>(null);
  const { text, status, error, finishReason, usage, start, cancel, reset } = useAiStream();

  const tasks = useMemo(
    () => availableTasks.filter((t) => AI_ACTIONS[t]),
    [availableTasks],
  );

  // 스트리밍은 raw, 완료 후엔 sanitize된 텍스트를 사용. 검토·적용 모두 동일 텍스트로 일관.
  // task를 넘겨 refine/summarize에 구조적 강한 정제 규칙을 적용한다.
  const cleanedText = useMemo(() => {
    if (status !== 'done') return text;
    return sanitizeAiOutput(text, activeTask ?? undefined, originalText);
  }, [status, text, activeTask, originalText]);

  const startTask = useCallback(
    async (task: UserFacingAiTask) => {
      setActiveTask(task);
      const payload = buildPayload(task, originalText);
      await start({ task, contextRequest, fieldHint, ...payload });
    },
    [originalText, contextRequest, fieldHint, start],
  );

  const handleApply = useCallback(() => {
    if (!activeTask || !cleanedText.trim()) return;
    onApply(cleanedText.trim(), modeForTask(activeTask));
    setOpen(false);
    reset();
    setActiveTask(null);
  }, [activeTask, cleanedText, onApply, reset]);

  const handleRegenerate = useCallback(() => {
    if (!activeTask) return;
    reset();
    void startTask(activeTask);
  }, [activeTask, reset, startTask]);

  const handleClose = useCallback(() => {
    if (status === 'streaming') void cancel();
    reset();
    setActiveTask(null);
    setOpen(false);
  }, [status, cancel, reset]);

  const handleOpenChange = useCallback(
    (next: boolean) => {
      if (!next) {
        // 팝오버가 닫힐 때 진행 중이면 정리.
        if (status === 'streaming') void cancel();
        reset();
        setActiveTask(null);
      }
      setOpen(next);
    },
    [status, cancel, reset],
  );

  const showActions = activeTask === null;
  const showDiff = activeTask !== null && status === 'done' && !!text;

  return (
    <Popover open={open} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={disabled}
          aria-label={buttonLabel}
          title={buttonLabel}
          className={cn(
            'h-7 gap-1 px-2 text-xs text-muted-foreground hover:text-foreground',
            className,
          )}
        >
          <Sparkles className="h-3.5 w-3.5" />
          AI 도우미
        </Button>
      </PopoverTrigger>

      <PopoverContent
        align="end"
        sideOffset={6}
        className="w-[26rem] max-w-[90vw] space-y-3"
      >
        {showActions ? (
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground">
              {buttonLabel}
            </p>
            <div className="space-y-1.5">
              {tasks.map((task) => {
                const meta = AI_ACTIONS[task];
                return (
                  <button
                    key={task}
                    type="button"
                    onClick={() => void startTask(task)}
                    className="group flex w-full items-start gap-3 rounded-md border border-border bg-background px-3 py-2 text-left text-sm transition hover:border-primary/40 hover:bg-primary/5"
                  >
                    <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-primary/70 group-hover:text-primary" />
                    <div className="min-w-0">
                      <p className="font-medium text-foreground">{meta.label}</p>
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {meta.description}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
            <p className="text-[10px] text-muted-foreground/80">
              생성된 결과는 검토 후 직접 적용을 눌러야 폼에 반영됩니다.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs font-medium text-muted-foreground">
                {activeTask && AI_ACTIONS[activeTask]?.label} 실행 중
              </p>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleClose}
                className="h-7 px-2 text-xs"
              >
                닫기
              </Button>
            </div>

            <AiStreamOutput
              text={status === 'done' ? cleanedText : text}
              status={status}
              error={error}
              finishReason={finishReason}
              usage={usage}
              onCancel={() => void cancel()}
              emptyHint="응답을 기다리는 중…"
            />

            {showDiff && activeTask && (
              <AiDiffView
                original={originalText}
                proposed={cleanedText}
                mode={modeForTask(activeTask)}
                onApply={handleApply}
                onRegenerate={handleRegenerate}
                onCancel={handleClose}
              />
            )}
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}
