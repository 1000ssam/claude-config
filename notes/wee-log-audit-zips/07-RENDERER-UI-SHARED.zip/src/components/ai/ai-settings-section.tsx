import { useState } from 'react';
import { Send, Sparkles } from 'lucide-react';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useAiModelStatus } from '@/hooks/use-ai-model-status';
import { useAiStream } from '@/hooks/use-ai-stream';
import { AiModelDownloadCard } from './ai-model-download-card';
import { AiStreamOutput } from './ai-stream-output';
import { AI_ACTIONS, AI_TASK_ORDER } from '@/lib/ai/ai-actions';
import type { AiTask } from '@/types/ai';

/**
 * 설정 페이지의 AI 섹션.
 *
 * - 상단: 모델 다운로드/상태 카드.
 * - 하단: 원시 프롬프트 박스. task 선택 + 입력 → 생성. Phase 4에서 인라인 UI로
 *   대체될 때까지 디버깅·검증용으로 유지.
 *
 * 모델이 ready+providerReady가 아닐 때는 입력 박스를 비활성화하고 안내한다.
 */
export function AiSettingsSection() {
  const { addToast } = useToast();
  const modelStatus = useAiModelStatus();
  const stream = useAiStream();

  const [task, setTask] = useState<AiTask>('qa');
  const [userInput, setUserInput] = useState('');

  const ready =
    modelStatus.status?.model.state === 'ready' &&
    modelStatus.status?.providerReady === true;

  const canSubmit =
    ready && userInput.trim().length > 0 && stream.status !== 'streaming';

  async function handleDownload() {
    const res = await modelStatus.download();
    if ('error' in res) {
      addToast({
        title: '다운로드 시작 실패',
        description: res.error,
        variant: 'destructive',
      });
    } else if (!res.started) {
      addToast({
        title: '이미 다운로드가 진행 중입니다.',
        variant: 'default',
      });
    }
  }

  async function handleCancelDownload() {
    const res = await modelStatus.cancelDownload();
    if ('error' in res) {
      addToast({
        title: '다운로드 취소 실패',
        description: res.error,
        variant: 'destructive',
      });
    }
  }

  async function handleWarmUp() {
    const res = await modelStatus.warmUp();
    if ('error' in res) {
      addToast({
        title: '모델 로드 실패',
        description: res.error,
        variant: 'destructive',
      });
    } else {
      addToast({
        title: '모델이 메모리에 로드되었습니다.',
        variant: 'success',
      });
    }
  }

  async function handleGenerate() {
    if (!canSubmit) return;
    const res = await stream.start({
      task,
      userInput: userInput.trim(),
    });
    if ('error' in res) {
      addToast({
        title: '생성 시작 실패',
        description: res.error.message,
        variant: 'destructive',
      });
    }
  }

  function handleReset() {
    stream.reset();
    setUserInput('');
  }

  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          AI 도우미 (시험 운영)
        </CardTitle>
        <CardDescription>
          상담 기록 작성 시 문장 다듬기·요약·이어쓰기 등을 도와줍니다. 모든 추론은
          이 PC에서 수행되며, 데이터는 외부로 전송되지 않습니다.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        <AiModelDownloadCard
          status={modelStatus.status}
          loading={modelStatus.loading}
          downloadProgress={modelStatus.downloadProgress}
          downloadError={modelStatus.downloadError}
          onDownload={handleDownload}
          onCancel={handleCancelDownload}
          onWarmUp={handleWarmUp}
        />

        <div className="border-t border-border" />

        <div className="space-y-3">
          <div>
            <p className="text-sm font-medium">원시 프롬프트 박스 (검증용)</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Phase 2에서 end-to-end 동작을 확인하기 위한 임시 입력 박스입니다.
              실제 인라인 UI는 사례 기록 화면에 곧 추가됩니다.
            </p>
          </div>

          <div className="grid gap-3 md:grid-cols-[160px_1fr] md:items-start">
            <div className="space-y-1.5">
              <Label htmlFor="ai-task" className="text-xs">
                작업 종류
              </Label>
              <Select
                value={task}
                onValueChange={(v) => setTask(v as AiTask)}
                disabled={stream.status === 'streaming'}
              >
                <SelectTrigger id="ai-task">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {AI_TASK_ORDER.map((t) => (
                    <SelectItem key={t} value={t}>
                      {AI_ACTIONS[t].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-[11px] text-muted-foreground leading-snug">
                {AI_ACTIONS[task].description}
              </p>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="ai-input" className="text-xs">
                입력
              </Label>
              <Textarea
                id="ai-input"
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                placeholder={
                  ready
                    ? '예: 상담 기록 초안 또는 질문을 입력하세요.'
                    : '모델이 준비되면 사용할 수 있습니다.'
                }
                rows={5}
                disabled={!ready || stream.status === 'streaming'}
                onKeyDown={(e) => {
                  // Ctrl/Cmd+Enter로 전송
                  if (
                    (e.ctrlKey || e.metaKey) &&
                    e.key === 'Enter' &&
                    canSubmit
                  ) {
                    e.preventDefault();
                    void handleGenerate();
                  }
                }}
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              onClick={handleGenerate}
              disabled={!canSubmit}
              variant="default"
              size="sm"
            >
              <Send className="mr-2 h-4 w-4" />
              {stream.status === 'streaming' ? '생성 중…' : '생성'}
            </Button>
            <Button
              onClick={handleReset}
              variant="ghost"
              size="sm"
              disabled={stream.status === 'idle' && !userInput}
            >
              초기화
            </Button>
            {!ready && modelStatus.status?.model.state === 'ready' && (
              <p className="text-xs text-muted-foreground self-center">
                모델 로드(워밍업)가 필요합니다.
              </p>
            )}
          </div>

          <AiStreamOutput
            text={stream.text}
            status={stream.status}
            error={stream.error}
            finishReason={stream.finishReason}
            usage={stream.usage}
            onCancel={stream.cancel}
            emptyHint={
              ready
                ? '응답이 여기에 표시됩니다. (Ctrl/Cmd+Enter로 전송)'
                : '모델 준비 후 사용할 수 있습니다.'
            }
          />
        </div>
      </CardContent>
    </Card>
  );
}
