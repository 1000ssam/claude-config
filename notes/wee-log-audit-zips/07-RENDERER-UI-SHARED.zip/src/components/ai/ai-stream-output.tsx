import { CircleStop, Sparkles, TriangleAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import type { AiStreamError, AiStreamStatus } from '@/hooks/use-ai-stream';
import type { AiFinishReason, AiUsage } from '@/types/ai';

interface AiStreamOutputProps {
  text: string;
  status: AiStreamStatus;
  error: AiStreamError | null;
  finishReason: AiFinishReason | null;
  usage: AiUsage | null;
  onCancel?: () => void;
  /** 추가 클래스 */
  className?: string;
  /** 빈 상태 안내 문구 */
  emptyHint?: string;
}

/**
 * AI 스트리밍 텍스트 렌더러 + 멈춤 버튼.
 *
 * - 토큰은 사전 줄바꿈을 유지하기 위해 `whitespace-pre-wrap`로 표시.
 * - 스트리밍 중에는 우측 상단에 멈춤 버튼, 종료 후에는 finishReason 라벨.
 * - 부분 결과(취소)도 그대로 노출 — 사용자가 저장/폐기 결정 가능.
 */
export function AiStreamOutput({
  text,
  status,
  error,
  finishReason,
  usage,
  onCancel,
  className,
  emptyHint = '응답이 여기에 표시됩니다.',
}: AiStreamOutputProps) {
  const isStreaming = status === 'streaming';
  const isDone = status === 'done';
  const isError = status === 'error';

  return (
    <div
      className={cn(
        'relative rounded-lg border border-border bg-muted/30 p-4',
        className,
      )}
    >
      <div className="flex items-start justify-between gap-3 mb-2">
        <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
          <Sparkles className="h-3.5 w-3.5" />
          <span>AI 응답</span>
          {isStreaming && (
            <span className="inline-flex items-center gap-1 text-primary">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-60" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-primary" />
              </span>
              <span>스트리밍 중…</span>
            </span>
          )}
          {isDone && finishReason === 'aborted' && (
            <span className="text-amber-600 dark:text-amber-400">
              취소됨 (부분 결과)
            </span>
          )}
          {isDone && finishReason === 'length' && (
            <span className="text-amber-600 dark:text-amber-400">
              길이 한계로 종료
            </span>
          )}
          {isDone && finishReason === 'stop' && (
            <span className="text-emerald-600 dark:text-emerald-400">완료</span>
          )}
        </div>

        {isStreaming && onCancel && (
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={onCancel}
            className="h-8 border-destructive/50 bg-destructive/5 px-3 text-destructive shadow-sm hover:bg-destructive/15 hover:text-destructive hover:border-destructive/70"
          >
            <CircleStop className="mr-1.5 h-4 w-4" />
            멈춤
          </Button>
        )}
      </div>

      {isError && error && (
        <div className="flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
          <TriangleAlert className="h-4 w-4 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <p className="font-medium">생성 실패</p>
            <p className="text-xs opacity-80">{error.message}</p>
            <p className="text-[10px] opacity-60">code: {error.code}</p>
          </div>
        </div>
      )}

      {text ? (
        <div className="whitespace-pre-wrap text-sm leading-relaxed text-foreground">
          {text}
          {isStreaming && (
            <span
              aria-hidden
              className="ml-0.5 inline-block h-4 w-[2px] translate-y-0.5 animate-pulse bg-primary align-baseline"
            />
          )}
        </div>
      ) : !isError ? (
        <p className="text-sm text-muted-foreground/70">{emptyHint}</p>
      ) : null}

      {isDone && usage && (
        <p className="mt-3 text-[11px] text-muted-foreground/80">
          토큰 사용: 입력 {usage.promptTokens.toLocaleString()} · 출력{' '}
          {usage.completionTokens.toLocaleString()}
        </p>
      )}
    </div>
  );
}
