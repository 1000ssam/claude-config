import {
  CheckCircle2,
  CloudDownload,
  HardDriveDownload,
  Loader2,
  RotateCw,
  TriangleAlert,
  X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import type { AiStatus } from '@/types/ai';
import type { AiDownloadProgress } from '@/hooks/use-ai-model-status';

interface AiModelDownloadCardProps {
  status: AiStatus | null;
  loading: boolean;
  downloadProgress: AiDownloadProgress | null;
  downloadError: string | null;
  onDownload: () => void;
  onCancel: () => void;
  onWarmUp: () => void;
  /** warm-up이 잠금 게이트 안에 있어서 LockScreen 진입 전엔 호출 못함을 알림 */
  warmUpDisabled?: boolean;
}

function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 MB';
  const mb = bytes / (1024 * 1024);
  if (mb < 1024) return `${mb.toFixed(1)} MB`;
  return `${(mb / 1024).toFixed(2)} GB`;
}

/**
 * 모델 다운로드 카드. 5가지 분기:
 *   1) loading — 초기 status fetch 중
 *   2) absent — 다운로드 시작 가능
 *   3) downloading — 진행률 표시 + 취소
 *   4) ready — 완료, 워밍업 가능
 *   5) error — 오류 표시 + 재시도
 */
export function AiModelDownloadCard({
  status,
  loading,
  downloadProgress,
  downloadError,
  onDownload,
  onCancel,
  onWarmUp,
  warmUpDisabled = false,
}: AiModelDownloadCardProps) {
  if (loading && !status) {
    return (
      <div className="rounded-lg border border-border bg-muted/30 p-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          모델 상태 확인 중…
        </div>
      </div>
    );
  }

  if (!status) {
    // status가 null이고 loading=false면 IPC 자체 실패
    return (
      <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
        AI 상태를 불러올 수 없습니다.
      </div>
    );
  }

  const modelState = status.model.state;
  const isLocal = status.backend === 'local';

  // 진행률 — model.downloadedBytes/sizeBytes도 활용 가능하지만 실시간성은 이벤트 쪽이 우선.
  const percent = downloadProgress?.percent ?? 0;
  const downloaded = downloadProgress?.downloaded ?? status.model.downloadedBytes ?? 0;
  const total = downloadProgress?.total ?? status.model.sizeBytes ?? 0;

  return (
    <div className="rounded-lg border border-border bg-card p-4 space-y-3">
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-0.5">
          <p className="text-sm font-medium text-foreground">로컬 모델</p>
          <p className="text-xs text-muted-foreground">
            {isLocal
              ? '온디바이스 추론 — 데이터가 PC 밖으로 나가지 않습니다.'
              : '원격 백엔드를 사용 중입니다.'}
          </p>
        </div>
        <ModelStateBadge state={modelState} ready={status.providerReady} />
      </div>

      {/* absent */}
      {modelState === 'absent' && (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground">
            AI 기능을 사용하려면 약 1.4GB의 모델 파일을 한 번만 내려받아야 합니다.
            네트워크에 따라 5~20분 정도 걸립니다.
          </p>
          <Button onClick={onDownload} variant="default" size="sm">
            <CloudDownload className="mr-2 h-4 w-4" />
            모델 다운로드
          </Button>
        </div>
      )}

      {/* downloading */}
      {modelState === 'downloading' && (
        <div className="space-y-2">
          <ProgressBar percent={percent} />
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>
              {formatBytes(downloaded)}
              {total > 0 && <> / {formatBytes(total)}</>}
            </span>
            <span>{percent.toFixed(1)}%</span>
          </div>
          <Button onClick={onCancel} variant="outline" size="sm">
            <X className="mr-2 h-4 w-4" />
            다운로드 취소
          </Button>
        </div>
      )}

      {/* ready */}
      {modelState === 'ready' && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <HardDriveDownload className="h-3.5 w-3.5" />
            <span>
              {status.model.path ? '저장됨 · ' : ''}
              {total > 0 ? formatBytes(total) : '크기 확인 중'}
            </span>
          </div>
          {status.capabilities && (
            <div className="text-[11px] text-muted-foreground/80">
              컨텍스트 {status.capabilities.contextWindow.toLocaleString()} 토큰
              · 최대 출력 {status.capabilities.maxOutputTokens.toLocaleString()}{' '}
              토큰
            </div>
          )}
          {!status.providerReady && (
            <Button
              onClick={onWarmUp}
              variant="outline"
              size="sm"
              disabled={warmUpDisabled}
              title={
                warmUpDisabled
                  ? '잠금 해제 후 사용할 수 있습니다.'
                  : undefined
              }
            >
              <RotateCw className="mr-2 h-4 w-4" />
              모델 로드 (워밍업)
            </Button>
          )}
        </div>
      )}

      {/* error */}
      {modelState === 'error' && (
        <div className="space-y-2">
          <div className="flex items-start gap-2 text-xs text-destructive">
            <TriangleAlert className="h-4 w-4 shrink-0 mt-0.5" />
            <span>{downloadError || '모델 준비 중 오류가 발생했습니다.'}</span>
          </div>
          <Button onClick={onDownload} variant="outline" size="sm">
            <RotateCw className="mr-2 h-4 w-4" />
            다시 시도
          </Button>
        </div>
      )}
    </div>
  );
}

function ModelStateBadge({
  state,
  ready,
}: {
  state: AiStatus['model']['state'];
  ready: boolean;
}) {
  const map: Record<
    AiStatus['model']['state'],
    { label: string; cls: string; icon: typeof CheckCircle2 }
  > = {
    absent: {
      label: '미설치',
      cls: 'bg-muted text-muted-foreground',
      icon: CloudDownload,
    },
    downloading: {
      label: '다운로드 중',
      cls: 'bg-primary/10 text-primary',
      icon: Loader2,
    },
    ready: {
      label: ready ? '준비 완료' : '로드 대기',
      cls: ready
        ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400'
        : 'bg-amber-500/15 text-amber-700 dark:text-amber-400',
      icon: CheckCircle2,
    },
    error: {
      label: '오류',
      cls: 'bg-destructive/15 text-destructive',
      icon: TriangleAlert,
    },
  };
  const { label, cls, icon: Icon } = map[state];
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium',
        cls,
      )}
    >
      <Icon
        className={cn(
          'h-3 w-3',
          state === 'downloading' && 'animate-spin',
        )}
      />
      {label}
    </span>
  );
}

function ProgressBar({ percent }: { percent: number }) {
  const clamped = Math.max(0, Math.min(100, percent));
  return (
    <div
      className="h-2 w-full overflow-hidden rounded-full bg-muted"
      role="progressbar"
      aria-valuenow={clamped}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className="h-full bg-primary transition-[width] duration-150"
        style={{ width: `${clamped}%` }}
      />
    </div>
  );
}
