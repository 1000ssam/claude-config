import { useEffect, useMemo, useState } from 'react';
import { AiFieldPopover } from './ai-field-popover';
import type { AiDiffMode } from './ai-diff-view';
import type { AiContextRequest, AiStatus, UserFacingAiTask } from '@/types/ai';
import type { AiEvent } from '@/types/ai';

interface AiAssistButtonProps {
  /** 인라인 버튼 라벨 + 팝오버 헤더. 예: "회기 내용 다듬기" */
  buttonLabel: string;
  /** 이 필드에서 가능한 task 목록. */
  availableTasks: UserFacingAiTask[];
  /** 현재 폼 필드 값. */
  originalText: string;
  /** 메인 측이 DB 복호화해 맥락을 만들기 위한 디스크립터. */
  contextRequest: AiContextRequest;
  /**
   * 사용자가 "적용"을 눌렀을 때 호출. replace면 텍스트를 폼 필드로 교체,
   * append면 호출자가 originalText + '\n' + result로 합쳐서 폼에 반영.
   */
  onApply: (result: string, mode: AiDiffMode) => void;
  /**
   * 필드 의미/형식 힌트. 모델이 이 필드의 길이·형식을 인지하도록 user 메시지 상단에
   * [지침]으로 박힘. 예: "회기 제목 — 명사구 한 줄, 본문처럼 늘이지 말 것".
   * 생략 시 generic 다듬기.
   */
  fieldHint?: string;
  className?: string;
}

/**
 * 인라인 AI 도우미 진입점.
 *
 * - 모델이 ready + AI 활성이 아니면 자체적으로 렌더하지 않는다 (호출자 무관).
 * - 실제 UI는 `AiFieldPopover`에 위임.
 *
 * 페이지 단위 단일 구독 vs 컴포넌트별 구독: Phase 4 첫 버전은 컴포넌트별. 인라인 버튼이
 * 폼 1개에 4~6개 마운트되므로 측정 후 Provider화 검토(implementation-notes 미결).
 */
export function AiAssistButton(props: AiAssistButtonProps) {
  const ready = useAiReadiness();
  if (!ready) return null;
  // fieldHint를 포함해 모든 props를 그대로 위임.
  return <AiFieldPopover {...props} />;
}

/**
 * 모델/AI 활성 상태를 추적하는 경량 훅.
 * - useAiModelStatus는 다운로드 진행률·warmUp 같은 풀세트를 제공하지만, 인라인 버튼은
 *   "보일까/말까" 한 비트만 필요. 마운트마다 그 풀세트 훅을 호출하면 IPC 호출(`getStatus`)이
 *   N배 발생.
 * - 여기서는 한 번 getStatus → model-state 이벤트만 구독.
 */
function useAiReadiness(): boolean {
  const [status, setStatus] = useState<AiStatus | null>(null);

  useEffect(() => {
    let mounted = true;
    void window.api.ai.getStatus().then((s) => {
      if (mounted) setStatus(s);
    });
    const unsubscribe = window.api.ai.onEvent((evt: AiEvent) => {
      if (evt.requestId !== '*') return;
      if (evt.type === 'model-state') {
        setStatus((prev) => (prev ? { ...prev, model: { ...prev.model, state: evt.state } } : prev));
      } else if (evt.type === 'download-done') {
        setStatus((prev) =>
          prev ? { ...prev, model: { ...prev.model, state: 'ready' } } : prev,
        );
      }
    });
    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);

  return useMemo(() => {
    if (!status) return false;
    return status.enabled && status.model.state === 'ready';
  }, [status]);
}
