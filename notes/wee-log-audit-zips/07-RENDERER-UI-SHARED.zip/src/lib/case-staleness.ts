import type { CaseWithSessionCount } from '@/types/case';

/**
 * '장기 미접촉' 사례 판별.
 *
 * 진행 중(active)인데 마지막 상담이 N일 넘게 없는 사례 = 방치 위험.
 * 홈 대시보드 경고 카드와 사례 목록 `?view=stale` 필터가 공유한다.
 */

/** 기준일(일). active인데 마지막 상담이 이만큼 지났으면 미접촉으로 본다. */
export const STALE_CASE_DAYS = 14;

const DAY_MS = 24 * 60 * 60 * 1000;

/**
 * DB 날짜 문자열을 epoch ms로. 파싱 실패 시 null.
 * - session_date: 'YYYY-MM-DD'
 * - created_at:   'YYYY-MM-DD HH:mm:ss' (datetime('now','localtime'))
 */
function toTime(dateStr: string | null | undefined): number | null {
  if (!dateStr) return null;
  const iso = dateStr.length === 10 ? `${dateStr}T00:00:00` : dateStr.replace(' ', 'T');
  const t = Date.parse(iso);
  return Number.isNaN(t) ? null : t;
}

/**
 * 장기 미접촉인가.
 * - status === 'active'
 * - 등록도 N일 지난 사례만 (어제 연 새 사례가 '미접촉'으로 잡히지 않도록)
 * - 마지막 상담일이 N일 경과했거나, 상담 이력이 0회
 *
 * @param now 기준 시각(epoch ms). 호출부에서 Date.now() 주입(테스트 용이).
 */
export function isStaleCase(
  c: Pick<CaseWithSessionCount, 'status' | 'created_at' | 'last_session_date'>,
  now: number,
  days: number = STALE_CASE_DAYS,
): boolean {
  if (c.status !== 'active') return false;
  const cutoff = now - days * DAY_MS;

  const created = toTime(c.created_at);
  if (created !== null && created > cutoff) return false; // 등록 N일 미만 → 제외

  const last = toTime(c.last_session_date);
  if (last === null) return true; // 상담 0회 → 미접촉
  return last <= cutoff;          // 마지막 상담 N일 경과
}

/** 목록에서 장기 미접촉 건수. */
export function countStaleCases(
  cases: Pick<CaseWithSessionCount, 'status' | 'created_at' | 'last_session_date'>[],
  now: number,
  days: number = STALE_CASE_DAYS,
): number {
  return cases.reduce((n, c) => n + (isStaleCase(c, now, days) ? 1 : 0), 0);
}

/**
 * 미접촉 정렬 키 — 작을수록 더 방치됨(맨 위).
 * 상담 0회(날짜 null)는 최우선(-Infinity), 그 외는 마지막 상담일 오름차순.
 */
export function staleSortKey(
  c: Pick<CaseWithSessionCount, 'last_session_date'>,
): number {
  const last = toTime(c.last_session_date);
  return last === null ? -Infinity : last;
}
