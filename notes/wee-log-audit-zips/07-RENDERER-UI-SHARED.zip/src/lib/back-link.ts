import { useSearchParams } from 'react-router-dom';

export type BackSourceType =
  | 'case'
  | 'session'
  | 'student'
  | 'cases-list'
  | 'students-list'
  | 'sessions-list';

interface BackContextInput {
  caseId?: number | string;
  sessionId?: number | string;
  studentId?: number | string;
  tab?: string;
}

interface BackLink {
  label: string;
  href: string;
}

const LIST_HREF: Record<Extract<BackSourceType, `${string}-list`>, string> = {
  'cases-list': '/cases',
  'students-list': '/students',
  'sessions-list': '/sessions',
};

const LIST_LABEL: Record<Extract<BackSourceType, `${string}-list`>, string> = {
  'cases-list': '사례 목록으로',
  'students-list': '학생 목록',
  'sessions-list': '세션 목록으로',
};

export function withBackContext(type: BackSourceType, ctx: BackContextInput = {}): URLSearchParams {
  const params = new URLSearchParams();
  params.set('from', type);
  if (ctx.caseId != null) params.set('fromCaseId', String(ctx.caseId));
  if (ctx.sessionId != null) params.set('fromSessionId', String(ctx.sessionId));
  if (ctx.studentId != null) params.set('fromStudentId', String(ctx.studentId));
  if (ctx.tab) params.set('fromTab', ctx.tab);
  return params;
}

export function appendBackContext(href: string, type: BackSourceType, ctx: BackContextInput = {}): string {
  const back = withBackContext(type, ctx).toString();
  if (!back) return href;
  return href.includes('?') ? `${href}&${back}` : `${href}?${back}`;
}

function resolveBackLink(searchParams: URLSearchParams): BackLink | null {
  const type = searchParams.get('from') as BackSourceType | null;
  if (!type) return null;

  const caseId = searchParams.get('fromCaseId');
  const sessionId = searchParams.get('fromSessionId');
  const studentId = searchParams.get('fromStudentId');
  const tab = searchParams.get('fromTab');

  switch (type) {
    case 'case':
      if (!caseId) return null;
      return {
        label: '사례로 돌아가기',
        href: `/cases/${caseId}${tab ? `?tab=${tab}` : ''}`,
      };
    case 'session':
      if (!caseId || !sessionId) return null;
      return {
        label: '상담 기록으로 돌아가기',
        href: `/cases/${caseId}/sessions/${sessionId}`,
      };
    case 'student':
      if (!studentId) return null;
      return {
        label: '학생 정보로 돌아가기',
        href: `/students/${studentId}`,
      };
    case 'cases-list':
    case 'students-list':
    case 'sessions-list':
      return { label: LIST_LABEL[type], href: LIST_HREF[type] };
    default:
      return null;
  }
}

export function useBackLink(fallback: BackLink): BackLink {
  const [searchParams] = useSearchParams();
  return resolveBackLink(searchParams) ?? fallback;
}
