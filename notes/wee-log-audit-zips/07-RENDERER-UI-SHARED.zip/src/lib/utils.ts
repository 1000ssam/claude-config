import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatPhoneNumber(value: string): string {
  const digits = value.replace(/\D/g, '').slice(0, 11);
  if (digits.length <= 3) return digits;
  if (digits.length <= 7) return `${digits.slice(0, 3)}-${digits.slice(3)}`;
  return `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7)}`;
}

export function formatDuration(hours: number): string {
  const h = Math.floor(hours);
  const m = Math.round((hours - h) * 60);
  if (h === 0) return `${m}분`;
  if (m === 0) return `${h}시간`;
  return `${h}시간 ${m}분`;
}

/** 전화번호 유효성 검사. 빈 문자열은 유효(선택 입력). */
export function validatePhoneNumber(value: string): string | null {
  if (!value.trim()) return null; // 선택 입력이므로 빈 값 허용

  const digits = value.replace(/\D/g, '');

  if (digits.length < 8 || digits.length > 11) {
    return '전화번호는 8~11자리여야 합니다.';
  }

  // 유효한 국번 패턴: 010, 011, 016, 017, 018, 019, 02, 031~070 등
  const validPatterns = /^(010|011|016|017|018|019|02|0[3-6]\d|070)/;
  if (!validPatterns.test(digits)) {
    return '올바른 전화번호 형식이 아닙니다.';
  }

  return null;
}
