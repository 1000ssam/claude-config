/**
 * Re-export shim. 정본은 `lib/constants/conceptualization-templates.ts` (메인 프로세스의
 * AI 컨텍스트 빌더가 같은 데이터를 직접 import 하기 위해 lib/ 측에 둠).
 *
 * 기존 `@/lib/constants/conceptualization-templates` import는 변경 없이 동작.
 */

export * from '../../../lib/constants/conceptualization-templates';
