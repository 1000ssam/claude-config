export interface CategoryDetail {
  label: string;
}

export interface CategoryMedium {
  label: string;
  details: CategoryDetail[];
}

export interface CategoryLarge {
  label: string;
  mediums: CategoryMedium[];
}

export const CATEGORY_TREE: CategoryLarge[] = [
  {
    label: '상담',
    mediums: [
      {
        label: '학부모상담',
        details: [
          { label: '학생관련상담' },
          { label: '교사관련상담' },
          { label: '학습' },
          { label: '기타' },
        ],
      },
      {
        label: '개인상담',
        details: [
          { label: '학업' },
          { label: '진로' },
          { label: '성격' },
          { label: '성' },
          { label: '대인관계' },
          { label: '가정 및 가족관계' },
          { label: '일탈 및 비행' },
          { label: '학교폭력 가해' },
          { label: '학교폭력 피해' },
          { label: '자해 및 자살' },
          { label: '정신건강' },
          { label: '컴퓨터 및 스마트폰 과사용' },
          { label: '정보제공' },
          { label: '기타' },
        ],
      },
      {
        label: '집단상담',
        details: [
          { label: '학업' },
          { label: '진로' },
          { label: '학교폭력' },
          { label: '성격/대인관계' },
          { label: '기타' },
        ],
      },
    ],
  },
  {
    label: '검사',
    mediums: [
      {
        label: '심리검사',
        details: [
          { label: '개인심리검사' },
          { label: '집단심리검사' },
          { label: '기타' },
        ],
      },
    ],
  },
  {
    label: '자문',
    mediums: [
      {
        label: '교원자문',
        details: [
          { label: '학교학습' },
          { label: '사회성발달' },
          { label: '정서발달' },
          { label: '진로발달' },
          { label: '행동발달' },
          { label: '기타' },
        ],
      },
    ],
  },
  {
    label: '교육',
    mediums: [
      {
        label: '프로그램운영',
        details: [
          { label: '사회성발달' },
          { label: '인성발달' },
          { label: '학습발달' },
          { label: '진로발달' },
          { label: '행동발달' },
          { label: '기타' },
        ],
      },
      {
        label: '연수',
        details: [
          { label: '교직원 상담연수' },
          { label: '학부모 상담연수' },
        ],
      },
    ],
  },
  {
    label: '연구',
    mediums: [
      {
        label: '자기계발',
        details: [
          { label: '상담연수참석' },
          { label: '상담모범학교방문' },
          { label: '외부강연' },
          { label: '신문/잡지 기고' },
          { label: '기타' },
        ],
      },
      {
        label: '직무계발',
        details: [
          { label: '상담프로그램개발' },
          { label: '상담 연간계획서작성' },
          { label: '기타' },
        ],
      },
    ],
  },
  {
    label: '의뢰',
    mediums: [
      {
        label: '교내외의뢰',
        details: [
          { label: '외부전문가에게 상담의뢰' },
          { label: '교내 교사에게 상담의뢰' },
          { label: '기타' },
        ],
      },
    ],
  },
];

// 평탄화된 소분류 항목 (검색용)
export interface FlatCategory {
  large: string;
  medium: string;
  detail: string;
  display: string;
}

let _flatCache: FlatCategory[] | null = null;

export function getFlatCategories(): FlatCategory[] {
  if (_flatCache) return _flatCache;
  const result: FlatCategory[] = [];
  for (const large of CATEGORY_TREE) {
    for (const medium of large.mediums) {
      for (const detail of medium.details) {
        result.push({
          large: large.label,
          medium: medium.label,
          detail: detail.label,
          display: `${detail.label} (${large.label} > ${medium.label})`,
        });
      }
    }
  }
  _flatCache = result;
  return result;
}

// Helper functions
export function getMediumsByLarge(largeLabel: string): CategoryMedium[] {
  const found = CATEGORY_TREE.find((c) => c.label === largeLabel);
  return found ? found.mediums : [];
}

export function getDetailsByMedium(
  largeLabel: string,
  mediumLabel: string
): CategoryDetail[] {
  const mediums = getMediumsByLarge(largeLabel);
  const found = mediums.find((m) => m.label === mediumLabel);
  return found ? found.details : [];
}
