export interface NeisColumn {
  key: string;
  header: string;
  required: boolean;
  width: number;
}

export const NEIS_COLUMNS: NeisColumn[] = [
  { key: 'counseling_class', header: '상담분류', required: true, width: 12 },
  { key: 'wee_class', header: 'Wee클래스', required: true, width: 12 },
  { key: 'category_large', header: '대분류', required: true, width: 10 },
  { key: 'category_medium', header: '중분류', required: true, width: 15 },
  { key: 'category_detail', header: '상담구분', required: true, width: 22 },
  { key: 'headcount', header: '상담인원', required: true, width: 10 },
  { key: 'academic_year', header: '학년도', required: true, width: 10 },
  { key: 'session_date', header: '상담일자', required: true, width: 14 },
  { key: 'grade', header: '학년', required: false, width: 10 },
  { key: 'gender', header: '성별', required: false, width: 10 },
  { key: 'session_title', header: '상담제목', required: true, width: 30 },
  { key: 'session_content', header: '상담내용', required: true, width: 50 },
  { key: 'session_hour', header: '상담시간(시)', required: true, width: 12 },
  { key: 'session_minute', header: '상담시간(분)', required: true, width: 12 },
  { key: 'counselor_affil', header: '상담사소속', required: true, width: 16 },
  { key: 'medium', header: '상담매체구분', required: true, width: 14 },
];
