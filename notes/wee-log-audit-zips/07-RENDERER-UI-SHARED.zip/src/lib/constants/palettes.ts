/**
 * WEE-STORY 컬러 팔레트 프리셋.
 * HSL 값은 Tailwind/shadcn 형식 (예: "173 82% 36%").
 * 변경 대상: --primary, --ring, --sidebar-primary, --sidebar-ring
 * 차트 색상은 chart-palette.ts에서 primary + 고정 9색으로 자동 구성.
 *
 * ── 배열 순서 원칙 ────────────────────────────────────────────────
 * 1. 메인(기본) 팔레트를 맨 앞에 둔다 (= DEFAULT_PALETTE_ID와 1번 항목 일치).
 * 2. 나머지 유채색은 색상환(hue) 오름차순으로 배열한다 (인접 스와치가 자연스럽게 전이).
 * 3. 무채색(채도≈0)은 컬러군과 분리해 맨 끝에 둔다.
 *
 * 기본(globals.css :root)은 메인 팔레트 색과 동일해야 한다.
 * applyPalette가 메인 팔레트 선택 시 인라인 변수를 제거하고 :root로 복원하기 때문.
 */

export interface Palette {
  id: string;
  name: string;
  /** hex for UI swatch display */
  hex: string;
  /** CSS variable overrides (HSL without hsl() wrapper) */
  vars: Record<string, string>;
}

export const PALETTES: Palette[] = [
  {
    // 메인 — globals.css :root와 동일 (선택 시 인라인 제거 → :root 복원)
    id: 'calm-teal',
    name: 'Calm Teal',
    hex: '#12a594',
    vars: {
      '--primary': '173 82% 36%',
      '--ring': '173 82% 36%',
      '--sidebar-primary': '173 82% 36%',
      '--sidebar-ring': '173 82% 36%',
    },
  },
  {
    id: 'fresh-green',
    name: 'Fresh Green',
    hex: '#46a758',
    vars: {
      '--primary': '131 37% 46%',
      '--ring': '131 37% 46%',
      '--sidebar-primary': '131 37% 46%',
      '--sidebar-ring': '131 37% 46%',
    },
  },
  {
    id: 'sage-teal',
    name: 'Sage Teal',
    hex: '#1F5D5C',
    vars: {
      '--primary': '179 50% 24%',
      '--ring': '179 50% 24%',
      '--sidebar-primary': '179 50% 24%',
      '--sidebar-ring': '179 50% 24%',
    },
  },
  {
    id: 'classic-blue',
    name: 'Classic Blue',
    hex: '#2383e2',
    vars: {
      '--primary': '208 100% 44%',
      '--ring': '208 100% 44%',
      '--sidebar-primary': '208 100% 44%',
      '--sidebar-ring': '208 100% 44%',
    },
  },
  {
    id: 'deep-indigo',
    name: 'Deep Indigo',
    hex: '#3e63dd',
    vars: {
      '--primary': '226 70% 55%',
      '--ring': '226 70% 55%',
      '--sidebar-primary': '226 70% 55%',
      '--sidebar-ring': '226 70% 55%',
    },
  },
  {
    // 무채색 — 맨 끝
    id: 'warm-grey',
    name: 'Warm Grey',
    hex: '#44423F',
    vars: {
      '--primary': '24 5% 26%',
      '--ring': '24 5% 26%',
      '--sidebar-primary': '24 5% 26%',
      '--sidebar-ring': '24 5% 26%',
    },
  },
];

export const DEFAULT_PALETTE_ID = 'calm-teal';

export function getPaletteById(id: string): Palette | undefined {
  return PALETTES.find((p) => p.id === id);
}
