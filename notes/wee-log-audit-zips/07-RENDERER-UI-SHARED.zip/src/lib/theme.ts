import { getPaletteById, DEFAULT_PALETTE_ID } from '@/lib/constants/palettes';
import { invalidateChartColors } from '@/lib/chart-palette';

/**
 * 팔레트 CSS 변수를 :root에 즉시 적용한다.
 * 기본 팔레트(classic-blue)인 경우 인라인 스타일을 제거하여 globals.css 기본값으로 복원한다.
 */
export function applyPalette(paletteId: string): void {
  const root = document.documentElement;
  const palette = getPaletteById(paletteId);

  if (!palette || palette.id === DEFAULT_PALETTE_ID) {
    const varsToRemove = [
      '--primary', '--ring',
      '--sidebar-primary', '--sidebar-ring',
    ];
    for (const v of varsToRemove) {
      root.style.removeProperty(v);
    }
    invalidateChartColors();
    return;
  }

  for (const [prop, value] of Object.entries(palette.vars)) {
    root.style.setProperty(prop, value);
  }
  invalidateChartColors();
}
