/**
 * 학생 이름+학적+성별 표기 통일 유틸리티
 *
 * 모든 컴포넌트에서 학생 정보를 표시할 때 이 모듈의 함수만 사용한다.
 */

export interface StudentIdentity {
  name?: string;
  grade?: string | null;
  class_name?: string | null;
  number?: string | null;
  gender?: string | null;
}

/** 학적 부분만 조합: "1학년 4반 2번" */
function buildEnrollmentParts(s: StudentIdentity): string[] {
  const parts: string[] = [];
  if (s.grade) parts.push(s.grade);
  if (s.class_name) parts.push(`${s.class_name}반`);
  if (s.number) parts.push(`${s.number}번`);
  return parts;
}

/**
 * 풀 표기: "이름 · 1학년 4반 2번 · 여"
 * 카드 헤더, 인쇄 섹션, Badge 등에서 사용
 */
export function formatStudentFull(s: StudentIdentity): string {
  const segments: string[] = [];
  if (s.name) segments.push(s.name);
  const enrollment = buildEnrollmentParts(s).join(' ');
  if (enrollment) segments.push(enrollment);
  if (s.gender) segments.push(s.gender);
  return segments.join(' · ');
}

/**
 * 컴팩트 표기: "이름 (1학년 4반 2번 · 여)"
 * 드롭다운, 칩, 검색 결과에서 사용
 */
export function formatStudentCompact(s: StudentIdentity): string {
  const name = s.name || '';
  const details: string[] = [];
  const enrollment = buildEnrollmentParts(s).join(' ');
  if (enrollment) details.push(enrollment);
  if (s.gender) details.push(s.gender);
  if (details.length === 0) return name;
  return `${name} (${details.join(' · ')})`;
}

/**
 * 학적만: "1학년 4반 2번"
 * null 입력 시 '학적 정보 없음' 반환
 * 학년도 헤더, 아코디언 등에서 사용
 */
export function formatStudentEnrollment(s: StudentIdentity | null): string {
  if (!s) return '학적 정보 없음';
  const parts = buildEnrollmentParts(s);
  return parts.length > 0 ? parts.join(' ') : '학적 정보 없음';
}

/**
 * 복수 학생 표기: full 또는 compact 모드
 * 3명 이상이면 "이름 외 N명" 형태로 축약
 */
export function formatStudentNames(
  students: StudentIdentity[],
  mode: 'full' | 'compact' = 'full',
): string {
  if (students.length === 0) return '(학생 없음)';
  const fmt = mode === 'full' ? formatStudentFull : formatStudentCompact;
  if (students.length <= 2) return students.map(fmt).join(', ');
  return `${fmt(students[0])} 외 ${students.length - 1}명`;
}
