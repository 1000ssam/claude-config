/** 제네릭 필터+정렬 유틸리티 — StudentsPage, CasesPage 공용 */

export interface SortConfig {
  col: string;
  dir: 'asc' | 'desc';
}

/** 레코드 배열에 컬럼별 필터 + 정렬 적용 */
export function applyFiltersAndSort<T extends Record<string, unknown>>(
  items: T[],
  filters: Record<string, string[]>,
  sort: SortConfig | null,
): T[] {
  let result = [...items];

  for (const [col, vals] of Object.entries(filters)) {
    if (!vals || vals.length === 0) continue;
    result = result.filter((item) => {
      const v = item[col] as string | null;
      return vals.includes(v ?? '');
    });
  }

  if (sort) {
    result.sort((a, b) => {
      const av = a[sort.col] as string | number | null;
      const bv = b[sort.col] as string | number | null;
      let cmp = 0;
      if (av === null || av === undefined) cmp = 1;
      else if (bv === null || bv === undefined) cmp = -1;
      else if (typeof av === 'number' && typeof bv === 'number') cmp = av - bv;
      else if (av !== '' && bv !== '' && isFinite(Number(av)) && isFinite(Number(bv))) cmp = Number(av) - Number(bv);
      else cmp = String(av).localeCompare(String(bv), 'ko');
      return sort.dir === 'asc' ? cmp : -cmp;
    });
  }

  return result;
}

/** 특정 컬럼의 고유 값 목록 (한국어 정렬) */
export function getDistinctValues<T extends Record<string, unknown>>(
  items: T[],
  col: string,
): string[] {
  const vals = new Set<string>();
  for (const item of items) {
    const v = item[col] as string | null;
    if (v) vals.add(v);
  }
  return Array.from(vals).sort((a, b) => a.localeCompare(b, 'ko'));
}
