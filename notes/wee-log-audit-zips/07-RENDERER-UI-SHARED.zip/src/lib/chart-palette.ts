/**
 * 차트 전용 컬러 팔레트 (통계/대시보드)
 *
 * primary 색상의 hue를 감지하여, hue가 겹치는 후보를 자동 제외.
 * 14개 후보 중 primary와 ±25° 이상 떨어진 9색을 선택하여 총 10색 구성.
 * 10개 초과 항목은 opacity 70%로 순환.
 */

function getCssVar(name: string): string {
  const raw = getComputedStyle(document.documentElement)
    .getPropertyValue(name)
    .trim();
  return raw ? `hsl(${raw})` : '#888';
}

/** primary의 hue 추출 (CSS 변수 "H S% L%" 형식) */
function getPrimaryHue(): number {
  const raw = getComputedStyle(document.documentElement)
    .getPropertyValue('--primary')
    .trim();
  if (!raw) return -1;
  return parseInt(raw.split(' ')[0], 10) || 0;
}

/** 두 hue 간 최소 각도 차이 (0~180) */
function hueDist(a: number, b: number): number {
  const d = Math.abs(a - b) % 360;
  return d > 180 ? 360 - d : d;
}

interface Candidate {
  hue: number;
  css: string;
}

/** 14개 후보: 색상환 전체에 ~25° 간격으로 배치 */
const CANDIDATES: Candidate[] = [
  { hue: 0,   css: 'hsl(0, 65%, 52%)' },      // red
  { hue: 25,  css: 'hsl(25, 85%, 57%)' },      // warm orange
  { hue: 50,  css: 'hsl(50, 80%, 48%)' },       // amber
  { hue: 80,  css: 'hsl(80, 50%, 44%)' },       // olive
  { hue: 110, css: 'hsl(110, 45%, 42%)' },      // green
  { hue: 142, css: 'hsl(142, 45%, 45%)' },      // forest green
  { hue: 173, css: 'hsl(173, 65%, 40%)' },      // teal
  { hue: 200, css: 'hsl(200, 65%, 48%)' },      // cyan-blue
  { hue: 226, css: 'hsl(226, 55%, 55%)' },      // indigo
  { hue: 255, css: 'hsl(255, 52%, 56%)' },      // violet
  { hue: 285, css: 'hsl(285, 40%, 50%)' },      // purple
  { hue: 310, css: 'hsl(310, 45%, 50%)' },      // magenta
  { hue: 335, css: 'hsl(335, 55%, 52%)' },      // pink
  { hue: 350, css: 'hsl(350, 60%, 55%)' },      // rose
];

const MIN_HUE_DIST = 25;

let _cache: string[] = [];
let _lastPrimary = '';

export function getChartColors(): string[] {
  const primary = getCssVar('--primary');
  if (_cache.length > 0 && _lastPrimary === primary) return _cache;

  const primaryHue = getPrimaryHue();
  const filtered = CANDIDATES.filter((c) => hueDist(c.hue, primaryHue) >= MIN_HUE_DIST);
  const selected = filtered.slice(0, 9).map((c) => c.css);

  _cache = [primary, ...selected];
  _lastPrimary = primary;
  return _cache;
}

/** 인덱스가 10을 초과하면 opacity를 낮춰 순환 */
export function getChartColor(index: number): string {
  const colors = getChartColors();
  const base = colors[index % colors.length];
  if (index < colors.length) return base;
  return base.replace(')', ' / 0.7)').replace('hsl(', 'hsla(');
}

/** 차트 색상 캐시 초기화 (팔레트 변경 시 호출) */
export function invalidateChartColors(): void {
  _cache = [];
  _lastPrimary = '';
}
