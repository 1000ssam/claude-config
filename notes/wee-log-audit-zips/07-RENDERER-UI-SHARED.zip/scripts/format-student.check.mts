/** format-student 표기 통일 회귀 체크. */
import {
  formatStudentFull,
  formatStudentCompact,
  formatStudentEnrollment,
  formatStudentNames,
  type StudentIdentity,
} from '../src/lib/format-student.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('format-student');

const full: StudentIdentity = { name: '홍길동', grade: '1학년', class_name: '4', number: '2', gender: '여' };

// formatStudentFull
t.eq('풀 표기 전체', formatStudentFull(full), '홍길동 · 1학년 4반 2번 · 여');
t.eq('이름만', formatStudentFull({ name: '홍길동' }), '홍길동');
t.eq('학적만(이름 없음)', formatStudentFull({ grade: '1학년', class_name: '4', number: '2' }), '1학년 4반 2번');
t.eq('빈 입력', formatStudentFull({}), '');
t.eq('null 학적은 생략', formatStudentFull({ name: '홍길동', grade: null, class_name: null, number: null }), '홍길동');

// formatStudentCompact
t.eq('컴팩트 전체', formatStudentCompact(full), '홍길동 (1학년 4반 2번 · 여)');
t.eq('컴팩트 이름만(괄호 없음)', formatStudentCompact({ name: '홍길동' }), '홍길동');
t.eq('컴팩트 성별만', formatStudentCompact({ name: '홍길동', gender: '남' }), '홍길동 (남)');

// formatStudentEnrollment
t.eq('학적 null → 안내문', formatStudentEnrollment(null), '학적 정보 없음');
t.eq('학적 빈 객체 → 안내문', formatStudentEnrollment({}), '학적 정보 없음');
t.eq('학적 일부', formatStudentEnrollment({ grade: '2학년' }), '2학년');
t.eq('학적 전체', formatStudentEnrollment(full), '1학년 4반 2번');

// formatStudentNames
t.eq('복수 0명', formatStudentNames([]), '(학생 없음)');
t.eq('복수 1명', formatStudentNames([{ name: '홍길동' }]), '홍길동');
t.eq('복수 2명', formatStudentNames([{ name: '가' }, { name: '나' }]), '가, 나');
t.eq(
  '복수 3명 이상 축약',
  formatStudentNames([{ name: '가' }, { name: '나' }, { name: '다' }]),
  '가 외 2명',
);
t.eq(
  '복수 compact 모드',
  formatStudentNames([{ name: '가', gender: '남' }, { name: '나' }], 'compact'),
  '가 (남), 나',
);

t.report();
