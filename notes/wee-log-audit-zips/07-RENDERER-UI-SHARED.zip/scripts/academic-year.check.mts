/** academic-year 산출 회귀 체크. (한국 학년도: 3월 1일 시작) */
import {
  getAcademicYear,
  getAcademicYearFromDateStr,
  getAcademicYearOptions,
} from '../src/lib/academic-year.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('academic-year');

// getAcademicYear(Date) — month 0-indexed
t.eq('3월 1일 → 당해', getAcademicYear(new Date(2026, 2, 1)), '2026');
t.eq('2월 말 → 전해', getAcademicYear(new Date(2026, 1, 28)), '2025');
t.eq('1월 → 전해', getAcademicYear(new Date(2026, 0, 1)), '2025');
t.eq('12월 → 당해', getAcademicYear(new Date(2026, 11, 31)), '2026');
t.eq('연말 경계(2025-12)', getAcademicYear(new Date(2025, 11, 1)), '2025');

// getAcademicYearFromDateStr('YYYY-MM-DD')
t.eq('문자열 3월 → 당해', getAcademicYearFromDateStr('2026-03-01'), '2026');
t.eq('문자열 2월 → 전해', getAcademicYearFromDateStr('2026-02-15'), '2025');
t.eq('문자열 1월 → 전해', getAcademicYearFromDateStr('2026-01-01'), '2025');
t.eq('문자열 12월 → 당해', getAcademicYearFromDateStr('2026-12-31'), '2026');

// getAcademicYearOptions(count) — 현재 학년도 기준이라 절대값 대신 구조 검증
const cur = Number(getAcademicYear(new Date()));
const opts = getAcademicYearOptions();
t.eq('기본 개수 8', opts.length, 8);
t.eq('첫 항목 = 현재 학년도', opts[0], String(cur));
t.eq('내림차순 연속', opts, Array.from({ length: 8 }, (_, i) => String(cur - i)));
t.eq('count 인자 반영', getAcademicYearOptions(3), [String(cur), String(cur - 1), String(cur - 2)]);
t.eq('count=1', getAcademicYearOptions(1), [String(cur)]);
t.ok('모두 숫자 문자열', opts.every((o) => /^\d{4}$/.test(o)));

t.report();
