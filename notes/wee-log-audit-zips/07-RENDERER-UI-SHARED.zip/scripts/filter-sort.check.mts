/** applyFiltersAndSort / getDistinctValues 회귀 체크. */
import { applyFiltersAndSort, getDistinctValues } from '../src/lib/filter-sort.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('filter-sort');

type Row = Record<string, unknown>;
const rows: Row[] = [
  { name: '가영', grade: '3학년', class_name: '2', case_count: 5 },
  { name: '나래', grade: '1학년', class_name: '10', case_count: 0 },
  { name: '다온', grade: '3학년', class_name: '1', case_count: 2 },
  { name: '라온', grade: null, class_name: '2', case_count: 0 },
];

// ── 필터 ──────────────────────────────────────────────────────────────
t.eq(
  '단일 컬럼 단일 값',
  applyFiltersAndSort(rows, { grade: ['3학년'] }, null).map((r) => r.name),
  ['가영', '다온'],
);

t.eq(
  '단일 컬럼 복수 값(OR)',
  applyFiltersAndSort(rows, { grade: ['1학년', '3학년'] }, null).map((r) => r.name),
  ['가영', '나래', '다온'],
);

t.eq(
  '복수 컬럼(AND)',
  applyFiltersAndSort(rows, { grade: ['3학년'], class_name: ['1'] }, null).map((r) => r.name),
  ['다온'],
);

t.eq(
  '빈 값 배열은 해당 컬럼 필터 무시',
  applyFiltersAndSort(rows, { grade: [] }, null).length,
  4,
);

t.eq(
  'null 값은 빈 문자열로 취급되어 매칭',
  applyFiltersAndSort(rows, { grade: [''] }, null).map((r) => r.name),
  ['라온'],
);

// ── 정렬 ──────────────────────────────────────────────────────────────
t.eq(
  '숫자형 문자열 오름차순(수치 비교)',
  applyFiltersAndSort(rows, {}, { col: 'class_name', dir: 'asc' }).map((r) => r.class_name),
  ['1', '2', '2', '10'],
);

t.eq(
  '숫자형 문자열 내림차순',
  applyFiltersAndSort(rows, {}, { col: 'class_name', dir: 'desc' }).map((r) => r.class_name),
  ['10', '2', '2', '1'],
);

t.eq(
  '숫자 컬럼 오름차순',
  applyFiltersAndSort(rows, {}, { col: 'case_count', dir: 'asc' }).map((r) => r.case_count),
  [0, 0, 2, 5],
);

t.eq(
  '문자열 한국어 정렬(localeCompare)',
  applyFiltersAndSort(
    [{ name: '다' }, { name: '가' }, { name: '나' }],
    {},
    { col: 'name', dir: 'asc' },
  ).map((r) => r.name),
  ['가', '나', '다'],
);

t.eq(
  'null 값은 오름차순에서 뒤로',
  applyFiltersAndSort(rows, {}, { col: 'grade', dir: 'asc' }).map((r) => r.grade),
  ['1학년', '3학년', '3학년', null],
);

// 입력 배열 불변(non-mutating)
const original = [{ name: '다' }, { name: '가' }];
applyFiltersAndSort(original, {}, { col: 'name', dir: 'asc' });
t.eq('입력 배열을 변형하지 않음', original.map((r) => r.name), ['다', '가']);

// ── getDistinctValues ─────────────────────────────────────────────────
t.eq(
  '고유값 + 한국어 정렬, falsy 제외',
  getDistinctValues(rows, 'grade'),
  ['1학년', '3학년'],
);

t.eq(
  '숫자형 문자열 고유값은 문자열 정렬',
  getDistinctValues(rows, 'class_name'),
  ['1', '10', '2'],
);

t.eq('값 없는 컬럼은 빈 배열', getDistinctValues(rows, 'nonexistent'), []);

t.report();
