/** options 상수·getGraduationGrade 회귀 체크. */
import {
  getGraduationGrade,
  GRADE_OPTIONS,
  CASE_STATUS_LABELS,
  SCHOOL_TYPE_OPTIONS,
} from '../src/lib/constants/options.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('options');

// getGraduationGrade — 초등만 6학년, 그 외 3학년
t.eq('초등학교 → 6학년', getGraduationGrade('초등학교'), '6학년');
t.eq('중학교 → 3학년', getGraduationGrade('중학교'), '3학년');
t.eq('고등학교 → 3학년', getGraduationGrade('고등학교'), '3학년');
t.eq('특수학교 → 3학년', getGraduationGrade('특수학교'), '3학년');
t.eq('빈 문자열 → 3학년(기본)', getGraduationGrade(''), '3학년');
t.eq('알 수 없는 값 → 3학년(기본)', getGraduationGrade('대학교'), '3학년');

// 상수 불변식
t.ok('GRADE_OPTIONS 1~6학년 포함', ['1학년', '2학년', '3학년', '4학년', '5학년', '6학년'].every((g) => (GRADE_OPTIONS as readonly string[]).includes(g)));
t.eq('CASE_STATUS_LABELS', { active: CASE_STATUS_LABELS.active, closed: CASE_STATUS_LABELS.closed }, { active: '진행중', closed: '종료' });
t.eq('SCHOOL_TYPE_OPTIONS', [...SCHOOL_TYPE_OPTIONS], ['초등학교', '중학교', '고등학교', '특수학교']);

t.report();
