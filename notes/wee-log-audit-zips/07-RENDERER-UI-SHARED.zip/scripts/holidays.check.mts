/** holidays 조회 회귀 체크. */
import { getHolidayName, isHoliday, KOREAN_HOLIDAYS } from '../src/lib/holidays.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('holidays');

t.eq('신정 이름', getHolidayName('2026-01-01'), '신정');
t.eq('삼일절 이름', getHolidayName('2026-03-01'), '삼일절');
t.eq('2025 어린이날·부처님오신날 병기', getHolidayName('2025-05-05'), '어린이날·부처님오신날');
t.eq('공휴일 아님 → undefined', getHolidayName('2026-01-02'), undefined);

t.ok('isHoliday 참', isHoliday('2026-12-25'));
t.ok('isHoliday 거짓', !isHoliday('2026-12-24'));
t.ok('범위 밖 연도 거짓', !isHoliday('2030-01-01'));

t.ok('데이터 모든 키가 YYYY-MM-DD', Object.keys(KOREAN_HOLIDAYS).every((k) => /^\d{4}-\d{2}-\d{2}$/.test(k)));
t.ok('데이터 모든 값이 비어있지 않음', Object.values(KOREAN_HOLIDAYS).every((v) => v.length > 0));

t.report();
