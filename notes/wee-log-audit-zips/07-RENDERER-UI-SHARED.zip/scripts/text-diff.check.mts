/** text-diff (LCS 줄단위 diff) 회귀 체크. */
import {
  splitLines,
  diffLines,
  collapseUnchanged,
  type DiffOp,
} from '../src/lib/ai/text-diff.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('text-diff');

// ── splitLines ────────────────────────────────────────────────────────
t.eq('빈 문자열 → []', splitLines(''), []);
t.eq('LF 분할', splitLines('a\nb'), ['a', 'b']);
t.eq('CRLF/CR 혼합 정규화', splitLines('a\r\nb\rc'), ['a', 'b', 'c']);
t.eq('끝 개행 → 빈 줄', splitLines('a\n'), ['a', '']);

// ── diffLines: 자명 케이스 ────────────────────────────────────────────
t.eq('양쪽 빈 입력', diffLines('', ''), []);
t.eq('전부 추가', diffLines('', 'x\ny'), [
  { kind: 'added', text: 'x' },
  { kind: 'added', text: 'y' },
]);
t.eq('전부 삭제', diffLines('x\ny', ''), [
  { kind: 'removed', text: 'x' },
  { kind: 'removed', text: 'y' },
]);
t.eq('동일 텍스트 → 전부 unchanged', diffLines('a\nb', 'a\nb'), [
  { kind: 'unchanged', text: 'a' },
  { kind: 'unchanged', text: 'b' },
]);

// ── diffLines: 재구성 불변식 (순서 quirk와 무관하게 항상 성립) ─────────
// unchanged+added 의 텍스트 = newText 줄, unchanged+removed = oldText 줄
function reconstruct(ops: DiffOp[]) {
  return {
    newSide: ops.filter((o) => o.kind !== 'removed').map((o) => o.text),
    oldSide: ops.filter((o) => o.kind !== 'added').map((o) => o.text),
  };
}
const cases: [string, string][] = [
  ['a\nb\nc', 'a\nc'],
  ['a\nb\nc', 'a\nx\nc'],
  ['a', 'b'],
  ['1\n2\n3\n4', '1\n3\n4\n5'],
  ['같은\n줄\n유지', '같은\n수정됨\n유지'],
];
for (const [oldT, newT] of cases) {
  const { newSide, oldSide } = reconstruct(diffLines(oldT, newT));
  t.eq(`재구성 new: ${JSON.stringify(newT)}`, newSide, splitLines(newT));
  t.eq(`재구성 old: ${JSON.stringify(oldT)}`, oldSide, splitLines(oldT));
}

// ── collapseUnchanged ────────────────────────────────────────────────
t.eq(
  '인접 unchanged 병합',
  collapseUnchanged([
    { kind: 'unchanged', text: 'a' },
    { kind: 'unchanged', text: 'b' },
    { kind: 'removed', text: 'c' },
    { kind: 'unchanged', text: 'd' },
  ]),
  [
    { kind: 'unchanged', text: 'a\nb' },
    { kind: 'removed', text: 'c' },
    { kind: 'unchanged', text: 'd' },
  ],
);
t.eq(
  'added/removed 는 병합 안 함',
  collapseUnchanged([
    { kind: 'added', text: 'x' },
    { kind: 'added', text: 'y' },
  ]),
  [
    { kind: 'added', text: 'x' },
    { kind: 'added', text: 'y' },
  ],
);
t.eq('빈 입력', collapseUnchanged([]), []);

t.report();
