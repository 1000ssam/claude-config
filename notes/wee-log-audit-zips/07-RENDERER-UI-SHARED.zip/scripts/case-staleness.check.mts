/** 장기 미접촉(stale case) 판별 회귀 체크. */
import {
  isStaleCase,
  countStaleCases,
  staleSortKey,
  STALE_CASE_DAYS,
} from '../src/lib/case-staleness.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('case-staleness');

// 기준 시각 고정: 2026-06-05 12:00 (N=14 → cutoff = 2026-05-22 12:00)
const now = Date.parse('2026-06-05T12:00:00');
const C = (over: Partial<{ status: string; created_at: string; last_session_date: string | null }>) => ({
  status: 'active',
  created_at: '2026-01-01 00:00:00',
  last_session_date: null,
  ...over,
}) as { status: 'active' | 'closed'; created_at: string; last_session_date: string | null };

t.ok('active + 마지막상담 14일 경과 → stale', isStaleCase(C({ last_session_date: '2026-05-01' }), now));
t.ok('active + 마지막상담 14일 이내 → not stale', !isStaleCase(C({ last_session_date: '2026-06-01' }), now));
t.ok('active + 상담 0회(오래된 등록) → stale', isStaleCase(C({ last_session_date: null }), now));
t.ok('active + 상담 0회지만 등록 14일 미만 → not stale', !isStaleCase(C({ last_session_date: null, created_at: '2026-06-04 09:00:00' }), now));
t.ok('closed는 무조건 not stale', !isStaleCase(C({ status: 'closed', last_session_date: '2025-01-01' }), now));
t.ok('경계: 정확히 cutoff일(05-22)도 14일 경과로 포함', isStaleCase(C({ last_session_date: '2026-05-22' }), now));

t.eq('countStaleCases 집계', countStaleCases([
  C({ last_session_date: '2026-05-01' }),         // stale
  C({ last_session_date: '2026-06-01' }),         // not
  C({ last_session_date: null }),                 // stale
  C({ status: 'closed', last_session_date: null }), // not
], now), 2);

t.ok('staleSortKey: 상담 0회는 -Infinity(최우선)', staleSortKey({ last_session_date: null }) === -Infinity);
t.ok('staleSortKey: 오래된 날짜가 더 작음', staleSortKey({ last_session_date: '2026-05-01' }) < staleSortKey({ last_session_date: '2026-05-20' }));

t.eq('STALE_CASE_DAYS 기본 14', STALE_CASE_DAYS, 14);

// 커스텀 기준일(설정값으로 주입) — 홈 대시보드가 의존하는 계약
t.ok('days=7: 마지막상담 10일 경과 → stale', isStaleCase(C({ last_session_date: '2026-05-26' }), now, 7));
t.ok('days=30: 마지막상담 10일 경과 → not stale', !isStaleCase(C({ last_session_date: '2026-05-26' }), now, 30));
t.ok('days=30: 상담 0회지만 등록 30일 미만 → not stale', !isStaleCase(C({ last_session_date: null, created_at: '2026-05-20 09:00:00' }), now, 30));
t.eq('countStaleCases days=7 집계', countStaleCases([
  C({ last_session_date: '2026-05-26' }),  // 10일 경과 → stale(7)
  C({ last_session_date: '2026-06-01' }),  // 4일 경과 → not
], now, 7), 1);

t.report();
