// POST /redeem { code, full_name? } — 코드를 로그인 계정에 바인딩(1 redeem = 1행).
//   좌석캡·중복은 DB(트리거+CHECK, UNIQUE)가 원자적 강제. 여기 사전체크는 UX 친화 에러용.
//   설계 §8(redemption code 바인딩), §17.3·§17.4.
import { json, preflight, getUser, adminClient } from '../_shared/http.ts';
import { normalizeCode } from '../_shared/codes.ts';

Deno.serve(async (req) => {
  const pf = preflight(req);
  if (pf) return pf;
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  try {
    const user = await getUser(req);
    if (!user) return json({ error: 'unauthorized' }, 401);

    const body = await req.json().catch(() => ({}));
    const codeInput = typeof body.code === 'string' ? body.code : '';
    if (!codeInput.trim()) return json({ error: 'code_required' }, 400);
    const code = normalizeCode(codeInput);

    const db = adminClient();
    const { data: row, error } = await db
      .from('redemption_codes')
      .select('id, status, max_seats, seats_used, redeem_window_end, period_end, plan, is_trial')
      .eq('code', code)
      .maybeSingle();
    if (error) return json({ error: 'db_error', detail: error.message }, 500);
    if (!row) return json({ error: 'invalid_code' }, 404);

    const now = Date.now();
    if (row.status !== 'active') return json({ error: 'code_disabled' }, 409);
    if (Date.parse(row.redeem_window_end) <= now) return json({ error: 'redeem_window_closed' }, 409);
    if (Date.parse(row.period_end) <= now) return json({ error: 'code_expired' }, 409);
    if (row.seats_used >= row.max_seats) return json({ error: 'no_seats' }, 409); // 사전체크(UX)

    // 신원(이름) 가입 시 1회 업서트
    if (typeof body.full_name === 'string' && body.full_name.trim()) {
      await db.from('profiles').upsert({ id: user.id, full_name: body.full_name.trim() }, { onConflict: 'id' });
    }

    // 바인딩 생성 — 좌석캡(트리거+CHECK)·중복(UNIQUE)이 원자적으로 강제됨.
    const { error: insErr } = await db
      .from('code_bindings')
      .insert({ code_id: row.id, account_id: user.id });
    if (insErr) {
      const msg = insErr.message || '';
      if (insErr.code === '23505' || /duplicate key|unique/i.test(msg))
        return json({ error: 'already_redeemed' }, 409);
      if (insErr.code === '23514' || /seats_used|check constraint/i.test(msg))
        return json({ error: 'no_seats' }, 409);
      return json({ error: 'db_error', detail: msg }, 500);
    }

    return json({ ok: true, plan: row.plan, is_trial: row.is_trial, period_end: row.period_end });
  } catch (e) {
    return json({ error: 'internal', detail: String((e as Error)?.message ?? e) }, 500);
  }
});
