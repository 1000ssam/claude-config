// GET/POST /entitlement — 로그인 사용자의 구독을 EdDSA 서명 토큰으로 발급.
//   상태: none(구독없음→redeem 유도) | active | trialing | expired(읽기전용).
//   설계 §3.3, §5, §17.5(features 서버 주입), §17.7(grace 7일).
import { json, preflight, getUser, adminClient } from '../_shared/http.ts';
import { getSigningKey } from '../_shared/signing-key.ts';
import { signEntitlement, computeStatus, type EntitlementStatus } from '../_shared/entitlement.ts';

const GRACE_SECONDS = 7 * 24 * 60 * 60; // 오프라인 유효창 7일

interface CodeRow {
  id: string;
  plan: string;
  period_end: string;
  is_trial: boolean;
  status: string;
}

Deno.serve(async (req) => {
  const pf = preflight(req);
  if (pf) return pf;
  try {
    const user = await getUser(req);
    if (!user) return json({ error: 'unauthorized' }, 401);

    const db = adminClient();
    const { data: bindings, error } = await db
      .from('code_bindings')
      .select('id, status, redeemed_at, redemption_codes!inner(id, plan, period_end, is_trial, status)')
      .eq('account_id', user.id)
      .order('redeemed_at', { ascending: false });
    if (error) return json({ error: 'db_error', detail: error.message }, 500);

    const rows = bindings ?? [];
    if (rows.length === 0) return json({ status: 'none' }); // 구독 이력 없음 → redeem 화면

    const now = Math.floor(Date.now() / 1000);
    const nowMs = now * 1000;

    // 유효(활성 바인딩 + 활성 코드 + 기간 내) 중 period_end 가장 늦은 것
    const valid = rows
      .filter((b) => b.status === 'active')
      .map((b) => b.redemption_codes as unknown as CodeRow)
      .filter((c) => c && c.status === 'active' && Date.parse(c.period_end) > nowMs);

    let code: CodeRow;
    let status: EntitlementStatus;
    if (valid.length > 0) {
      valid.sort((a, b) => Date.parse(b.period_end) - Date.parse(a.period_end));
      code = valid[0];
      status = computeStatus(code.period_end, code.is_trial, now); // active | trialing
    } else {
      // 만료/회수 — 읽기전용. 가장 최근 바인딩의 코드를 맥락으로.
      code = rows[0].redemption_codes as unknown as CodeRow;
      status = 'expired';
    }

    const { data: planRow } = await db
      .from('plans')
      .select('features')
      .eq('plan', code.plan)
      .maybeSingle();
    const features: string[] = status === 'expired' ? [] : (planRow?.features ?? []);

    const token = await signEntitlement(
      {
        sub: user.id,
        email: user.email,
        plan: code.plan,
        features,
        status,
        is_trial: code.is_trial,
        period_end: code.period_end,
        iat: now,
        exp: now + GRACE_SECONDS,
      },
      await getSigningKey(),
    );

    return json({ status, token });
  } catch (e) {
    return json({ error: 'internal', detail: String((e as Error)?.message ?? e) }, 500);
  }
});
