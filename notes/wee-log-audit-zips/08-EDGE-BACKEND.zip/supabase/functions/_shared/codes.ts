// redemption code 생성·정규화.
// Crockford base32 본문(혼동문자 I/L/O/U 제외). 저장·매칭은 하이픈 없는 정규형, 표시는 하이픈.
//   정규형(stored `code`):  WEELOG9F3K7Q2XM4RT   (WEELOG + 12자)
//   표시형(display):        WEELOG-9F3K-7Q2X-M4RT
const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ'; // 32자, I·L·O·U 제외
const PREFIX = 'WEELOG';
const BODY_LEN = 12;

// 저장용 정규형(하이픈 없음) 생성.
export function generateCode(): string {
  const bytes = new Uint8Array(BODY_LEN);
  crypto.getRandomValues(bytes);
  let body = '';
  for (let i = 0; i < BODY_LEN; i++) body += ALPHABET[bytes[i] % 32];
  return PREFIX + body;
}

// 표시용(4자 그룹 하이픈).
export function formatCode(canonical: string): string {
  const body = canonical.startsWith(PREFIX) ? canonical.slice(PREFIX.length) : canonical;
  const groups = body.match(/.{1,4}/g) ?? [];
  return [PREFIX, ...groups].join('-');
}

// 사용자 입력 → 정규형. 접두사 본문에만 혼동문자 보정(접두사 WEELOG는 보존).
export function normalizeCode(input: string): string {
  const s = input.trim().toUpperCase().replace(/[^A-Z0-9]/g, ''); // 하이픈·공백 제거
  let body = s.startsWith(PREFIX) ? s.slice(PREFIX.length) : s;
  body = body
    .replace(/I/g, '1')
    .replace(/L/g, '1')
    .replace(/O/g, '0')
    .replace(/U/g, 'V');
  return PREFIX + body;
}
