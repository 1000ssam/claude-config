// 운영 비공개 서명키 로드(함수 시크릿 ENTITLEMENT_PRIVATE_JWK). 1회 import 후 캐시.
import { importPrivateJwk } from './entitlement.ts';

let cached: CryptoKey | null = null;

export async function getSigningKey(): Promise<CryptoKey> {
  if (cached) return cached;
  const raw = Deno.env.get('ENTITLEMENT_PRIVATE_JWK');
  if (!raw) throw new Error('missing env: ENTITLEMENT_PRIVATE_JWK');
  let jwk: JsonWebKey;
  try {
    jwk = JSON.parse(raw);
  } catch {
    throw new Error('ENTITLEMENT_PRIVATE_JWK is not valid JSON');
  }
  cached = await importPrivateJwk(jwk);
  return cached;
}
