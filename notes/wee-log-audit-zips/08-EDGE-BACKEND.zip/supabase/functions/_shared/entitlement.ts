// 엔타이틀먼트 토큰 — EdDSA(Ed25519) JWT 서명/검증 공유 코어.
// 의존성 0: 표준 Web Crypto(globalThis.crypto.subtle)만 사용 → Deno(Supabase Edge)·Node 24+ 양쪽 동작.
// 설계: SUBSCRIPTION_DESIGN.md §5(토큰 구조), §17.5(features 서버 주입), §17.7(grace).
//
// ⚠️ 타입 스트리핑 호환: enum·파라미터 프로퍼티 금지(Node 네이티브 TS 실행 위해). 순수 타입+함수만.

export type EntitlementStatus = 'active' | 'trialing' | 'expired';

export interface EntitlementClaims {
  sub: string;            // 계정 id (auth.users.id)
  email: string;
  plan: string;           // 등급명 (앱은 직접 참조 금지 — features만 사용)
  features: string[];     // 서버가 plan→features로 계산해 주입 (§17.5)
  status: EntitlementStatus;
  is_trial: boolean;
  period_end: string;     // ISO8601 — 구독 기간 종료(실제 유료기간)
  iat: number;            // 발급 시각(초)
  exp: number;            // 토큰 만료(초) = iat + grace(오프라인 유효창)
}

const JWT_HEADER = { alg: 'EdDSA', typ: 'JWT' } as const;
const ALG = { name: 'Ed25519' } as const;

// ── base64url ──────────────────────────────────────────────────────────────
function b64urlFromBytes(bytes: Uint8Array): string {
  let bin = '';
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function bytesFromB64url(s: string): Uint8Array<ArrayBuffer> {
  const pad = s.length % 4 === 0 ? '' : '='.repeat(4 - (s.length % 4));
  const bin = atob(s.replace(/-/g, '+').replace(/_/g, '/') + pad);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function b64urlFromJson(obj: unknown): string {
  return b64urlFromBytes(new TextEncoder().encode(JSON.stringify(obj)));
}

// ── 키 import (JWK) ──────────────────────────────────────────────────────────
// 비공개키: 서버(Supabase 함수 시크릿)에서만. 공개키: 앱·동의서 Worker 내장.
export function importPrivateJwk(jwk: JsonWebKey): Promise<CryptoKey> {
  return crypto.subtle.importKey('jwk', jwk, ALG, false, ['sign']);
}

export function importPublicJwk(jwk: JsonWebKey): Promise<CryptoKey> {
  return crypto.subtle.importKey('jwk', jwk, ALG, true, ['verify']);
}

// ── 서명 ─────────────────────────────────────────────────────────────────────
export async function signEntitlement(
  claims: EntitlementClaims,
  privateKey: CryptoKey,
): Promise<string> {
  const signingInput = `${b64urlFromJson(JWT_HEADER)}.${b64urlFromJson(claims)}`;
  const sig = await crypto.subtle.sign(
    ALG,
    privateKey,
    new TextEncoder().encode(signingInput),
  );
  return `${signingInput}.${b64urlFromBytes(new Uint8Array(sig))}`;
}

// ── 검증 ─────────────────────────────────────────────────────────────────────
export interface VerifyOptions {
  // 현재 시각(초). 미지정 시 Date.now(). 테스트·시계되돌리기 검사용 주입 가능.
  now?: number;
  // exp(grace) 만료 검사 생략 여부(기본 false = 검사함).
  ignoreExpiry?: boolean;
}

export class EntitlementVerifyError extends Error {}

export async function verifyEntitlement(
  token: string,
  publicKey: CryptoKey,
  opts: VerifyOptions = {},
): Promise<EntitlementClaims> {
  const parts = token.split('.');
  if (parts.length !== 3) throw new EntitlementVerifyError('malformed token');
  const [h, p, s] = parts;

  // 헤더 alg 고정 검사 (alg confusion 방지)
  let header: { alg?: string; typ?: string };
  try {
    header = JSON.parse(new TextDecoder().decode(bytesFromB64url(h)));
  } catch {
    throw new EntitlementVerifyError('bad header');
  }
  if (header.alg !== 'EdDSA') throw new EntitlementVerifyError('unexpected alg');

  const ok = await crypto.subtle.verify(
    ALG,
    publicKey,
    bytesFromB64url(s),
    new TextEncoder().encode(`${h}.${p}`),
  );
  if (!ok) throw new EntitlementVerifyError('signature verification failed');

  let claims: EntitlementClaims;
  try {
    claims = JSON.parse(new TextDecoder().decode(bytesFromB64url(p)));
  } catch {
    throw new EntitlementVerifyError('bad payload');
  }

  if (!opts.ignoreExpiry) {
    const now = opts.now ?? Math.floor(Date.now() / 1000);
    if (typeof claims.exp !== 'number' || now >= claims.exp) {
      throw new EntitlementVerifyError('token expired (grace window passed)');
    }
  }
  return claims;
}

// ── 구독 상태 계산 (서버에서 사용) ──────────────────────────────────────────────
// period_end / is_trial 로부터 status 결정. 토큰 발급 직전 서버가 호출.
export function computeStatus(periodEndIso: string, isTrial: boolean, now: number): EntitlementStatus {
  const periodEnd = Date.parse(periodEndIso);
  if (Number.isNaN(periodEnd)) return 'expired';
  if (now * 1000 >= periodEnd) return 'expired';
  return isTrial ? 'trialing' : 'active';
}
