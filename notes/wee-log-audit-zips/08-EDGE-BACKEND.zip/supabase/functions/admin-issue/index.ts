// POST /admin-issue — 운영자가 테크빌 주문을 받아 주문 1건 + 코드 N장 발급.
//   인증: x-admin-key 헤더 == ADMIN_API_KEY 시크릿(타이밍 안전 비교). Supabase 유저 아님.
//   설계 §17.2(admin/CSV 수동 입력구 먼저), §17.1(개인=1장 / 단체=멀티시트).
//   body: { external_ref?, buyer_type('individual'|'org'), org_name?, buyer_name?, buyer_contact?,
//           note?, plan='standard', max_seats=1, count=1, period_end(ISO, 필수),
//           redeem_window_days=30, is_trial=false }
import { json, preflight, adminClient, safeEqual } from '../_shared/http.ts';
import { generateCode, formatCode } from '../_shared/codes.ts';

function toInt(v: unknown, def: number): number {
  const n = parseInt(String(v ?? ''), 10);
  return Number.isFinite(n) ? n : def;
}

Deno.serve(async (req) => {
  const pf = preflight(req);
  if (pf) return pf;
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);

  const expected = Deno.env.get('ADMIN_API_KEY') ?? '';
  const provided = req.headers.get('x-admin-key') ?? '';
  if (!expected || !safeEqual(provided, expected)) return json({ error: 'forbidden' }, 403);

  try {
    const b = await req.json().catch(() => ({}));

    const periodEndRaw = typeof b.period_end === 'string' ? Date.parse(b.period_end) : NaN;
    if (Number.isNaN(periodEndRaw)) return json({ error: 'period_end_required_iso' }, 400);
    const periodEnd = new Date(periodEndRaw);
    if (periodEnd.getTime() <= Date.now()) return json({ error: 'period_end_in_past' }, 400);

    const plan = typeof b.plan === 'string' ? b.plan : 'standard';
    const isTrial = !!b.is_trial;
    const maxSeats = Math.max(1, toInt(b.max_seats, 1));
    const count = Math.max(1, Math.min(toInt(b.count, 1), 500)); // 개별 코드 N장(상한 500)
    const redeemWindowDays = Math.max(1, toInt(b.redeem_window_days, 30));
    const redeemWindowEnd = new Date(Date.now() + redeemWindowDays * 86400 * 1000);

    const db = adminClient();

    // plan 존재 검증(서버 config)
    const { data: planRow } = await db.from('plans').select('plan').eq('plan', plan).maybeSingle();
    if (!planRow) return json({ error: `unknown_plan:${plan}` }, 400);

    // 주문 1건
    const { data: ord, error: oErr } = await db
      .from('orders')
      .insert({
        external_ref: b.external_ref ?? null,
        buyer_type: b.buyer_type === 'org' ? 'org' : 'individual',
        org_name: b.org_name ?? null,
        buyer_name: b.buyer_name ?? null,
        buyer_contact: b.buyer_contact ?? null,
        note: b.note ?? null,
      })
      .select('id')
      .single();
    if (oErr) return json({ error: 'db_error_order', detail: oErr.message }, 500);

    // 코드 N장(충돌 시 재시도)
    const created: Array<{ code: string; display: string }> = [];
    for (let i = 0; i < count; i++) {
      let issued = '';
      for (let attempt = 0; attempt < 5; attempt++) {
        const candidate = generateCode();
        const { error: cErr } = await db.from('redemption_codes').insert({
          order_id: ord.id,
          code: candidate,
          plan,
          max_seats: maxSeats,
          period_end: periodEnd.toISOString(),
          redeem_window_end: redeemWindowEnd.toISOString(),
          is_trial: isTrial,
        });
        if (!cErr) { issued = candidate; break; }
        if (cErr.code !== '23505') return json({ error: 'db_error_code', detail: cErr.message }, 500);
      }
      if (!issued) return json({ error: 'code_collision_retry_exhausted' }, 500);
      created.push({ code: issued, display: formatCode(issued) });
    }

    return json({
      ok: true,
      order_id: ord.id,
      plan,
      max_seats: maxSeats,
      is_trial: isTrial,
      period_end: periodEnd.toISOString(),
      redeem_window_end: redeemWindowEnd.toISOString(),
      codes: created,
    });
  } catch (e) {
    return json({ error: 'internal', detail: String((e as Error)?.message ?? e) }, 500);
  }
});
