-- wee-log 구독 백엔드 — Phase 1 스키마
-- 설계: SUBSCRIPTION_DESIGN.md §17.3 (orders ──< redemption_codes ──< code_bindings >── auth.users)
-- 원칙: 서버가 구독의 단일 진실원천. 유저는 직접 조회/조작 불가(RLS 전면 차단, Edge Function=service_role 경유).

-- ──────────────────────────────────────────────────────────────────────────
-- profiles: 신원(이름)을 계정 레이어에 1회 (§17.3). auth.users 1:1 확장.
-- ──────────────────────────────────────────────────────────────────────────
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text,
  created_at  timestamptz not null default now()
);

-- ──────────────────────────────────────────────────────────────────────────
-- plans: 플랜 등급 → feature 플래그 매핑 (서버 config). §17.5
--   등급 재단 = 이 테이블 수정만, 앱 재배포 0.
-- ──────────────────────────────────────────────────────────────────────────
create table if not exists public.plans (
  plan          text primary key,
  display_name  text not null,
  features      text[] not null default '{}',
  created_at    timestamptz not null default now()
);

-- 기본 플랜 시드 (features 실제 내용은 미정 가능 — 구조만 고정)
insert into public.plans (plan, display_name, features)
values ('standard', '스탠다드', array['consent_sms','export','reports'])
on conflict (plan) do nothing;

-- ──────────────────────────────────────────────────────────────────────────
-- orders: 테크빌(대행사) 주문 단위 = 구독자 정보 출처 (§17.1). 벤더 무과금.
-- ──────────────────────────────────────────────────────────────────────────
create table if not exists public.orders (
  id            uuid primary key default gen_random_uuid(),
  external_ref  text,                                   -- 테크빌 주문번호(추적용)
  buyer_type    text not null default 'individual'
                check (buyer_type in ('individual','org')),
  org_name      text,                                   -- 단체(교육청)명
  buyer_name    text,
  buyer_contact text,
  note          text,
  created_at    timestamptz not null default now()
);

-- ──────────────────────────────────────────────────────────────────────────
-- redemption_codes: 바인딩 조인키. 개인=max_seats 1, 단체=max_seats N (§17.1)
--   기간은 코드에 둠(단체 N명 공유, 연장 시 일괄 롤포워드) — §17.3
-- ──────────────────────────────────────────────────────────────────────────
create table if not exists public.redemption_codes (
  id                 uuid primary key default gen_random_uuid(),
  order_id           uuid not null references public.orders(id) on delete restrict,
  code               text not null unique,              -- 사용자가 입력하는 코드 문자열
  plan               text not null default 'standard' references public.plans(plan),
  max_seats          int  not null default 1  check (max_seats >= 1),
  seats_used         int  not null default 0  check (seats_used >= 0 and seats_used <= max_seats),
  period_end         timestamptz not null,              -- 구독 기간 종료(서버 정의)
  redeem_window_end  timestamptz not null,              -- 이 시각 후 redeem 거부(유출통제 §17.4)
  is_trial           boolean not null default false,    -- 체험 = 일반코드+태그 (§17.5)
  status             text not null default 'active'
                     check (status in ('active','disabled')),
  created_at         timestamptz not null default now()
);

create index if not exists idx_codes_order on public.redemption_codes(order_id);

-- ──────────────────────────────────────────────────────────────────────────
-- code_bindings: 1 redeem = 1행 (§17.3). 좌석 회수 granularity의 핵심.
--   단체 50명 = 50행. 회수 = 해당 행 revoke → 좌석 반환 + 계정 만료(읽기전용).
-- ──────────────────────────────────────────────────────────────────────────
create table if not exists public.code_bindings (
  id          uuid primary key default gen_random_uuid(),
  code_id     uuid not null references public.redemption_codes(id) on delete restrict,
  account_id  uuid not null references auth.users(id) on delete cascade,
  status      text not null default 'active' check (status in ('active','revoked')),
  redeemed_at timestamptz not null default now(),
  revoked_at  timestamptz,
  unique (code_id, account_id)                          -- 같은 코드 중복 redeem 금지
);

create index if not exists idx_bindings_account on public.code_bindings(account_id);
create index if not exists idx_bindings_code on public.code_bindings(code_id);

-- ──────────────────────────────────────────────────────────────────────────
-- 좌석 캡 enforcement: 트리거가 seats_used 재계산 → CHECK(seats_used<=max_seats)가 초과 롤백.
--   트리거의 UPDATE가 코드 행 락 → 동시 redeem 직렬화(마지막 좌석 레이스 안전).
-- ──────────────────────────────────────────────────────────────────────────
create or replace function public.sync_seats_used()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  target_code uuid := coalesce(new.code_id, old.code_id);
begin
  update public.redemption_codes c
     set seats_used = (
       select count(*) from public.code_bindings b
        where b.code_id = target_code and b.status = 'active'
     )
   where c.id = target_code;
  return null;  -- AFTER 트리거
end;
$$;

drop trigger if exists trg_sync_seats_used on public.code_bindings;
create trigger trg_sync_seats_used
  after insert or update or delete on public.code_bindings
  for each row execute function public.sync_seats_used();

-- ──────────────────────────────────────────────────────────────────────────
-- RLS: 전면 차단(anon/authenticated 정책 없음). Edge Function=service_role가 우회.
--   유저가 코드/주문/바인딩을 직접 조회·조작하면 좌석·기간 위변조 위험 → 전부 함수 경유.
-- ──────────────────────────────────────────────────────────────────────────
alter table public.orders            enable row level security;
alter table public.redemption_codes  enable row level security;
alter table public.code_bindings     enable row level security;
alter table public.plans             enable row level security;
alter table public.profiles          enable row level security;

-- profiles: 소유자 본인만 자기 행 읽기/생성/수정 허용 (가입 시 이름 1회).
drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles
  for select using (auth.uid() = id);

drop policy if exists profiles_insert_own on public.profiles;
create policy profiles_insert_own on public.profiles
  for insert with check (auth.uid() = id);

drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

-- orders / redemption_codes / code_bindings / plans: 정책 없음 = anon·authenticated 전면 차단.
-- (service_role 키로 도는 Edge Function만 접근. plans도 entitlement 함수가 서버에서 join.)
