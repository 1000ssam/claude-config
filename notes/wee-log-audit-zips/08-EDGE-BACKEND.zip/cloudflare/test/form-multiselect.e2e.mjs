/**
 * 신규 폼 기능 실브라우저 E2E: 다중선택(체크박스→배열) + 단일선택(드롭다운) + 안내문(description hint).
 * 실행: node cloudflare/test/form-multiselect.e2e.mjs http://127.0.0.1:8787
 */
import { randomBytes } from 'node:crypto';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const PW = process.env.PW_CORE || '/mnt/c/dev/running-challenge-3/node_modules/playwright-core';
const { chromium } = require(PW);
const CHROME = process.env.CHROME_BIN || '/home/user/.cache/ms-playwright/chromium-1223/chrome-linux64/chrome';

const sodium = (await import('libsodium-wrappers')).default;
await sodium.ready;
const B = sodium.base64_variants.ORIGINAL;
const BASE = (process.argv[2] || 'http://127.0.0.1:8787').replace(/\/$/, '');

let pass = 0;
const fails = [];
const ok = (n, c) => { if (c) pass++; else { fails.push(n); console.error('  ❌ ' + n); } };

const device = randomBytes(32).toString('hex');
const token = randomBytes(18).toString('base64url');
const kp = sodium.crypto_box_keypair();
const publicKey = sodium.to_base64(kp.publicKey, B);
const schema = {
  version: 1, title: '다중선택/안내문 E2E',
  fields: [
    { key: 'student_name', type: 'text', label: '학생 이름', required: true, description: '학생의 실명을 적어주세요.' },
    { key: 'rel', type: 'select', label: '보호자 관계', required: true, options: ['부', '모', '기타'] },
    { key: 'subjects', type: 'select', multiple: true, label: '동의 과목(복수)', required: true, options: ['국어', '영어', '수학'] },
  ],
};
let r = await fetch(BASE + '/requests', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + device },
  body: JSON.stringify({ token, publicKey, formSchema: schema, title: schema.title, expiresAt: new Date(Date.now() + 7 * 864e5).toISOString() }),
});
ok('요청 등록', r.ok);

const browser = await chromium.launch({ executablePath: CHROME, headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage();
const pageErrors = [];
page.on('pageerror', (e) => pageErrors.push(String(e)));
await page.goto(BASE + '/f/' + token, { waitUntil: 'networkidle' });
await page.waitForSelector('#submitBtn', { timeout: 15000 });

// 렌더 검증
ok('단답 렌더', !!(await page.$('input[data-key="student_name"]')));
ok('단일선택=드롭다운 렌더', !!(await page.$('select[data-key="rel"]')));
ok('다중선택=체크박스 렌더', (await page.$$('input[data-multi="subjects"]')).length === 3);
const hints = await page.$$eval('.hint', (els) => els.map((e) => e.textContent));
ok('안내문(hint) 표시', hints.some((h) => (h || '').includes('학생의 실명을 적어주세요')));

// 다중선택 필수검증: 아무것도 안 고르고 제출 → 막힘
await page.click('#submitBtn');
await page.waitForTimeout(300);
ok('다중선택 미선택 시 필수 에러', await page.$eval('#err_subjects', (el) => el.classList.contains('show')).catch(() => false));

// 채우기: 텍스트 + 단일선택 + 다중 2개 체크
await page.fill('input[data-key="student_name"]', '홍길동');
await page.selectOption('select[data-key="rel"]', '모');
await page.check('input[data-multi="subjects"][value="국어"]');
await page.check('input[data-multi="subjects"][value="수학"]');

await page.click('#submitBtn');
await page.waitForFunction(() => (document.querySelector('#root')?.textContent || '').includes('제출 완료'), { timeout: 15000 }).catch(() => {});
ok('제출 성공화면', (await page.$eval('#root', (el) => el.textContent || '')).includes('제출 완료'));
ok('브라우저 콘솔 에러 없음', pageErrors.length === 0 || (console.error('pageerrors:', pageErrors), false));
await browser.close();

// 복호 검증
r = await fetch(BASE + '/requests/pending', { headers: { Authorization: 'Bearer ' + device } });
const data = await r.json();
const item = (data.requests || []).find((x) => x.token === token);
ok('서버 암호문 수령', !!(item && item.ciphertext));
if (item && item.ciphertext) {
  const ans = JSON.parse(sodium.to_string(sodium.crypto_box_seal_open(sodium.from_base64(item.ciphertext, B), kp.publicKey, kp.privateKey)));
  ok('복호: 단답 일치', ans.student_name === '홍길동');
  ok('복호: 단일선택 일치', ans.rel === '모');
  ok('복호: 다중선택 = 배열', Array.isArray(ans.subjects));
  ok('복호: 다중선택 값 일치(국어,수학)', JSON.stringify((ans.subjects || []).slice().sort()) === JSON.stringify(['국어', '수학']));
}

console.log(`\n[multiselect.e2e] pass ${pass}, fail ${fails.length}`);
if (fails.length) { console.error('FAILED:', fails.join(', ')); process.exit(1); }
console.log('✅ 다중선택·단일선택·안내문 E2E 통과: 렌더 → 수집 → 암호화 제출 → 배열 복호 일치');
