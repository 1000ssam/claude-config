/**
 * 동의서 영지식 전체 흐름 통합 검증 (로컬 wrangler dev 대상).
 *
 * 실제 구성과 동일하게 두 구현을 교차 사용한다:
 *   - 앱 측: npm 'libsodium-wrappers'(Node)로 키쌍 생성 + 복호 (electron/lib과 동일).
 *   - 보호자 측: 동일 출처 셀프 호스팅 브라우저 번들(public/)로 암호화.
 * 이 교차 검증으로 base64 변형/바이트 레이아웃 호환을 보장한다.
 *
 * 실행: node cloudflare/test/flow.mjs http://127.0.0.1:8787
 */

import { randomBytes, createHash } from 'node:crypto';

const BASE = (process.argv[2] || 'http://127.0.0.1:8787').replace(/\/$/, '');

// 앱 측 sodium (Node npm 패키지)
const appSodium = (await import('libsodium-wrappers')).default;
await appSodium.ready;

// 보호자 측 sodium (셀프 호스팅 브라우저 번들 + 브라우저 전역 셰임)
globalThis.self = globalThis;
globalThis.window = globalThis;
const browserSodium = (await import('../public/sodium-wrappers.mjs')).default;
await browserSodium.ready;

const B64 = (s) => s.base64_variants.ORIGINAL;
let pass = 0;
const fails = [];
const ok = (name, cond) => { if (cond) { pass++; } else { fails.push(name); console.error('  ❌ ' + name); } };
const eq = (name, a, b) => ok(name, JSON.stringify(a) === JSON.stringify(b));

async function req(method, path, { auth, body } = {}) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (auth) headers['Authorization'] = 'Bearer ' + auth;
  const res = await fetch(BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  let json = null;
  try { json = await res.json(); } catch { /* html/empty */ }
  return { status: res.status, json };
}

const FORM_SCHEMA = {
  version: 1,
  title: '상담 접수 및 개인정보 수집·이용 동의서',
  intro: '미성년자 법정대리인 동의 안내…',
  fields: [
    { key: 'guardian_name', type: 'text', label: '보호자 성명', required: true },
    { key: 'consent_privacy', type: 'consent', label: '개인정보 수집·이용 동의', required: true },
    { key: 'signature', type: 'signature', label: '전자서명', required: true },
  ],
};

const ANSWERS = {
  guardian_name: '김보호',
  consent_privacy: true,
  signature: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVR4nGNgYGAAAAAEAAH2FzhVAAAAAElFTkSuQmCC',
};

// ── 0) health ───────────────────────────────────────────────────────────────
{
  const r = await req('GET', '/health');
  ok('health 200', r.status === 200 && r.json?.ok === true);
}

// ── 정상 흐름 ─────────────────────────────────────────────────────────────────
const device = randomBytes(32).toString('hex');
const otherDevice = randomBytes(32).toString('hex');
const token = randomBytes(18).toString('base64url');

// 앱: 요청별 키쌍
const kp = appSodium.crypto_box_keypair();
const publicKey = appSodium.to_base64(kp.publicKey, B64(appSodium));
const privateKey = appSodium.to_base64(kp.privateKey, B64(appSodium));
const expiresAt = new Date(Date.now() + 7 * 86400000).toISOString();

// 1) 서버 등록
{
  const r = await req('POST', '/requests', { auth: device, body: { token, publicKey, formSchema: FORM_SCHEMA, title: FORM_SCHEMA.title, expiresAt } });
  ok('POST /requests 200', r.status === 200 && r.json?.ok === true);
}
// 중복 토큰 등록 → 409
{
  const r = await req('POST', '/requests', { auth: device, body: { token, publicKey, formSchema: FORM_SCHEMA, title: 'x', expiresAt } });
  ok('중복 토큰 409', r.status === 409);
}
// 인증 없는 등록 → 401
{
  const r = await req('POST', '/requests', { body: { token: 'x', publicKey, formSchema: FORM_SCHEMA, title: 'x', expiresAt } });
  ok('무인증 등록 401', r.status === 401);
}

// 2) 보호자: 폼 데이터 조회(공개)
{
  const r = await req('GET', '/api/f/' + token);
  ok('GET form 200', r.status === 200);
  eq('공개키 전달 일치', r.json?.publicKey, publicKey);
  eq('스키마 전달 일치', r.json?.formSchema, FORM_SCHEMA);
}

// 3) 보호자: 브라우저 번들로 암호화 후 제출
const ciphertext = browserSodium.to_base64(
  browserSodium.crypto_box_seal(browserSodium.from_string(JSON.stringify(ANSWERS)), browserSodium.from_base64(publicKey, B64(browserSodium))),
  B64(browserSodium),
);
{
  const r = await req('POST', '/api/f/' + token + '/submit', { body: { ciphertext } });
  ok('제출 200', r.status === 200 && r.json?.ok === true);
}
// 1회용: 재제출 → 409
{
  const r = await req('POST', '/api/f/' + token + '/submit', { body: { ciphertext } });
  ok('재제출 차단 409', r.status === 409);
}
// 제출 후 폼 조회 → 409 (이미 제출됨)
{
  const r = await req('GET', '/api/f/' + token);
  ok('제출 후 폼 409', r.status === 409);
}

// 4) 앱: pending 수령(소유 디바이스)
let pendingCt = null;
{
  const r = await req('GET', '/requests/pending', { auth: device });
  ok('pending 200', r.status === 200);
  const item = (r.json?.requests || []).find((x) => x.token === token);
  ok('pending에 우리 토큰 존재', !!item);
  pendingCt = item?.ciphertext;
  eq('서버가 보관한 암호문 == 제출 암호문', pendingCt, ciphertext);
}
// 다른 디바이스는 못 봄(소유 격리)
{
  const r = await req('GET', '/requests/pending', { auth: otherDevice });
  const item = (r.json?.requests || []).find((x) => x.token === token);
  ok('타 디바이스 격리(못 봄)', !item);
}

// 5) 영지식: 앱 개인키로만 복호 성공 / 서버(공개키만)는 불가
{
  const opened = appSodium.to_string(
    appSodium.crypto_box_seal_open(appSodium.from_base64(pendingCt, B64(appSodium)), kp.publicKey, kp.privateKey),
  );
  eq('교차 복호 원문 일치(앱↔브라우저 interop)', JSON.parse(opened), ANSWERS);

  // 서버가 가진 정보(공개키)만으로 복호 시도 → 개인키가 없어 불가능함을 모사
  let serverFailed = false;
  try {
    const fakePriv = appSodium.crypto_box_keypair().privateKey; // 서버는 진짜 개인키 부재
    appSodium.crypto_box_seal_open(appSodium.from_base64(pendingCt, B64(appSodium)), kp.publicKey, fakePriv);
  } catch { serverFailed = true; }
  ok('개인키 없이 복호 불가(영지식)', serverFailed);
}

// 6) ack → 암호문 파기
{
  const r = await req('POST', '/requests/' + token + '/ack', { auth: device });
  ok('ack 200', r.status === 200 && r.json?.ok === true);
}
// 타 디바이스 ack는 거부(이미 처리됐지만 소유 검증)
{
  const r = await req('POST', '/requests/' + token + '/ack', { auth: otherDevice });
  ok('타 디바이스 ack 404', r.status === 404);
}
// 파기 확인: pending 비어있음
{
  const r = await req('GET', '/requests/pending', { auth: device });
  const item = (r.json?.requests || []).find((x) => x.token === token);
  ok('파기 후 pending 없음', !item);
}

// ── 만료 흐름 ─────────────────────────────────────────────────────────────────
{
  const expToken = randomBytes(18).toString('base64url');
  const past = new Date(Date.now() - 1000).toISOString();
  await req('POST', '/requests', { auth: device, body: { token: expToken, publicKey, formSchema: FORM_SCHEMA, title: 't', expiresAt: past } });
  const g = await req('GET', '/api/f/' + expToken);
  ok('만료 폼 조회 410', g.status === 410);
  const s = await req('POST', '/api/f/' + expToken + '/submit', { body: { ciphertext } });
  ok('만료 제출 410', s.status === 410);
}

// ── 잘못된 입력 ───────────────────────────────────────────────────────────────
{
  const okToken = randomBytes(18).toString('base64url');
  await req('POST', '/requests', { auth: device, body: { token: okToken, publicKey, formSchema: FORM_SCHEMA, title: 't', expiresAt } });
  const bad = await req('POST', '/api/f/' + okToken + '/submit', { body: { ciphertext: '@@@not-base64@@@' } });
  ok('비base64 암호문 400', bad.status === 400);
  const missing = await req('POST', '/api/f/' + okToken + '/submit', { body: {} });
  ok('암호문 누락 400', missing.status === 400);
}

console.log(`\n[flow] pass ${pass}, fail ${fails.length}`);
if (fails.length) { console.error('FAILED:', fails.join(', ')); process.exit(1); }
console.log('✅ 전체 흐름 검증 통과 (영지식 / 1회용 / 만료 / 소유격리 / 교차 interop)');
