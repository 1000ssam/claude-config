/**
 * 보호자 폼 실브라우저 E2E (Playwright + 실제 Chromium).
 * flow.mjs가 검증 못한 마지막 층 — 폼의 DOM 렌더·필수검증·서명 캔버스·클라이언트 암호화 제출을
 * 진짜 브라우저로 구동하고, 그 결과를 앱 개인키로 복호해 일치를 확인한다.
 *
 * 실행(워크트리 루트에서, libsodium 해석): node cloudflare/test/form.e2e.mjs http://127.0.0.1:8787
 * 의존: playwright-core(절대경로) + ~/.cache/ms-playwright chromium.
 */

import { randomBytes } from 'node:crypto';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const PW = process.env.PW_CORE || '/mnt/c/dev/running-challenge-3/node_modules/playwright-core';
const { chromium } = require(PW);
const CHROME = process.env.CHROME_BIN || '/home/user/.cache/ms-playwright/chromium-1223/chrome-linux64/chrome';

const sodium = (await import('libsodium-wrappers')).default;
await sodium.ready;
const B = sodium.base64_variants.ORIGINAL;
const BASE = (process.argv[2] || 'http://127.0.0.1:8787').replace(/\/$/, '');

let pass = 0;
const fails = [];
const ok = (n, c) => { if (c) pass++; else { fails.push(n); console.error('  ❌ ' + n); } };

// 1) 앱: 키쌍 + 요청 등록
const device = randomBytes(32).toString('hex');
const token = randomBytes(18).toString('base64url');
const kp = sodium.crypto_box_keypair();
const publicKey = sodium.to_base64(kp.publicKey, B);
const schema = {
  version: 1, title: '동의서 실브라우저 E2E', intro: '미성년자 법정대리인 동의 안내',
  fields: [
    { key: 'guardian_name', type: 'text', label: '보호자 성명', required: true },
    { key: 'rel', type: 'select', label: '관계', required: true, options: ['부', '모', '기타'] },
    { key: 'consent_privacy', type: 'consent', label: '개인정보 수집·이용 동의', required: true, description: '수집 항목·목적·보관기간 고지' },
    { key: 'note', type: 'textarea', label: '전달사항', required: false },
    { key: 'signature', type: 'signature', label: '전자서명', required: true },
  ],
};
let r = await fetch(BASE + '/requests', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + device },
  body: JSON.stringify({ token, publicKey, formSchema: schema, title: schema.title, expiresAt: new Date(Date.now() + 7 * 864e5).toISOString() }),
});
ok('요청 등록', r.ok);

// 2) 브라우저로 폼 로드
const browser = await chromium.launch({ executablePath: CHROME, headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage();
const pageErrors = [];
page.on('pageerror', (e) => pageErrors.push(String(e)));
await page.goto(BASE + '/f/' + token, { waitUntil: 'networkidle' });
await page.waitForSelector('#submitBtn', { timeout: 15000 });

// 스키마 주도 렌더 확인
ok('단답 필드 렌더', !!(await page.$('input[data-key="guardian_name"]')));
ok('드롭다운 렌더', !!(await page.$('select[data-key="rel"]')));
ok('동의 체크 렌더', !!(await page.$('input[data-key="consent_privacy"]')));
ok('서명 캔버스 렌더', !!(await page.$('canvas[data-key="signature"]')));

// 3) 빈 제출 → 필수검증으로 막힘(성공화면 미도달)
await page.click('#submitBtn');
await page.waitForTimeout(300);
const nameErrShown = await page.$eval('#err_guardian_name', (el) => el.classList.contains('show')).catch(() => false);
ok('빈 제출 시 필수 에러 표시', nameErrShown);
// 렌더된 #root 텍스트로 확인(전체 HTML엔 인라인 스크립트 소스가 섞여 오탐).
const rootEmpty = await page.$eval('#root', (el) => el.textContent || '');
ok('빈 제출 시 성공화면 미도달', !rootEmpty.includes('제출 완료'));

// 4) 채우기 + 서명 드로잉
await page.fill('input[data-key="guardian_name"]', '김보호');
await page.selectOption('select[data-key="rel"]', '모');
await page.fill('textarea[data-key="note"]', '오후에 연락 부탁드립니다');
await page.check('input[data-key="consent_privacy"]');
const box = await page.$eval('canvas[data-key="signature"]', (el) => { const b = el.getBoundingClientRect(); return { x: b.x, y: b.y }; });
await page.mouse.move(box.x + 20, box.y + 20);
await page.mouse.down();
await page.mouse.move(box.x + 90, box.y + 60, { steps: 10 });
await page.mouse.move(box.x + 140, box.y + 25, { steps: 10 });
await page.mouse.up();

// 5) 제출 → 성공화면
await page.click('#submitBtn');
await page.waitForFunction(() => (document.querySelector('#root')?.textContent || '').includes('제출 완료'), { timeout: 15000 }).catch(() => {});
ok('제출 성공화면 도달', (await page.$eval('#root', (el) => el.textContent || '')).includes('제출 완료'));
ok('브라우저 콘솔 에러 없음', pageErrors.length === 0 || (console.error('pageerrors:', pageErrors), false));
await browser.close();

// 6) 앱: 수령 + 복호 일치 (브라우저 libsodium → 앱 복호)
r = await fetch(BASE + '/requests/pending', { headers: { Authorization: 'Bearer ' + device } });
const data = await r.json();
const item = (data.requests || []).find((x) => x.token === token);
ok('서버에 암호문 수령', !!(item && item.ciphertext));
if (item && item.ciphertext) {
  const plain = sodium.to_string(sodium.crypto_box_seal_open(sodium.from_base64(item.ciphertext, B), kp.publicKey, kp.privateKey));
  const ans = JSON.parse(plain);
  ok('복호: 성명 일치', ans.guardian_name === '김보호');
  ok('복호: 관계 일치', ans.rel === '모');
  ok('복호: 전달사항 일치', ans.note === '오후에 연락 부탁드립니다');
  ok('복호: 동의 true', ans.consent_privacy === true);
  ok('복호: 서명 dataURL', typeof ans.signature === 'string' && ans.signature.startsWith('data:image'));
}

console.log(`\n[form.e2e] pass ${pass}, fail ${fails.length}`);
if (fails.length) { console.error('FAILED:', fails.join(', ')); process.exit(1); }
console.log('✅ 실브라우저 폼 E2E 통과: 렌더·필수검증·서명·클라이언트 암호화 → 앱 복호 일치');
