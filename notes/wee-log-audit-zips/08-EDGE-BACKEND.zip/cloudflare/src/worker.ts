/**
 * 동의서 영지식 서버 — Cloudflare Worker (단일 배포: API + 보호자 폼).
 *
 * 신뢰경계: 서버는 평문 응답·개인키를 절대 보지 못한다. 보관 데이터는
 * {token, device_hash, public_key, title, form_schema(평문 질문), ciphertext, status, timestamps}뿐.
 *
 * 라우팅:
 *   GET  /                       정보 페이지
 *   GET  /health                 헬스체크
 *   GET  /f/:token               보호자 폼(HTML)
 *   GET  /api/f/:token           폼 스키마 + 공개키(공개)
 *   POST /api/f/:token/submit    암호문 제출(공개)
 *   POST /requests               요청 등록(디바이스 인증)
 *   GET  /requests/pending       응답완료 암호문 수령(디바이스 인증)
 *   POST /requests/:token/ack    암호문 파기(디바이스 인증)
 */

import { renderFormPage } from './form-page';

export interface Env {
  DB: D1Database;
  MAX_CIPHERTEXT_BYTES: string;
  ALLOW_RESUBMIT: string;
}

interface RequestRow {
  token: string;
  device_hash: string;
  public_key: string;
  title: string;
  form_schema: string;
  ciphertext: string | null;
  status: string;
  created_at: string;
  submitted_at: string | null;
  expires_at: string;
}

const json = (data: unknown, status = 200): Response =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
  });

const nowIso = (): string => new Date().toISOString();

async function sha256Hex(input: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(input));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

function bearer(req: Request): string | null {
  const h = req.headers.get('Authorization') || '';
  const m = h.match(/^Bearer\s+(.+)$/i);
  return m ? m[1].trim() : null;
}

function isExpired(row: RequestRow): boolean {
  return new Date(row.expires_at).getTime() <= Date.now();
}

// ── 디바이스 인증 엔드포인트 ────────────────────────────────────────────────────

async function handleCreate(req: Request, env: Env): Promise<Response> {
  const token = bearer(req);
  if (!token) return json({ error: 'unauthorized' }, 401);

  let body: {
    token?: string;
    publicKey?: string;
    formSchema?: unknown;
    title?: string;
    expiresAt?: string;
  };
  try {
    body = await req.json();
  } catch {
    return json({ error: 'invalid json' }, 400);
  }

  if (
    !body.token ||
    !body.publicKey ||
    !body.formSchema ||
    !body.title ||
    !body.expiresAt
  ) {
    return json({ error: 'missing fields' }, 400);
  }
  // 토큰/공개키/만료/스키마 형식·크기 검증
  if (!/^[A-Za-z0-9_-]{16,64}$/.test(body.token)) return json({ error: 'bad token' }, 400);
  if (!/^[A-Za-z0-9+/=]{40,}$/.test(body.publicKey)) return json({ error: 'bad publicKey' }, 400);
  if (Number.isNaN(new Date(body.expiresAt).getTime())) return json({ error: 'bad expiresAt' }, 400);
  const schemaStr = JSON.stringify(body.formSchema);
  if (schemaStr.length > 65_536) return json({ error: 'schema too large' }, 413);
  const fields = (body.formSchema as { fields?: unknown[] }).fields;
  if (!Array.isArray(fields) || fields.length === 0 || fields.length > 100) {
    return json({ error: 'bad schema' }, 400);
  }

  const deviceHash = await sha256Hex(token);
  try {
    await env.DB.prepare(
      `INSERT INTO consent_requests
         (token, device_hash, public_key, title, form_schema, status, created_at, expires_at)
       VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)`,
    )
      .bind(
        body.token,
        deviceHash,
        body.publicKey,
        String(body.title).slice(0, 200),
        schemaStr,
        nowIso(),
        body.expiresAt,
      )
      .run();
  } catch (e) {
    // token UNIQUE 충돌 등
    return json({ error: 'create failed', detail: String((e as Error).message).slice(0, 120) }, 409);
  }
  return json({ ok: true });
}

async function handlePending(req: Request, env: Env): Promise<Response> {
  const token = bearer(req);
  if (!token) return json({ error: 'unauthorized' }, 401);
  const deviceHash = await sha256Hex(token);

  const { results } = await env.DB.prepare(
    `SELECT token, ciphertext, submitted_at
       FROM consent_requests
      WHERE device_hash = ? AND status = 'responded' AND ciphertext IS NOT NULL`,
  )
    .bind(deviceHash)
    .all<{ token: string; ciphertext: string; submitted_at: string }>();

  return json({
    requests: (results || []).map((r) => ({
      token: r.token,
      ciphertext: r.ciphertext,
      submittedAt: r.submitted_at,
    })),
  });
}

async function handleAck(req: Request, env: Env, token: string): Promise<Response> {
  const auth = bearer(req);
  if (!auth) return json({ error: 'unauthorized' }, 401);
  const deviceHash = await sha256Hex(auth);

  // 암호문 파기 + acked. 소유 디바이스만.
  const res = await env.DB.prepare(
    `UPDATE consent_requests
        SET ciphertext = NULL, status = 'acked'
      WHERE token = ? AND device_hash = ?`,
  )
    .bind(token, deviceHash)
    .run();

  if (!res.meta.changes) return json({ error: 'not found' }, 404);
  return json({ ok: true });
}

// 재발송 무효화: 옛 링크를 '만료'시킨다(ack=제출완료와 구분).
//   expires_at=now → 보호자 GET이 410을 받아 "만료된 링크"로 안내(409 "이미 제출됨"이 아님).
async function handleRevoke(req: Request, env: Env, token: string): Promise<Response> {
  const auth = bearer(req);
  if (!auth) return json({ error: 'unauthorized' }, 401);
  const deviceHash = await sha256Hex(auth);

  // expires_at=now 로 즉시 만료 → 보호자 GET/submit이 isExpired 검사에서 410.
  //   (status는 CHECK 제약(pending/responded/acked)이 있어 새 값 못 넣음 → 만료시각만 당긴다.)
  const res = await env.DB.prepare(
    `UPDATE consent_requests
        SET ciphertext = NULL, expires_at = ?
      WHERE token = ? AND device_hash = ?`,
  )
    .bind(new Date(Date.now() - 1000).toISOString(), token, deviceHash)
    .run();

  if (!res.meta.changes) return json({ error: 'not found' }, 404);
  return json({ ok: true });
}

// ── 공개(보호자) 엔드포인트 ────────────────────────────────────────────────────

async function handleFormData(env: Env, token: string): Promise<Response> {
  const row = await env.DB.prepare(
    'SELECT * FROM consent_requests WHERE token = ?',
  )
    .bind(token)
    .first<RequestRow>();

  if (!row) return json({ error: 'not_found' }, 404);
  if (isExpired(row)) return json({ error: 'expired' }, 410);
  if (row.status !== 'pending') return json({ error: 'already_submitted' }, 409);

  return json({
    title: row.title,
    formSchema: JSON.parse(row.form_schema),
    publicKey: row.public_key,
    expiresAt: row.expires_at,
  });
}

async function handleSubmit(req: Request, env: Env, token: string): Promise<Response> {
  const row = await env.DB.prepare(
    'SELECT * FROM consent_requests WHERE token = ?',
  )
    .bind(token)
    .first<RequestRow>();

  if (!row) return json({ error: 'not_found' }, 404);
  if (isExpired(row)) return json({ error: 'expired' }, 410);
  if (row.status !== 'pending' && env.ALLOW_RESUBMIT !== 'true') {
    return json({ error: 'already_submitted' }, 409);
  }

  let body: { ciphertext?: string };
  try {
    body = await req.json();
  } catch {
    return json({ error: 'invalid_json' }, 400);
  }
  const ct = body.ciphertext;
  const maxBytes = Number(env.MAX_CIPHERTEXT_BYTES || '262144');
  if (!ct || typeof ct !== 'string') return json({ error: 'missing_ciphertext' }, 400);
  if (!/^[A-Za-z0-9+/=]+$/.test(ct)) return json({ error: 'bad_ciphertext' }, 400);
  if (ct.length > maxBytes) return json({ error: 'too_large' }, 413);

  // 원자적 제출: WHERE에 상태 조건을 넣어 동시 제출 레이스를 닫는다(단일 D1 statement는 원자적).
  // status 조건에 맞는 단 하나만 성공하고, 나머지는 changes=0 → 409.
  const allowResubmit = env.ALLOW_RESUBMIT === 'true';
  const res = await env.DB.prepare(
    allowResubmit
      ? `UPDATE consent_requests SET ciphertext = ?, status = 'responded', submitted_at = ?
           WHERE token = ? AND status IN ('pending', 'responded')`
      : `UPDATE consent_requests SET ciphertext = ?, status = 'responded', submitted_at = ?
           WHERE token = ? AND status = 'pending'`,
  )
    .bind(ct, nowIso(), token)
    .run();

  if (!res.meta.changes) return json({ error: 'already_submitted' }, 409);
  return json({ ok: true });
}

// ── 라우터 ──────────────────────────────────────────────────────────────────────

export default {
  async fetch(req: Request, env: Env): Promise<Response> {
    const url = new URL(req.url);
    const path = url.pathname;
    const method = req.method.toUpperCase();

    try {
      if (path === '/health') return json({ ok: true, ts: nowIso() });

      if (path === '/' && method === 'GET') {
        return new Response(
          '<!doctype html><meta charset="utf-8"><title>Wee 동의서</title>' +
            '<body style="font-family:sans-serif;padding:2rem;color:#334"><h1>Wee 상담 동의서 서버</h1>' +
            '<p>이 서버는 암호화된 응답만 보관하며 평문을 보지 못합니다(영지식).</p></body>',
          { headers: { 'Content-Type': 'text/html; charset=utf-8' } },
        );
      }

      // 보호자 폼 HTML
      const formMatch = path.match(/^\/f\/([^/]+)$/);
      if (formMatch && method === 'GET') {
        return new Response(renderFormPage(formMatch[1]), {
          headers: {
            'Content-Type': 'text/html; charset=utf-8',
            'Cache-Control': 'no-store',
            'X-Content-Type-Options': 'nosniff',
          },
        });
      }

      // 공개 API
      const apiGet = path.match(/^\/api\/f\/([^/]+)$/);
      if (apiGet && method === 'GET') return await handleFormData(env, apiGet[1]);

      const apiSubmit = path.match(/^\/api\/f\/([^/]+)\/submit$/);
      if (apiSubmit && method === 'POST') return await handleSubmit(req, env, apiSubmit[1]);

      // 디바이스 인증 API
      if (path === '/requests' && method === 'POST') return await handleCreate(req, env);
      if (path === '/requests/pending' && method === 'GET') return await handlePending(req, env);

      const ackMatch = path.match(/^\/requests\/([^/]+)\/ack$/);
      if (ackMatch && method === 'POST') return await handleAck(req, env, ackMatch[1]);

      const revokeMatch = path.match(/^\/requests\/([^/]+)\/revoke$/);
      if (revokeMatch && method === 'POST') return await handleRevoke(req, env, revokeMatch[1]);

      return json({ error: 'not_found' }, 404);
    } catch (e) {
      return json({ error: 'server_error', detail: String((e as Error).message).slice(0, 160) }, 500);
    }
  },

  // 만료/파기 정리: 만료된 pending/responded는 암호문 제거, 오래된 acked는 삭제.
  async scheduled(_event: ScheduledController, env: Env): Promise<void> {
    const now = nowIso();
    // 만료된 요청의 암호문 파기(평문 응답 잔류 방지)
    await env.DB.prepare(
      `UPDATE consent_requests SET ciphertext = NULL, status = 'acked'
        WHERE expires_at <= ? AND ciphertext IS NOT NULL`,
    )
      .bind(now)
      .run();
    // 만료 30일 경과한 tombstone 삭제
    const cutoff = new Date(Date.now() - 30 * 86_400_000).toISOString();
    await env.DB.prepare('DELETE FROM consent_requests WHERE expires_at <= ?').bind(cutoff).run();
  },
};
