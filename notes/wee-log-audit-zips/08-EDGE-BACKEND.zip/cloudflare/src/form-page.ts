/**
 * 보호자 폼 HTML 렌더러.
 *
 * 데이터 주도: 스키마는 /api/f/:token 에서 받아 클라이언트가 렌더.
 * E2E: 응답 JSON은 브라우저에서 libsodium sealed box(앱 공개키)로 암호화 후 제출.
 *      평문은 브라우저를 떠나지 않는다(암호문만 전송).
 * libsodium은 동일 출처(/sodium-wrappers.mjs)에서 로드 — CDN 공급망 리스크 제거.
 * 모바일 우선: 입력 글꼴 16px(iOS 자동 줌 방지), 터치 서명 지원.
 */

export function renderFormPage(token: string): string {
  const safeToken = token.replace(/[^A-Za-z0-9_-]/g, '');
  return `<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<meta name="robots" content="noindex, nofollow" />
<title>상담 접수 동의서</title>
<style>
  :root { --bg:#f4f5f7; --card:#fff; --fg:#1f2430; --muted:#6b7280; --line:#e5e7eb; --primary:#2563eb; --primary-press:#1d4ed8; --danger:#dc2626; --ok:#059669; }
  * { box-sizing: border-box; }
  html, body { margin:0; padding:0; background:var(--bg); color:var(--fg);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Pretendard', 'Noto Sans KR', sans-serif; -webkit-text-size-adjust:100%; }
  .wrap { max-width: 560px; margin: 0 auto; padding: 16px 16px 48px; }
  .card { background:var(--card); border:1px solid var(--line); border-radius:14px; padding:18px 16px; margin-bottom:14px; }
  h1 { font-size:19px; line-height:1.4; margin:6px 0 2px; }
  .intro { font-size:13.5px; color:var(--muted); line-height:1.7; white-space:pre-wrap; }
  label.field { display:block; margin-top:16px; }
  .field > .lab { font-size:14px; font-weight:600; margin-bottom:6px; display:block; }
  .req { color:var(--danger); margin-left:3px; }
  input[type=text], input[type=date], textarea, select {
    width:100%; font-size:16px; /* iOS 줌 방지 */ padding:11px 12px; border:1px solid var(--line);
    border-radius:10px; background:#fff; color:var(--fg); font-family:inherit; }
  textarea { min-height:88px; resize:vertical; line-height:1.6; }
  select { appearance:none; -webkit-appearance:none; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='%236b7280' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 10px center; padding-right:38px; }
  .radio-row, .check-row { display:flex; align-items:flex-start; gap:9px; padding:9px 0; }
  .radio-row input, .check-row input { width:20px; height:20px; margin-top:1px; flex:0 0 auto; }
  .consent-box { border:1px solid var(--line); border-radius:10px; background:#fafbfc; padding:12px; margin-top:6px; }
  .consent-text { font-size:13px; color:var(--muted); line-height:1.7; white-space:pre-wrap; margin-bottom:8px; }
  .sig-pad { border:1.5px dashed #c3c9d4; border-radius:10px; background:#fff; touch-action:none; width:100%; height:170px; display:block; }
  .sig-actions { display:flex; justify-content:flex-end; margin-top:6px; }
  .link-btn { background:none; border:none; color:var(--primary); font-size:13px; cursor:pointer; padding:4px; }
  .hint { font-size:12px; color:var(--muted); margin-top:5px; }
  .err { font-size:12.5px; color:var(--danger); margin-top:5px; display:none; }
  .err.show { display:block; }
  .submit { width:100%; font-size:16px; font-weight:600; color:#fff; background:var(--primary); border:none;
    border-radius:12px; padding:15px; margin-top:18px; cursor:pointer; }
  .submit:active { background:var(--primary-press); }
  .submit:disabled { opacity:.55; cursor:default; }
  .state { text-align:center; padding:40px 16px; }
  .state h2 { font-size:18px; } .state p { color:var(--muted); font-size:14px; line-height:1.7; }
  .badge-ok { color:var(--ok); font-size:40px; }
  .footer { text-align:center; font-size:11.5px; color:var(--muted); margin-top:18px; line-height:1.6; }
  .skel { color:var(--muted); text-align:center; padding:48px 0; }
</style>
</head>
<body>
<div class="wrap">
  <div id="root"><div class="skel">불러오는 중…</div></div>
  <div class="footer">제출 내용은 이 기기에서 암호화되어 전송되며, 서버는 내용을 열람할 수 없습니다.<br/>(종단간 암호화 / 영지식)</div>
</div>

<script type="module">
import sodium from '/sodium-wrappers.mjs';

const TOKEN = ${JSON.stringify(safeToken)};
const root = document.getElementById('root');
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function stateMsg(title, body, ok) {
  root.innerHTML = '<div class="card state">' +
    (ok ? '<div class="badge-ok"><svg viewBox="0 0 24 24" width="44" height="44" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg></div>' : '') +
    '<h2>' + esc(title) + '</h2><p>' + esc(body) + '</p></div>';
}

let SCHEMA = null, PUBKEY = null, sigPads = {};

async function boot() {
  let data;
  try {
    const res = await fetch('/api/f/' + encodeURIComponent(TOKEN));
    if (res.status === 410) return stateMsg('만료된 링크', '이 동의서 링크는 만료되었습니다. 상담 선생님께 재발송을 요청해 주세요.', false);
    if (res.status === 409) return stateMsg('이미 제출됨', '이 동의서는 이미 제출되었습니다. 감사합니다.', true);
    if (res.status === 404) return stateMsg('잘못된 링크', '유효하지 않은 링크입니다. 주소를 다시 확인해 주세요.', false);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    data = await res.json();
  } catch (e) {
    return stateMsg('불러오기 실패', '네트워크 상태를 확인하고 다시 시도해 주세요.', false);
  }
  SCHEMA = data.formSchema; PUBKEY = data.publicKey;
  await sodium.ready;
  render();
}

// 안내 도움말(보호자 폼에 항상 보이는 설명) — description이 있으면 표시.
function hint(f) {
  return f.description ? '<div class="hint">' + esc(f.description) + '</div>' : '';
}

function fieldHtml(f) {
  const id = 'f_' + f.key;
  const reqMark = f.required ? '<span class="req">*</span>' : '';
  const lab = '<span class="lab">' + esc(f.label) + reqMark + '</span>';
  const errEl = '<div class="err" role="alert" id="err_' + esc(f.key) + '"></div>';
  switch (f.type) {
    case 'textarea':
      return '<label class="field" for="' + id + '">' + lab + hint(f) +
        '<textarea id="' + id + '" data-key="' + esc(f.key) + '" placeholder="' + esc(f.placeholder||'') + '"></textarea>' + errEl + '</label>';
    case 'select':
      // 다중 선택 → 체크박스(배열), 단일 → 드롭다운.
      if (f.multiple) {
        return '<div class="field">' + lab + hint(f) +
          (f.options||[]).map((o) => '<label class="check-row"><input type="checkbox" data-multi="' + esc(f.key) + '" value="' + esc(o) + '"/> <span>' + esc(o) + '</span></label>').join('') +
          errEl + '</div>';
      }
      return '<label class="field" for="' + id + '">' + lab + hint(f) +
        '<select id="' + id + '" data-key="' + esc(f.key) + '"><option value="">선택하세요</option>' +
        (f.options||[]).map((o) => '<option value="' + esc(o) + '">' + esc(o) + '</option>').join('') +
        '</select>' + errEl + '</label>';
    case 'radio':
      return '<div class="field">' + lab +
        (f.options||[]).map((o) => '<label class="radio-row"><input type="radio" name="' + id + '" data-key="' + esc(f.key) + '" value="' + esc(o) + '"/> <span>' + esc(o) + '</span></label>').join('') +
        errEl + '</div>';
    case 'checkbox':
      return '<div class="field"><label class="check-row"><input type="checkbox" data-key="' + esc(f.key) + '" /> <span>' + esc(f.label) + reqMark + '</span></label>' + errEl + '</div>';
    case 'consent':
      return '<div class="field"><span class="lab">' + esc(f.label) + reqMark + '</span>' +
        '<div class="consent-box">' + (f.description ? '<div class="consent-text">' + esc(f.description) + '</div>' : '') +
        '<label class="check-row"><input type="checkbox" data-key="' + esc(f.key) + '" /> <span>위 내용에 동의합니다.</span></label></div>' + errEl + '</div>';
    case 'date':
      return '<label class="field" for="' + id + '">' + lab +
        '<input type="date" id="' + id + '" data-key="' + esc(f.key) + '" />' + errEl + '</label>';
    case 'signature':
      return '<div class="field"><span class="lab">' + esc(f.label) + reqMark + '</span>' +
        (f.description ? '<div class="hint">' + esc(f.description) + '</div>' : '') +
        '<canvas class="sig-pad" data-key="' + esc(f.key) + '" id="' + id + '"></canvas>' +
        '<div class="sig-actions"><button type="button" class="link-btn" data-clear="' + esc(f.key) + '">지우기</button></div>' + errEl + '</div>';
    default: // text
      return '<label class="field" for="' + id + '">' + lab + hint(f) +
        '<input type="text" id="' + id + '" data-key="' + esc(f.key) + '" placeholder="' + esc(f.placeholder||'') + '" />' + errEl + '</label>';
  }
}

function render() {
  let html = '<div class="card"><h1>' + esc(SCHEMA.title) + '</h1>' +
    (SCHEMA.intro ? '<div class="intro">' + esc(SCHEMA.intro) + '</div>' : '') + '</div>';
  html += '<div class="card">' + SCHEMA.fields.map(fieldHtml).join('') +
    '<button class="submit" id="submitBtn">제출하기</button>' +
    '<div class="err" role="alert" id="submit_err" style="text-align:center;margin-top:8px"></div></div>';
  root.innerHTML = html;
  SCHEMA.fields.filter((f) => f.type === 'signature').forEach(initSigPad);
  document.getElementById('submitBtn').addEventListener('click', onSubmit);
}

function initSigPad(f) {
  const canvas = document.querySelector('canvas[data-key="' + cssEsc(f.key) + '"]');
  const ratio = Math.max(window.devicePixelRatio || 1, 1);
  const rect = canvas.getBoundingClientRect();
  canvas.width = rect.width * ratio; canvas.height = rect.height * ratio;
  const ctx = canvas.getContext('2d');
  ctx.scale(ratio, ratio); ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.strokeStyle = '#1f2430';
  let drawing = false, dirty = false;
  const pos = (e) => { const r = canvas.getBoundingClientRect(); const t = e.touches ? e.touches[0] : e; return { x: t.clientX - r.left, y: t.clientY - r.top }; };
  const start = (e) => {
    drawing = true; dirty = true; const p = pos(e);
    // 단일 탭도 점으로 보이게 — 빈 서명처럼 오인되지 않도록.
    ctx.beginPath(); ctx.arc(p.x, p.y, 1.2, 0, Math.PI * 2); ctx.fillStyle = '#1f2430'; ctx.fill();
    ctx.beginPath(); ctx.moveTo(p.x, p.y);
    e.preventDefault();
  };
  const move = (e) => { if (!drawing) return; const p = pos(e); ctx.lineTo(p.x, p.y); ctx.stroke(); e.preventDefault(); };
  const end = () => { drawing = false; };
  canvas.addEventListener('mousedown', start); canvas.addEventListener('mousemove', move); window.addEventListener('mouseup', end);
  canvas.addEventListener('touchstart', start, { passive: false }); canvas.addEventListener('touchmove', move, { passive: false }); canvas.addEventListener('touchend', end);
  sigPads[f.key] = { canvas, isDirty: () => dirty, clear: () => { ctx.clearRect(0, 0, canvas.width, canvas.height); dirty = false; } };
  const btn = document.querySelector('button[data-clear="' + cssEsc(f.key) + '"]');
  if (btn) btn.addEventListener('click', () => sigPads[f.key].clear());
}

function cssEsc(s) { return String(s).replace(/["\\\\]/g, '\\\\$&'); }

function setErr(key, msg) {
  const el = document.getElementById('err_' + key);
  if (el) { el.textContent = msg || ''; el.classList.toggle('show', !!msg); }
}

function collect() {
  const answers = {}; let firstErr = null;
  for (const f of SCHEMA.fields) {
    setErr(f.key, '');
    let val;
    if (f.type === 'signature') {
      const pad = sigPads[f.key];
      val = pad && pad.isDirty() ? pad.canvas.toDataURL('image/png') : '';
    } else if (f.type === 'checkbox' || f.type === 'consent') {
      const el = document.querySelector('input[data-key="' + cssEsc(f.key) + '"]');
      val = !!(el && el.checked);
    } else if (f.type === 'select' && f.multiple) {
      const els = document.querySelectorAll('input[data-multi="' + cssEsc(f.key) + '"]:checked');
      val = Array.from(els).map((e) => e.value);
    } else if (f.type === 'radio') {
      const el = document.querySelector('input[data-key="' + cssEsc(f.key) + '"]:checked');
      val = el ? el.value : '';
    } else {
      const el = document.querySelector('[data-key="' + cssEsc(f.key) + '"]');
      val = el ? el.value.trim() : '';
    }
    // 필수 검증
    const empty = (f.type === 'checkbox' || f.type === 'consent') ? val !== true
      : Array.isArray(val) ? val.length === 0
      : !val;
    if (f.required && empty) {
      const m = (f.type === 'consent' || f.type === 'checkbox') ? '동의가 필요합니다.'
        : (f.type === 'signature') ? '서명이 필요합니다.' : '필수 항목입니다.';
      setErr(f.key, m); if (!firstErr) firstErr = f.key;
    }
    answers[f.key] = val;
  }
  return { answers, firstErr };
}

async function onSubmit() {
  const btn = document.getElementById('submitBtn');
  const se = document.getElementById('submit_err');
  if (se) { se.textContent = ''; se.classList.remove('show'); }
  const { answers, firstErr } = collect();
  if (firstErr) { const el = document.getElementById('err_' + firstErr); if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }
  btn.disabled = true; btn.textContent = '암호화 중…';
  try {
    const plaintext = JSON.stringify(answers);
    const pk = sodium.from_base64(PUBKEY, sodium.base64_variants.ORIGINAL);
    const ct = sodium.crypto_box_seal(sodium.from_string(plaintext), pk);
    const ciphertext = sodium.to_base64(ct, sodium.base64_variants.ORIGINAL);
    btn.textContent = '전송 중…';
    const res = await fetch('/api/f/' + encodeURIComponent(TOKEN) + '/submit', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ciphertext }),
    });
    if (res.status === 409) return stateMsg('이미 제출됨', '이 동의서는 이미 제출되었습니다. 감사합니다.', true);
    if (res.status === 410) return stateMsg('만료됨', '링크가 만료되어 제출할 수 없습니다.', false);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    stateMsg('제출 완료', '동의서가 안전하게 제출되었습니다. 감사합니다.', true);
  } catch (e) {
    btn.disabled = false; btn.textContent = '제출하기';
    if (se) { se.textContent = '전송에 실패했습니다. 네트워크 상태를 확인하고 다시 시도해 주세요.'; se.classList.add('show'); }
  }
}

boot();
</script>
</body>
</html>`;
}
