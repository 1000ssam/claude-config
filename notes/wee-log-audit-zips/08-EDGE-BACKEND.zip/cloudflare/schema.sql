-- 동의서 영지식 서버 D1 스키마.
-- 평문 PII 0: 서버는 공개키/평문 질문/암호문/상태/타임스탬프만 보관한다.
-- 응답 평문과 개인키는 절대 서버에 존재하지 않는다.

CREATE TABLE IF NOT EXISTS consent_requests (
  token       TEXT PRIMARY KEY,           -- 1회용 접속 토큰(앱 생성)
  device_hash TEXT NOT NULL,              -- sha256(디바이스 bearer) — 소유 디바이스만 수합/파기
  public_key  TEXT NOT NULL,              -- sealed-box 공개키(base64)
  title       TEXT NOT NULL,              -- 폼 제목(평문)
  form_schema TEXT NOT NULL,              -- JSON 폼 스키마(평문 질문 — PII 없음)
  ciphertext  TEXT,                       -- sealed-box 암호문(base64). 제출 전 NULL, ack 후 NULL로 파기
  status      TEXT NOT NULL DEFAULT 'pending'
              CHECK(status IN ('pending', 'responded', 'acked')),
  created_at   TEXT NOT NULL,
  submitted_at TEXT,
  expires_at   TEXT NOT NULL              -- ISO8601(UTC)
);

CREATE INDEX IF NOT EXISTS idx_cr_device ON consent_requests(device_hash);
CREATE INDEX IF NOT EXISTS idx_cr_status ON consent_requests(status);
CREATE INDEX IF NOT EXISTS idx_cr_expires ON consent_requests(expires_at);
