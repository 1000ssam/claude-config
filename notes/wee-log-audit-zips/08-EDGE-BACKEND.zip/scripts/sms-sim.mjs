/**
 * SMS 게이트웨이(Solapi) 실발송 시뮬레이션.
 *
 * electron/sms.ts 와 동일한 v4 HMAC-SHA256 인증·요청 포맷을 독립 실행으로 검증한다.
 * (electron/sms.ts 는 import.meta.env 기반이라 plain node에서 직접 못 돌리므로, 동일 로직을 여기 재현.)
 *
 * 자격증명은 인자 또는 환경변수로 주입한다. 시크릿을 코드/깃에 하드코딩하지 않는다.
 *   node scripts/sms-sim.mjs <수신번호> [--send]
 *   환경변수: SOLAPI_API_KEY, SOLAPI_API_SECRET, SOLAPI_SENDER
 * --send 없으면 드라이런(요청 구성만 출력, 실제 발송 안 함).
 */

import { createHmac, randomBytes } from 'node:crypto';

const API_BASE = 'https://api.solapi.com';
const to = process.argv[2];
const doSend = process.argv.includes('--send');

const KEY = process.env.SOLAPI_API_KEY;
const SECRET = process.env.SOLAPI_API_SECRET;
const SENDER = process.env.SOLAPI_SENDER;

if (!to) { console.error('사용법: node scripts/sms-sim.mjs <수신번호> [--send]'); process.exit(2); }
if (!KEY || !SECRET || !SENDER) { console.error('SOLAPI_API_KEY/SECRET/SENDER 환경변수 필요'); process.exit(2); }

const norm = (p) => String(p).replace(/[^0-9]/g, '');

function authHeader() {
  const date = new Date().toISOString();
  const salt = randomBytes(32).toString('hex');
  const signature = createHmac('sha256', SECRET).update(date + salt).digest('hex');
  return `HMAC-SHA256 apiKey=${KEY}, date=${date}, salt=${salt}, signature=${signature}`;
}

// 실제 발송 본문 형식과 동일 (본문엔 PII 없음 — 링크만). [테스트] 표식 부착.
const sampleToken = randomBytes(18).toString('base64url');
const link = `https://wee-consent.example.workers.dev/f/${sampleToken}`;
const text = `[테스트][Wee 상담실] 상담 접수 동의서를 보내드립니다. 아래 링크에서 작성해 주세요.\n${link}`;
const subject = '상담 접수 동의서(테스트)';

const message = { to: norm(to), from: norm(SENDER), text, subject };

console.log('── SMS 발송 시뮬레이션 ──────────────────────────────');
console.log('수신:', message.to, '| 발신:', message.from);
console.log('제목:', subject);
console.log('본문:\n' + text);
console.log('본문 PII 포함 여부: 없음(링크만)');
console.log('─────────────────────────────────────────────────');

if (!doSend) { console.log('드라이런(미발송). 실제 발송하려면 --send 추가.'); process.exit(0); }

const res = await fetch(`${API_BASE}/messages/v4/send`, {
  method: 'POST',
  headers: { Authorization: authHeader(), 'Content-Type': 'application/json' },
  body: JSON.stringify({ message }),
});
const data = await res.json().catch(() => ({}));
console.log('HTTP', res.status);
console.log(JSON.stringify(data, null, 2));
const statusCode = String(data?.statusCode ?? '');
const okStatus = res.ok && (!statusCode || statusCode.startsWith('2'));
if (okStatus) {
  console.log('✅ 발송 성공 messageId:', data.messageId || data.groupId || '(n/a)');
} else {
  console.error('❌ 발송 실패');
  process.exit(1);
}
