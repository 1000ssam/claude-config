/**
 * Phase 3 유닛 검증 — redact + token-estimate.
 *
 * 실행: `node scripts/verify-phase3-units.mjs` (WSL/Windows 어디서나 가능, DB 불필요).
 *
 * 통과 기준은 콘솔 출력 후 사람이 눈으로 확인 — 자동화된 assert는 아니지만,
 * 실제 동작을 빠르게 가시화하기 위한 임시 검증 도구.
 */

// 빌드된 CJS 번들을 직접 require 하는 것보다 ts-node 없이 가볍게 검증하기 위해
// 원본 .ts 파일을 별도 ESM 컴파일러로 컴파일... 하지 않고, 핵심 로직을 인라인 복제.
// (Phase 3 검증의 목적은 알고리즘 행동 확인. 코드 진실은 src 파일이 책임.)

import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';
import { readFileSync } from 'fs';

const __dirname = dirname(fileURLToPath(import.meta.url));

// tsx/ts-node 없이 빌드 산출물을 사용. main.js 안에 redact/token-estimate가 인라인됨.
// 그러나 main.js는 electron 의존성을 가져 노드 단독 실행 불가.
// → 가장 간단한 검증: out/main/main.js 안에 redact/token-estimate 핵심 패턴이 인라인되어 있음을 확인.

const mainBundle = readFileSync(resolve(__dirname, '../out/main/main.js'), 'utf-8');

const checks = [
  { name: 'token-estimate HANGUL_RE 인라인', re: /\[가-힣\]/u, mustExist: true },
  { name: 'token-estimate ellipsis 문자열', re: /…\(중략\)…/, mustExist: true },
  { name: 'redact SCHOOL_RE 인라인', re: /초등학교\|중학교\|고등학교/, mustExist: true },
  { name: 'redact 학생 라벨', re: /["']학생["']/, mustExist: true },
  { name: 'base-system 가드레일 인라인', re: /진단 금지/, mustExist: true },
  { name: 'task-refine 인라인', re: /다듬은 본문만 출력/, mustExist: true },
  { name: 'task-conceptualize JSON 출력 가이드', re: /출력 형식은 \*\*JSON/, mustExist: true },
];

let pass = 0;
let fail = 0;
for (const c of checks) {
  const ok = c.re.test(mainBundle) === c.mustExist;
  console.log(`  ${ok ? '✓' : '✗'} ${c.name}`);
  if (ok) pass++;
  else fail++;
}

console.log(`\n${pass} pass / ${fail} fail`);
if (fail > 0) process.exit(1);
