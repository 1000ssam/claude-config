/**
 * Phase 3 행동 검증 — redact / token-estimate 알고리즘을 JS로 포팅해 실행 확인.
 *
 * TypeScript 소스를 직접 require할 수 없는 상황(빌드 산출물은 electron 의존)에서
 * 알고리즘 행동을 가시화하기 위해, 핵심 로직을 동일하게 옮겨 assert 한다.
 *
 * 만약 lib/ai 소스의 알고리즘이 바뀌면 이 파일도 같이 갱신해야 한다 — 그래서
 * 파일 상단에 동기화 마커를 둔다.
 *
 * 동기화 마커: 2026-05-20 (Phase 3 도입 직후)
 */

import assert from 'assert/strict';

// ─── token-estimate.ts 복제 ─────────────────────────────────────────────────
const HANGUL_RE = /[가-힣]/;
const ASCII_RE = /[\x20-\x7E]/;

function estimateTokens(text) {
  if (!text) return 0;
  let total = 0;
  for (const ch of text) {
    if (HANGUL_RE.test(ch)) total += 2.5;
    else if (ASCII_RE.test(ch)) total += 0.35;
    else total += 1.5;
  }
  return Math.ceil(total);
}

function trimMiddle(text, maxTokens, headRatio = 0.66) {
  if (maxTokens <= 0) return '';
  if (estimateTokens(text) <= maxTokens) return text;
  const ellipsis = '…(중략)…';
  const ellipsisTokens = estimateTokens(ellipsis);
  const usable = Math.max(0, maxTokens - ellipsisTokens);
  if (usable <= 0) return ellipsis;
  const charBudget = Math.floor(usable * 0.4);
  const headChars = Math.max(1, Math.floor(charBudget * headRatio));
  const tailChars = Math.max(1, charBudget - headChars);
  if (text.length <= headChars + tailChars) return text;
  const head = text.slice(0, headChars).replace(/\s+\S*$/, '');
  const tail = text.slice(text.length - tailChars).replace(/^\S*\s+/, '');
  return `${head}${ellipsis}${tail}`;
}

// ─── redact.ts 복제 ─────────────────────────────────────────────────────────
const ROLE_LABEL = { student: '학생', guardian: '보호자', teacher: '교사', referrer: '의뢰인' };
const SCHOOL_RE = /[가-힣A-Za-z0-9]{1,12}(?:초등학교|중학교|고등학교|여자중학교|여자고등학교|여중|여고|대학교|특수학교|국제학교)/g;
const PHONE_RE = /(?:\+?82[-\s]?|0)(?:\d{1,2})[-.\s]?\d{3,4}[-.\s]?\d{4}/g;
const RRN_RE = /\b\d{6}[-\s]?\d{7}\b/g;
const EMAIL_RE = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
const ADDRESS_RE = /[가-힣]{1,8}(?:특별시|광역시|특별자치시|특별자치도|도)\s?[가-힣\s\d\-]{2,40}(?:구|군|시|동|로|길)\s?\d+(?:[-\s]?\d+)?/g;

function toAlphaIndex(n) {
  let result = '';
  let i = n;
  while (i >= 0) {
    result = String.fromCharCode(65 + (i % 26)) + result;
    i = Math.floor(i / 26) - 1;
  }
  return result;
}

function createRedactContext() {
  const mapping = new Map();
  const counters = { student: 0, guardian: 0, teacher: 0, referrer: 0 };
  function assign(name, role) {
    const trimmed = name.trim();
    if (!trimmed) return name;
    const existing = mapping.get(trimmed);
    if (existing) return existing;
    const label = `${ROLE_LABEL[role]} ${toAlphaIndex(counters[role])}`;
    counters[role] += 1;
    mapping.set(trimmed, label);
    return label;
  }
  return {
    registerPerson(name, role) { if (name && name.trim()) assign(name, role); },
    redact(text) {
      if (!text) return text;
      let out = text;
      const names = [...mapping.keys()].sort((a, b) => b.length - a.length);
      for (const name of names) {
        const label = mapping.get(name);
        if (out.includes(name)) out = out.split(name).join(label);
      }
      out = out.replace(SCHOOL_RE, '[학교]');
      out = out.replace(RRN_RE, '[주민번호]');
      out = out.replace(PHONE_RE, '[전화번호]');
      out = out.replace(EMAIL_RE, '[이메일]');
      out = out.replace(ADDRESS_RE, '[주소]');
      return out;
    },
    getMapping() {
      const obj = {}; for (const [k, v] of mapping) obj[k] = v; return obj;
    },
  };
}

// ─── assertions ─────────────────────────────────────────────────────────────

console.log('=== token-estimate ===');
{
  const a = estimateTokens('안녕하세요'); // 5자 * 2.5 = 12.5 → 13
  console.log(`  "안녕하세요" → ${a} tokens (기대 ~13)`);
  assert.ok(a >= 12 && a <= 14, `예상 12~14, 실제 ${a}`);
}
{
  const long = '한'.repeat(1000);
  const t = estimateTokens(long); // 1000 * 2.5 = 2500
  console.log(`  한글 1000자 → ${t} tokens (기대 2500)`);
  assert.equal(t, 2500);
}
{
  const en = estimateTokens('Hello, world.'); // 13 * 0.35 = 4.55 → 5
  console.log(`  "Hello, world." → ${en} tokens (기대 ~5)`);
  assert.ok(en >= 4 && en <= 6);
}
{
  const long = '회기 메모를 길게 작성합니다. '.repeat(100); // 약 1400자 한글+공백
  const trimmed = trimMiddle(long, 200);
  const ttok = estimateTokens(trimmed);
  console.log(`  trimMiddle 결과 토큰: ${ttok} (예산 200, ${trimmed.length}자)`);
  assert.ok(trimmed.includes('…(중략)…'), '중략 마커 필요');
  assert.ok(ttok <= 200, `예산 200 초과: ${ttok}`);
}

console.log('\n=== redact ===');
{
  const ctx = createRedactContext();
  ctx.registerPerson('홍길동', 'student');
  ctx.registerPerson('박영희', 'student');
  ctx.registerPerson('홍어머니', 'guardian');
  const text = '홍길동 학생(010-1234-5678)이 인창고등학교에서 박영희와 다툼. 홍길동이 다시 등장.';
  const out = ctx.redact(text);
  console.log(`  원문: ${text}`);
  console.log(`  결과: ${out}`);
  console.log(`  매핑: ${JSON.stringify(ctx.getMapping())}`);
  assert.ok(out.includes('학생 A'), '홍길동 → 학생 A');
  assert.ok(out.includes('학생 B'), '박영희 → 학생 B');
  assert.ok(out.includes('[전화번호]'), '전화 치환');
  assert.ok(out.includes('[학교]'), '학교 치환');
  assert.ok(!out.includes('홍길동'), '실명 잔존 금지');
  // 두 번째 등장도 같은 이니셜
  assert.equal((out.match(/학생 A/g) || []).length, 2, '두 번 등장 모두 학생 A');
}
{
  const ctx = createRedactContext();
  ctx.registerPerson('김민수', 'teacher');
  const t = ctx.redact('김민수 선생님 이메일: kim.minsu@example.com. 주민번호 900101-1234567.');
  console.log(`  결과: ${t}`);
  assert.ok(t.includes('교사 A'));
  assert.ok(t.includes('[이메일]'));
  assert.ok(t.includes('[주민번호]'));
  assert.ok(!t.includes('900101-1234567'));
}

console.log('\n모든 행동 검증 통과 ✓');
