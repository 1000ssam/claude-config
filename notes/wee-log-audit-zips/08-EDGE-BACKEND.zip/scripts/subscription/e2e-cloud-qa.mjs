#!/usr/bin/env node
// 구독 백엔드 클라우드 E2E QA — 임시 Supabase 프로젝트 대상.
// 코드발급→redeem→entitlement 전 체인 + 음성 케이스(인증/좌석캡/중복/잘못된키)를 실행해
// 한 번에 PASS/FAIL로 보여준다. 시크릿(서명키·service_role·access_token)은 출력하지 않는다.
//
// 사전: 함수 3종 배포 완료 + supabase CLI 로그인.
// 실행:  node scripts/subscription/e2e-cloud-qa.mjs <project-ref>
//   (이 스크립트가 임시 Ed25519 키페어 생성 → ENTITLEMENT_PRIVATE_JWK·ADMIN_API_KEY 시크릿 등록 →
//    테스트 유저 생성 → 전 체인 검증. 운영 서명키 미사용.)
import { execFileSync } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';
import {
  verifyEntitlement,
  importPublicJwk,
} from '../../supabase/functions/_shared/entitlement.ts';

const ref = process.argv[2];
if (!ref) {
  console.error('usage: node scripts/subscription/e2e-cloud-qa.mjs <project-ref>');
  process.exit(1);
}
const BASE = `https://${ref}.supabase.co`;
const FN = (n) => `${BASE}/functions/v1/${n}`;

let pass = 0;
let fail = 0;
function ok(name, cond, extra = '') {
  if (cond) { pass++; console.log('  ✓', name, extra); }
  else { fail++; console.error('  ✗', name, extra); }
}

// ── 1. 프로젝트 API 키(anon·service_role) ─────────────────────────────────────
const envOut = execFileSync('supabase', ['projects', 'api-keys', '--project-ref', ref, '-o', 'env'], { encoding: 'utf8' });
const kv = Object.fromEntries(
  envOut.split('\n').filter((l) => l.includes('=')).map((l) => {
    const i = l.indexOf('=');
    const val = l.slice(i + 1).trim().replace(/^"(.*)"$/, '$1'); // -o env는 값을 따옴표로 감쌈
    return [l.slice(0, i).trim(), val];
  }),
);
const ANON = kv.SUPABASE_ANON_KEY;
const SR = kv.SUPABASE_SERVICE_ROLE_KEY;
if (!ANON || !SR) { console.error('API 키 파싱 실패'); process.exit(1); }

// ── 2. 임시 서명 키페어 + admin 키 ───────────────────────────────────────────
const kp = await crypto.subtle.generateKey({ name: 'Ed25519' }, true, ['sign', 'verify']);
const pubJwk = await crypto.subtle.exportKey('jwk', kp.publicKey);
const privJwk = await crypto.subtle.exportKey('jwk', kp.privateKey);
for (const k of [pubJwk, privJwk]) { k.alg = 'EdDSA'; k.use = 'sig'; }
const pubKey = await importPublicJwk(pubJwk);
const ADMIN_KEY = [...crypto.getRandomValues(new Uint8Array(24))].map((b) => b.toString(16).padStart(2, '0')).join('');

// ── 3. 시크릿 등록(값 미출력) ────────────────────────────────────────────────
console.log('· 시크릿 등록(서명키·admin키) …');
execFileSync('supabase', [
  'secrets', 'set',
  `ENTITLEMENT_PRIVATE_JWK=${JSON.stringify(privJwk)}`,
  `ADMIN_API_KEY=${ADMIN_KEY}`,
  '--project-ref', ref,
], { stdio: 'ignore' });

console.log('· 시크릿 전파 대기(20s) …');
await sleep(20000);

// ── auth/함수 헬퍼 ───────────────────────────────────────────────────────────
const PW = 'Test-' + ADMIN_KEY.slice(0, 16);
async function createUser(email) {
  const r = await fetch(`${BASE}/auth/v1/admin/users`, {
    method: 'POST',
    headers: { apikey: SR, Authorization: `Bearer ${SR}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: PW, email_confirm: true }),
  });
  if (!r.ok) throw new Error(`createUser ${r.status} ${await r.text()}`);
}
async function signIn(email) {
  const r = await fetch(`${BASE}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: { apikey: ANON, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: PW }),
  });
  if (!r.ok) throw new Error(`signIn ${r.status} ${await r.text()}`);
  return (await r.json()).access_token;
}
async function fn(name, { token, body, adminKey } = {}) {
  const headers = { apikey: ANON, 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (adminKey) headers['x-admin-key'] = adminKey;
  const r = await fetch(FN(name), { method: 'POST', headers, body: body ? JSON.stringify(body) : undefined });
  const text = await r.text();
  let j;
  try { j = JSON.parse(text); } catch { j = text; }
  return { status: r.status, body: j };
}

// entitlement는 콜드스타트 시 시크릿 반영 지연 가능 → active 검증에 짧은 재시도.
async function entitlementWithRetry(token, tries = 6) {
  for (let i = 0; i < tries; i++) {
    const r = await fn('entitlement', { token });
    if (r.status !== 500) return r;
    await sleep(5000);
  }
  return fn('entitlement', { token });
}

console.log(`\n구독 백엔드 E2E (project ${ref})\n`);

const ts = Date.now();
const emailA = `qa-a-${ts}@weelog.test`;
const emailB = `qa-b-${ts}@weelog.test`;
const periodEnd = new Date(Date.now() + 30 * 86400 * 1000).toISOString();

try {
  // T1 잘못된 admin 키 → 403
  let r = await fn('admin-issue', { adminKey: 'wrong-key', body: { buyer_type: 'individual', period_end: periodEnd } });
  ok('잘못된 admin 키 → 403', r.status === 403, `(got ${r.status})`);

  // T2 미인증 entitlement → 401
  r = await fn('entitlement', {});
  ok('미인증 entitlement → 401', r.status === 401, `(got ${r.status})`);

  // 유저 2명
  await createUser(emailA);
  await createUser(emailB);
  const tA = await signIn(emailA);
  const tB = await signIn(emailB);

  // T3 구독 없음 → status 'none'
  r = await fn('entitlement', { token: tA });
  ok("구독 없는 계정 → status 'none'", r.body?.status === 'none', JSON.stringify(r.body));

  // T4 admin-issue (개인, max_seats=1)
  r = await fn('admin-issue', { adminKey: ADMIN_KEY, body: { buyer_type: 'individual', period_end: periodEnd, max_seats: 1, count: 1 } });
  ok('admin-issue → ok + 코드 발급', !!(r.body?.ok && r.body?.codes?.[0]?.code), r.body?.codes?.[0]?.display ?? JSON.stringify(r.body));
  const code1 = r.body?.codes?.[0]?.display;

  // T5 잘못된 코드 → invalid_code(404)
  r = await fn('redeem', { token: tA, body: { code: 'WEELOG-0000-0000-0000' } });
  ok('잘못된 코드 redeem → invalid_code(404)', r.status === 404 && r.body?.error === 'invalid_code', JSON.stringify(r.body));

  // T6 redeem(A) → ok
  r = await fn('redeem', { token: tA, body: { code: code1, full_name: '테스트교사' } });
  ok('redeem(A) → ok', r.body?.ok === true, JSON.stringify(r.body));

  // T7 entitlement(A) → active + 토큰 서명/클레임 검증
  r = await entitlementWithRetry(tA);
  ok('entitlement(A) → active', r.body?.status === 'active', JSON.stringify({ status: r.body?.status }));
  if (r.body?.token) {
    try {
      const c = await verifyEntitlement(r.body.token, pubKey);
      ok('토큰 EdDSA 서명 검증 통과', true);
      ok('plan = standard', c.plan === 'standard', c.plan);
      ok('features 서버 주입됨', Array.isArray(c.features) && c.features.length > 0, JSON.stringify(c.features));
      ok('exp = iat + 7일(grace)', c.exp - c.iat === 7 * 86400, `(${(c.exp - c.iat) / 86400}일)`);
      ok('sub = 로그인 계정', typeof c.sub === 'string' && c.sub.length > 0);
      console.log('    └ 클레임:', JSON.stringify({ plan: c.plan, status: c.status, features: c.features, period_end: c.period_end, grace_days: (c.exp - c.iat) / 86400 }));
    } catch (e) {
      ok('토큰 EdDSA 서명 검증 통과', false, e.message);
    }
  } else {
    ok('entitlement 토큰 존재', false, JSON.stringify(r.body));
  }

  // T8 중복 redeem 검출: 좌석 여유 있는 코드(max_seats=2)를 같은 계정이 2회 → already_redeemed(409)
  //   (max_seats=1 코드는 좌석 사전체크가 UNIQUE보다 먼저라 no_seats가 반환됨 — 둘 다 정상 차단)
  r = await fn('admin-issue', { adminKey: ADMIN_KEY, body: { buyer_type: 'org', org_name: '중복테스트', period_end: periodEnd, max_seats: 2, count: 1 } });
  const codeDup = r.body?.codes?.[0]?.display;
  r = await fn('redeem', { token: tA, body: { code: codeDup } });
  ok('중복검출 사전: redeem(A) 1회 ok', r.body?.ok === true, JSON.stringify(r.body));
  r = await fn('redeem', { token: tA, body: { code: codeDup } });
  ok('동일 계정 동일 코드 재redeem → already_redeemed(409)', r.status === 409 && r.body?.error === 'already_redeemed', JSON.stringify(r.body));

  // T9 좌석 초과 redeem(B, max_seats=1 소진) → no_seats(409)
  r = await fn('redeem', { token: tB, body: { code: code1 } });
  ok('좌석 초과 redeem(B) → no_seats(409)', r.status === 409 && r.body?.error === 'no_seats', JSON.stringify(r.body));

  // T10 멀티시트(단체, max_seats=2) 발급 → redeem(B) ok → entitlement(B) active
  r = await fn('admin-issue', { adminKey: ADMIN_KEY, body: { buyer_type: 'org', org_name: '테스트교육청', period_end: periodEnd, max_seats: 2, count: 1 } });
  const code2 = r.body?.codes?.[0]?.display;
  ok('멀티시트 코드 발급 → ok', !!(r.body?.ok && code2), r.body?.max_seats ? `max_seats=${r.body.max_seats}` : JSON.stringify(r.body));
  r = await fn('redeem', { token: tB, body: { code: code2 } });
  ok('멀티시트 redeem(B) → ok', r.body?.ok === true, JSON.stringify(r.body));
  r = await entitlementWithRetry(tB);
  ok('entitlement(B) → active', r.body?.status === 'active', JSON.stringify({ status: r.body?.status }));
} catch (e) {
  fail++;
  console.error('  ✗ 예외 발생:', e.message);
}

console.log(`\n결과: ${pass} 통과 / ${fail} 실패`);
process.exit(fail ? 1 : 0);
