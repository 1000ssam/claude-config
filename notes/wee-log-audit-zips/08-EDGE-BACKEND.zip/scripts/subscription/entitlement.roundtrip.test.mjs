#!/usr/bin/env node
// 엔타이틀먼트 서명 코어 라운드트립 테스트 (일회용 임시 키 — 운영 키 미사용).
// 설계 §14 Phase1 산출물 검증: "로그인→토큰 발급→공개키 검증 라운드트립".
// 실행:  node scripts/subscription/entitlement.roundtrip.test.mjs
//   (Node 24+ 네이티브 TS 스트리핑으로 _shared/entitlement.ts 직접 import)

import {
  signEntitlement,
  verifyEntitlement,
  importPrivateJwk,
  importPublicJwk,
  computeStatus,
  EntitlementVerifyError,
} from '../../supabase/functions/_shared/entitlement.ts';

let pass = 0;
let fail = 0;
function ok(name, cond) {
  if (cond) { pass++; console.log('  ✓', name); }
  else { fail++; console.error('  ✗', name); }
}
async function throws(name, fn, ErrType) {
  try { await fn(); fail++; console.error('  ✗', name, '(예외 안 남)'); }
  catch (e) {
    if (!ErrType || e instanceof ErrType) { pass++; console.log('  ✓', name); }
    else { fail++; console.error('  ✗', name, '(다른 예외:', e.message + ')'); }
  }
}

const now = Math.floor(Date.now() / 1000);
const GRACE = 7 * 24 * 60 * 60; // 7일 (§17.7)

function baseClaims(over = {}) {
  return {
    sub: 'acct-uuid-123',
    email: 'teacher@goedu.kr',
    plan: 'standard',
    features: ['consent_sms', 'export', 'reports'],
    status: 'active',
    is_trial: false,
    period_end: new Date((now + 30 * 86400) * 1000).toISOString(),
    iat: now,
    exp: now + GRACE,
    ...over,
  };
}

console.log('entitlement 라운드트립 테스트');

// 1) 일회용 키 생성 → JWK export → 운영과 동일한 JWK import 경로 검증
const kp = await crypto.subtle.generateKey({ name: 'Ed25519' }, true, ['sign', 'verify']);
const pubJwk = await crypto.subtle.exportKey('jwk', kp.publicKey);
const privJwk = await crypto.subtle.exportKey('jwk', kp.privateKey);
const priv = await importPrivateJwk(privJwk);
const pub = await importPublicJwk(pubJwk);

// 2) sign → verify 라운드트립 (claims 보존)
const claims = baseClaims();
const token = await signEntitlement(claims, priv);
ok('토큰은 점 2개로 분리된 JWT 형태', token.split('.').length === 3);
const verified = await verifyEntitlement(token, pub, { now });
ok('verify가 claims를 원형 그대로 반환', JSON.stringify(verified) === JSON.stringify(claims));
ok('features 보존', JSON.stringify(verified.features) === JSON.stringify(claims.features));
ok('period_end 보존', verified.period_end === claims.period_end);

// 3) 변조 탐지: 페이로드 1바이트 바꾸면 서명 실패
const [h, p, s] = token.split('.');
const tampered = `${h}.${p.slice(0, -2)}${p.slice(-2) === 'AA' ? 'AB' : 'AA'}.${s}`;
await throws('페이로드 변조 → 검증 실패', () => verifyEntitlement(tampered, pub, { now }), EntitlementVerifyError);

// 4) 서명 변조: 서명부 한 글자 변경
const sBad = `${s.slice(0, -2)}${s.slice(-2) === 'AA' ? 'AB' : 'AA'}`;
await throws('서명 변조 → 검증 실패', () => verifyEntitlement(`${h}.${p}.${sBad}`, pub, { now }), EntitlementVerifyError);

// 5) 다른 키로 검증 시 실패 (위조 토큰 차단)
const otherKp = await crypto.subtle.generateKey({ name: 'Ed25519' }, true, ['sign', 'verify']);
await throws('다른 공개키로 검증 → 실패', () => verifyEntitlement(token, otherKp.publicKey, { now }), EntitlementVerifyError);

// 6) grace 만료: exp 경과 → 거부 / ignoreExpiry → 통과
const expiredToken = await signEntitlement(baseClaims({ iat: now - 2 * GRACE, exp: now - GRACE }), priv);
await throws('grace 만료 토큰 → 거부', () => verifyEntitlement(expiredToken, pub, { now }), EntitlementVerifyError);
const stillReads = await verifyEntitlement(expiredToken, pub, { now, ignoreExpiry: true });
ok('ignoreExpiry면 만료여도 claims 읽힘(서명만 검사)', stillReads.sub === 'acct-uuid-123');

// 7) alg confusion: 헤더 alg를 none/HS256으로 바꾸면 거부
function b64url(obj) {
  return Buffer.from(JSON.stringify(obj)).toString('base64url');
}
const algNoneHeader = b64url({ alg: 'none', typ: 'JWT' });
await throws('alg=none 헤더 → 거부', () => verifyEntitlement(`${algNoneHeader}.${p}.${s}`, pub, { now }), EntitlementVerifyError);

// 8) computeStatus
ok('computeStatus active', computeStatus(claims.period_end, false, now) === 'active');
ok('computeStatus trialing', computeStatus(claims.period_end, true, now) === 'trialing');
ok('computeStatus expired(과거 period_end)', computeStatus(new Date((now - 86400) * 1000).toISOString(), false, now) === 'expired');
ok('computeStatus expired(잘못된 날짜)', computeStatus('not-a-date', false, now) === 'expired');

// 9) malformed
await throws('점 1개 토큰 → 거부', () => verifyEntitlement('only.two', pub, { now }), EntitlementVerifyError);

console.log(`\n결과: ${pass} pass / ${fail} fail`);
process.exit(fail === 0 ? 0 : 1);
