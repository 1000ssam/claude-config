#!/usr/bin/env node
// codes.ts 정규화/생성 결정론 테스트.
import { generateCode, formatCode, normalizeCode } from '../../supabase/functions/_shared/codes.ts';

let pass = 0, fail = 0;
const ok = (n, c) => c ? (pass++, console.log('  ✓', n)) : (fail++, console.error('  ✗', n));

console.log('codes 테스트');

const code = generateCode();
ok('생성 코드 = WEELOG + 12자 (하이픈 없음)', /^WEELOG[0-9A-HJKMNP-TV-Z]{12}$/.test(code));
ok('생성 코드에 혼동문자 I/L/O/U 없음', !/[ILOU]/.test(code.slice(6)));

// 정규화 멱등성: 생성 코드는 이미 정규형
ok('normalize 멱등(생성코드)', normalizeCode(code) === code);

// 표시형 → 정규화하면 원래 정규형 복귀
const disp = formatCode(code);
ok('formatCode 하이픈 4자 그룹', disp === `WEELOG-${code.slice(6,10)}-${code.slice(10,14)}-${code.slice(14,18)}`);
ok('표시형 normalize → 정규형', normalizeCode(disp) === code);

// 지저분한 입력 보정
ok('소문자+공백 보정', normalizeCode('  weelog-9f3k-7q2x-m4rt ') === 'WEELOG9F3K7Q2XM4RT');
ok('혼동문자 보정(본문 I→1,O→0)', normalizeCode('WEELOG-I23O-AAAA-BBBB') === 'WEELOG1230AAAABBBB');
ok('접두사 L/O 보존(WEELOG 안 깨짐)', normalizeCode('WEELOG-ABCD-EFGH-JKMN').startsWith('WEELOG'));

console.log(`\n결과: ${pass} pass / ${fail} fail`);
process.exit(fail === 0 ? 0 : 1);
