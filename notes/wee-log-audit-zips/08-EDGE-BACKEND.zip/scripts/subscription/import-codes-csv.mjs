#!/usr/bin/env node
// 테크빌 주문 CSV → admin-issue 일괄 호출(운영자 편의). §17.2(admin/CSV 수동 입력구).
// 사용:
//   node scripts/subscription/import-codes-csv.mjs orders.csv \
//     --base https://<ref>.supabase.co/functions/v1 --admin-key "$ADMIN_API_KEY" --out issued.csv
//
// CSV 헤더(순서 무관, 일부 생략 가능):
//   buyer_type,org_name,buyer_name,buyer_contact,external_ref,plan,max_seats,count,period_end,redeem_window_days,is_trial
//   - buyer_type: individual | org
//   - period_end: ISO8601 (필수)
//   - max_seats: 단체 좌석수(기본 1) / count: 발급할 코드 장수(개인 다건, 기본 1)
//   - is_trial: true/false (기본 false)

import { readFileSync, writeFileSync } from 'node:fs';

function arg(name, def) {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1] : def;
}

const csvPath = process.argv[2];
const base = arg('base');
const adminKey = arg('admin-key');
const outPath = arg('out', 'issued.csv');

if (!csvPath || !base || !adminKey) {
  console.error('사용: import-codes-csv.mjs <orders.csv> --base <url> --admin-key <key> [--out issued.csv]');
  process.exit(1);
}

// ── 최소 CSV 파서(따옴표·콤마 이스케이프 처리) ──────────────────────────────
function parseCsv(text) {
  const rows = [];
  let row = [], field = '', inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else inQuotes = false;
      } else field += c;
    } else if (c === '"') inQuotes = true;
    else if (c === ',') { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      if (field !== '' || row.length > 0) { row.push(field); rows.push(row); row = []; field = ''; }
    } else field += c;
  }
  if (field !== '' || row.length > 0) { row.push(field); rows.push(row); }
  return rows;
}

const raw = readFileSync(csvPath, 'utf8');
const rows = parseCsv(raw).filter((r) => r.some((c) => c.trim() !== ''));
if (rows.length < 2) { console.error('데이터 행이 없습니다.'); process.exit(1); }

const header = rows[0].map((h) => h.trim());
const records = rows.slice(1).map((r) => {
  const o = {};
  header.forEach((h, i) => { o[h] = (r[i] ?? '').trim(); });
  return o;
});

const out = [['row', 'buyer_name', 'org_name', 'plan', 'period_end', 'display_code', 'status']];
let okCount = 0, failCount = 0;

for (let i = 0; i < records.length; i++) {
  const rec = records[i];
  const payload = {
    external_ref: rec.external_ref || undefined,
    buyer_type: rec.buyer_type === 'org' ? 'org' : 'individual',
    org_name: rec.org_name || undefined,
    buyer_name: rec.buyer_name || undefined,
    buyer_contact: rec.buyer_contact || undefined,
    plan: rec.plan || 'standard',
    max_seats: rec.max_seats ? Number(rec.max_seats) : 1,
    count: rec.count ? Number(rec.count) : 1,
    period_end: rec.period_end,
    redeem_window_days: rec.redeem_window_days ? Number(rec.redeem_window_days) : 30,
    is_trial: /^(true|1|y|yes)$/i.test(rec.is_trial || ''),
  };
  try {
    const res = await fetch(`${base.replace(/\/$/, '')}/admin-issue`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-admin-key': adminKey },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.ok) {
      failCount++;
      out.push([i + 1, payload.buyer_name ?? '', payload.org_name ?? '', payload.plan, payload.period_end, '', `FAIL: ${data.error ?? res.status}`]);
      console.error(`행 ${i + 1} 실패:`, data.error ?? res.status);
      continue;
    }
    for (const c of data.codes) {
      okCount++;
      out.push([i + 1, payload.buyer_name ?? '', payload.org_name ?? '', payload.plan, data.period_end, c.display, 'OK']);
    }
    console.log(`행 ${i + 1}: ${data.codes.length}장 발급`);
  } catch (e) {
    failCount++;
    out.push([i + 1, payload.buyer_name ?? '', payload.org_name ?? '', payload.plan, payload.period_end, '', `ERROR: ${e.message}`]);
    console.error(`행 ${i + 1} 오류:`, e.message);
  }
}

const csvOut = out.map((r) => r.map((c) => /[",\n]/.test(String(c)) ? `"${String(c).replace(/"/g, '""')}"` : String(c)).join(',')).join('\n') + '\n';
writeFileSync(outPath, csvOut);
console.log(`\n완료: 성공 ${okCount}장 · 실패 ${failCount}건 → ${outPath}`);
