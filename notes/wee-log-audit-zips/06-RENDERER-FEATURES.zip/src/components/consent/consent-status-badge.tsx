import { Badge } from '@/components/ui/badge';
import type { ConsentStatus } from '@/types/consent';

const MAP: Record<ConsentStatus, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' | 'success' }> = {
  pending: { label: '대기', variant: 'outline' },
  sent: { label: '발송됨 · 응답대기', variant: 'secondary' },
  responded: { label: '응답 도착', variant: 'success' },
  ingested: { label: '수합 완료', variant: 'success' },
  expired: { label: '만료', variant: 'outline' },
  failed: { label: '발송 실패', variant: 'destructive' },
};

export function ConsentStatusBadge({ status }: { status: ConsentStatus }) {
  const { label, variant } = MAP[status] ?? MAP.pending;
  return <Badge variant={variant} className="text-xs font-normal">{label}</Badge>;
}
