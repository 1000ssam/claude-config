import { useCallback, useEffect, useState } from 'react';
import { Send, RefreshCw, Settings2, Copy, Eye, Loader2, AlertTriangle, ShieldCheck, History } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { formatPhoneNumber } from '@/lib/utils';
import { ConsentStatusBadge } from './consent-status-badge';
import { ConsentTemplateManager } from './consent-template-manager';
import type { ConsentTemplate, ConsentRequest, ConsentChannel, ConsentResponseRecord, ConsentAuditRecord } from '@/types/consent';

interface CaseStudent {
  student_id: number | null;
  name: string;
  guardian_name?: string | null;
  guardian_contact?: string | null;
}

interface Props {
  caseId: number;
  students: CaseStudent[];
}

/** 감사 로그 이벤트 코드 → 한글 표시명(UI 전용). */
const AUDIT_EVENT_LABELS: Record<string, string> = {
  request_created: '요청 생성',
  sent_to_server: '서버 등록',
  delivered: 'SMS 발송',
  status_sent: '발송 완료',
  send_failed: '발송 실패',
  resend_invalidated: '재발송(이전 무효화)',
  poll_started: '수합 시작',
  response_recorded: '응답 수합',
  response_destroyed: '서버 암호문 파기',
  decrypt_failed: '복호 실패',
  requests_expired: '만료 처리',
};

/** 감사 로그 detail(JSON)을 사람이 읽는 짧은 문구로. PII는 이미 제거된 메타만 들어온다. */
function auditDetailText(detail: string | null): string {
  if (!detail) return '';
  try {
    const d = JSON.parse(detail) as Record<string, unknown>;
    const parts: string[] = [];
    if (d.channel) parts.push(d.channel === 'sms' ? 'SMS' : '링크');
    if (typeof d.pending === 'number') parts.push(`대기 ${d.pending}건`);
    if (typeof d.count === 'number') parts.push(`${d.count}건`);
    if (d.stage) parts.push(d.stage === 'sms' ? 'SMS 단계' : '서버 단계');
    if (d.error) parts.push(String(d.error));
    return parts.join(' · ');
  } catch {
    return '';
  }
}

export function ConsentPanel({ caseId, students }: Props) {
  const { addToast } = useToast();
  const [caps, setCaps] = useState<{ server: boolean; sms: boolean }>({ server: false, sms: false });
  const [templates, setTemplates] = useState<ConsentTemplate[]>([]);
  const [requests, setRequests] = useState<ConsentRequest[]>([]);
  const [polling, setPolling] = useState(false);
  const [managerOpen, setManagerOpen] = useState(false);

  // 발송 다이얼로그 상태
  const [sendFor, setSendFor] = useState<CaseStudent | null>(null);
  const [sendTemplateIds, setSendTemplateIds] = useState<number[]>([]);
  const [sendChannel, setSendChannel] = useState<ConsentChannel>('link');
  const [sending, setSending] = useState(false);

  // 링크/응답 다이얼로그 (여러 양식 동시 발송 시 링크가 여러 개일 수 있음)
  const [linksToShow, setLinksToShow] = useState<string[]>([]);
  const [viewResponse, setViewResponse] = useState<ConsentResponseRecord | null>(null);
  const [viewTitle, setViewTitle] = useState('');
  const [viewLabels, setViewLabels] = useState<Record<string, string>>({});

  // 감사 로그 다이얼로그(읽기 전용, 비식별)
  const [auditOpen, setAuditOpen] = useState(false);
  const [auditRows, setAuditRows] = useState<ConsentAuditRecord[]>([]);

  const loadRequests = useCallback(() => {
    window.api.consent.list(caseId).then(setRequests).catch(() => setRequests([]));
  }, [caseId]);

  const loadTemplates = useCallback(() => {
    window.api.consent.templatesList()
      .then(setTemplates)
      .catch(() => setTemplates([]));
  }, []);

  const poll = useCallback(async (silent: boolean) => {
    setPolling(true);
    try {
      const r = await window.api.consent.poll();
      if (!silent) {
        if (!r.success) addToast({ title: r.error || '수합에 실패했습니다.', variant: 'destructive' });
        else addToast({ title: `수합 완료 — 신규 ${r.ingested}건, 만료 ${r.expired}건${r.errors ? `, 오류 ${r.errors}건` : ''}`, variant: 'success' });
      }
      loadRequests();
    } finally {
      setPolling(false);
    }
  }, [addToast, loadRequests]);

  useEffect(() => {
    window.api.consent.capabilities().then(setCaps).catch(() => {});
    loadTemplates();
    loadRequests();
  }, [loadTemplates, loadRequests]);

  // 서버 설정돼 있으면 진입 시 1회 자동 수합
  useEffect(() => {
    if (caps.server) poll(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [caps.server]);

  function openSend(student: CaseStudent) {
    setSendFor(student);
    // 기본 양식(없으면 첫 양식)을 기본 선택
    const def = templates.find((t) => t.is_default) ?? templates[0];
    setSendTemplateIds(def ? [def.id] : []);
    // 연락처 있고 SMS 가능하면 기본 SMS, 아니면 링크
    setSendChannel(student.guardian_contact && caps.sms ? 'sms' : 'link');
  }

  function toggleTemplate(id: number) {
    setSendTemplateIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id],
    );
  }

  async function doSend() {
    if (!sendFor || sendFor.student_id == null || sendTemplateIds.length === 0) return;
    if (sendChannel === 'sms' && !sendFor.guardian_contact) {
      addToast({ title: '보호자 연락처가 없어 SMS로 보낼 수 없습니다.', variant: 'destructive' });
      return;
    }
    setSending(true);
    try {
      const res = await window.api.consent.sendBatch({
        case_id: caseId,
        student_id: sendFor.student_id,
        template_ids: sendTemplateIds,
        channel: sendChannel,
      });
      const sent = res.sentCount ?? 0;
      const failed = res.failedCount ?? 0;
      if (!res.success) {
        addToast({ title: res.error || '발송에 실패했습니다.', variant: 'destructive' });
      } else {
        if (sendChannel === 'sms') {
          addToast({
            title: failed > 0
              ? `SMS 발송 — 성공 ${sent}건 · 실패 ${failed}건`
              : `SMS로 동의서 ${sent}건을 한 통에 묶어 발송했습니다.`,
            variant: failed > 0 ? 'destructive' : 'success',
          });
        } else {
          const links = res.results.filter((r) => r.success && r.link).map((r) => r.link!);
          if (links.length > 0) setLinksToShow(links);
          if (failed > 0) {
            addToast({ title: `링크 생성 — 성공 ${sent}건 · 실패 ${failed}건`, variant: 'destructive' });
          }
        }
        loadRequests();
        setSendFor(null);
      }
    } catch (e) {
      addToast({ title: (e as Error).message || '발송 중 오류가 발생했습니다.', variant: 'destructive' });
    } finally {
      setSending(false);
    }
  }

  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      addToast({ title: '링크가 복사되었습니다.', variant: 'success' });
    } catch {
      addToast({ title: '복사에 실패했습니다. 직접 선택해 복사하세요.', variant: 'destructive' });
    }
  }

  async function showResponse(req: ConsentRequest) {
    try {
      const r = await window.api.consent.response(req.id);
      if (!r) { addToast({ title: '응답을 찾을 수 없습니다.', variant: 'destructive' }); return; }
      // 발송 시점 스키마 스냅샷에서 key→라벨 매핑(없으면 raw key로 폴백).
      const labels: Record<string, string> = {};
      for (const f of req.form_schema?.fields ?? []) labels[f.key] = f.label;
      setViewLabels(labels);
      setViewResponse(r);
      setViewTitle(`${req.student_name ?? ''} · ${req.template_name}`);
    } catch (e) {
      addToast({ title: (e as Error).message || '응답을 불러오지 못했습니다.', variant: 'destructive' });
    }
  }

  function openAudit() {
    setAuditOpen(true);
    window.api.consent.auditList(caseId).then(setAuditRows).catch(() => setAuditRows([]));
  }

  const studentsWithId = students.filter((s) => s.student_id != null);
  const requestsByStudent = (sid: number) => requests.filter((r) => r.student_id === sid);

  return (
    <div className="space-y-4">
      {/* 영지식 안내 + 액션 */}
      <Card className="shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-primary" />
              보호자 동의서
            </span>
            <span className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => poll(false)} disabled={polling || !caps.server}>
                {polling ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="mr-1.5 h-3.5 w-3.5" />}
                지금 수합
              </Button>
              <Button variant="outline" size="sm" onClick={() => setManagerOpen(true)}>
                <Settings2 className="mr-1.5 h-3.5 w-3.5" />양식 관리
              </Button>
              <Button variant="ghost" size="sm" onClick={openAudit} title="발송·수합·파기 이력(비식별)">
                <History className="mr-1.5 h-3.5 w-3.5" />감사 로그
              </Button>
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-xs text-muted-foreground leading-relaxed">
            보호자에게 동의서 링크를 전달하고 응답을 수합합니다. 응답은 보호자 기기에서 암호화되어 전송되며,
            서버는 내용을 열람할 수 없습니다(종단간 암호화). 복호된 응답은 이 기기에만 저장됩니다.
          </p>
          {!caps.server && (
            <div className="flex items-start gap-2 rounded-md border border-amber-300 bg-amber-50 p-2.5 text-xs text-amber-800">
              <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
              <span>동의서 서버가 설정되지 않았습니다. <code>VITE_CONSENT_SERVER_URL</code> 환경변수를 설정한 뒤 사용할 수 있습니다.</span>
            </div>
          )}

          {/* 학생별 발송 */}
          <div className="space-y-2">
            {studentsWithId.length === 0 && (
              <p className="text-sm text-muted-foreground">등록된 학생이 없습니다.</p>
            )}
            {studentsWithId.map((s) => (
              <div key={s.student_id} className="flex items-center justify-between rounded-lg border bg-card p-3">
                <div className="text-sm">
                  <span className="font-medium">{s.name}</span>
                  <span className="ml-2 text-xs text-muted-foreground">
                    {s.guardian_name ? `보호자 ${s.guardian_name}` : '보호자 미등록'}
                    {s.guardian_contact ? ` · ${formatPhoneNumber(s.guardian_contact)}` : ''}
                  </span>
                </div>
                <Button size="sm" onClick={() => openSend(s)} disabled={!caps.server || templates.length === 0}>
                  <Send className="mr-1.5 h-3.5 w-3.5" />동의서 발송
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 발송 이력 */}
      {requests.length > 0 && (
        <Card className="shadow-sm">
          <CardHeader><CardTitle>발송/응답 이력</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-2">
              {requests.map((r) => (
                <div key={r.id} className="flex items-center gap-3 rounded-lg border p-2.5">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium truncate">{r.student_name ?? `학생 #${r.student_id}`}</span>
                      <ConsentStatusBadge status={r.status} />
                      <span className="text-xs text-muted-foreground">{r.channel === 'sms' ? 'SMS' : '링크'}</span>
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground truncate">
                      {r.template_name} · {r.created_at}
                      {r.last_error ? ` · 오류: ${r.last_error}` : ''}
                    </p>
                  </div>
                  <div className="flex shrink-0 gap-1">
                    {r.link && (r.status === 'sent' || r.status === 'pending') && (
                      <Button variant="ghost" size="sm" className="h-8 px-2 text-xs" onClick={() => copy(r.link!)} title="링크 복사">
                        <Copy className="h-3.5 w-3.5" />
                      </Button>
                    )}
                    {r.status === 'ingested' && (
                      <Button variant="outline" size="sm" className="h-8 px-2 text-xs" onClick={() => showResponse(r)}>
                        <Eye className="mr-1 h-3.5 w-3.5" />응답 보기
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* 발송 다이얼로그 */}
      <Dialog open={sendFor !== null} onOpenChange={(o) => { if (!o) setSendFor(null); }}>
        <DialogContent className="sm:max-w-[440px]">
          <DialogHeader>
            <DialogTitle>동의서 발송</DialogTitle>
            <DialogDescription>
              {sendFor?.name} 학생의 보호자에게 동의서를 전달합니다.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-1">
            <div className="space-y-1.5">
              <Label>양식 <span className="text-muted-foreground font-normal">(여러 개 선택 가능)</span></Label>
              <div className="max-h-44 space-y-0.5 overflow-y-auto rounded-md border p-1">
                {templates.map((t) => (
                  <label
                    key={t.id}
                    htmlFor={`tpl-${t.id}`}
                    className="flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 text-sm hover:bg-accent"
                  >
                    <Checkbox
                      id={`tpl-${t.id}`}
                      checked={sendTemplateIds.includes(t.id)}
                      onCheckedChange={() => toggleTemplate(t.id)}
                    />
                    <span>{t.name}{t.is_default ? ' (기본)' : ''}</span>
                  </label>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>전달 방법</Label>
              <Select value={sendChannel} onValueChange={(v) => setSendChannel(v as ConsentChannel)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="sms" disabled={!caps.sms || !sendFor?.guardian_contact}>
                    SMS 자동 발송{!caps.sms ? ' (미설정)' : !sendFor?.guardian_contact ? ' (연락처 없음)' : ''}
                  </SelectItem>
                  <SelectItem value="link">링크 직접 전달(복사)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {sendChannel === 'sms' && sendFor?.guardian_contact && (
              <p className="text-xs text-muted-foreground">
                수신 번호: <span className="font-medium">{formatPhoneNumber(sendFor.guardian_contact)}</span>
                {sendTemplateIds.length > 1
                  ? ` — 선택한 ${sendTemplateIds.length}개 양식 링크를 문자 1통에 묶어 보냅니다.`
                  : ' (1통)'}
                <br />문자 본문에는 개인정보가 포함되지 않으며 1회용 링크만 전송됩니다.
              </p>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSendFor(null)} disabled={sending}>취소</Button>
            <Button onClick={doSend} disabled={sending || sendTemplateIds.length === 0}>
              {sending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
              {sendChannel === 'sms'
                ? `문자 발송${sendTemplateIds.length > 1 ? ` (${sendTemplateIds.length}건)` : ''}`
                : `링크 생성${sendTemplateIds.length > 1 ? ` (${sendTemplateIds.length}건)` : ''}`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 링크 표시(수동 전달) — 여러 양식이면 링크 여러 개 */}
      <Dialog open={linksToShow.length > 0} onOpenChange={(o) => { if (!o) setLinksToShow([]); }}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle>동의서 링크{linksToShow.length > 1 ? ` (${linksToShow.length}건)` : ''}</DialogTitle>
            <DialogDescription>
              {linksToShow.length > 1
                ? '각 링크를 보호자에게 전달하세요. 모두 1회용이며 만료됩니다.'
                : '이 링크를 보호자에게 전달하세요. 1회용이며 만료됩니다.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            {linksToShow.map((lk, i) => (
              <div key={lk} className="flex items-center gap-2">
                {linksToShow.length > 1 && (
                  <span className="w-5 shrink-0 text-right text-xs text-muted-foreground tabular-nums">{i + 1}.</span>
                )}
                <input readOnly value={lk} className="flex-1 rounded-md border px-2 py-1.5 text-xs" onFocus={(e) => e.currentTarget.select()} />
                <Button size="sm" onClick={() => copy(lk)}><Copy className="mr-1.5 h-3.5 w-3.5" />복사</Button>
              </div>
            ))}
            {linksToShow.length > 1 && (
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => copy(linksToShow.map((l, i) => `${i + 1}. ${l}`).join('\n'))}
              >
                <Copy className="mr-1.5 h-3.5 w-3.5" />전체 링크 한 번에 복사
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* 응답 보기 */}
      <Dialog open={viewResponse !== null} onOpenChange={(o) => { if (!o) setViewResponse(null); }}>
        <DialogContent className="sm:max-w-[560px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>동의서 응답</DialogTitle>
            <DialogDescription>{viewTitle} · 제출 {viewResponse?.submitted_at}</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {viewResponse && Object.entries(viewResponse.answers).map(([k, v]) => (
              <div key={k} className="text-sm">
                <p className="text-xs font-medium text-muted-foreground">{viewLabels[k] ?? k}</p>
                {typeof v === 'string' && v.startsWith('data:image') ? (
                  <img src={v} alt="서명" className="mt-1 max-h-40 rounded border bg-white" />
                ) : typeof v === 'boolean' ? (
                  <p className={v ? 'text-foreground' : 'text-muted-foreground'}>{v ? '동의함' : '미동의'}</p>
                ) : Array.isArray(v) ? (
                  <p className="whitespace-pre-wrap">{v.length ? v.join(', ') : '-'}</p>
                ) : (
                  <p className="whitespace-pre-wrap">{String(v) || '-'}</p>
                )}
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* 감사 로그(비식별 이력) */}
      <Dialog open={auditOpen} onOpenChange={setAuditOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>감사 로그</DialogTitle>
            <DialogDescription>
              이 사례의 동의서 발송·수합·파기 이력입니다. 개인정보는 기록하지 않습니다(비식별).
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            {auditRows.length === 0 && (
              <p className="text-sm text-muted-foreground">기록된 이벤트가 없습니다.</p>
            )}
            {auditRows.map((a) => {
              // 표시: 학생 실명(읽기 시점 결합) · 양식명. 요청/학생 삭제 시 비식별 표기.
              const who =
                a.request_id == null
                  ? '전체'
                  : a.student_name
                    ? `${a.student_name}${a.template_name ? ` · ${a.template_name}` : ''}`
                    : `요청 #${a.request_id} (삭제됨)`;
              const dt = auditDetailText(a.detail);
              return (
                <div key={a.id} className="flex items-start gap-3 rounded-md border px-2.5 py-1.5 text-xs">
                  <span className="shrink-0 font-medium">{AUDIT_EVENT_LABELS[a.event] ?? a.event}</span>
                  <span className="flex-1 min-w-0 break-words">
                    <span className="text-foreground">{who}</span>
                    {dt && <span className="text-muted-foreground"> · {dt}</span>}
                  </span>
                  <span className="shrink-0 tabular-nums text-muted-foreground">{a.created_at}</span>
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      <ConsentTemplateManager open={managerOpen} onOpenChange={setManagerOpen} onChanged={loadTemplates} />
    </div>
  );
}
