import { useEffect, useState } from 'react';
import { Plus, Trash2, ArrowUp, ArrowDown, Loader2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { useToast } from '@/hooks/use-toast';
import type { ConsentTemplate, ConsentField, ConsentFieldType, ConsentFormSchema } from '@/types/consent';

const FIELD_TYPE_LABELS: Record<ConsentFieldType, string> = {
  text: '단답',
  textarea: '장문',
  select: '선택',
  radio: '단일선택(구)', // 레거시 — 신규는 '선택'+다중토글로 통합
  checkbox: '체크박스(구)',
  date: '날짜',
  consent: '동의문구',
  signature: '전자서명',
};

// 빌더 드롭다운에 노출하는 타입(레거시 radio/checkbox는 숨김 — 렌더만 호환 유지).
const BUILDER_TYPES: ConsentFieldType[] = ['text', 'textarea', 'select', 'date', 'consent', 'signature'];

// 선택지 텍스트 → 배열(쉼표 구분, 공백 제거, 빈값 제외).
function parseOptions(text: string | undefined): string[] {
  return (text ?? '').split(',').map((s) => s.trim()).filter(Boolean);
}

interface DraftField extends ConsentField {
  _id: number; // 편집용 임시 식별자
  optionsText?: string; // 편집용 원문(쉼표 입력 보존 — 저장 시 parseOptions)
}

interface Draft {
  id: number | null;
  name: string;
  title: string;
  intro: string;
  is_default: boolean;
  fields: DraftField[];
}

let uid = 1;
function toDraftFields(fields: ConsentField[]): DraftField[] {
  return fields.map((f) => ({
    ...f,
    _id: uid++,
    optionsText: (f.options ?? []).join(', '),
    // 레거시 placeholder를 안내문(description)으로 이관해 편집 가능하게.
    description: f.description ?? ((f.type === 'text' || f.type === 'textarea') ? f.placeholder : undefined),
  }));
}

function emptyDraft(): Draft {
  return {
    id: null,
    name: '',
    title: '',
    intro: '',
    is_default: false,
    fields: [{ _id: uid++, key: 'field_1', type: 'text', label: '', required: true }],
  };
}

function draftToSchema(d: Draft): ConsentFormSchema {
  return {
    version: 1,
    title: d.title.trim() || d.name.trim(),
    intro: d.intro.trim() || undefined,
    fields: d.fields.map((f) => {
      const out: ConsentField = { key: f.key.trim(), type: f.type, label: f.label.trim(), required: f.required };
      // 타입별 화이트리스트 — 타입 변경 후 남은 무관 필드가 스키마에 새지 않게 한다.
      if (f.type === 'select' || f.type === 'radio') {
        out.options = parseOptions(f.optionsText);
        if (f.type === 'select' && f.multiple) out.multiple = true;
      }
      // 안내 도움말(보호자 폼에 표시) — consent/signature/단답/장문 공통.
      if (
        (f.type === 'consent' || f.type === 'signature' || f.type === 'text' || f.type === 'textarea') &&
        f.description?.trim()
      ) {
        out.description = f.description.trim();
      }
      return out;
    }),
  };
}

function validate(d: Draft): string | null {
  if (!d.name.trim()) return '템플릿 이름을 입력하세요.';
  if (d.fields.length === 0) return '항목을 1개 이상 추가하세요.';
  const keys = d.fields.map((f) => f.key.trim());
  if (keys.some((k) => !/^[a-z][a-z0-9_]*$/.test(k))) return '항목 키는 영문 소문자/숫자/언더스코어로 시작해야 합니다.';
  if (new Set(keys).size !== keys.length) return '항목 키가 중복되었습니다.';
  if (d.fields.some((f) => !f.label.trim())) return '모든 항목에 라벨을 입력하세요.';
  if (d.fields.some((f) => (f.type === 'select' || f.type === 'radio') && parseOptions(f.optionsText).length === 0))
    return '선택 항목에는 선택지가 1개 이상 필요합니다.';
  return null;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onChanged: () => void; // 템플릿 목록 변경 시 부모 갱신
}

export function ConsentTemplateManager({ open, onOpenChange, onChanged }: Props) {
  const { addToast } = useToast();
  const [templates, setTemplates] = useState<ConsentTemplate[]>([]);
  const [draft, setDraft] = useState<Draft>(emptyDraft());
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<number | null>(null);

  function loadTemplates() {
    window.api.consent.templatesList().then(setTemplates).catch(() => setTemplates([]));
  }

  useEffect(() => {
    if (open) {
      loadTemplates();
      setDraft(emptyDraft());
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  function editTemplate(t: ConsentTemplate) {
    setDraft({
      id: t.id,
      name: t.name,
      title: t.schema.title,
      intro: t.schema.intro ?? '',
      is_default: !!t.is_default,
      fields: toDraftFields(t.schema.fields),
    });
  }

  function updateField(_id: number, patch: Partial<DraftField>) {
    setDraft((d) => ({ ...d, fields: d.fields.map((f) => (f._id === _id ? { ...f, ...patch } : f)) }));
  }
  function addField() {
    // 전역 단조증가 uid를 key 접미사로 사용 → 삭제 후 추가해도 key 충돌 없음.
    const id = uid++;
    setDraft((d) => ({
      ...d,
      fields: [...d.fields, { _id: id, key: `field_${id}`, type: 'text', label: '', required: false }],
    }));
  }
  function removeField(_id: number) {
    setDraft((d) => ({ ...d, fields: d.fields.filter((f) => f._id !== _id) }));
  }
  function moveField(idx: number, dir: -1 | 1) {
    setDraft((d) => {
      const next = [...d.fields];
      const j = idx + dir;
      if (j < 0 || j >= next.length) return d;
      [next[idx], next[j]] = [next[j], next[idx]];
      return { ...d, fields: next };
    });
  }

  async function save() {
    const err = validate(draft);
    if (err) { addToast({ title: err, variant: 'destructive' }); return; }
    setSaving(true);
    try {
      const input = { name: draft.name.trim(), schema: draftToSchema(draft), is_default: draft.is_default };
      if (draft.id == null) await window.api.consent.templateCreate(input);
      else await window.api.consent.templateUpdate(draft.id, input);
      addToast({ title: '템플릿이 저장되었습니다.', variant: 'success' });
      loadTemplates();
      onChanged();
      setDraft(emptyDraft());
    } catch (e) {
      addToast({ title: (e as Error).message || '저장에 실패했습니다.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  async function doDelete() {
    if (deleteTarget == null) return;
    try {
      await window.api.consent.templateDelete(deleteTarget);
      addToast({ title: '템플릿이 삭제되었습니다.', variant: 'success' });
      if (draft.id === deleteTarget) setDraft(emptyDraft());
      loadTemplates();
      onChanged();
    } catch (e) {
      addToast({ title: (e as Error).message || '삭제에 실패했습니다.', variant: 'destructive' });
    } finally {
      setDeleteTarget(null);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[760px] max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>동의서 양식 관리</DialogTitle>
          <DialogDescription>질문지 종류와 응답 항목을 추가·편집합니다. 질문은 평문, 응답만 종단간 암호화됩니다.</DialogDescription>
        </DialogHeader>

        {/* 기존 템플릿 목록 */}
        <div className="space-y-1.5">
          <Label>저장된 양식</Label>
          <div className="flex flex-wrap gap-2">
            {templates.map((t) => (
              <div key={t.id} className="flex items-center gap-1 rounded-md border px-2 py-1 text-xs">
                <button type="button" className="hover:text-primary" onClick={() => editTemplate(t)}>
                  {t.name}{t.is_default ? ' (기본)' : ''}
                </button>
                {!t.is_default && (
                  <button type="button" className="text-muted-foreground hover:text-destructive" onClick={() => setDeleteTarget(t.id)} title="삭제">
                    <Trash2 className="h-3 w-3" />
                  </button>
                )}
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" className="h-7 text-xs" onClick={() => setDraft(emptyDraft())}>
              <Plus className="mr-1 h-3 w-3" />새 양식
            </Button>
          </div>
        </div>

        {/* 편집기 */}
        <div className="space-y-3 border-t pt-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="tpl-name">템플릿 이름 <span className="text-destructive">*</span></Label>
              <Input id="tpl-name" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} placeholder="예: 상담 접수 동의서" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="tpl-title">폼 제목(보호자 화면)</Label>
              <Input id="tpl-title" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} placeholder="비우면 템플릿 이름 사용" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="tpl-intro">상단 안내문(법적 고지)</Label>
            <Textarea id="tpl-intro" value={draft.intro} onChange={(e) => setDraft({ ...draft, intro: e.target.value })} placeholder="개인정보 수집·이용, 미성년자 법정대리인 동의 안내 등" className="min-h-[72px] text-sm" />
          </div>

          <div className="space-y-2">
            <Label>응답 항목</Label>
            {draft.fields.map((f, idx) => (
              <div key={f._id} className="rounded-lg border bg-card p-2.5 space-y-2">
                <div className="flex items-center gap-1.5">
                  <Input value={f.label} onChange={(e) => updateField(f._id, { label: e.target.value })} placeholder="질문/라벨" className="h-8 text-sm flex-1" />
                  <Select value={f.type} onValueChange={(v) => updateField(f._id, { type: v as ConsentFieldType })}>
                    <SelectTrigger className="h-8 w-28 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {/* 레거시 타입(radio/checkbox) 필드면 그 항목도 표시해 값이 비지 않게. */}
                      {(BUILDER_TYPES.includes(f.type) ? BUILDER_TYPES : [...BUILDER_TYPES, f.type]).map((tp) => (
                        <SelectItem key={tp} value={tp}>{FIELD_TYPE_LABELS[tp]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="flex items-center gap-1 px-1">
                    <Switch checked={f.required} onCheckedChange={(c) => updateField(f._id, { required: c })} />
                    <span className="text-xs text-muted-foreground">필수</span>
                  </div>
                  <button type="button" onClick={() => moveField(idx, -1)} className="p-1 text-muted-foreground hover:text-foreground" title="위로"><ArrowUp className="h-3.5 w-3.5" /></button>
                  <button type="button" onClick={() => moveField(idx, 1)} className="p-1 text-muted-foreground hover:text-foreground" title="아래로"><ArrowDown className="h-3.5 w-3.5" /></button>
                  <button type="button" onClick={() => removeField(f._id)} className="p-1 text-muted-foreground hover:text-destructive" title="삭제"><Trash2 className="h-3.5 w-3.5" /></button>
                </div>
                {/* key는 내부 식별자(자동 생성) — 화면에 노출하지 않는다. 보조 입력이 있는 타입만 두 번째 줄을 렌더. */}
                {(f.type === 'select' || f.type === 'radio' || f.type === 'consent' || f.type === 'signature' || f.type === 'text' || f.type === 'textarea') && (
                  <div className="flex flex-wrap items-center gap-1.5 pl-0.5">
                    {(f.type === 'select' || f.type === 'radio') && (
                      <>
                        <Input
                          value={f.optionsText ?? ''}
                          onChange={(e) => updateField(f._id, { optionsText: e.target.value })}
                          placeholder="선택지 쉼표로 구분 (예: 부, 모, 기타)"
                          className="h-7 flex-1 min-w-[180px] text-xs"
                        />
                        {f.type === 'select' && (
                          <label className="flex items-center gap-1 whitespace-nowrap text-xs text-muted-foreground">
                            <Switch checked={!!f.multiple} onCheckedChange={(c) => updateField(f._id, { multiple: c })} />
                            다중 선택
                          </label>
                        )}
                      </>
                    )}
                    {(f.type === 'consent' || f.type === 'signature' || f.type === 'text' || f.type === 'textarea') && (
                      <Input
                        value={f.description ?? ''}
                        onChange={(e) => updateField(f._id, { description: e.target.value })}
                        placeholder={
                          f.type === 'consent' ? '동의 문구 본문'
                          : f.type === 'signature' ? '서명 안내문'
                          : '답변 안내 문구 (예: 어떻게 작성할지 설명)'
                        }
                        className="h-7 flex-1 text-xs"
                      />
                    )}
                  </div>
                )}
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" className="h-8 text-xs" onClick={addField}>
              <Plus className="mr-1 h-3.5 w-3.5" />항목 추가
            </Button>
          </div>

          <div className="flex items-center justify-between border-t pt-3">
            <label className="flex items-center gap-2 text-sm">
              <Switch checked={draft.is_default} onCheckedChange={(c) => setDraft({ ...draft, is_default: c })} />
              기본 양식으로 설정
            </label>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)}>닫기</Button>
              <Button onClick={save} disabled={saving}>
                {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                {draft.id == null ? '새 양식 저장' : '양식 수정'}
              </Button>
            </div>
          </div>
        </div>

        <ConfirmDialog
          open={deleteTarget !== null}
          onOpenChange={(o) => { if (!o) setDeleteTarget(null); }}
          title="양식을 삭제하시겠습니까?"
          description="이 동의서 양식이 삭제됩니다. 이미 발송된 요청에는 영향이 없습니다."
          confirmLabel="삭제"
          variant="destructive"
          onConfirm={doDelete}
        />
      </DialogContent>
    </Dialog>
  );
}
