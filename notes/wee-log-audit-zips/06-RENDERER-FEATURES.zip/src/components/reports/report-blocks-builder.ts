import type { ReportData } from '../../../lib/queries/report-generator';
import type { ReportBlock } from './block-editor';

let _idCounter = 0;
function id() { return `block-${++_idCounter}-${Date.now()}`; }

export function buildReportBlocks(data: ReportData): ReportBlock[] {
  const { startDate, endDate, sessionCounts, counselingBreakdown, cases } = data;

  const blocks: ReportBlock[] = [];

  // 1. 보고 기간
  blocks.push({
    id: id(), type: 'heading', title: '1. 보고 기간', content: '',
  });
  blocks.push({
    id: id(), type: 'text', title: '',
    content: `${startDate} ~ ${endDate}`,
  });

  // 2. 업무 실적 총괄
  blocks.push({ id: id(), type: 'heading', title: '2. 업무 실적 총괄', content: '' });
  blocks.push({
    id: id(), type: 'chart', title: '업무 실적 총괄',
    content: '',
    chartConfig: {
      chartType: 'bar-h',
      data: [
        { name: '상담', value: sessionCounts.counseling },
        { name: '검사', value: sessionCounts.inspection },
        { name: '자문', value: sessionCounts.consultation },
        { name: '교육', value: sessionCounts.education },
        { name: '연구', value: sessionCounts.research },
        { name: '의뢰', value: sessionCounts.referral },
      ].filter(d => d.value > 0),
      showDataTable: true,
    },
  });

  // 3. 상담 상세
  blocks.push({ id: id(), type: 'heading', title: '3. 상담 상세', content: '' });

  blocks.push({
    id: id(), type: 'chart', title: '유형별',
    content: '',
    chartConfig: {
      chartType: 'donut',
      data: [
        { name: '개인상담', value: counselingBreakdown.individual },
        { name: '집단상담', value: counselingBreakdown.group },
        { name: '학부모상담', value: counselingBreakdown.parent },
      ].filter(d => d.value > 0),
      showDataTable: true,
    },
  });

  blocks.push({
    id: id(), type: 'chart', title: '매체별',
    content: '',
    chartConfig: {
      chartType: 'donut',
      data: [
        { name: '면담', value: counselingBreakdown.face },
        { name: '전화상담', value: counselingBreakdown.phone },
        { name: '사이버상담', value: counselingBreakdown.cyber },
      ].filter(d => d.value > 0),
      showDataTable: true,
    },
  });

  blocks.push({
    id: id(), type: 'table', title: '분류별',
    content: '',
    tableHeaders: ['항목', '건수'],
    tableRows: [
      { cells: ['일반상담', String(counselingBreakdown.general)] },
      { cells: ['전문상담', String(counselingBreakdown.professional)] },
      { cells: ['순회상담', String(counselingBreakdown.outreach)] },
    ],
  });

  if (counselingBreakdown.individualAreas.length > 0) {
    blocks.push({
      id: id(), type: 'chart', title: '개인상담 영역별',
      content: '',
      chartConfig: {
        chartType: 'bar-h',
        data: counselingBreakdown.individualAreas.map(a => ({ name: a.area, value: a.count })),
        showDataTable: true,
      },
    });
  }

  // 4. 상담 사례 개요
  blocks.push({ id: id(), type: 'heading', title: '4. 상담 사례 개요', content: '' });
  // 기본 정보 (좁은 컬럼)
  blocks.push({
    id: id(), type: 'table', title: '기본 정보',
    content: '',
    tableHeaders: ['사례번호', '학년', '이름', '시작일', '종료일'],
    tableRows: cases.length > 0
      ? cases.map((c) => ({
          cells: [
            c.case_number,
            c.grade,
            c.student_names,
            c.first_session_date ?? '-',
            c.status === 'closed' ? (c.last_session_date ?? '-') : '미종료',
          ],
        }))
      : [{ cells: ['-', '-', '-', '-', '-'] }],
  });
  // 상담 내용 요약 — 사례별 세로 테이블
  if (cases.length === 0) {
    blocks.push({
      id: id(), type: 'table', title: '상담 내용 요약',
      content: '',
      tableHeaders: ['항목', '내용'],
      tableRows: [{ cells: ['-', '-'] }],
    });
  } else {
    for (const c of cases) {
      blocks.push({
        id: id(), type: 'table', title: `사례 ${c.case_number}`,
        content: '',
        tableHeaders: ['항목', '내용'],
        tableRows: [
          { cells: ['주호소문제', c.main_complaint ?? '-'] },
          { cells: ['상담목표', c.counseling_goal ?? '-'] },
          { cells: ['교사의견', c.teacher_opinion ?? '-'] },
        ],
      });
    }
  }

  // 5. 행사 실적
  blocks.push({ id: id(), type: 'heading', title: '5. 행사 실적', content: '' });
  blocks.push({ id: id(), type: 'text', title: '', content: '해당 기간에 행사가 없습니다.' });

  // 6. 기타 보고사항
  blocks.push({ id: id(), type: 'heading', title: '6. 기타 보고사항', content: '' });
  blocks.push({ id: id(), type: 'text', title: '', content: '-\n-\n-' });

  return blocks;
}
