import { useState, useRef } from 'react';
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  verticalListSortingStrategy,
  useSortable,
  arrayMove,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical, Trash2, Plus, PlusCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Cell,
} from 'recharts';
import { getChartColors } from '@/lib/chart-palette';
import { ProportionBar } from '@/components/statistics/proportion-bar';

export type BlockType = 'heading' | 'table' | 'text' | 'chart';

export interface TableRow {
  cells: string[];
}

export interface ChartConfig {
  chartType: 'bar-h' | 'bar-v' | 'donut';
  data: { name: string; value: number }[];
  showDataTable?: boolean;
}

export interface ReportBlock {
  id: string;
  type: BlockType;
  title: string;
  // heading/text: content is string; table: rows
  content: string;
  tableHeaders?: string[];
  tableRows?: TableRow[];
  chartConfig?: ChartConfig;
}

interface SortableBlockProps {
  block: ReportBlock;
  onChange: (updated: ReportBlock) => void;
  onDelete: () => void;
  isPrintMode: boolean;
}

function SortableBlock({ block, onChange, onDelete, isPrintMode }: SortableBlockProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: block.id });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
  };

  function updateTitle(v: string) { onChange({ ...block, title: v }); }
  function updateContent(v: string) { onChange({ ...block, content: v }); }

  function updateTableHeader(colIdx: number, v: string) {
    const headers = [...(block.tableHeaders ?? [])];
    headers[colIdx] = v;
    onChange({ ...block, tableHeaders: headers });
  }

  function updateTableCell(rowIdx: number, colIdx: number, v: string) {
    const rows = (block.tableRows ?? []).map((r) => ({ cells: [...r.cells] }));
    rows[rowIdx].cells[colIdx] = v;
    onChange({ ...block, tableRows: rows });
  }

  function addTableRow() {
    const colCount = block.tableHeaders?.length ?? 1;
    const rows = [...(block.tableRows ?? []), { cells: Array(colCount).fill('') }];
    onChange({ ...block, tableRows: rows });
  }

  function deleteTableRow(rowIdx: number) {
    const rows = (block.tableRows ?? []).filter((_, i) => i !== rowIdx);
    onChange({ ...block, tableRows: rows });
  }

  function addTableCol() {
    const headers = [...(block.tableHeaders ?? []), '새 열'];
    const rows = (block.tableRows ?? []).map((r) => ({ cells: [...r.cells, ''] }));
    onChange({ ...block, tableHeaders: headers, tableRows: rows });
  }

  function deleteTableCol(colIdx: number) {
    const headers = (block.tableHeaders ?? []).filter((_, i) => i !== colIdx);
    const rows = (block.tableRows ?? []).map((r) => ({ cells: r.cells.filter((_, i) => i !== colIdx) }));
    onChange({ ...block, tableHeaders: headers, tableRows: rows });
  }

  return (
    <div ref={setNodeRef} style={style} className="group relative">
      {/* 드래그 핸들 + 삭제 — 인쇄 시 숨김 */}
      <div className="absolute -left-8 top-2 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity print:hidden">
        <button
          className="cursor-grab text-muted-foreground hover:text-foreground"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-4 w-4" />
        </button>
        <button onClick={onDelete} className="text-muted-foreground hover:text-destructive">
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      </div>

      {block.type === 'heading' && (
        <div className="mt-6 mb-1 first:mt-0">
          <input
            className="w-full text-lg font-bold bg-transparent border-b border-transparent hover:border-border focus:border-primary outline-none pb-1 print:border-none"
            value={block.title}
            onChange={(e) => updateTitle(e.target.value)}
            readOnly={isPrintMode}
          />
        </div>
      )}

      {block.type === 'text' && (
        <div className="mb-4 space-y-1">
          {block.title && (
            <input
              className="w-full text-sm font-semibold bg-transparent border-b border-transparent hover:border-border focus:border-primary outline-none pb-0.5 print:border-none"
              value={block.title}
              onChange={(e) => updateTitle(e.target.value)}
              readOnly={isPrintMode}
            />
          )}
          <textarea
            className="w-full text-sm bg-transparent border border-transparent hover:border-border focus:border-primary outline-none rounded p-1 resize-none print:border-none"
            value={block.content}
            onChange={(e) => updateContent(e.target.value)}
            rows={1}
            onInput={(e) => {
              const el = e.currentTarget;
              el.style.height = 'auto';
              el.style.height = `${el.scrollHeight}px`;
            }}
            readOnly={isPrintMode}
          />
        </div>
      )}

      {block.type === 'table' && (
        <div className="mb-6">
          <input
            className="w-full text-base font-semibold bg-transparent border-b border-transparent hover:border-border focus:border-primary outline-none pb-1 mb-2 print:border-none"
            value={block.title}
            onChange={(e) => updateTitle(e.target.value)}
            readOnly={isPrintMode}
          />
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead>
                <tr className="bg-secondary">
                  {(block.tableHeaders ?? []).map((h, ci) => (
                    <th key={ci} className="border border-border px-3 py-2 text-left font-semibold">
                      <div className="flex items-center gap-1">
                        <input
                          className="w-full bg-transparent outline-none font-semibold print:pointer-events-none"
                          value={h}
                          onChange={(e) => updateTableHeader(ci, e.target.value)}
                          readOnly={isPrintMode}
                        />
                        {(block.tableHeaders?.length ?? 0) > 1 && (
                          <button onClick={() => deleteTableCol(ci)} className="text-muted-foreground hover:text-destructive shrink-0 print:hidden">
                            <Trash2 className="h-3 w-3" />
                          </button>
                        )}
                      </div>
                    </th>
                  ))}
                  <th className="w-8 border border-border print:hidden" />
                </tr>
              </thead>
              <tbody>
                {(block.tableRows ?? []).map((row, ri) => (
                  <tr key={ri} className="hover:bg-secondary/50">
                    {row.cells.map((cell, ci) => (
                      <td key={ci} className="border border-border px-3 py-1.5">
                        <textarea
                          className="w-full bg-transparent outline-none resize-none text-sm print:pointer-events-none"
                          value={cell}
                          onChange={(e) => updateTableCell(ri, ci, e.target.value)}
                          rows={1}
                          onInput={(e) => {
                            const el = e.currentTarget;
                            el.style.height = 'auto';
                            el.style.height = `${el.scrollHeight}px`;
                          }}
                          readOnly={isPrintMode}
                        />
                      </td>
                    ))}
                    <td className="border border-border text-center print:hidden">
                      <button onClick={() => deleteTableRow(ri)} className="text-muted-foreground hover:text-destructive p-1">
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-1 flex gap-3 print:hidden">
            <button
              onClick={addTableRow}
              className="flex items-center gap-1 text-xs text-muted-foreground hover:text-primary"
            >
              <Plus className="h-3 w-3" /> 행 추가
            </button>
            <button
              onClick={addTableCol}
              className="flex items-center gap-1 text-xs text-muted-foreground hover:text-primary"
            >
              <Plus className="h-3 w-3" /> 열 추가
            </button>
          </div>
        </div>
      )}

      {block.type === 'chart' && block.chartConfig && (() => {
        const colors = getChartColors();
        return (
          <div className="mb-6 print-section">
            <input
              className="w-full text-base font-semibold bg-transparent border-b border-transparent hover:border-border focus:border-primary outline-none pb-1 mb-2 print:border-none"
              value={block.title}
              onChange={(e) => updateTitle(e.target.value)}
              readOnly={isPrintMode}
            />
            {/* Chart */}
            <div className="my-2">
              {block.chartConfig.chartType === 'bar-h' && (
                <BarChart
                  width={600}
                  height={Math.max(160, block.chartConfig.data.length * 32)}
                  data={block.chartConfig.data}
                  layout="vertical"
                  barSize={12}
                  margin={{ top: 4, right: 48, left: 8, bottom: 4 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={100} />
                  <Bar dataKey="value" name="건수" radius={[0, 3, 3, 0]}>
                    {block.chartConfig.data.map((_, i) => (
                      <Cell key={i} fill={colors[i % colors.length]} />
                    ))}
                  </Bar>
                </BarChart>
              )}
              {block.chartConfig.chartType === 'bar-v' && (
                <BarChart
                  width={600}
                  height={200}
                  data={block.chartConfig.data}
                  barSize={20}
                  margin={{ top: 4, right: 24, left: 8, bottom: 4 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.06)" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                  <Bar dataKey="value" name="건수" radius={[3, 3, 0, 0]}>
                    {block.chartConfig.data.map((_, i) => (
                      <Cell key={i} fill={colors[i % colors.length]} />
                    ))}
                  </Bar>
                </BarChart>
              )}
              {block.chartConfig.chartType === 'donut' && (
                // 'donut'은 레거시 키 — 도넛 대신 가로 비중 막대로 렌더(통계 페이지와 통일).
                // 아래 데이터 표(showDataTable)가 켜져 있으면 범례는 중복이므로 끈다.
                <ProportionBar
                  data={block.chartConfig.data}
                  showLegend={!block.chartConfig.showDataTable}
                />
              )}
            </div>
            {/* Data table below chart when showDataTable is true */}
            {block.chartConfig.showDataTable && (
              <table className="w-full text-sm border-collapse mt-2">
                <thead>
                  <tr className="bg-secondary">
                    <th className="border border-border px-3 py-1.5 text-left font-semibold">항목</th>
                    <th className="border border-border px-3 py-1.5 text-right font-semibold">건수</th>
                  </tr>
                </thead>
                <tbody>
                  {block.chartConfig.data.map((d, i) => (
                    <tr key={i}>
                      <td className="border border-border px-3 py-1">{d.name}</td>
                      <td className="border border-border px-3 py-1 text-right">{d.value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        );
      })()}
    </div>
  );
}

interface BlockEditorProps {
  blocks: ReportBlock[];
  onChange: (blocks: ReportBlock[]) => void;
  isPrintMode: boolean;
}

export function BlockEditor({ blocks, onChange, isPrintMode }: BlockEditorProps) {
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (over && active.id !== over.id) {
      const oldIdx = blocks.findIndex((b) => b.id === active.id);
      const newIdx = blocks.findIndex((b) => b.id === over.id);
      onChange(arrayMove(blocks, oldIdx, newIdx));
    }
  }

  function updateBlock(id: string, updated: ReportBlock) {
    onChange(blocks.map((b) => (b.id === id ? updated : b)));
  }

  function deleteBlock(id: string) {
    onChange(blocks.filter((b) => b.id !== id));
  }

  function addBlock(type: BlockType) {
    const id = `block-${Date.now()}`;
    let newBlock: ReportBlock;
    if (type === 'table') {
      newBlock = { id, type, title: '새 표', content: '', tableHeaders: ['항목', '내용'], tableRows: [{ cells: ['', ''] }] };
    } else if (type === 'chart') {
      newBlock = { id, type, title: '새 차트', content: '', chartConfig: { chartType: 'bar-h', data: [{ name: '항목1', value: 10 }], showDataTable: true } };
    } else {
      newBlock = { id, type, title: type === 'heading' ? '새 섹션' : '', content: '' };
    }
    onChange([...blocks, newBlock]);
  }

  return (
    <div>
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <SortableContext items={blocks.map((b) => b.id)} strategy={verticalListSortingStrategy}>
          <div className="pl-8">
            {blocks.map((block) => (
              <SortableBlock
                key={block.id}
                block={block}
                onChange={(updated) => updateBlock(block.id, updated)}
                onDelete={() => deleteBlock(block.id)}
                isPrintMode={isPrintMode}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>

      <div className="flex gap-2 mt-4 pl-8 print:hidden">
        <Button variant="outline" size="sm" onClick={() => addBlock('heading')}>
          <PlusCircle className="h-3.5 w-3.5 mr-1" /> 섹션 제목
        </Button>
        <Button variant="outline" size="sm" onClick={() => addBlock('table')}>
          <PlusCircle className="h-3.5 w-3.5 mr-1" /> 표
        </Button>
        <Button variant="outline" size="sm" onClick={() => addBlock('text')}>
          <PlusCircle className="h-3.5 w-3.5 mr-1" /> 텍스트
        </Button>
        <Button variant="outline" size="sm" onClick={() => addBlock('chart')}>
          <PlusCircle className="h-3.5 w-3.5 mr-1" /> 차트
        </Button>
      </div>
    </div>
  );
}
