'use client';

import { useState, useRef, useEffect } from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CATEGORY_TREE, getMediumsByLarge, getDetailsByMedium, getFlatCategories } from '@/lib/constants/categories';
import type { FlatCategory } from '@/lib/constants/categories';

interface CascadingSelectProps {
  categoryLarge: string;
  categoryMedium: string;
  categoryDetail: string;
  onCategoryLargeChange: (value: string) => void;
  onCategoryMediumChange: (value: string) => void;
  onCategoryDetailChange: (value: string) => void;
  onBatchCategoryChange?: (large: string, medium: string, detail: string) => void;
}

export function CascadingSelect({
  categoryLarge,
  categoryMedium,
  categoryDetail,
  onCategoryLargeChange,
  onCategoryMediumChange,
  onCategoryDetailChange,
  onBatchCategoryChange,
}: CascadingSelectProps) {
  const mediums = categoryLarge ? getMediumsByLarge(categoryLarge) : [];
  const details = categoryLarge && categoryMedium
    ? getDetailsByMedium(categoryLarge, categoryMedium)
    : [];

  // 소분류 검색 상태
  const [searchQuery, setSearchQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchResults, setSearchResults] = useState<FlatCategory[]>([]);
  const [highlightIdx, setHighlightIdx] = useState(-1);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function handleLargeChange(value: string) {
    onCategoryLargeChange(value);
    onCategoryMediumChange('');
    onCategoryDetailChange('');
  }

  function handleMediumChange(value: string) {
    onCategoryMediumChange(value);
    onCategoryDetailChange('');
  }

  // 소분류 검색 처리
  function handleSearchInput(query: string) {
    setSearchQuery(query);
    setHighlightIdx(-1);
    if (query.trim().length === 0) {
      setSearchResults([]);
      setSearchOpen(false);
      return;
    }
    const flat = getFlatCategories();
    const filtered = flat.filter((item) =>
      item.detail.includes(query) || item.medium.includes(query) || item.large.includes(query)
    );
    setSearchResults(filtered);
    setSearchOpen(filtered.length > 0);
  }

  function handleSearchSelect(item: FlatCategory) {
    if (onBatchCategoryChange) {
      onBatchCategoryChange(item.large, item.medium, item.detail);
    } else {
      onCategoryLargeChange(item.large);
      onCategoryMediumChange(item.medium);
      onCategoryDetailChange(item.detail);
    }
    setSearchQuery('');
    setSearchOpen(false);
    setSearchResults([]);
  }

  function handleSearchKeyDown(e: React.KeyboardEvent) {
    if (!searchOpen || searchResults.length === 0) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightIdx((prev) => Math.min(prev + 1, searchResults.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightIdx((prev) => Math.max(prev - 1, 0));
    } else if (e.key === 'Enter' && highlightIdx >= 0) {
      e.preventDefault();
      handleSearchSelect(searchResults[highlightIdx]);
    } else if (e.key === 'Escape') {
      setSearchOpen(false);
    }
  }

  // 외부 클릭 시 검색 드롭다운 닫기
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setSearchOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="space-y-4">
      {/* 소분류 빠른 검색 */}
      <div ref={searchRef} className="relative">
        <Label htmlFor="cs-quick-search" className="text-xs text-muted-foreground">소분류 (상담 구분) 빠른 검색 (입력하면 상위 분류가 자동 설정됩니다)</Label>
        <Input
          id="cs-quick-search"
          ref={inputRef}
          value={searchQuery}
          onChange={(e) => handleSearchInput(e.target.value)}
          onKeyDown={handleSearchKeyDown}
          onFocus={() => { if (searchResults.length > 0) setSearchOpen(true); }}
          placeholder="소분류명을 검색하세요 (예: 학업, 진로, 성격...)"
          className="mt-1"
        />
        {searchOpen && searchResults.length > 0 && (
          <div className="absolute z-50 mt-1 w-full max-h-60 overflow-auto rounded-md border bg-popover p-1 shadow-md">
            {searchResults.map((item, idx) => (
              <button
                key={`${item.large}-${item.medium}-${item.detail}`}
                type="button"
                className={`w-full text-left rounded-sm px-2 py-1.5 text-sm cursor-pointer ${
                  idx === highlightIdx ? 'bg-accent text-accent-foreground' : 'hover:bg-accent/50'
                }`}
                onMouseEnter={() => setHighlightIdx(idx)}
                onClick={() => handleSearchSelect(item)}
              >
                <span className="font-medium">{item.detail}</span>
                <span className="ml-2 text-xs text-muted-foreground">
                  {item.large} &gt; {item.medium}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 기존 3단계 드롭다운 */}
      <div className="grid gap-4 md:grid-cols-3">
        {/* 대분류 */}
        <div className="space-y-2">
          <Label htmlFor="cs-large">대분류 *</Label>
          <Select value={categoryLarge} onValueChange={handleLargeChange}>
            <SelectTrigger id="cs-large">
              <SelectValue placeholder="대분류 선택" />
            </SelectTrigger>
            <SelectContent>
              {CATEGORY_TREE.map((cat) => (
                <SelectItem key={cat.label} value={cat.label}>
                  {cat.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* 중분류 */}
        <div className="space-y-2">
          <Label htmlFor="cs-medium">중분류 *</Label>
          <Select
            key={categoryLarge}
            value={categoryMedium}
            onValueChange={handleMediumChange}
            disabled={!categoryLarge}
          >
            <SelectTrigger id="cs-medium">
              <SelectValue placeholder={categoryLarge ? '중분류 선택' : '대분류를 먼저 선택'} />
            </SelectTrigger>
            <SelectContent>
              {mediums.map((m) => (
                <SelectItem key={m.label} value={m.label}>
                  {m.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* 소분류 (상담 구분) */}
        <div className="space-y-2">
          <Label htmlFor="cs-detail">소분류 (상담 구분) *</Label>
          <Select
            key={`${categoryLarge}-${categoryMedium}`}
            value={categoryDetail}
            onValueChange={onCategoryDetailChange}
            disabled={!categoryMedium}
          >
            <SelectTrigger id="cs-detail">
              <SelectValue placeholder={categoryMedium ? '소분류 선택' : '중분류를 먼저 선택'} />
            </SelectTrigger>
            <SelectContent>
              {details.map((d) => (
                <SelectItem key={d.label} value={d.label}>
                  {d.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}
