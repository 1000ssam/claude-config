import { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { CaseCombobox } from '@/components/cases/case-combobox';
import { SessionForm } from '@/components/sessions/session-form';
import type { CaseWithSessionCount } from '@/types/case';

interface QuickSessionDialogProps {
  open: boolean;
  /** 닫기(취소/완료 공통) */
  onClose: () => void;
  /** 저장 성공 시(캘린더 갱신용) */
  onSuccess: () => void;
  /** 초기 상담일자(YYYY-MM-DD). 캘린더 셀/패널에서 진입 시 프리필 */
  initialDate?: string;
}

/**
 * 대시보드에서 사례 맥락 없이 세션(일정)을 빠르게 등록하는 다이얼로그.
 * 1단계: 진행중 사례 선택 → 2단계: 기존 SessionForm 전체 재사용.
 * 사례를 먼저 고르면 SessionForm이 그 caseId로 사례 데이터(자동 제목·학생·학년도)를 로드한다.
 */
export function QuickSessionDialog({ open, onClose, onSuccess, initialDate }: QuickSessionDialogProps) {
  const [selectedCase, setSelectedCase] = useState<CaseWithSessionCount | null>(null);

  // 닫힐 때 선택 상태 초기화(다음 진입은 사례 선택부터)
  function handleClose() {
    setSelectedCase(null);
    onClose();
  }

  function handleSuccess() {
    setSelectedCase(null);
    onSuccess();
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) handleClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>일정 추가</DialogTitle>
          <DialogDescription>
            {selectedCase
              ? `사례 ${selectedCase.case_number} · 새 상담 일정`
              : '세션을 추가할 진행중 사례를 먼저 선택하세요.'}
          </DialogDescription>
        </DialogHeader>

        {!selectedCase ? (
          <div className="py-2">
            <CaseCombobox onSelect={setSelectedCase} autoFocus />
          </div>
        ) : (
          <div className="flex flex-col gap-3 overflow-y-auto">
            <Button
              variant="ghost"
              size="sm"
              className="w-fit -ml-1"
              onClick={() => setSelectedCase(null)}
            >
              <ArrowLeft className="mr-1.5 h-3.5 w-3.5" />
              사례 다시 선택
            </Button>
            <SessionForm
              caseId={String(selectedCase.id)}
              defaultDate={initialDate}
              onSuccess={handleSuccess}
              onCancel={handleClose}
            />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
