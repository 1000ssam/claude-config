import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, RotateCcw } from 'lucide-react';
import { DateTimePicker } from '@/components/ui/date-time-picker';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { CascadingSelect } from '@/components/sessions/cascading-select';
import { SttRecorderButton } from '@/components/stt/stt-recorder-button';
import {
  COUNSELING_CLASS_OPTIONS,
  WEE_CLASS_OPTIONS,
  COUNSELOR_AFFILIATION_OPTIONS,
  MEDIUM_OPTIONS,
} from '@/lib/constants/options';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { getAcademicYearFromDateStr } from '@/lib/academic-year';
import type { Session } from '@/types/session';
import type { Case, CaseStudent } from '@/types/case';
import { AiAssistButton } from '@/components/ai/ai-assist-button';
import type { AiContextRequest } from '@/types/ai';

interface SessionFormProps {
  caseId: string;
  /** 수정 모드일 때 기존 세션 데이터 */
  initialData?: Session;
  /** 수정 모드 여부 */
  isEdit?: boolean;
  /** 수정 취소/완료 콜백 */
  onCancel?: () => void;
  /** 생성 모드 초기 상담일자(대시보드 빠른 등록용). YYYY-MM-DD */
  defaultDate?: string;
  /** 생성 모드 초기 예약시각(HH:MM). defaultDate와 함께 사용 */
  defaultTime?: string | null;
  /** 생성 저장 성공 시 호출(있으면 navigate 대신 콜백 — 대시보드 유지용) */
  onSuccess?: (sessionId: number) => void;
}

/**
 * 회기 제목 자동 생성. 형식: `{YYMMDD}_{사례번호-앞2자리제거}_{카테고리}`.
 * 예: 2026-05-21 · 사례 2026-001 · 상담 → "260521_26-001_상담".
 *
 * 회기 번호는 의도적으로 빼고 날짜로 식별 (회기 번호는 동적 계산값이라 NEIS 제출 후 변동
 * 가능성 — 박제 문제 회피). 같은 날 같은 카테고리 회기가 2건 있으면 제목이 같아지는데,
 * NEIS 상담제목은 라벨이라 무영향. UI도 회기 카드는 별도 행이라 사용자 혼란 거의 없음.
 */
function formatAutoSessionTitle(sessionDate: string, caseNumber: string, categoryLarge: string): string {
  // sessionDate: 'YYYY-MM-DD' → 'YYMMDD'. 형식이 다르면 빈 문자열.
  const m = /^(\d{2})(\d{2})-(\d{2})-(\d{2})$/.exec(sessionDate);
  const shortDate = m ? `${m[2]}${m[3]}${m[4]}` : '';
  // caseNumber: 'YYYY-NNN' → 'YY-NNN'. 형식이 다르면 그대로.
  const shortCase = /^\d{4}-\d+/.test(caseNumber) ? caseNumber.slice(2) : caseNumber;
  const cat = (categoryLarge || '').trim();
  if (!shortDate || !shortCase || !cat) return '';
  return `${shortDate}_${shortCase}_${cat}`;
}

/** AI 인라인 버튼이 보낼 ContextRequest 디스크립터 — 폼의 현재 작성 중 값을 draft로 같이 전달. */
function buildSessionContextRequest(
  caseId: string,
  form: { session_title: string; session_content: string; internal_notes: string },
  initialData: Session | undefined,
): AiContextRequest {
  return {
    kind: 'session-form',
    caseId: Number(caseId),
    sessionId: initialData?.id,
    draft: {
      session_title: form.session_title,
      session_content: form.session_content,
      // internal_notes는 produceSessionForm이 자체 필터링하지만, 호출 일관성을 위해 같이 보냄.
      internal_notes: form.internal_notes,
    },
  };
}

/** AI 결과를 폼 필드에 반영 (mode='append'면 기존 값 뒤로). */
function applyToField(
  field: 'session_title' | 'session_content' | 'internal_notes',
  result: string,
  mode: 'replace' | 'append',
  form: { session_title: string; session_content: string; internal_notes: string },
  updateField: (k: 'session_title' | 'session_content' | 'internal_notes', v: string) => void,
): void {
  if (mode === 'replace') {
    updateField(field, result);
    return;
  }
  const prev = form[field] || '';
  const sep = prev && !prev.endsWith('\n') ? '\n' : '';
  updateField(field, prev + sep + result);
}

function getTodayString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

const REMINDER_OPTIONS = [
  { label: '없음', value: null },
  { label: '10분 전', value: 10 },
  { label: '30분 전', value: 30 },
  { label: '1시간 전', value: 60 },
  { label: '2시간 전', value: 120 },
  { label: '하루 전', value: 1440 },
];

interface FormState {
  counseling_class: string;
  wee_class: string;
  category_large: string;
  category_medium: string;
  category_detail: string;
  academic_year: string;
  session_date: string;
  appointment_time: string | null;
  reminder_minutes: number | null;
  session_title: string;
  session_content: string;
  session_hour: number;
  session_minute: number;
  counselor_affil: string;
  medium: string;
  internal_notes: string;
}

// 검증 에러를 스크롤 대상 섹션/필드와 매핑하기 위한 키
type FieldErrorKey =
  | 'students'
  | 'counseling_class'
  | 'wee_class'
  | 'category'
  | 'session_date'
  | 'session_title'
  | 'session_content'
  | 'counselor_affil';

const FIELD_ERROR_DOM_IDS: Record<FieldErrorKey, string> = {
  students: 'sf-students-section',
  counseling_class: 'sf-counseling-class',
  wee_class: 'sf-wee-class',
  category: 'sf-category-section',
  session_date: 'sf-session-date',
  session_title: 'sf-session-title',
  session_content: 'sf-session-content',
  counselor_affil: 'sf-counselor-affil',
};

const DEFAULT_FORM: FormState = {
  counseling_class: '',
  wee_class: '',
  category_large: '',
  category_medium: '',
  category_detail: '',
  academic_year: getAcademicYearFromDateStr(getTodayString()),
  session_date: getTodayString(),
  appointment_time: null,
  reminder_minutes: null,
  session_title: '',
  session_content: '',
  session_hour: 0,
  session_minute: 0,
  counselor_affil: '',
  medium: '면담',
  internal_notes: '',
};

export function SessionForm({ caseId, initialData, isEdit = false, onCancel, defaultDate, defaultTime, onSuccess }: SessionFormProps) {
  const navigate = useNavigate();
  const { addToast } = useToast();
  const [saving, setSaving] = useState(false);
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [fieldError, setFieldError] = useState<{ key: FieldErrorKey; message: string } | null>(null);
  const [caseData, setCaseData] = useState<Case | null>(null);
  const [showYearMismatchDialog, setShowYearMismatchDialog] = useState(false);

  // Selected student IDs for this session
  const [selectedStudentIds, setSelectedStudentIds] = useState<Set<number>>(new Set());

  // category_large 전환 감지용 — 첫 마운트는 skip, 이후 전환에만 동작
  const prevCategoryLargeRef = useRef<string | null>(null);

  // 사용자가 session_title 입력란을 직접 건드렸는지 추적. true 이후엔 자동 생성 중단.
  // 수정 모드는 항상 사용자 입력으로 간주(자동 갱신 안 함).
  const titleTouchedRef = useRef<boolean>(isEdit);

  const [form, setForm] = useState<FormState>(() => {
    if (initialData) {
      return {
        counseling_class: initialData.counseling_class,
        wee_class: initialData.wee_class,
        category_large: initialData.category_large,
        category_medium: initialData.category_medium,
        category_detail: initialData.category_detail,
        academic_year: initialData.academic_year,
        session_date: initialData.session_date,
        appointment_time: initialData.appointment_time ?? null,
        reminder_minutes: initialData.reminder_minutes ?? null,
        session_title: initialData.session_title,
        session_content: initialData.session_content,
        session_hour: initialData.session_hour,
        session_minute: initialData.session_minute,
        counselor_affil: initialData.counselor_affil,
        medium: initialData.medium,
        internal_notes: initialData.internal_notes || '',
      };
    }
    return {
      ...DEFAULT_FORM,
      ...(defaultDate ? { session_date: defaultDate } : {}),
      ...(defaultDate && defaultTime ? { appointment_time: defaultTime } : {}),
    };
  });

  // 설정 + 사례 정보 로드
  useEffect(() => {
    if (settingsLoaded) return;

    if (isEdit) {
      // 수정 모드: 사례 데이터만 로드
      window.api.cases.get(Number(caseId))
        .then((c) => {
          if (c) {
            setCaseData(c);
            // Edit mode: pre-select students from initialData
            if (initialData?.students) {
              setSelectedStudentIds(new Set(initialData.students.map((s) => s.student_id)));
            } else {
              // fallback: select all case students
              setSelectedStudentIds(new Set(c.students.map((s) => s.student_id)));
            }
          }
          setSettingsLoaded(true);
        })
        .catch(() => setSettingsLoaded(true));
    } else {
      // 새 작성 모드: 설정 + 사례 정보에서 기본값 프리필
      Promise.all([
        window.api.settings.get(),
        window.api.cases.get(Number(caseId)),
      ])
        .then(([settings, c]) => {
          if (c) {
            setCaseData(c);
            // 새 세션: 모든 학생 선택
            setSelectedStudentIds(new Set(c.students.map((s) => s.student_id)));
          }
          // [의도적 비정규화] counselor_affil은 settings에서 기본값을 프리필하되,
          // 세션별로 다른 값을 선택할 수 있다. 저장된 값은 해당 세션 시점의 소속을 보존한다.
          setForm((prev) => ({
            ...prev,
            counselor_affil: prev.counselor_affil || settings.counselor_affiliation || '',
            wee_class: prev.wee_class || settings.wee_class || '',
            counseling_class: prev.counseling_class || settings.default_counseling_class || '',
          }));
          setSettingsLoaded(true);
        })
        .catch(() => setSettingsLoaded(true));
    }
  }, [isEdit, settingsLoaded, caseId, initialData]);

  // category_large 전환 시 학생 선택 자동 조정
  // - '연구'로 전환: 전원 해제 (연구는 자기계발/직무계발로 학생과 무관)
  // - '연구' → 타 카테고리 전환: 사례 학생 전원 재선택
  // 첫 마운트는 skip하여 edit 모드에서 저장된 선택을 덮어쓰지 않음
  useEffect(() => {
    if (prevCategoryLargeRef.current === null) {
      prevCategoryLargeRef.current = form.category_large;
      return;
    }
    if (prevCategoryLargeRef.current === form.category_large) return;

    const prev = prevCategoryLargeRef.current;
    const curr = form.category_large;
    prevCategoryLargeRef.current = curr;

    if (curr === '연구') {
      setSelectedStudentIds(new Set());
    } else if (prev === '연구' && caseData) {
      setSelectedStudentIds(new Set(caseData.students.map((s) => s.student_id)));
    }
  }, [form.category_large, caseData]);

  // 회기 제목 자동 생성: 신규 모드 + 사용자가 직접 안 건드린 상태 + caseData·date·category 모두 준비됐을 때.
  // 형식: '260521_26-001_상담' (formatAutoSessionTitle 참조).
  useEffect(() => {
    if (titleTouchedRef.current) return;
    if (!caseData?.case_number) return;
    if (!form.session_date || !form.category_large) return;
    const next = formatAutoSessionTitle(form.session_date, caseData.case_number, form.category_large);
    if (next && next !== form.session_title) {
      setForm((prev) => ({ ...prev, session_title: next }));
    }
  }, [form.session_date, form.category_large, caseData?.case_number, form.session_title]);

  // 필드 변경 → 해당 필드에 걸린 검증 에러 자동 해제
  function clearFieldErrorIf(keys: FieldErrorKey[]) {
    setFieldError((prev) => (prev && keys.includes(prev.key) ? null : prev));
  }

  function updateField<K extends keyof FormState>(
    key: K,
    value: FormState[K]
  ) {
    setForm((prev) => {
      const next = { ...prev, [key]: value };
      // session_date 변경 시 academic_year 자동 산출
      if (key === 'session_date' && typeof value === 'string' && value) {
        next.academic_year = getAcademicYearFromDateStr(value);
      }
      return next;
    });
    // form 필드 → 검증 에러 키 매핑
    const map: Partial<Record<keyof FormState, FieldErrorKey>> = {
      counseling_class: 'counseling_class',
      wee_class: 'wee_class',
      category_large: 'category',
      category_medium: 'category',
      category_detail: 'category',
      session_date: 'session_date',
      session_title: 'session_title',
      session_content: 'session_content',
      counselor_affil: 'counselor_affil',
    };
    const mapped = map[key];
    if (mapped) clearFieldErrorIf([mapped]);
  }

  function toggleStudent(studentId: number, checked: boolean) {
    clearFieldErrorIf(['students']);
    setSelectedStudentIds((prev) => {
      const next = new Set(prev);
      if (checked) {
        next.add(studentId);
      } else {
        next.delete(studentId);
      }
      return next;
    });
  }

  function validateForm(): { key: FieldErrorKey; message: string } | null {
    // 연구 카테고리는 학생 없이 등록 가능
    if (selectedStudentIds.size === 0 && form.category_large !== '연구')
      return { key: 'students', message: '최소 1명의 학생을 선택하세요.' };
    if (!form.counseling_class) return { key: 'counseling_class', message: '상담분류를 선택하세요.' };
    if (!form.wee_class) return { key: 'wee_class', message: 'Wee설치여부를 선택하세요.' };
    if (!form.category_large) return { key: 'category', message: '대분류를 선택하세요.' };
    if (!form.category_medium) return { key: 'category', message: '중분류를 선택하세요.' };
    if (!form.category_detail) return { key: 'category', message: '소분류를 선택하세요.' };
    if (!form.academic_year) return { key: 'session_date', message: '학년도를 입력하세요.' };
    if (!form.session_date) return { key: 'session_date', message: '상담일자를 선택하세요.' };
    if (!form.counselor_affil) return { key: 'counselor_affil', message: '상담사소속을 선택하세요.' };
    return null;
  }

  function scrollToField(key: FieldErrorKey) {
    const el = document.getElementById(FIELD_ERROR_DOM_IDS[key]);
    if (!el) return;
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    // 포커스 가능한 요소면 스크롤 애니메이션 끝난 뒤 포커스 (scroll behavior와 타이밍 충돌 회피)
    setTimeout(() => {
      if (typeof (el as HTMLElement).focus === 'function') (el as HTMLElement).focus();
    }, 300);
  }

  const yearMismatch = caseData ? form.academic_year !== caseData.academic_year : false;

  async function doSave() {
    setSaving(true);

    const body: Record<string, unknown> = {
      ...form,
      student_ids: Array.from(selectedStudentIds),
      session_title: form.session_title.trim(),
      session_content: form.session_content.trim(),
      internal_notes: form.internal_notes?.trim() || null,
      appointment_time: form.appointment_time || null,
      reminder_minutes: form.appointment_time ? (form.reminder_minutes ?? null) : null,
    };

    try {
      let saved;
      if (isEdit) {
        saved = await window.api.sessions.update(initialData!.id, body);
      } else {
        saved = await window.api.sessions.create(Number(caseId), body);
      }

      addToast({
        title: isEdit ? '상담 기록이 수정되었습니다.' : '상담 기록이 저장되었습니다.',
        variant: 'success',
      });
      if (isEdit && onCancel) {
        onCancel();
      } else if (isEdit) {
        navigate(`/cases/${caseId}/sessions/${saved!.id}`);
      } else if (onSuccess) {
        onSuccess(saved!.id);
      } else {
        navigate(`/cases/${caseId}`);
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : '저장에 실패했습니다.';
      addToast({ title: message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const error = validateForm();
    if (error) {
      setFieldError(error);
      addToast({ title: error.message, variant: 'destructive' });
      scrollToField(error.key);
      return;
    }
    setFieldError(null);

    // 학년도 불일치 확인
    if (yearMismatch) {
      setShowYearMismatchDialog(true);
      return;
    }

    doSave();
  }

  const caseStudents: CaseStudent[] = caseData?.students ?? [];

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-3xl">
      {/* 참여 학생 선택 */}
      <Card
        id="sf-students-section"
        tabIndex={-1}
        className={cn(fieldError?.key === 'students' && 'border-destructive ring-1 ring-destructive/30')}
      >
        <CardHeader>
          <CardTitle>참여 학생</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {caseStudents.length === 0 ? (
            <p className="text-sm text-muted-foreground">사례에 등록된 학생이 없습니다.</p>
          ) : (
            <>
              <p className="text-xs text-muted-foreground">
                이 상담에 참여하는 학생을 선택하세요. (인원/학년/성별은 자동 계산됩니다)
                {form.category_large === '연구' && ' — 연구 카테고리는 학생 선택 없이 저장 가능합니다.'}
              </p>
              <div className="space-y-2">
                {caseStudents.map((s) => {
                  const checked = selectedStudentIds.has(s.student_id);
                  return (
                    <label
                      key={s.student_id}
                      className="flex items-center gap-3 rounded-md border px-3 py-2 cursor-pointer hover:bg-muted/50 transition-colors"
                    >
                      <Checkbox
                        checked={checked}
                        onCheckedChange={(c) => toggleStudent(s.student_id, !!c)}
                      />
                      <span className="text-sm font-medium">{s.name}</span>
                      <div className="flex items-center gap-1.5 ml-auto">
                        {s.grade && <Badge variant="outline" className="text-xs">{s.grade}</Badge>}
                        {s.class_name && <Badge variant="outline" className="text-xs">{s.class_name}반</Badge>}
                        {s.gender && <Badge variant="secondary" className="text-xs">{s.gender}</Badge>}
                      </div>
                    </label>
                  );
                })}
              </div>
              <div className="flex items-center gap-3 pt-2 text-xs text-muted-foreground">
                <span>선택: {selectedStudentIds.size}명</span>
                <button
                  type="button"
                  className="underline hover:text-foreground"
                  onClick={() => setSelectedStudentIds(new Set(caseStudents.map((s) => s.student_id)))}
                >
                  전체 선택
                </button>
                <button
                  type="button"
                  className="underline hover:text-foreground"
                  onClick={() => setSelectedStudentIds(new Set())}
                >
                  전체 해제
                </button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* 분류 정보 */}
      <Card>
        <CardHeader>
          <CardTitle>분류 정보</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 단독 드롭다운: 상담분류, Wee설치여부 */}
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="sf-counseling-class">상담분류 <span className="text-destructive">*</span></Label>
              <Select
                value={form.counseling_class}
                onValueChange={(v) => updateField('counseling_class', v)}
              >
                <SelectTrigger
                  id="sf-counseling-class"
                  aria-invalid={fieldError?.key === 'counseling_class'}
                  className={cn(fieldError?.key === 'counseling_class' && 'border-destructive ring-1 ring-destructive/30')}
                >
                  <SelectValue placeholder="상담분류 선택" />
                </SelectTrigger>
                <SelectContent>
                  {COUNSELING_CLASS_OPTIONS.map((o) => (
                    <SelectItem key={o} value={o}>{o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="sf-wee-class">Wee설치여부 <span className="text-destructive">*</span></Label>
              <Select
                value={form.wee_class}
                onValueChange={(v) => updateField('wee_class', v)}
              >
                <SelectTrigger
                  id="sf-wee-class"
                  aria-invalid={fieldError?.key === 'wee_class'}
                  className={cn(fieldError?.key === 'wee_class' && 'border-destructive ring-1 ring-destructive/30')}
                >
                  <SelectValue placeholder="Wee설치여부 선택" />
                </SelectTrigger>
                <SelectContent>
                  {WEE_CLASS_OPTIONS.map((o) => (
                    <SelectItem key={o} value={o}>{o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* 3단계 종속 드롭다운 */}
          <div
            id="sf-category-section"
            tabIndex={-1}
            className={cn(
              'rounded-md',
              fieldError?.key === 'category' && 'ring-1 ring-destructive/30 p-2 -m-2',
            )}
          >
            <CascadingSelect
              categoryLarge={form.category_large}
              categoryMedium={form.category_medium}
              categoryDetail={form.category_detail}
              onCategoryLargeChange={(v) => updateField('category_large', v)}
              onCategoryMediumChange={(v) => updateField('category_medium', v)}
              onCategoryDetailChange={(v) => updateField('category_detail', v)}
              onBatchCategoryChange={(large, medium, detail) => {
                setForm((prev) => ({ ...prev, category_large: large, category_medium: medium, category_detail: detail }));
              }}
            />
          </div>
        </CardContent>
      </Card>

      {/* 기본 정보 */}
      <Card>
        <CardHeader>
          <CardTitle>기본 정보</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="sf-academic-year" className={cn(yearMismatch && 'text-destructive')}>
                학년도
              </Label>
              <div className="flex items-center gap-1.5">
                <Input
                  id="sf-academic-year"
                  value={form.academic_year}
                  readOnly
                  tabIndex={-1}
                  className={cn(
                    'bg-muted text-muted-foreground cursor-default',
                    yearMismatch && 'border-destructive text-destructive',
                  )}
                />
                {yearMismatch && (
                  <AlertTriangle className="h-4 w-4 text-destructive shrink-0" />
                )}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="sf-session-date" className={cn(yearMismatch && 'text-destructive')}>
                상담일자 <span className="text-destructive">*</span>
              </Label>
              <DateTimePicker
                id="sf-session-date"
                date={form.session_date}
                time={form.appointment_time}
                onDateChange={(d) => updateField('session_date', d)}
                onTimeChange={(t) => {
                  updateField('appointment_time', t);
                  if (!t) updateField('reminder_minutes', null);
                }}
                className={cn(
                  yearMismatch && 'border-destructive',
                  fieldError?.key === 'session_date' && 'border-destructive ring-1 ring-destructive/30',
                )}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sf-medium">상담매체구분</Label>
              <Select
                value={form.medium}
                onValueChange={(v) => updateField('medium', v)}
              >
                <SelectTrigger id="sf-medium">
                  <SelectValue placeholder="매체 선택" />
                </SelectTrigger>
                <SelectContent>
                  {MEDIUM_OPTIONS.map((o) => (
                    <SelectItem key={o} value={o}>{o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {form.appointment_time && (
            <div className="space-y-2">
              <Label htmlFor="sf-reminder" className="text-[0.8125rem]">리마인더</Label>
              <Select
                value={form.reminder_minutes != null ? String(form.reminder_minutes) : 'none'}
                onValueChange={(v) => updateField('reminder_minutes', v === 'none' ? null : Number(v))}
              >
                <SelectTrigger id="sf-reminder" className="w-36">
                  <SelectValue placeholder="알림 없음" />
                </SelectTrigger>
                <SelectContent>
                  {REMINDER_OPTIONS.map((o) => (
                    <SelectItem key={String(o.value)} value={o.value == null ? 'none' : String(o.value)}>
                      {o.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="sf-counselor-affil">상담사소속 <span className="text-destructive">*</span></Label>
              <Select
                value={form.counselor_affil}
                onValueChange={(v) => updateField('counselor_affil', v)}
              >
                <SelectTrigger
                  id="sf-counselor-affil"
                  aria-invalid={fieldError?.key === 'counselor_affil'}
                  className={cn(fieldError?.key === 'counselor_affil' && 'border-destructive ring-1 ring-destructive/30')}
                >
                  <SelectValue placeholder="상담사소속 선택" />
                </SelectTrigger>
                <SelectContent>
                  {COUNSELOR_AFFILIATION_OPTIONS.map((o) => (
                    <SelectItem key={o} value={o}>{o}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="sf-session-hour">상담시간</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="sf-session-hour"
                  type="number"
                  min="0"
                  max="23"
                  value={form.session_hour}
                  onChange={(e) => updateField('session_hour', parseInt(e.target.value, 10) || 0)}
                  className="w-20"
                />
                <span className="text-sm text-muted-foreground">시간</span>
                <Input
                  type="number"
                  min="0"
                  max="59"
                  value={form.session_minute}
                  onChange={(e) => updateField('session_minute', parseInt(e.target.value, 10) || 0)}
                  className="w-20"
                />
                <span className="text-sm text-muted-foreground">분</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 상담 내용 */}
      <Card>
        <CardHeader>
          <CardTitle>상담 내용</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="sf-session-title">상담제목</Label>
            <div className="relative">
              <Input
                id="sf-session-title"
                value={form.session_title}
                onChange={(e) => {
                  // 사용자가 직접 수정한 순간부터 자동 생성 중단.
                  titleTouchedRef.current = true;
                  updateField('session_title', e.target.value);
                }}
                placeholder="회기일자·사례번호·카테고리로 자동 생성됩니다. 필요 시 수정하세요."
                aria-invalid={fieldError?.key === 'session_title'}
                className={cn(
                  'pr-9',
                  fieldError?.key === 'session_title' && 'border-destructive ring-1 ring-destructive/30',
                )}
              />
              {(() => {
                // 자동 생성이 가능한 상태(caseData·날짜·카테고리 다 준비됨)면 신규·수정 모드 모두 노출.
                // 수정 모드의 자동 갱신은 NEIS 박제 정책으로 막혀 있지만, 사용자가 명시적으로 누르는 재설정은 허용.
                const cn_ = caseData?.case_number;
                const canReset = !!cn_ && !!form.session_date && !!form.category_large;
                if (!canReset) return null;
                const autoTitle = formatAutoSessionTitle(form.session_date, cn_, form.category_large);
                // 이미 자동값과 같으면(=사용자가 수정 안 함) 버튼 숨김 — 시각 노이즈 제거.
                if (autoTitle && autoTitle === form.session_title) return null;
                return (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      titleTouchedRef.current = false;
                      setForm((prev) => ({ ...prev, session_title: autoTitle }));
                    }}
                    title="자동 생성 제목으로 되돌리기"
                    aria-label="자동 생성 제목으로 되돌리기"
                    className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 text-muted-foreground hover:text-foreground"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                  </Button>
                );
              })()}
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <Label htmlFor="sf-session-content">상담내용</Label>
              <div className="flex items-center gap-2">
                <SttRecorderButton
                  ariaLabel="상담 내용 음성 받아쓰기"
                  onTranscribed={(text) => {
                    const trimmedText = text.trim();
                    if (!trimmedText) return;
                    const currentTrimmed = form.session_content.trimEnd();
                    const next = currentTrimmed.length > 0
                      ? `${currentTrimmed}\n\n${trimmedText}`
                      : trimmedText;
                    updateField('session_content', next);
                  }}
                />
                <AiAssistButton
                  buttonLabel="상담 내용 다듬기·요약·이어쓰기"
                  availableTasks={['refine', 'summarize', 'continue']}
                  originalText={form.session_content}
                  contextRequest={buildSessionContextRequest(caseId, form, initialData)}
                  fieldHint="회기 본문 — 명사형 어미('- ~함')의 개조식 또는 줄글. 관찰·상호작용·해석·다음 회기 계획 순"
                  onApply={(result, mode) => applyToField('session_content', result, mode, form, updateField)}
                />
              </div>
            </div>
            <Textarea
              id="sf-session-content"
              value={form.session_content}
              onChange={(e) => updateField('session_content', e.target.value)}
              placeholder="상담 내용을 입력하세요..."
              rows={8}
              aria-invalid={fieldError?.key === 'session_content'}
              className={cn(fieldError?.key === 'session_content' && 'border-destructive ring-1 ring-destructive/30')}
            />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <Label htmlFor="sf-internal-notes">내부 메모 (NEIS 미포함)</Label>
              <AiAssistButton
                buttonLabel="내부 메모 다듬기"
                availableTasks={['refine']}
                originalText={form.internal_notes || ''}
                contextRequest={buildSessionContextRequest(caseId, form, initialData)}
                fieldHint="내부 참고 메모 — 명사형 어미의 짧은 개조식 메모(NEIS 미포함). 3~5줄 이내"
                onApply={(result, mode) => applyToField('internal_notes', result, mode, form, updateField)}
              />
            </div>
            <Textarea
              id="sf-internal-notes"
              value={form.internal_notes || ''}
              onChange={(e) => updateField('internal_notes', e.target.value)}
              placeholder="내부 참고용 메모를 입력하세요. NEIS 내보내기에 포함되지 않습니다."
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={() => onCancel ? onCancel() : navigate(-1)}>
          취소
        </Button>
        <Button type="submit" disabled={saving}>
          {saving ? (isEdit ? '저장 중...' : '등록 중...') : isEdit ? '저장' : '등록'}
        </Button>
      </div>

      {/* 학년도 불일치 확인 다이얼로그 */}
      <ConfirmDialog
        open={showYearMismatchDialog}
        onOpenChange={setShowYearMismatchDialog}
        title="학년도 불일치"
        description={`사례의 학년도(${caseData?.academic_year})와 상담일시의 학년도(${form.academic_year})가 일치하지 않습니다. 계속하시겠습니까?`}
        confirmLabel="계속 저장"
        cancelLabel="취소"
        onConfirm={doSave}
      />
    </form>
  );
}
