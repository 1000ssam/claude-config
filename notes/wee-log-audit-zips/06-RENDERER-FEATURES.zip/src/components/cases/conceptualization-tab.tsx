import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Pencil, Save, X, FileText } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { CONCEPTUALIZATION_TEMPLATES, getTemplateByType, findEquivalentValue } from '@/lib/constants/conceptualization-templates';
import type { CaseConceptualization } from '@/types/conceptualization';
import { AiAssistButton } from '@/components/ai/ai-assist-button';
import type { AiContextRequest } from '@/types/ai';

interface Props {
  caseId: number;
}

export function ConceptualizationTab({ caseId }: Props) {
  const { addToast } = useToast();
  const [data, setData] = useState<CaseConceptualization | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState('wee_standard');
  const [form, setForm] = useState<Record<string, string>>({});

  useEffect(() => {
    setLoading(true);
    window.api.conceptualizations.get(caseId).then((result) => {
      setData(result ?? null);
      if (result) {
        setSelectedTemplate(result.template_type);
      }
      setLoading(false);
    });
  }, [caseId]);

  const template = getTemplateByType(selectedTemplate);

  function startEditing() {
    const initial: Record<string, string> = {};
    if (template) {
      for (const s of template.sections) {
        initial[s.key] = data?.sections[s.key] ?? '';
      }
    }
    setForm(initial);
    setEditing(true);
  }

  function cancelEditing() {
    setEditing(false);
    setForm({});
    // 수정 취소 시 원래 템플릿으로 복구
    if (data) setSelectedTemplate(data.template_type);
  }

  function handleTemplateChange(type: string) {
    setSelectedTemplate(type);
    const newTemplate = getTemplateByType(type);
    if (!newTemplate) return;
    // 모든 소스: 현재 폼 + DB 저장 데이터
    const allData: Record<string, string> = { ...data?.sections, ...form };
    const merged: Record<string, string> = {};
    for (const s of newTemplate.sections) {
      // 1) 같은 key가 이미 있으면 직접 사용
      const direct = allData[s.key];
      if (direct?.trim()) { merged[s.key] = direct; continue; }
      // 2) 의미적 동등 필드에서 값 이전
      const equiv = findEquivalentValue(s.key, allData);
      if (equiv) { merged[s.key] = equiv; continue; }
      merged[s.key] = '';
    }
    setForm(merged);
  }

  async function handleSave() {
    setSaving(true);
    try {
      // 이전 템플릿 데이터를 보존하면서 현재 폼 데이터를 덮어쓴다
      const mergedSections = { ...data?.sections, ...form };
      const result = await window.api.conceptualizations.upsert(caseId, {
        template_type: selectedTemplate,
        sections: mergedSections,
      });
      setData(result);
      setEditing(false);
      setForm({});
      addToast({ title: '사례 개념화가 저장되었습니다.', variant: 'success' });
    } catch {
      addToast({ title: '저장에 실패했습니다.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <p className="text-sm text-muted-foreground py-8 text-center">불러오는 중...</p>;
  }

  // 아직 작성 안 됨
  const isEmpty = !data || Object.values(data.sections).every((v) => !v);

  if (isEmpty && !editing) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        <FileText className="mx-auto h-10 w-10 mb-3 opacity-40" />
        <p className="mb-4">아직 사례 개념화가 작성되지 않았습니다.</p>
        <Button onClick={startEditing}>
          <Pencil className="mr-2 h-4 w-4" />
          작성 시작
        </Button>
      </div>
    );
  }

  // 편집 모드
  if (editing && template) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Label htmlFor="ct-template" className="text-sm font-medium shrink-0">양식</Label>
            <Select value={selectedTemplate} onValueChange={handleTemplateChange}>
              <SelectTrigger id="ct-template" className="w-[220px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CONCEPTUALIZATION_TEMPLATES.map((t) => (
                  <SelectItem key={t.type} value={t.type}>
                    {t.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <span className="text-xs text-muted-foreground hidden sm:inline">
              {template.description}
            </span>
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={cancelEditing} disabled={saving}>
              <X className="mr-1 h-4 w-4" />
              취소
            </Button>
            <Button size="sm" onClick={handleSave} disabled={saving}>
              <Save className="mr-1 h-4 w-4" />
              {saving ? '저장 중...' : '저장'}
            </Button>
          </div>
        </div>
        {template.sections.map((s) => {
          const sectionValue = form[s.key] ?? '';
          const ctxReq: AiContextRequest = {
            kind: 'conceptualization',
            caseId,
            templateType: selectedTemplate,
            // 현재 편집 중인 섹션 값만 draft로 전달 — 다른 섹션은 DB 본문(작성된 개념화)으로 노출됨.
            draft: { [s.key]: sectionValue },
          };
          return (
            <div key={s.key} className="space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <Label htmlFor={`concept-${s.key}`} className="text-sm font-medium">
                  {s.label}
                </Label>
                <AiAssistButton
                  buttonLabel={`${s.label} 다듬기·이어쓰기`}
                  availableTasks={['refine', 'continue']}
                  originalText={sectionValue}
                  contextRequest={ctxReq}
                  fieldHint={`사례개념화 섹션 "${s.label}" — 명사형 어미 개조식 3~6줄. 진단 표현 금지, 약한 가설은 "~로 추정됨"으로 분리`}
                  onApply={(result, mode) => {
                    setForm((prev) => {
                      const prevValue = prev[s.key] ?? '';
                      const next =
                        mode === 'append'
                          ? prevValue + (prevValue && !prevValue.endsWith('\n') ? '\n' : '') + result
                          : result;
                      return { ...prev, [s.key]: next };
                    });
                  }}
                />
              </div>
              <Textarea
                id={`concept-${s.key}`}
                placeholder={s.placeholder}
                value={sectionValue}
                onChange={(e) => setForm((prev) => ({ ...prev, [s.key]: e.target.value }))}
                rows={4}
              />
            </div>
          );
        })}
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="ghost" size="sm" onClick={cancelEditing} disabled={saving}>
            <X className="mr-1 h-4 w-4" />취소
          </Button>
          <Button size="sm" onClick={handleSave} disabled={saving}>
            <Save className="mr-1 h-4 w-4" />{saving ? '저장 중...' : '저장'}
          </Button>
        </div>
      </div>
    );
  }

  // 조회 모드
  const viewTemplate = getTemplateByType(data?.template_type ?? 'wee_standard');

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Badge variant="outline">{viewTemplate?.label ?? data?.template_type}</Badge>
        <Button variant="ghost" size="sm" onClick={startEditing}>
          <Pencil className="mr-1 h-4 w-4" />
          수정
        </Button>
      </div>
      {viewTemplate?.sections.map((s) => {
        const value = data?.sections[s.key];
        if (!value) return null;
        return (
          <Card key={s.key}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">{s.label}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm whitespace-pre-wrap leading-relaxed">{value}</p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
