import { useState, useEffect, useRef, KeyboardEvent } from 'react';
import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import type { CaseWithSessionCount } from '@/types/case';

interface CaseComboboxProps {
  /** 사례 선택 시 호출 */
  onSelect: (c: CaseWithSessionCount) => void;
  /** 자동 포커스 여부 */
  autoFocus?: boolean;
}

/** 사례 한 건을 `사례번호 · 학생명` 형태로 표시. */
function formatCaseLabel(c: CaseWithSessionCount): string {
  const names = c.students.map((s) => s.name).filter(Boolean).join(', ');
  return names ? `${c.case_number} · ${names}` : c.case_number;
}

/**
 * 진행중(active) 사례를 검색해 선택하는 콤보박스.
 * 대시보드 빠른 일정 등록에서 "어느 사례의 세션인가"를 고르는 데 사용한다.
 * (StudentCombobox 패턴 차용)
 */
export function CaseCombobox({ onSelect, autoFocus }: CaseComboboxProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<CaseWithSessionCount[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [highlightIndex, setHighlightIndex] = useState(-1);
  const [loading, setLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // 디바운스 검색 — 빈 검색어면 active 사례 전체를 띄운다(초기 진입 시 목록 제공).
  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(async () => {
      try {
        const data = await window.api.cases.list({
          status: 'active',
          search: query.trim() || undefined,
        });
        setResults(data);
        setIsOpen(true);
        setHighlightIndex(-1);
      } catch (error) {
        console.error('Failed to search cases:', error);
        setResults([]);
      } finally {
        setLoading(false);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [query]);

  // 바깥 클릭 시 닫기
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  function handleSelect(c: CaseWithSessionCount) {
    onSelect(c);
    setIsOpen(false);
  }

  function handleKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (!isOpen || results.length === 0) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightIndex((prev) => (prev < results.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightIndex((prev) => (prev > 0 ? prev - 1 : -1));
    } else if (e.key === 'Enter' && highlightIndex >= 0) {
      e.preventDefault();
      handleSelect(results[highlightIndex]);
    } else if (e.key === 'Escape') {
      setIsOpen(false);
      setHighlightIndex(-1);
    }
  }

  return (
    <div ref={containerRef} className="relative">
      <label className="block text-sm font-medium mb-1.5">사례 선택 <span className="text-destructive">*</span></label>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          ref={inputRef}
          type="text"
          autoFocus={autoFocus}
          placeholder="사례번호 또는 학생 이름으로 검색..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          className="pl-10"
        />
      </div>

      {isOpen && (
        <div className="absolute z-50 w-full mt-1 rounded-md border bg-popover text-popover-foreground shadow-md max-h-60 overflow-y-auto">
          {loading ? (
            <div className="px-3 py-2 text-sm text-muted-foreground">검색 중...</div>
          ) : results.length === 0 ? (
            <div className="px-3 py-2 text-sm text-muted-foreground">진행중인 사례가 없습니다.</div>
          ) : (
            <ul>
              {results.map((c, index) => (
                <li
                  key={c.id}
                  className={`px-3 py-2 text-sm cursor-pointer ${
                    index === highlightIndex
                      ? 'bg-accent text-accent-foreground'
                      : 'hover:bg-accent hover:text-accent-foreground'
                  }`}
                  onClick={() => handleSelect(c)}
                  onMouseEnter={() => setHighlightIndex(index)}
                >
                  {formatCaseLabel(c)}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <p className="text-xs text-muted-foreground mt-1">
        세션을 추가할 진행중 사례를 고르세요.
      </p>
    </div>
  );
}
