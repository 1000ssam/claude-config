import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { REFERRER_ROLE_OPTIONS } from '@/lib/constants/options';
import { formatPhoneNumber, validatePhoneNumber } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { validateStudentFields } from '@/hooks/use-student-form';
import { getAcademicYear } from '@/lib/academic-year';
import type { Case, CreateCaseInput } from '@/types/case';
import type { StudentWithEnrollment } from '@/types/student';
import { StudentMultiSelect, type SelectedStudent, type GuardianEdit } from './student-multi-select';
import { AiAssistButton } from '@/components/ai/ai-assist-button';
import type { AiContextRequest } from '@/types/ai';

type AiCaseField = 'main_complaint' | 'counseling_goal' | 'teacher_opinion';

function buildCaseContextRequest(caseId: number, form: {
  main_complaint: string;
  counseling_goal: string;
  teacher_opinion: string;
}): AiContextRequest {
  return {
    kind: 'case-form',
    caseId,
    draft: {
      main_complaint: form.main_complaint,
      counseling_goal: form.counseling_goal,
      teacher_opinion: form.teacher_opinion,
    },
  };
}

function applyToCaseField(
  field: AiCaseField,
  result: string,
  mode: 'replace' | 'append',
  prevValue: string,
  updateField: (key: AiCaseField, value: string) => void,
): void {
  if (mode === 'replace') {
    updateField(field, result);
    return;
  }
  const prev = prevValue || '';
  const sep = prev && !prev.endsWith('\n') ? '\n' : '';
  updateField(field, prev + sep + result);
}

const ACADEMIC_YEAR_STORAGE_KEY = 'wee-log:cases:year';
const currentAcademicYear = getAcademicYear(new Date());

/**
 * CasesPage에서 useLocalStorage 훅이 JSON.stringify로 저장하므로
 * 여기서도 JSON.parse로 읽어야 따옴표가 섞여 들어가지 않는다.
 */
function getStoredDefaultYear(): string {
  try {
    const raw = localStorage.getItem(ACADEMIC_YEAR_STORAGE_KEY);
    if (!raw) return currentAcademicYear;
    const parsed = JSON.parse(raw);
    return typeof parsed === 'string' && parsed ? parsed : currentAcademicYear;
  } catch {
    return currentAcademicYear;
  }
}

interface CaseFormProps {
  initialData?: Case;
  isEdit?: boolean;
  onCancel?: () => void;
}

interface FormState {
  academic_year: string;
  referrer_name: string;
  referrer_role: string;
  referrer_contact: string;
  main_complaint: string;
  counseling_goal: string;
  teacher_opinion: string;
}

const DEFAULT_FORM: Omit<FormState, 'academic_year'> = {
  referrer_name: '',
  referrer_role: '',
  referrer_contact: '',
  main_complaint: '',
  counseling_goal: '',
  teacher_opinion: '',
};

// ── 필수 필드 정의 ─────────────────────────────────────────────────────────────

const REQUIRED_FIELDS: { key: keyof FormState; label: string }[] = [
  { key: 'main_complaint', label: '주호소' },
];

// ── CaseForm ──────────────────────────────────────────────────────────────────

export function CaseForm({ initialData, isEdit = false, onCancel }: CaseFormProps) {
  const navigate = useNavigate();
  const { addToast } = useToast();
  const [saving, setSaving] = useState(false);
  const [studentError, setStudentError] = useState('');
  const [phoneErrors, setPhoneErrors] = useState<Record<string, string>>({});
  const [fieldErrors, setFieldErrors] = useState<Partial<Record<keyof FormState, string>>>({});

  // 에러 필드 스크롤/포커스용 ref
  const studentSectionRef = useRef<HTMLDivElement>(null);
  const fieldRefs = useRef<Partial<Record<keyof FormState, HTMLElement | null>>>({});

  const [selectedStudents, setSelectedStudents] = useState<SelectedStudent[]>(() => {
    if (initialData?.students) {
      return initialData.students.map((s) => ({
        id: s.student_id,
        name: s.name,
        grade: s.grade,
        class_name: s.class_name,
        number: s.number,
        gender: s.gender,
        guardian_name: s.guardian_name,
        guardian_relation: s.guardian_relation,
        guardian_contact: s.guardian_contact,
      }));
    }
    return [];
  });

  const [form, setForm] = useState<FormState>(() => {
    if (initialData) {
      return {
        academic_year: initialData.academic_year || currentAcademicYear,
        referrer_name: initialData.referrer_name || '',
        referrer_role: initialData.referrer_role || '',
        referrer_contact: initialData.referrer_contact || '',
        main_complaint: initialData.main_complaint || '',
        counseling_goal: initialData.counseling_goal || '',
        teacher_opinion: initialData.teacher_opinion || '',
      };
    }
    return { academic_year: getStoredDefaultYear(), ...DEFAULT_FORM };
  });

  function updateField(key: keyof FormState, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function handleAddStudent(student: StudentWithEnrollment) {
    setSelectedStudents((prev) => {
      if (prev.some((s) => s.id === student.id)) return prev;
      return [...prev, {
        id: student.id,
        name: student.name,
        grade: student.grade,
        class_name: student.class_name,
        number: student.number,
        gender: student.gender,
        guardian_name: student.guardian_name,
        guardian_relation: student.guardian_relation,
        guardian_contact: student.guardian_contact,
      }];
    });
    if (studentError) setStudentError('');
  }

  function handleRemoveStudent(studentId: number) {
    setSelectedStudents((prev) => prev.filter((s) => s.id !== studentId));
  }

  async function handleGuardianSave(studentId: number, guardian: GuardianEdit, isDelete = false) {
    if (isDelete) {
      await window.api.students.update(studentId, {
        guardian_name: '',
        guardian_relation: '',
        guardian_contact: '',
      });
      setSelectedStudents((prev) =>
        prev.map((s) =>
          s.id === studentId
            ? { ...s, guardian_name: null, guardian_relation: null, guardian_contact: null }
            : s,
        ),
      );
      addToast({ title: '보호자 정보가 삭제되었습니다.', variant: 'success' });
      return;
    }

    const fieldErr = validateStudentFields({ guardian_contact: guardian.guardian_contact });
    if (fieldErr) {
      addToast({ title: fieldErr, variant: 'destructive' });
      throw new Error(fieldErr);
    }

    // 빈 값은 ''로 보내 삭제를 반영한다. undefined로 보내면 비암호화 컬럼
    // (guardian_relation)이 undefined로 바인딩돼 크래시하고, 빈값 삭제도 안 됨.
    // (updateStudent가 ''→null 변환. 삭제 버튼 경로(handleGuardianSave isDelete)와 동일.)
    await window.api.students.update(studentId, {
      guardian_name: guardian.guardian_name || '',
      guardian_relation: guardian.guardian_relation || '',
      guardian_contact: guardian.guardian_contact || '',
    });

    // 로컬 상태도 업데이트
    setSelectedStudents((prev) =>
      prev.map((s) =>
        s.id === studentId
          ? {
              ...s,
              guardian_name: guardian.guardian_name || null,
              guardian_relation: guardian.guardian_relation || null,
              guardian_contact: guardian.guardian_contact || null,
            }
          : s,
      ),
    );

    addToast({ title: '보호자 정보가 저장되었습니다.', variant: 'success' });
  }

  function scrollToFirstError(firstErrorKey?: keyof FormState | 'student') {
    if (firstErrorKey === 'student') {
      studentSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    if (firstErrorKey) {
      const el = fieldRefs.current[firstErrorKey];
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        el.focus();
      }
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    // ── 1) 학생 선택 검사
    if (selectedStudents.length === 0) {
      setStudentError('최소 1명의 학생을 선택하세요.');
      addToast({ title: '필수 항목을 모두 입력해주세요.', variant: 'destructive' });
      scrollToFirstError('student');
      return;
    }
    setStudentError('');

    // ── 2) 필수 필드 검사
    const fErrors: Partial<Record<keyof FormState, string>> = {};
    for (const { key, label } of REQUIRED_FIELDS) {
      if (!form[key]?.trim()) {
        fErrors[key] = `${label}은(는) 필수 입력 항목입니다.`;
      }
    }
    if (Object.keys(fErrors).length > 0) {
      setFieldErrors(fErrors);
      addToast({ title: '필수 항목을 모두 입력해주세요.', variant: 'destructive' });
      const firstKey = REQUIRED_FIELDS.find(({ key }) => fErrors[key])?.key;
      scrollToFirstError(firstKey);
      return;
    }
    setFieldErrors({});

    // ── 3) 전화번호 유효성 검사
    const pErrors: Record<string, string> = {};
    const referrerErr = validatePhoneNumber(form.referrer_contact || '');
    if (referrerErr) pErrors.referrer_contact = referrerErr;

    if (Object.keys(pErrors).length > 0) {
      setPhoneErrors(pErrors);
      addToast({ title: '전화번호 형식을 확인하세요.', variant: 'destructive' });
      return;
    }
    setPhoneErrors({});

    setSaving(true);

    // Build payload
    const body: Record<string, unknown> = {
      student_ids: selectedStudents.map((s) => s.id),
      academic_year: form.academic_year,
    };

    // 문자열 필드 반영 (academic_year는 위에서 처리).
    // 수정 모드에선 빈 값('')도 보내야 기존 값 삭제가 반영된다.
    // (updateCase가 ''→null로 변환. 생략하면 undefined로 스킵돼 옛 값이 남음.)
    // 생성 모드는 기존대로 빈 값 생략.
    for (const [key, value] of Object.entries(form)) {
      if (key === 'academic_year') continue;
      if (typeof value !== 'string') continue;
      const trimmed = value.trim();
      if (trimmed) {
        body[key] = trimmed;
      } else if (isEdit) {
        body[key] = '';
      }
    }

    try {
      let savedCase;
      if (isEdit) {
        savedCase = await window.api.cases.update(initialData!.id, body);
      } else {
        savedCase = await window.api.cases.create(body as unknown as CreateCaseInput);
      }

      addToast({
        title: isEdit ? '사례 정보가 수정되었습니다.' : '사례가 등록되었습니다.',
        variant: 'success',
      });
      if (isEdit && onCancel) {
        onCancel();
      } else if (savedCase?.id) {
        navigate(`/cases/${savedCase.id}`);
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : '저장에 실패했습니다.';
      addToast({ title: message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }

  function handleCancel() {
    if (onCancel) {
      onCancel();
    } else {
      navigate(-1);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl">
      {/* 학생 선택 + 보호자 인라인 편집 */}
      <Card ref={studentSectionRef}>
        <CardHeader>
          <CardTitle>내담자 정보</CardTitle>
        </CardHeader>
        <CardContent>
          <StudentMultiSelect
            selectedStudents={selectedStudents}
            onAdd={handleAddStudent}
            onRemove={handleRemoveStudent}
            onGuardianSave={handleGuardianSave}
            error={studentError}
          />
        </CardContent>
      </Card>

      {/* 의뢰 정보 */}
      <Card>
        <CardHeader>
          <CardTitle>의뢰 정보</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="cf-referrer-name">의뢰인 이름</Label>
            <Input
              id="cf-referrer-name"
              value={form.referrer_name}
              onChange={(e) => updateField('referrer_name', e.target.value)}
              placeholder="의뢰인 이름"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="cf-referrer-role">역할</Label>
            <Select
              value={form.referrer_role}
              onValueChange={(v) => updateField('referrer_role', v)}
            >
              <SelectTrigger id="cf-referrer-role">
                <SelectValue placeholder="역할 선택" />
              </SelectTrigger>
              <SelectContent>
                {REFERRER_ROLE_OPTIONS.map((r) => (
                  <SelectItem key={r} value={r}>{r}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="cf-referrer-contact">의뢰인 연락처</Label>
            <Input
              id="cf-referrer-contact"
              value={form.referrer_contact}
              onChange={(e) => {
                updateField('referrer_contact', formatPhoneNumber(e.target.value));
                if (phoneErrors.referrer_contact) setPhoneErrors((prev) => { const { referrer_contact: _, ...rest } = prev; return rest; });
              }}
              placeholder="010-0000-0000"
              className={phoneErrors.referrer_contact ? 'border-destructive' : ''}
            />
            {phoneErrors.referrer_contact && <p className="text-xs text-destructive">{phoneErrors.referrer_contact}</p>}
          </div>
        </CardContent>
      </Card>

      {/* 주호소 / 상담목표 / 교사의견 */}
      <Card>
        <CardHeader>
          <CardTitle>상담 정보</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <Label htmlFor="cf-main-complaint">
                주호소 <span className="text-destructive">*</span>
              </Label>
              {initialData?.id && (
                <AiAssistButton
                  buttonLabel="주호소 다듬기"
                  availableTasks={['refine', 'continue']}
                  originalText={form.main_complaint}
                  contextRequest={buildCaseContextRequest(initialData.id, form)}
                  fieldHint="사례 주호소 — 의뢰 시점 학생의 호소를 명사형 어미 개조식 2~5줄로. 진단 표현 금지"
                  onApply={(result, mode) =>
                    applyToCaseField('main_complaint', result, mode, form.main_complaint, updateField)
                  }
                />
              )}
            </div>
            <Textarea
              id="cf-main-complaint"
              ref={(el) => { fieldRefs.current.main_complaint = el; }}
              value={form.main_complaint}
              onChange={(e) => {
                updateField('main_complaint', e.target.value);
                if (fieldErrors.main_complaint) setFieldErrors((prev) => { const { main_complaint: _, ...rest } = prev; return rest; });
              }}
              placeholder="주호소 내용을 입력하세요..."
              rows={3}
              className={fieldErrors.main_complaint ? 'border-destructive focus-visible:ring-destructive' : ''}
            />
            {fieldErrors.main_complaint && (
              <p className="text-xs text-destructive">{fieldErrors.main_complaint}</p>
            )}
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <Label htmlFor="cf-counseling-goal">상담목표</Label>
              {initialData?.id && (
                <AiAssistButton
                  buttonLabel="상담목표 다듬기"
                  availableTasks={['refine', 'continue']}
                  originalText={form.counseling_goal}
                  contextRequest={buildCaseContextRequest(initialData.id, form)}
                  fieldHint="상담 목표 — 관찰 가능·측정 가능한 행동 목표 중심, 명사형 어미 개조식 2~4줄"
                  onApply={(result, mode) =>
                    applyToCaseField('counseling_goal', result, mode, form.counseling_goal, updateField)
                  }
                />
              )}
            </div>
            <Textarea
              id="cf-counseling-goal"
              value={form.counseling_goal}
              onChange={(e) => updateField('counseling_goal', e.target.value)}
              placeholder="상담목표를 입력하세요..."
              rows={3}
            />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <Label htmlFor="cf-teacher-opinion">교사의견</Label>
              {initialData?.id && (
                <AiAssistButton
                  buttonLabel="교사의견 다듬기"
                  availableTasks={['refine', 'continue']}
                  originalText={form.teacher_opinion}
                  contextRequest={buildCaseContextRequest(initialData.id, form)}
                  fieldHint="담임/교과 교사가 관찰한 학생 양상 — 명사형 어미 개조식 2~5줄, 평가어 대신 관찰 사실"
                  onApply={(result, mode) =>
                    applyToCaseField('teacher_opinion', result, mode, form.teacher_opinion, updateField)
                  }
                />
              )}
            </div>
            <Textarea
              id="cf-teacher-opinion"
              value={form.teacher_opinion}
              onChange={(e) => updateField('teacher_opinion', e.target.value)}
              placeholder="교사의견을 입력하세요..."
              rows={3}
            />
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-end gap-3">
        <Button type="button" variant="outline" onClick={handleCancel}>
          취소
        </Button>
        <Button type="submit" disabled={saving}>
          {saving ? (isEdit ? '저장 중...' : '등록 중...') : isEdit ? '저장' : '등록'}
        </Button>
      </div>
    </form>
  );
}
