import { useState, useEffect, useRef, KeyboardEvent } from 'react';
import { Search, X, Pencil, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { GUARDIAN_RELATION_OPTIONS } from '@/lib/constants/options';
import { formatPhoneNumber } from '@/lib/utils';
import { formatStudentCompact } from '@/lib/format-student';
import type { StudentWithEnrollment } from '@/types/student';

// ── 타입 ──────────────────────────────────────────────────────────────────────

export interface SelectedStudent {
  id: number;
  name: string;
  grade: string | null;
  class_name: string | null;
  number: string | null;
  gender: string | null;
  guardian_name: string | null;
  guardian_relation: string | null;
  guardian_contact: string | null;
}

export interface GuardianEdit {
  guardian_name: string;
  guardian_relation: string;
  guardian_contact: string;
}


// ── StudentMultiSelect ────────────────────────────────────────────────────────

interface StudentMultiSelectProps {
  selectedStudents: SelectedStudent[];
  onAdd: (student: StudentWithEnrollment) => void;
  onRemove: (studentId: number) => void;
  onGuardianSave: (studentId: number, guardian: GuardianEdit, isDelete?: boolean) => Promise<void>;
  error?: string;
}

export function StudentMultiSelect({
  selectedStudents,
  onAdd,
  onRemove,
  onGuardianSave,
  error,
}: StudentMultiSelectProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<StudentWithEnrollment[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [highlightIndex, setHighlightIndex] = useState(-1);
  const [loading, setLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const [editingGuardian, setEditingGuardian] = useState<Record<number, GuardianEdit>>({});
  const [savingGuardian, setSavingGuardian] = useState<number | null>(null);
  const [guardianToDelete, setGuardianToDelete] = useState<number | null>(null);

  const selectedIds = new Set(selectedStudents.map((s) => s.id));

  // Debounced search
  useEffect(() => {
    if (!query || query.trim().length === 0) {
      setResults([]);
      setIsOpen(false);
      return;
    }

    setLoading(true);
    const timer = setTimeout(async () => {
      try {
        const data = await window.api.students.search(query.trim());
        setResults(data);
        setIsOpen(true);
        setHighlightIndex(-1);
      } catch (err) {
        console.error('Failed to search students:', err);
        setResults([]);
      } finally {
        setLoading(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [query]);

  // Click outside to close
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  function handleSelect(student: StudentWithEnrollment) {
    if (!selectedIds.has(student.id)) {
      onAdd(student);
      if (!student.guardian_name) {
        setEditingGuardian((prev) => ({
          ...prev,
          [student.id]: { guardian_name: '', guardian_relation: '', guardian_contact: '' },
        }));
      }
    }
    setQuery('');
    setResults([]);
    setIsOpen(false);
    inputRef.current?.focus();
  }

  function handleKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (isOpen && highlightIndex >= 0 && results.length > 0) {
        handleSelect(results[highlightIndex]);
      }
      return;
    }

    if (!isOpen || results.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightIndex((prev) => (prev < results.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightIndex((prev) => (prev > 0 ? prev - 1 : -1));
    } else if (e.key === 'Escape') {
      setIsOpen(false);
      setHighlightIndex(-1);
    }
  }


  function toggleGuardianEdit(student: SelectedStudent) {
    setEditingGuardian((prev) => {
      if (prev[student.id]) {
        const { [student.id]: _, ...rest } = prev;
        return rest;
      }
      return {
        ...prev,
        [student.id]: {
          guardian_name: student.guardian_name || '',
          guardian_relation: student.guardian_relation || '',
          guardian_contact: student.guardian_contact || '',
        },
      };
    });
  }

  function updateGuardianField(studentId: number, field: keyof GuardianEdit, value: string) {
    setEditingGuardian((prev) => ({
      ...prev,
      [studentId]: { ...prev[studentId], [field]: value },
    }));
  }

  async function handleGuardianSave(studentId: number, isDelete = false) {
    const data: GuardianEdit = isDelete
      ? { guardian_name: '', guardian_relation: '', guardian_contact: '' }
      : editingGuardian[studentId];
    if (!data && !isDelete) return;

    setSavingGuardian(studentId);
    try {
      await onGuardianSave(studentId, data, isDelete);
      setEditingGuardian((prev) => {
        const { [studentId]: _, ...rest } = prev;
        return rest;
      });
    } catch {
      // 검증 실패 — 편집 폼 유지
    } finally {
      setSavingGuardian(null);
    }
  }

  const hasGuardian = (s: SelectedStudent) => !!s.guardian_name;

  return (
    <div ref={containerRef} className="relative space-y-4">
      <Label htmlFor="cf-student-search">학생 검색 <span className="text-destructive">*</span></Label>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          id="cf-student-search"
          ref={inputRef}
          type="text"
          placeholder="학생 이름으로 검색하여 추가..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          className={`pl-10 ${error ? 'border-destructive' : ''}`}
        />
      </div>

      {isOpen && (
        <div className="absolute left-0 right-0 z-50 mt-1 rounded-md border bg-popover text-popover-foreground shadow-md max-h-60 overflow-y-auto">
          {loading ? (
            <div className="px-3 py-2 text-sm text-muted-foreground">검색 중...</div>
          ) : results.length === 0 ? (
            <div className="px-3 py-2 text-sm text-muted-foreground">
              일치하는 학생이 없습니다.
            </div>
          ) : (
            <ul>
              {results.map((student, index) => {
                const already = selectedIds.has(student.id);
                return (
                  <li
                    key={student.id}
                    className={`px-3 py-2 text-sm cursor-pointer ${
                      already ? 'opacity-40 cursor-not-allowed' : ''
                    } ${
                      index === highlightIndex
                        ? 'bg-accent text-accent-foreground'
                        : 'hover:bg-accent hover:text-accent-foreground'
                    }`}
                    onClick={() => !already && handleSelect(student)}
                    onMouseEnter={() => setHighlightIndex(index)}
                  >
                    {formatStudentCompact(student)}
                    {already && <span className="ml-2 text-xs text-muted-foreground">(이미 추가됨)</span>}
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}

      {/* 선택된 학생 목록 + 보호자 정보 */}
      {selectedStudents.length > 0 && (
        <div className="space-y-2">
          {selectedStudents.map((s) => {
            const isEditing = !!editingGuardian[s.id];
            const edit = editingGuardian[s.id];

            return (
              <div key={s.id} className="rounded-lg border bg-card p-3 space-y-2">
                {/* 학생 칩 + 제거 버튼 */}
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{formatStudentCompact(s)}</span>
                  <button
                    type="button"
                    onClick={() => onRemove(s.id)}
                    className="rounded-full p-1 hover:bg-destructive/10 hover:text-destructive transition-colors"
                    title="제거"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>

                {/* 보호자 정보 표시 / 편집 */}
                {!isEditing ? (
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    {hasGuardian(s) ? (
                      <>
                        <span>
                          보호자: {s.guardian_name}
                          {s.guardian_relation && ` (${s.guardian_relation})`}
                        </span>
                        {s.guardian_contact && (
                          <>
                            <span className="text-border">|</span>
                            <span>{s.guardian_contact}</span>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => toggleGuardianEdit(s)}
                          className="ml-auto flex items-center gap-1 text-xs text-primary hover:underline"
                        >
                          <Pencil className="h-3 w-3" />
                          수정
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => toggleGuardianEdit(s)}
                        className="flex items-center gap-1.5 text-xs text-amber-600 hover:text-amber-700"
                      >
                        <AlertTriangle className="h-3.5 w-3.5" />
                        보호자 미등록 — 등록하기
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-wrap items-center gap-1.5 pt-1.5 border-t">
                    <Input
                      value={edit.guardian_name}
                      onChange={(e) => updateGuardianField(s.id, 'guardian_name', e.target.value)}
                      placeholder="이름"
                      className="h-7 text-xs w-20"
                    />
                    <Select
                      value={edit.guardian_relation || undefined}
                      onValueChange={(v) => updateGuardianField(s.id, 'guardian_relation', v)}
                    >
                      <SelectTrigger className="h-7 w-16 text-xs">
                        <SelectValue placeholder="관계" />
                      </SelectTrigger>
                      <SelectContent>
                        {GUARDIAN_RELATION_OPTIONS.map((r) => (
                          <SelectItem key={r} value={r}>{r}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input
                      value={edit.guardian_contact}
                      onChange={(e) => updateGuardianField(s.id, 'guardian_contact', formatPhoneNumber(e.target.value))}
                      placeholder="010-0000-0000"
                      className="h-7 text-xs w-32"
                    />
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="h-7 px-2 text-xs"
                      disabled={savingGuardian === s.id || !edit.guardian_name.trim()}
                      onClick={() => handleGuardianSave(s.id)}
                    >
                      {savingGuardian === s.id ? '...' : '저장'}
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2 text-xs"
                      onClick={() => toggleGuardianEdit(s)}
                    >
                      취소
                    </Button>
                    {hasGuardian(s) && (
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        className="h-7 px-2 text-xs text-destructive hover:text-destructive hover:bg-destructive/10"
                        disabled={savingGuardian === s.id}
                        onClick={() => setGuardianToDelete(s.id)}
                      >
                        삭제
                      </Button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {error && <p className="text-xs text-destructive">{error}</p>}
      {selectedStudents.length === 0 && !error && (
        <p className="text-xs text-muted-foreground">
          최소 1명의 학생을 선택하세요.
        </p>
      )}

      <ConfirmDialog
        open={guardianToDelete !== null}
        onOpenChange={(open) => { if (!open) setGuardianToDelete(null); }}
        title="보호자 삭제"
        description="이 보호자 정보를 삭제하시겠습니까?"
        confirmLabel="삭제"
        variant="destructive"
        onConfirm={() => {
          if (guardianToDelete !== null) {
            handleGuardianSave(guardianToDelete, true);
          }
        }}
      />
    </div>
  );
}
