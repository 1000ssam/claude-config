import { ArrowRight } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { useTabNav } from '@/hooks/use-tab-nav';
import { formatStudentEnrollment } from '@/lib/format-student';
import type { CaseWithSessionCount } from '@/types/case';

interface CaseListDialogProps {
  open: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  cases: CaseWithSessionCount[];
  emptyLabel: string;
  /** 행에 '최근 상담일/상담 0회'를 함께 표기(장기 미접촉용). */
  showLastSession?: boolean;
}

/**
 * 홈 카드 클릭 시 뜨는 사례 목록 팝업.
 * 사례 관리 페이지의 영속 필터 UI와 분리해, 혼란 없이 해당 목록만 보여준다.
 * 행 클릭 → 사례 상세로 이동(가운데/Ctrl 클릭 = 새 탭).
 */
export function CaseListDialog({
  open, onClose, title, description, cases, emptyLabel, showLastSession,
}: CaseListDialogProps) {
  const { go } = useTabNav();

  function pick(e: React.MouseEvent, id: number) {
    go(e, `/cases/${id}`);
    onClose();
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="sm:max-w-lg max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>

        <div className="-mx-1 flex flex-col gap-1.5 overflow-y-auto px-1 py-1">
          {cases.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">{emptyLabel}</p>
          ) : (
            cases.map((c) => {
              const student = c.students?.[0];
              const name = c.students?.length === 0
                ? '(학생 없음)'
                : c.students.length === 1
                  ? c.students[0].name
                  : `${c.students[0].name} 외 ${c.students.length - 1}명`;
              const identity = student ? formatStudentEnrollment(student) : '';
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={(e) => pick(e, c.id)}
                  onAuxClick={(e) => pick(e, c.id)}
                  className="group flex items-center justify-between gap-3 rounded-lg border border-border bg-card px-3.5 py-2.5 text-left transition-colors hover:border-border/80 hover:bg-muted/50"
                >
                  <div className="flex min-w-0 flex-col">
                    <span className="flex items-baseline gap-2">
                      <span className="truncate text-sm font-semibold">{name}</span>
                      {identity && <span className="shrink-0 text-xs text-muted-foreground">{identity}</span>}
                    </span>
                    <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <span className="font-mono">{c.case_number}</span>
                      {showLastSession && (
                        <>
                          <span className="text-muted-foreground/40">·</span>
                          <span>{c.last_session_date ? `최근 상담 ${c.last_session_date}` : '상담 0회'}</span>
                        </>
                      )}
                    </span>
                  </div>
                  <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground/40 transition-transform group-hover:translate-x-0.5 group-hover:text-foreground" />
                </button>
              );
            })
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
