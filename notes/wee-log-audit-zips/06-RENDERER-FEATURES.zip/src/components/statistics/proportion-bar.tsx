import { getChartColors } from '@/lib/chart-palette';

export interface ProportionItem {
  name: string;
  value: number;
}

interface ProportionBarProps {
  data: ProportionItem[];
  /** 막대 높이(px). 기본 24 */
  height?: number;
  /** 세그먼트 안 라벨을 표시할 최소 비중(%). 기본 12 */
  labelThreshold?: number;
  /** 막대 아래 범례 표시 여부. 기본 true */
  showLegend?: boolean;
}

/**
 * 하나의 가로 막대 안에 각 항목의 비중을 내림차순으로 표현.
 * - value 내림차순 정렬 후 전체 합 대비 비중(%) 계산
 * - 넓은 세그먼트(비중 ≥ labelThreshold)는 내부에 "이름 N%" 라벨
 * - 색상은 chart-palette(getChartColors)에서 가져와 인덱스 순환
 * - 세그먼트 배경은 인라인 style.background → printToPDF에 보존(print-color-adjust:exact)
 * - recharts SVG 대신 순수 div/flex 구현 → 인쇄 깨짐 위험 최소화
 */
export function ProportionBar({
  data,
  height = 24,
  labelThreshold = 12,
  showLegend = true,
}: ProportionBarProps) {
  const colors = getChartColors();
  const sorted = [...data]
    .filter((d) => d.value > 0)
    .sort((a, b) => b.value - a.value);
  const total = sorted.reduce((s, d) => s + d.value, 0);

  if (sorted.length === 0 || total === 0) {
    return (
      <p className="text-center text-sm text-muted-foreground py-6">
        조회된 데이터가 없습니다.
      </p>
    );
  }

  const items = sorted.map((d, i) => ({
    ...d,
    color: colors[i % colors.length],
    pct: (d.value / total) * 100,
  }));

  return (
    <div className="w-full">
      <div
        className="flex w-full overflow-hidden rounded-md"
        style={{ height }}
        role="img"
        aria-label="비중 막대"
      >
        {items.map((it, i) => {
          const showLabel = it.pct >= labelThreshold;
          return (
            <div
              key={i}
              className="flex items-center justify-center overflow-hidden"
              style={{
                width: `${it.pct}%`,
                background: it.color,
                borderRight: i < items.length - 1 ? '2px solid #fff' : undefined,
              }}
              title={`${it.name} ${it.value.toLocaleString()}건 (${it.pct.toFixed(1)}%)`}
            >
              {showLabel && (
                <span
                  className="px-1 text-[11px] font-medium leading-none text-white whitespace-nowrap"
                  style={{ wordBreak: 'keep-all' }}
                >
                  {it.pct >= labelThreshold + 6
                    ? `${it.name} ${it.pct.toFixed(0)}%`
                    : `${it.pct.toFixed(0)}%`}
                </span>
              )}
            </div>
          );
        })}
      </div>

      {showLegend && (
        <ul className="mt-2 flex flex-wrap gap-x-3 gap-y-1">
          {items.map((it, i) => (
            <li key={i} className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span
                className="inline-block h-2.5 w-2.5 shrink-0 rounded-[2px]"
                style={{ background: it.color }}
              />
              <span style={{ wordBreak: 'keep-all' }}>
                {it.name} {it.value.toLocaleString()}건 ({it.pct.toFixed(0)}%)
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
