import { format } from 'date-fns';
import { ko } from 'date-fns/locale';
import { Clock, CalendarCheck } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useTabNav } from '@/hooks/use-tab-nav';
import type { CalendarSession } from '../../../lib/queries/calendar';

interface TodayScheduleProps {
  sessions: CalendarSession[];
  holidayName?: string;
  schoolEvents?: string[];
}

export function TodaySchedule({ sessions, holidayName, schoolEvents }: TodayScheduleProps) {
  const { linkProps } = useTabNav();
  const today = new Date();
  const todayStr = format(today, 'yyyy-MM-dd');
  const todaySessions = sessions
    .filter((s) => s.session_date === todayStr)
    .sort((a, b) => {
      if (!a.appointment_time && !b.appointment_time) return 0;
      if (!a.appointment_time) return 1;
      if (!b.appointment_time) return -1;
      return a.appointment_time.localeCompare(b.appointment_time);
    });

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2">
        <CalendarCheck className="h-4 w-4 text-primary" />
        <span className="text-[0.9375rem] font-semibold text-foreground">오늘의 일정</span>
        <span className="text-[0.8125rem] text-muted-foreground">
          {format(today, 'M월 d일 (E)', { locale: ko })}
        </span>
        {todaySessions.length > 0 && (
          <span className="ml-auto flex h-5 min-w-[1.25rem] items-center justify-center rounded-full bg-primary/10 px-1.5 text-[0.6875rem] font-semibold text-primary">
            {todaySessions.length}
          </span>
        )}
      </div>

      {(holidayName || (schoolEvents && schoolEvents.length > 0)) && (
        <div className="flex flex-col gap-1">
          {holidayName && (
            <div className="flex items-center gap-2 px-3 py-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-rose-500 shrink-0" />
              <span className="text-[0.875rem] font-medium text-rose-500">{holidayName}</span>
            </div>
          )}
          {schoolEvents && schoolEvents.map((event, i) => (
            <div key={i} className="flex items-center gap-2 px-3 py-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-600 shrink-0" />
              <span className="text-[0.875rem] font-medium text-emerald-600">{event}</span>
            </div>
          ))}
        </div>
      )}

      {todaySessions.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border bg-secondary/30 py-5 text-center">
          <p className="text-[0.875rem] text-muted-foreground">오늘 예정된 상담이 없습니다.</p>
        </div>
      ) : (
        <div className="space-y-1.5">
          {todaySessions.map((s) => (
            <button
              key={s.id}
              {...linkProps(`/cases/${s.case_id}/sessions/${s.id}`)}
              className="w-full flex items-center gap-3 rounded-md px-3 py-1.5 text-left hover:bg-secondary transition-colors border border-transparent hover:border-border group"
            >
              {/* 시간 표시 */}
              <div className="flex shrink-0 items-center gap-1 w-[4rem] text-[0.8125rem]">
                {s.appointment_time ? (
                  <>
                    <Clock className="h-3 w-3 text-primary/60" />
                    <span className="font-medium text-primary">{s.appointment_time}</span>
                  </>
                ) : (
                  <span className="text-muted-foreground/50">시간 미정</span>
                )}
              </div>

              <div
                className={cn(
                  'w-1 h-5 rounded-full shrink-0',
                  s.appointment_time ? 'bg-primary' : 'bg-muted-foreground/30'
                )}
              />

              <div className="flex-1 min-w-0">
                <span className="block text-[0.9375rem] font-medium text-foreground group-hover:text-primary truncate">
                  {s.student_names}
                </span>
                <span className="block text-[0.75rem] text-muted-foreground">
                  {s.case_number}
                </span>
              </div>

              {s.reminder_minutes != null && (
                <div className="shrink-0 flex items-center gap-1 text-[0.75rem] text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  {s.reminder_minutes < 60
                    ? `${s.reminder_minutes}분 전 알림`
                    : `${Math.floor(s.reminder_minutes / 60)}시간 전 알림`}
                </div>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
