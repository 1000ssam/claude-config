import { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { isToday, parseISO } from 'date-fns';
import { ChevronDown, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  pointerWithin,
  useSensor,
  useSensors,
  useDraggable,
  useDroppable,
  type DragStartEvent,
  type DragEndEvent,
  type DragMoveEvent,
} from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import { cn } from '@/lib/utils';
import { getCategoryColor } from './SessionPill';
import { parseTimeString } from '@/components/ui/date-time-picker';
import type { CalendarSession } from '../../../../lib/queries/calendar';

// ── 상수 ─────────────────────────────────────────────────────────────────────
const GRID_START_HOUR = 8;
const GRID_END_HOUR = 20;
const TOTAL_HOURS = GRID_END_HOUR - GRID_START_HOUR;
const PX_PER_HOUR = 96;
const PX_PER_MIN = PX_PER_HOUR / 60;
export const SNAP_MIN = 15;
export const DEFAULT_DURATION_MIN = 60;

// ── 유틸 ─────────────────────────────────────────────────────────────────────
export function snapToGrid(min: number): number {
  return Math.round(min / SNAP_MIN) * SNAP_MIN;
}

export function clampTime(totalMin: number): number {
  const lo = GRID_START_HOUR * 60;
  const hi = (GRID_END_HOUR - 1) * 60;
  return Math.max(lo, Math.min(hi, snapToGrid(totalMin)));
}

export function toTimeString(totalMin: number): string {
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function sessionDuration(s: CalendarSession): number {
  const d = (s.session_hour ?? 0) * 60 + (s.session_minute ?? 0);
  return d > 0 ? d : DEFAULT_DURATION_MIN;
}

function parseTime(t: string): number {
  const [h, m] = t.split(':').map(Number);
  return h * 60 + m;
}

// ── 오버랩 계산 ───────────────────────────────────────────────────────────────
interface LayoutItem {
  session: CalendarSession;
  col: number;
  totalCols: number;
}

/**
 * 겹치는 세션들을 나란히 배치하기 위한 컬럼 인덱스를 계산한다.
 *
 * 알고리즘: 그리디 인터벌 컬러링
 * 1. 시작 시간 순 정렬
 * 2. 각 세션에 대해 이미 끝난 컬럼이 있으면 재사용, 없으면 새 컬럼 추가
 *    → columns[i] 에는 i번 컬럼에 마지막으로 배치된 세션의 종료 시간(분)을 유지
 * 3. 2-pass로 totalCols 계산: 특정 시간 구간에 겹치는 최대 컬럼 수 → 너비 산출에 사용
 */
function computeLayout(sessions: CalendarSession[]): LayoutItem[] {
  const sorted = [...sessions].sort((a, b) =>
    parseTime(a.appointment_time!) - parseTime(b.appointment_time!)
  );
  const items: LayoutItem[] = [];
  const columns: number[] = []; // columns[i] = i번 컬럼의 마지막 세션 종료 시간(분)

  for (const s of sorted) {
    const start = parseTime(s.appointment_time!);
    const end = start + sessionDuration(s);
    let col = columns.findIndex((endMin) => endMin <= start);
    if (col === -1) { col = columns.length; columns.push(end); }
    else columns[col] = end;
    items.push({ session: s, col, totalCols: 0 });
  }

  // 2-pass: 자신과 시간이 겹치는 모든 세션 중 최대 col+1 → 각 블록의 너비 기준
  for (const item of items) {
    const start = parseTime(item.session.appointment_time!);
    const end = start + sessionDuration(item.session);
    let maxCol = item.col;
    for (const other of items) {
      const os = parseTime(other.session.appointment_time!);
      const oe = os + sessionDuration(other.session);
      if (os < end && oe > start) maxCol = Math.max(maxCol, other.col);
    }
    item.totalCols = maxCol + 1;
  }

  return items;
}

// ── 현재 시간 인디케이터 ──────────────────────────────────────────────────────
function CurrentTimeIndicator() {
  const [top, setTop] = useState(() => {
    const now = new Date();
    return ((now.getHours() - GRID_START_HOUR) * 60 + now.getMinutes()) * PX_PER_MIN;
  });

  useEffect(() => {
    const t = setInterval(() => {
      const now = new Date();
      setTop(((now.getHours() - GRID_START_HOUR) * 60 + now.getMinutes()) * PX_PER_MIN);
    }, 60_000);
    return () => clearInterval(t);
  }, []);

  return (
    <div
      className="absolute left-12 right-0 flex items-center pointer-events-none z-10"
      style={{ top }}
    >
      <div className="w-2 h-2 rounded-full bg-red-500 -ml-1 shrink-0" />
      <div className="flex-1 border-t border-red-500" />
    </div>
  );
}

// ── Draggable 언스케줄드 pill ──────────────────────────────────────────────────
function DraggableUnscheduledPill({ session }: { session: CalendarSession }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: `unscheduled-${session.id}`,
    data: { type: 'unscheduled', session },
  });
  const style = transform ? { transform: CSS.Translate.toString(transform) } : undefined;
  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={cn(isDragging ? 'opacity-30' : '')}
    >
      <span
        className={cn(
          'block rounded border px-2 py-0.5 text-[0.6875rem] font-medium truncate max-w-[140px]',
          'cursor-grab active:cursor-grabbing hover:opacity-80 transition-opacity',
          getCategoryColor(session.category_large),
        )}
        title={session.student_names}
      >
        {session.student_names}
      </span>
    </div>
  );
}

// ── 시간 미정 섹션 ────────────────────────────────────────────────────────────
interface UnscheduledSectionProps {
  sessions: CalendarSession[];
}

function UnscheduledSection({ sessions }: UnscheduledSectionProps) {
  const [open, setOpen] = useState(sessions.length > 0);

  return (
    <div className="border-b border-border shrink-0">
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-1.5 px-3 py-2 text-xs text-muted-foreground hover:text-foreground transition-colors"
      >
        <ChevronDown
          className={cn('h-3.5 w-3.5 transition-transform duration-150', !open && '-rotate-90')}
        />
        <span>시간 미정</span>
        {sessions.length > 0 && (
          <span className="ml-0.5 text-muted-foreground/70">({sessions.length})</span>
        )}
      </button>
      {open && (
        <div className="px-3 pb-2.5 min-h-[28px]">
          {sessions.length === 0 ? (
            <p className="text-[0.6875rem] text-muted-foreground/50 italic">없음</p>
          ) : (
            <div className="flex flex-wrap gap-1.5">
              {sessions.map((s) => (
                <DraggableUnscheduledPill key={s.id} session={s} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Droppable 타임그리드 영역 ──────────────────────────────────────────────────
function DroppableTimeGrid({ children }: { children: React.ReactNode }) {
  const { setNodeRef, isOver } = useDroppable({ id: 'timegrid' });
  return (
    <div
      ref={setNodeRef}
      className={cn(
        'flex-1 relative',
        isOver && 'bg-primary/3',
      )}
      style={{ minHeight: 0 }}
    >
      {children}
    </div>
  );
}

// ── 세션 블록 ─────────────────────────────────────────────────────────────────
interface TimeBlockProps {
  session: CalendarSession;
  col: number;
  totalCols: number;
  resizingDuration: number | null;
  isDraggingThis: boolean;
  isEditing: boolean;
  onClick: () => void;
  onEditSave: (h: number, m: number, durationMin: number) => void;
  onEditCancel: () => void;
  onResizeStart: (e: React.PointerEvent, session: CalendarSession) => void;
}

function TimeBlock({ session, col, totalCols, resizingDuration, isDraggingThis, isEditing, onClick, onEditSave, onEditCancel, onResizeStart }: TimeBlockProps) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: `timed-${session.id}`,
    data: { type: 'timed', session },
  });

  // 시간 편집 상태 (시작·종료 각각)
  const [startStr, setStartStr] = useState('');
  const [endStr, setEndStr] = useState('');
  useEffect(() => {
    if (isEditing && session.appointment_time) {
      const startMin = parseTime(session.appointment_time);
      const dur = sessionDuration(session);
      setStartStr(session.appointment_time.substring(0, 5));
      setEndStr(toTimeString(startMin + dur));
    }
  }, [isEditing, session.appointment_time, session.session_hour, session.session_minute]);

  function handleSave() {
    const parsedStart = parseTimeString(startStr);
    const parsedEnd = parseTimeString(endStr);
    if (parsedStart && parsedEnd) {
      const startTotalMin = parseTime(parsedStart);
      const endTotalMin = parseTime(parsedEnd);
      const durationMin = endTotalMin - startTotalMin;
      if (durationMin > 0) {
        const [hStr, mStr] = parsedStart.split(':');
        onEditSave(
          Math.max(GRID_START_HOUR, Math.min(GRID_END_HOUR - 1, parseInt(hStr, 10))),
          Math.max(0, Math.min(59, parseInt(mStr, 10))),
          durationMin,
        );
        return;
      }
    }
    onEditCancel();
  }

  const [h, m] = session.appointment_time!.split(':').map(Number);
  const startMin = (h - GRID_START_HOUR) * 60 + m;
  const duration = resizingDuration ?? sessionDuration(session);
  const top = startMin * PX_PER_MIN;
  const height = Math.max(duration * PX_PER_MIN, SNAP_MIN * PX_PER_MIN);
  const widthPct = 100 / totalCols;
  const leftPct = col * widthPct;
  const color = getCategoryColor(session.category_large);

  const style = {
    top,
    height,
    left: `calc(48px + ${leftPct}%)`,
    width: `calc(${widthPct}% - 4px)`,
    ...(transform && !isEditing ? { transform: CSS.Translate.toString(transform) } : {}),
  };

  return (
    <div
      ref={setNodeRef}
      className={cn(
        'absolute rounded border select-none group',
        'transition-opacity overflow-hidden',
        color,
        isEditing ? 'cursor-default ring-2 ring-primary/60' : 'hover:opacity-90',
        (isDragging || isDraggingThis) ? 'opacity-30 cursor-grabbing' : (!isEditing && 'cursor-grab'),
      )}
      style={style}
      {...attributes}
      {...(isEditing ? {} : listeners)}
      onClick={(e) => { e.stopPropagation(); if (!isEditing) onClick(); }}
    >
      {isEditing ? (
        /* 시간 편집 폼 — 시작~종료 두 인풋, 포커스가 밖으로 나갈 때 저장 */
        <div
          className="px-1.5 py-1 flex items-center gap-0.5"
          onClick={(e) => e.stopPropagation()}
          onBlur={(e) => {
            if (!e.currentTarget.contains(e.relatedTarget as Node)) handleSave();
          }}
        >
          <input
            type="text"
            inputMode="numeric"
            value={startStr}
            onChange={(e) => setStartStr(e.target.value)}
            onFocus={(e) => e.target.select()}
            onKeyDown={(e) => {
              e.stopPropagation();
              if (e.key === 'Enter') e.currentTarget.blur();
              if (e.key === 'Escape') onEditCancel();
            }}
            className="w-12 text-center text-[0.6875rem] font-mono bg-background/95 border border-border rounded py-0 leading-tight"
            autoFocus
          />
          <span className="text-[0.625rem] text-muted-foreground shrink-0">~</span>
          <input
            type="text"
            inputMode="numeric"
            value={endStr}
            onChange={(e) => setEndStr(e.target.value)}
            onFocus={(e) => e.target.select()}
            onKeyDown={(e) => {
              e.stopPropagation();
              if (e.key === 'Enter') e.currentTarget.blur();
              if (e.key === 'Escape') onEditCancel();
            }}
            className="w-12 text-center text-[0.6875rem] font-mono bg-background/95 border border-border rounded py-0 leading-tight"
          />
        </div>
      ) : (
        <div className="px-1.5 py-0.5">
          <div className="text-[0.6875rem] font-semibold leading-tight truncate">
            {session.appointment_time} {session.student_names}
          </div>
          {duration >= 30 && (
            <div className="text-[0.5625rem] opacity-60 leading-tight truncate">
              {session.session_title || session.category_large}
            </div>
          )}
        </div>
      )}

      {/* 리사이즈 핸들 (편집 중엔 숨김) */}
      {!isEditing && (
        <div
          className="absolute bottom-0 inset-x-0 h-3 cursor-ns-resize opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
          onPointerDown={(e) => { e.stopPropagation(); onResizeStart(e, session); }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="w-8 h-0.5 bg-current rounded-full opacity-40" />
        </div>
      )}
    </div>
  );
}

// ── DayTimeGrid (메인) ────────────────────────────────────────────────────────
interface DayTimeGridProps {
  date: string;
  sessions: CalendarSession[];
  onUpdate?: () => void;
  /** 이 날짜로 빠른 일정 등록 */
  onAddSession?: (dateStr: string) => void;
}

export function DayTimeGrid({ date, sessions, onUpdate, onAddSession }: DayTimeGridProps) {
  const gridRef = useRef<HTMLDivElement>(null);
  const today = isToday(parseISO(date));
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));

  // 해당 날짜 세션 분류
  const daySessions = useMemo(
    () => sessions.filter((s) => s.session_date === date),
    [sessions, date]
  );
  const [optimisticSessions, setOptimisticSessions] = useState<CalendarSession[]>(daySessions);
  useEffect(() => { setOptimisticSessions(daySessions); }, [daySessions]);

  const timedSessions = useMemo(
    () => optimisticSessions.filter((s) => !!s.appointment_time),
    [optimisticSessions]
  );
  const unscheduledSessions = useMemo(
    () => optimisticSessions.filter((s) => !s.appointment_time),
    [optimisticSessions]
  );

  // 레이아웃 (오버랩 처리)
  const layout = useMemo(() => computeLayout(timedSessions), [timedSessions]);

  // 드래그 상태
  const [activeSession, setActiveSession] = useState<CalendarSession | null>(null);
  const [previewTime, setPreviewTime] = useState<string>('');
  // 네이티브 pointermove로 실제 포인터 Y를 추적 (dnd-kit delta는 auto-scroll 보정이 포함되어 부정확)
  const rawPointerYRef = useRef(0);
  useEffect(() => {
    const track = (e: PointerEvent) => { rawPointerYRef.current = e.clientY; };
    document.addEventListener('pointermove', track);
    return () => document.removeEventListener('pointermove', track);
  }, []);
  // 시간 편집 상태
  const [editingId, setEditingId] = useState<number | null>(null);

  // 리사이즈 상태
  // resizingRef: pointerup 핸들러는 addEventListener로 등록되어 React 렌더 사이클 밖에 존재한다.
  // 클로저가 최초 등록 시점의 state를 캡처하므로, 최신 값을 읽으려면 ref로 동기화해야 한다.
  const [resizingState, setResizingState] = useState<{ id: number; duration: number } | null>(null);
  const resizingRef = useRef(resizingState);
  useEffect(() => { resizingRef.current = resizingState; }, [resizingState]);

  // 마운트 시 첫 상담 시간으로 스크롤 (빈 날은 최상단)
  useEffect(() => {
    if (!gridRef.current) return;
    const timed = daySessions.filter((s) => !!s.appointment_time);
    if (timed.length > 0) {
      const firstMin = Math.min(...timed.map((s) => parseTime(s.appointment_time!)));
      const targetHour = Math.floor(firstMin / 60);
      const scrollTop = Math.max(0, (targetHour - GRID_START_HOUR - 1) * PX_PER_HOUR);
      gridRef.current.scrollTo({ top: scrollTop, behavior: 'smooth' });
    } else {
      gridRef.current.scrollTo({ top: 0 });
    }
  }, [date, daySessions]);

  // ── Y좌표 → 시간 변환 ────────────────────────────────────────────────────
  function calcTimeFromPointerY(clientY: number): number {
    if (!gridRef.current) return GRID_START_HOUR * 60;
    const rect = gridRef.current.getBoundingClientRect();
    const relY = clientY - rect.top + gridRef.current.scrollTop;
    const totalMin = GRID_START_HOUR * 60 + relY / PX_PER_MIN;
    return clampTime(totalMin);
  }

  // ── 드래그 핸들러 ─────────────────────────────────────────────────────────
  const handleDragStart = useCallback((event: DragStartEvent) => {
    const { session } = event.active.data.current as { type: string; session: CalendarSession };
    setActiveSession(session);
    setEditingId(null);
  }, []);

  const handleDragMove = useCallback((event: DragMoveEvent) => {
    const { type, session } = event.active.data.current as { type: string; session: CalendarSession };
    let totalMin: number;
    if (type === 'timed' && session.appointment_time) {
      // delta만 snap하고 원래 시간에는 snap하지 않음 (비정렬 시간 튕김 방지)
      const deltaMin = snapToGrid(event.delta.y / PX_PER_MIN);
      const lo = GRID_START_HOUR * 60;
      const hi = (GRID_END_HOUR - 1) * 60;
      totalMin = Math.max(lo, Math.min(hi, parseTime(session.appointment_time) + deltaMin));
    } else {
      // 시간 미정: 네이티브 포인터 Y로 계산 (dnd-kit delta는 auto-scroll 보정 포함되어 부정확)
      totalMin = calcTimeFromPointerY(rawPointerYRef.current);
    }
    setPreviewTime(toTimeString(totalMin));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    const { over, active, delta } = event;
    setActiveSession(null);

    const { type, session } = active.data.current as { type: string; session: CalendarSession };

    // 낙관적 업데이트 + API 저장 공통 헬퍼
    function commit(newTime: string) {
      setOptimisticSessions((prev) =>
        prev.map((s) => s.id === session.id ? { ...s, appointment_time: newTime } : s)
      );
      window.api.sessions.update(session.id, { appointment_time: newTime })
        .then(() => onUpdate?.())
        .catch((e) => { console.error('[DayTimeGrid] update time', e); setOptimisticSessions(daySessions); });
    }

    if (type === 'timed' && session.appointment_time) {
      // delta만 snap → 원래 시간 + 스냅된 이동량. 전체 시간을 snap하면 비정렬 시간이 튕김.
      const deltaMin = snapToGrid(delta.y / PX_PER_MIN);
      if (deltaMin === 0) return;
      const lo = GRID_START_HOUR * 60;
      const hi = (GRID_END_HOUR - 1) * 60;
      const newTotalMin = Math.max(lo, Math.min(hi, parseTime(session.appointment_time) + deltaMin));
      const newTime = toTimeString(newTotalMin);
      if (newTime !== session.appointment_time) commit(newTime);
    } else {
      // 시간 미정 pill: 절대 포인터 Y → 시간 변환 (시작 위치 정보 없으므로 delta 사용 불가).
      // 타임그리드 밖에 드롭한 경우 무시.
      if (!over || over.id !== 'timegrid') return;
      commit(toTimeString(calcTimeFromPointerY(rawPointerYRef.current)));
    }
  }, [daySessions, onUpdate]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── 시간 편집 저장 ────────────────────────────────────────────────────────
  const handleEditSave = useCallback((session: CalendarSession, newH: number, newM: number, durationMin: number) => {
    const newTime = toTimeString(newH * 60 + newM);
    const session_hour = Math.floor(durationMin / 60);
    const session_minute = durationMin % 60;
    setEditingId(null);
    setOptimisticSessions((prev) =>
      prev.map((s) => s.id === session.id ? { ...s, appointment_time: newTime, session_hour, session_minute } : s)
    );
    window.api.sessions.update(session.id, { appointment_time: newTime, session_hour, session_minute })
      .then(() => onUpdate?.())
      .catch((e) => { console.error('[DayTimeGrid] edit save', e); setOptimisticSessions(daySessions); });
  }, [daySessions, onUpdate]);

  // ── 리사이즈 핸들러 ────────────────────────────────────────────────────────
  const handleResizeStart = useCallback((e: React.PointerEvent, session: CalendarSession) => {
    e.preventDefault();
    (e.target as Element).setPointerCapture(e.pointerId);
    const startY = e.clientY;
    const startDuration = sessionDuration(session);

    function onMove(ev: PointerEvent) {
      const delta = ev.clientY - startY;
      const raw = startDuration + delta / PX_PER_MIN;
      const snapped = Math.max(SNAP_MIN, snapToGrid(raw));
      setResizingState({ id: session.id, duration: snapped });
    }

    function onUp() {
      const state = resizingRef.current;
      if (state) {
        const hour = Math.floor(state.duration / 60);
        const minute = state.duration % 60;
        window.api.sessions.update(state.id, { session_hour: hour, session_minute: minute })
          .then(() => onUpdate?.())
          .catch((e) => console.error('[DayTimeGrid] resize save', e));
        setResizingState(null);
      }
      document.removeEventListener('pointermove', onMove);
      document.removeEventListener('pointerup', onUp);
    }

    document.addEventListener('pointermove', onMove);
    document.addEventListener('pointerup', onUp);
  }, [onUpdate]);

  // ── 시간 레이블 ────────────────────────────────────────────────────────────
  const hours = Array.from({ length: TOTAL_HOURS + 1 }, (_, i) => GRID_START_HOUR + i);

  const gridContent = (
    <>
      {/* 시간 슬롯 (그리드 라인) */}
      {hours.map((h, i) => (
        <div
          key={h}
          className={cn('flex relative', i < TOTAL_HOURS ? 'border-b border-border/50' : '')}
          style={{ height: i < TOTAL_HOURS ? PX_PER_HOUR : 0 }}
        >
          <span className="w-12 text-[0.625rem] text-muted-foreground/60 shrink-0 select-none -translate-y-2 pl-2 pt-0.5">
            {String(h).padStart(2, '0')}:00
          </span>
          {i < TOTAL_HOURS && (
            <div className="flex-1 relative">
              <div className="absolute left-0 right-0 top-1/2 border-t border-dashed border-border/25" />
            </div>
          )}
        </div>
      ))}

      {/* 세션 블록 */}
      {layout.map(({ session, col, totalCols }) => (
        <TimeBlock
          key={session.id}
          session={session}
          col={col}
          totalCols={totalCols}
          resizingDuration={resizingState?.id === session.id ? resizingState.duration : null}
          isDraggingThis={activeSession?.id === session.id}
          isEditing={editingId === session.id}
          onClick={() => setEditingId(session.id)}
          onEditSave={(newH, newM, dur) => handleEditSave(session, newH, newM, dur)}
          onEditCancel={() => setEditingId(null)}
          onResizeStart={handleResizeStart}
        />
      ))}

      {today && <CurrentTimeIndicator />}
    </>
  );

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={pointerWithin}
      onDragStart={handleDragStart}
      onDragMove={handleDragMove}
      onDragEnd={handleDragEnd}
    >
      <div className="flex flex-col h-full">
        {onAddSession && (
          <div className="shrink-0 border-b border-border px-3 py-2">
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={() => onAddSession(date)}
            >
              <Plus className="mr-1.5 h-3.5 w-3.5" />
              이 날짜에 일정 추가
            </Button>
          </div>
        )}
        <UnscheduledSection sessions={unscheduledSessions} />

        <DroppableTimeGrid>
          <div ref={gridRef} className="absolute inset-0 overflow-y-auto">
            {gridContent}
          </div>
        </DroppableTimeGrid>
      </div>

      {/* 드래그 고스트 */}
      <DragOverlay dropAnimation={null}>
        {activeSession && (
          <div className="bg-background/95 border border-primary/60 rounded shadow-lg px-2.5 py-1.5 text-xs backdrop-blur-sm pointer-events-none">
            <span className="font-semibold text-primary tabular-nums">{previewTime}</span>
            <span className="ml-2 text-muted-foreground truncate">{activeSession.student_names}</span>
          </div>
        )}
      </DragOverlay>
    </DndContext>
  );
}
