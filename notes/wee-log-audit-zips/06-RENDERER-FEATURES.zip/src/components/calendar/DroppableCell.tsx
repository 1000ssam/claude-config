import { useDroppable } from '@dnd-kit/core';
import { cn } from '@/lib/utils';

interface DroppableCellProps {
  dateStr: string;
  isDroppable: boolean;
  className?: string;
  onClick?: () => void;
  children: React.ReactNode;
}

export function DroppableCell({ dateStr, isDroppable, className, onClick, children }: DroppableCellProps) {
  const { setNodeRef, isOver } = useDroppable({
    id: dateStr,
    disabled: !isDroppable,
  });

  return (
    <div
      ref={setNodeRef}
      className={cn(
        className,
        isOver && isDroppable && 'bg-primary/8 ring-1 ring-inset ring-primary/30',
        onClick && 'cursor-pointer',
      )}
      onClick={onClick}
    >
      {children}
    </div>
  );
}
