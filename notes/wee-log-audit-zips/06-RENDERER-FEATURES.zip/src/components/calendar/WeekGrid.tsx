import { useState, useRef, useEffect } from 'react';
import { format, isToday } from 'date-fns';
import { Plus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { DroppableCell } from './DroppableCell';
import { DraggableSessionPill } from './SessionPill';
import type { GridProps } from './calendar-types';

// 이름 경계에서 잘라 "이름A · 이름B ···" 형태로 반환
function fitNames(
  names: string[],
  maxPx: number,
  ctx: CanvasRenderingContext2D,
): { text: string; hasMore: boolean } {
  if (!names.length) return { text: '', hasMore: false };

  const sep = ' · ';
  const suffix = ' ···';
  const sepW = ctx.measureText(sep).width;
  const suffixW = ctx.measureText(suffix).width;

  let usedW = 0;
  const shown: string[] = [];

  for (let i = 0; i < names.length; i++) {
    const nameW = ctx.measureText(names[i]).width;
    const addW = i === 0 ? nameW : sepW + nameW;
    const isLast = i === names.length - 1;
    const totalW = usedW + addW + (isLast ? 0 : suffixW);

    if (totalW <= maxPx) {
      usedW += addW;
      shown.push(names[i]);
    } else {
      break;
    }
  }

  if (shown.length === 0) {
    return { text: names[0], hasMore: names.length > 1 };
  }

  const hasMore = shown.length < names.length;
  return { text: shown.join(sep) + (hasMore ? suffix : ''), hasMore };
}

export function WeekGrid({ days, sessionsByDate, inMonthDates, draggingId, onSessionClick, onDateClick, onAddSession, onDateUpdate, onTimeUpdate, getHolidayName, getSchoolEventName }: GridProps) {
  const [overlayDate, setOverlayDate] = useState<string | null>(null);
  const [cellInnerWidth, setCellInnerWidth] = useState(0);

  const gridRef = useRef<HTMLDivElement>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);

  // Canvas ctx 초기화 — text-[0.6875rem] = 11px
  useEffect(() => {
    const canvas = document.createElement('canvas');
    ctxRef.current = canvas.getContext('2d');
    if (ctxRef.current) {
      ctxRef.current.font = '11px system-ui, -apple-system, "Malgun Gothic", sans-serif';
    }
  }, []);

  // 그리드 너비 감지 → 셀 내부 사용 가능 너비 계산
  useEffect(() => {
    const el = gridRef.current;
    if (!el) return;
    const update = () => {
      // p-2(8px) * 2 = 16px 셀 패딩, border 1px, school span pl-0.5(2px)
      const cellW = el.offsetWidth / 7;
      setCellInnerWidth(Math.floor(cellW) - 19); // 16 + 1 + 2
    };
    const obs = new ResizeObserver(update);
    obs.observe(el);
    update();
    return () => obs.disconnect();
  }, []);

  return (
    <div ref={gridRef} className="grid grid-cols-7 border-l border-t border-border">
      {days.map((day) => {
        const dateStr = format(day, 'yyyy-MM-dd');
        const daySessions = sessionsByDate.get(dateStr) ?? [];
        const today = isToday(day);
        const isSun = day.getDay() === 0;
        const isSat = day.getDay() === 6;

        const holidayName = getHolidayName(dateStr);
        const schoolEventNames = getSchoolEventName(dateStr);
        const isHolidayDay = !!holidayName;

        // 이름 경계 기준 truncation
        const schoolFit = schoolEventNames && ctxRef.current && cellInnerWidth > 0
          ? fitNames(schoolEventNames, cellInnerWidth, ctxRef.current)
          : schoolEventNames
            ? { text: schoolEventNames.join(' · '), hasMore: schoolEventNames.length > 1 }
            : null;

        return (
          <DroppableCell
            key={dateStr}
            dateStr={dateStr}
            isDroppable={inMonthDates.has(dateStr)}
            onClick={() => onDateClick(dateStr)}
            className={cn(
              'group border-b border-r border-border p-2 min-h-[140px] transition-colors',
              isSun && 'bg-rose-50/30 hover:bg-rose-50/60',
              isSat && 'bg-blue-50/30 hover:bg-blue-50/60',
              !isSun && !isSat && 'hover:bg-secondary/30',
            )}
          >
            <div className="mb-2">
              <div className="flex items-center justify-between">
                <span
                  title={holidayName}
                  onClick={(e) => { e.stopPropagation(); onDateClick(dateStr); }}
                  className={cn(
                    'flex h-7 w-7 items-center justify-center rounded-full text-[0.8125rem] font-semibold shrink-0 cursor-pointer transition-colors',
                    today && 'bg-primary text-white hover:bg-primary/90',
                    !today && (isSun || isHolidayDay) && 'text-red-500 hover:bg-secondary/80',
                    !today && isSat && !isHolidayDay && 'text-blue-500 hover:bg-secondary/80',
                    !today && !isSun && !isHolidayDay && !isSat && 'text-foreground hover:bg-secondary/80',
                  )}
                >
                  {format(day, 'd')}
                </span>
                {onAddSession && (
                  <button
                    type="button"
                    title="이 날짜에 일정 추가"
                    onClick={(e) => { e.stopPropagation(); onAddSession(dateStr); }}
                    className="flex h-5 w-5 items-center justify-center rounded-md text-muted-foreground opacity-0 transition-opacity hover:bg-secondary hover:text-foreground focus:opacity-100 group-hover:opacity-100"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
              {/* 고정 높이 info 라인 — 공휴일 OR 학사일정 (공휴일 우선), 없으면 빈 공간 유지 */}
              <div className="h-5 relative mt-0.5">
                {isHolidayDay ? (
                  <span className="text-[0.6875rem] text-rose-400 leading-none truncate max-w-full pl-0.5 absolute inset-0 flex items-center">
                    {holidayName}
                  </span>
                ) : schoolFit ? (
                  <>
                    <span
                      className={cn(
                        'text-[0.6875rem] text-emerald-600 leading-none truncate max-w-full pl-0.5 absolute inset-0 flex items-center',
                        schoolFit.hasMore && 'cursor-pointer hover:text-emerald-700',
                      )}
                      title={schoolEventNames!.join(' · ')}
                      onClick={schoolFit.hasMore ? (e) => {
                        e.stopPropagation();
                        setOverlayDate(overlayDate === dateStr ? null : dateStr);
                      } : undefined}
                    >
                      {schoolFit.text}
                    </span>
                    {overlayDate === dateStr && (
                      <>
                        <div className="fixed inset-0 z-40" onClick={() => setOverlayDate(null)} />
                        <div
                          className="absolute left-0 top-full z-50 min-w-[9rem] rounded-md border border-border bg-background shadow-md p-2 mt-0.5"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <p className="text-[0.625rem] font-semibold text-muted-foreground mb-1">학사일정</p>
                          {schoolEventNames!.map((name, i) => (
                            <p key={i} className="text-[0.6875rem] text-emerald-600 py-0.5 whitespace-nowrap">{name}</p>
                          ))}
                        </div>
                      </>
                    )}
                  </>
                ) : null}
              </div>
            </div>
            <div className="space-y-1">
              {daySessions.map((s) => (
                <div key={s.id} onClick={(e) => e.stopPropagation()}>
                  <DraggableSessionPill
                    session={s}
                    onClick={() => onSessionClick(s)}
                    compact={false}
                    isDraggingThis={draggingId === s.id}
                    onDateUpdate={onDateUpdate}
                    onTimeUpdate={onTimeUpdate}
                  />
                </div>
              ))}
              {daySessions.length === 0 && (
                <div className="text-[0.75rem] text-muted-foreground/50 italic py-1">없음</div>
              )}
            </div>
          </DroppableCell>
        );
      })}
    </div>
  );
}
