import { useState, useRef, useEffect } from 'react';
import { format, isToday } from 'date-fns';
import { Plus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { DroppableCell } from './DroppableCell';
import { DraggableSessionPill } from './SessionPill';
import type { GridProps } from './calendar-types';

// 이름 경계에서 잘라 "이름A · 이름B ···" 형태로 반환
function fitNames(
  names: string[],
  maxPx: number,
  ctx: CanvasRenderingContext2D,
): { text: string; hasMore: boolean } {
  if (!names.length) return { text: '', hasMore: false };

  const sep = ' · ';
  const suffix = ' ···';
  const sepW = ctx.measureText(sep).width;
  const suffixW = ctx.measureText(suffix).width;

  let usedW = 0;
  const shown: string[] = [];

  for (let i = 0; i < names.length; i++) {
    const nameW = ctx.measureText(names[i]).width;
    const addW = i === 0 ? nameW : sepW + nameW;
    const isLast = i === names.length - 1;
    // 마지막 이름이 아니면 suffix 공간 예약
    const totalW = usedW + addW + (isLast ? 0 : suffixW);

    if (totalW <= maxPx) {
      usedW += addW;
      shown.push(names[i]);
    } else {
      break;
    }
  }

  // 아무것도 안 들어오면 첫 이름만 (CSS truncate로 처리)
  if (shown.length === 0) {
    return { text: names[0], hasMore: names.length > 1 };
  }

  const hasMore = shown.length < names.length;
  return { text: shown.join(sep) + (hasMore ? suffix : ''), hasMore };
}

export function MonthGrid({ days, cursor, sessionsByDate, inMonthDates, draggingId, onSessionClick, onDateClick, onAddSession, onDateUpdate, onTimeUpdate, getHolidayName, getSchoolEventName }: GridProps) {
  const MAX_VISIBLE = 3;
  const [expandedDates, setExpandedDates] = useState<Set<string>>(new Set());
  const [overlayDate, setOverlayDate] = useState<string | null>(null);
  const [cellInnerWidth, setCellInnerWidth] = useState(0);

  const gridRef = useRef<HTMLDivElement>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);

  // Canvas ctx 초기화
  useEffect(() => {
    const canvas = document.createElement('canvas');
    ctxRef.current = canvas.getContext('2d');
    if (ctxRef.current) {
      // text-[0.5625rem] = 9px. 시스템 폰트로 한국어 측정
      ctxRef.current.font = '9px system-ui, -apple-system, "Malgun Gothic", sans-serif';
    }
  }, []);

  // 그리드 너비 감지 → 셀 내부 사용 가능 너비 계산
  useEffect(() => {
    const el = gridRef.current;
    if (!el) return;
    const update = () => {
      // 셀 너비 = 그리드 너비 / 7
      // p-1.5(6px) * 2 = 12px 셀 패딩, border 1px, info span px-0.5(2px) * 2 = 4px
      const cellW = el.offsetWidth / 7;
      setCellInnerWidth(Math.floor(cellW) - 17); // 12 + 1 + 4
    };
    const obs = new ResizeObserver(update);
    obs.observe(el);
    update();
    return () => obs.disconnect();
  }, []);

  function toggleExpand(dateStr: string) {
    setExpandedDates((prev) => {
      const next = new Set(prev);
      if (next.has(dateStr)) next.delete(dateStr);
      else next.add(dateStr);
      return next;
    });
  }

  return (
    <div ref={gridRef} className="grid grid-cols-7 border-l border-t border-border">
      {days.map((day) => {
        const dateStr = format(day, 'yyyy-MM-dd');
        const daySessions = sessionsByDate.get(dateStr) ?? [];
        const hidden = daySessions.length - MAX_VISIBLE;
        const inMonth = inMonthDates.has(dateStr);
        const today = isToday(day);
        const isSun = day.getDay() === 0;
        const isSat = day.getDay() === 6;
        const isExpanded = expandedDates.has(dateStr);
        const visibleSessions = isExpanded ? daySessions : daySessions.slice(0, MAX_VISIBLE);

        const holidayName = getHolidayName(dateStr);
        const schoolEventNames = getSchoolEventName(dateStr);
        const isHolidayDay = !!holidayName && inMonth;

        // 이름 경계 기준 truncation
        const schoolFit = schoolEventNames && inMonth && ctxRef.current && cellInnerWidth > 0
          ? fitNames(schoolEventNames, cellInnerWidth, ctxRef.current)
          : schoolEventNames && inMonth
            ? { text: schoolEventNames.join(' · '), hasMore: schoolEventNames.length > 1 }
            : null;

        return (
          <DroppableCell
            key={dateStr}
            dateStr={dateStr}
            isDroppable={inMonth}
            onClick={inMonth ? () => onDateClick(dateStr) : undefined}
            className={cn(
              'group min-h-[100px] border-b border-r border-border p-1.5 transition-colors',
              !inMonth && 'bg-secondary/40',
              inMonth && isSun && 'bg-rose-50/30 hover:bg-rose-50/60',
              inMonth && isSat && 'bg-blue-50/30 hover:bg-blue-50/60',
              inMonth && !isSun && !isSat && 'hover:bg-secondary/30',
            )}
          >
            {/* 날짜 헤더 — 고정 높이로 pill 시작 위치 통일 */}
            <div className="mb-1">
              <div className="flex justify-between items-center w-full">
                <span
                  title={holidayName}
                  onClick={(e) => { e.stopPropagation(); inMonth && onDateClick(dateStr); }}
                  className={cn(
                    'flex h-6 w-6 items-center justify-center rounded-full text-[0.75rem] font-medium',
                    inMonth && 'cursor-pointer hover:bg-secondary/80 transition-colors',
                    today && 'bg-primary text-white font-bold hover:bg-primary/90',
                    !today && (isSun || isHolidayDay) && 'text-red-500',
                    !today && isSat && !isHolidayDay && 'text-blue-500',
                    !today && !isSun && !isHolidayDay && !isSat && (inMonth ? 'text-foreground' : 'text-muted-foreground/50'),
                  )}
                >
                  {format(day, 'd')}
                </span>
                {inMonth && onAddSession && (
                  <button
                    type="button"
                    title="이 날짜에 일정 추가"
                    onClick={(e) => { e.stopPropagation(); onAddSession(dateStr); }}
                    className="flex h-5 w-5 items-center justify-center rounded-md text-muted-foreground opacity-0 transition-opacity hover:bg-secondary hover:text-foreground focus:opacity-100 group-hover:opacity-100"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
              {/* info 라인 — 항상 고정 높이 */}
              <div className="h-3.5 relative">
                {isHolidayDay ? (
                  <span className="text-[0.5625rem] text-rose-400 leading-none truncate max-w-full px-0.5 absolute inset-0 flex items-center">
                    {holidayName}
                  </span>
                ) : schoolFit ? (
                  <>
                    <span
                      className={cn(
                        'text-[0.5625rem] text-emerald-600 leading-none truncate max-w-full px-0.5 absolute inset-0 flex items-center',
                        schoolFit.hasMore && 'cursor-pointer hover:text-emerald-700',
                      )}
                      title={schoolEventNames!.join(' · ')}
                      onClick={schoolFit.hasMore ? (e) => {
                        e.stopPropagation();
                        setOverlayDate(overlayDate === dateStr ? null : dateStr);
                      } : undefined}
                    >
                      {schoolFit.text}
                    </span>
                    {overlayDate === dateStr && (
                      <>
                        <div className="fixed inset-0 z-40" onClick={() => setOverlayDate(null)} />
                        <div
                          className="absolute left-0 top-full z-50 min-w-[9rem] rounded-md border border-border bg-background shadow-md p-2 mt-0.5"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <p className="text-[0.625rem] font-semibold text-muted-foreground mb-1">학사일정</p>
                          {schoolEventNames!.map((name, i) => (
                            <p key={i} className="text-[0.6875rem] text-emerald-600 py-0.5 whitespace-nowrap">{name}</p>
                          ))}
                        </div>
                      </>
                    )}
                  </>
                ) : null}
              </div>
            </div>

            <div className="space-y-0.5">
              {visibleSessions.map((s) => (
                <div key={s.id} onClick={(e) => e.stopPropagation()}>
                  <DraggableSessionPill
                    session={s}
                    onClick={() => onSessionClick(s)}
                    compact
                    isDraggingThis={draggingId === s.id}
                    onDateUpdate={onDateUpdate}
                    onTimeUpdate={onTimeUpdate}
                  />
                </div>
              ))}
              {!isExpanded && hidden > 0 && (
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); toggleExpand(dateStr); }}
                  className="text-[0.6875rem] text-muted-foreground pl-1 hover:text-foreground transition-colors cursor-pointer"
                >
                  +{hidden}개 더
                </button>
              )}
              {isExpanded && daySessions.length > MAX_VISIBLE && (
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); toggleExpand(dateStr); }}
                  className="text-[0.6875rem] text-muted-foreground pl-1 hover:text-foreground transition-colors cursor-pointer"
                >
                  접기
                </button>
              )}
            </div>
          </DroppableCell>
        );
      })}
    </div>
  );
}
