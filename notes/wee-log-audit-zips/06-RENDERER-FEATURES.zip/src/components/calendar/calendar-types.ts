import type { CalendarSession } from '../../../../lib/queries/calendar';

export type ViewMode = 'month' | 'week';

export interface GridProps {
  days: Date[];
  cursor?: Date;
  sessionsByDate: Map<string, CalendarSession[]>;
  inMonthDates: Set<string>;
  draggingId: number | null;
  onSessionClick: (s: CalendarSession) => void;
  onDateClick: (dateStr: string) => void;
  /** 날짜 셀 호버 '+' → 그 날짜로 빠른 일정 등록 */
  onAddSession?: (dateStr: string) => void;
  onDateUpdate: (sessionId: number, newDate: string) => void;
  onTimeUpdate: (sessionId: number, time: string | null) => void;
  getHolidayName: (dateStr: string) => string | undefined;
  getSchoolEventName: (dateStr: string) => string[] | undefined;
}
