import { useState, useMemo, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  startOfMonth, endOfMonth, startOfWeek, endOfWeek,
  eachDayOfInterval, format,
  addMonths, subMonths, addWeeks, subWeeks,
} from 'date-fns';
import { ko } from 'date-fns/locale';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
  closestCenter,
  type DragStartEvent,
  type DragEndEvent,
} from '@dnd-kit/core';
import {
  SortableContext,
  horizontalListSortingStrategy,
  arrayMove,
} from '@dnd-kit/sortable';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { getHolidayName } from '@/lib/holidays';
import type { CalendarSession } from '../../../lib/queries/calendar';
import type { ViewMode } from './calendar-types';
import { MonthGrid } from './MonthGrid';
import { WeekGrid } from './WeekGrid';
import { SessionPill } from './SessionPill';
import { SortableTab } from './SortableTab';

interface CalendarViewProps {
  sessions: CalendarSession[];
  onRangeChange: (from: string, to: string) => void;
  onSessionMoved?: (sessionId: number, newDate: string) => void;
  onTimeUpdate?: (sessionId: number, time: string | null) => void;
  onDateClick?: (dateStr: string) => void;
  /** 날짜 셀 호버 '+' → 그 날짜로 빠른 일정 등록 */
  onAddSession?: (dateStr: string) => void;
  initialViewMode?: ViewMode;
  onViewModeChange?: (mode: ViewMode) => void;
}

function formatDate(date: Date): string {
  return format(date, 'yyyy-MM-dd');
}

const DOW_LABELS = ['일', '월', '화', '수', '목', '금', '토'];

export function CalendarView({
  sessions,
  onRangeChange,
  onSessionMoved,
  onTimeUpdate,
  onDateClick,
  onAddSession,
  initialViewMode,
  onViewModeChange,
}: CalendarViewProps) {
  const navigate = useNavigate();

  // ── 상태 (훅 순서: useState → useEffect 순으로 정렬) ──────────────────────
  const initMode: ViewMode = initialViewMode === 'week' ? 'week' : 'month';
  const [cursor, setCursor] = useState(new Date());
  const [viewMode, setViewMode] = useState<ViewMode>(initMode);
  const [tabOrder, setTabOrder] = useState<ViewMode[]>(
    initMode === 'week' ? ['week', 'month'] : ['month', 'week']
  );
  const [dynamicHolidays, setDynamicHolidays] = useState<Record<string, string>>({});
  const [schoolEvents, setSchoolEvents] = useState<Record<string, string[]>>({});
  const [optimisticSessions, setOptimisticSessions] = useState<CalendarSession[]>(sessions);
  const [activeSession, setActiveSession] = useState<CalendarSession | null>(null);

  // ── 이펙트 ────────────────────────────────────────────────────────────────

  // 공휴일 + 학사일정 동적 로드 (연도 변경 시)
  useEffect(() => {
    const year = cursor.getFullYear();
    window.api.holidays.getYear(year).then((data) => {
      if (!data) return;
      const map: Record<string, string> = {};
      for (const { date, name } of data) map[date] = name;
      setDynamicHolidays(map);
    }).catch((e) => console.error('[Calendar] holidays fetch', e));

    window.api.school.getSchedule(year).then((data) => {
      const map: Record<string, string[]> = {};
      for (const { date, name } of data) (map[date] ??= []).push(name);
      setSchoolEvents(map);
    }).catch((e) => console.error('[Calendar] school schedule fetch', e));
  }, [cursor.getFullYear()]); // eslint-disable-line react-hooks/exhaustive-deps

  // 설정 비동기 로드 후 뷰모드+탭순서 동기화
  useEffect(() => {
    if (!initialViewMode) return;
    const mode: ViewMode = initialViewMode === 'week' ? 'week' : 'month';
    setViewMode(mode);
    setTabOrder(mode === 'week' ? ['week', 'month'] : ['month', 'week']);
  }, [initialViewMode]);

  // sessions prop이 바뀌면 낙관적 상태를 동기화
  useMemo(() => {
    setOptimisticSessions(sessions);
  }, [sessions]);

  // ── 센서 ─────────────────────────────────────────────────────────────────
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } })
  );
  const tabSensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } })
  );

  // ── 날짜 범위 계산 ────────────────────────────────────────────────────────
  const { days, rangeFrom, rangeTo, headerLabel, inMonthDates } = useMemo(() => {
    if (viewMode === 'month') {
      const start = startOfWeek(startOfMonth(cursor), { weekStartsOn: 0 });
      const end = endOfWeek(endOfMonth(cursor), { weekStartsOn: 0 });
      const allDays = eachDayOfInterval({ start, end });
      return {
        days: allDays,
        rangeFrom: formatDate(start),
        rangeTo: formatDate(end),
        headerLabel: format(cursor, 'yyyy년 M월', { locale: ko }),
        inMonthDates: new Set(
          allDays.filter((d) => d.getMonth() === cursor.getMonth()).map(formatDate)
        ),
      };
    } else {
      const start = startOfWeek(cursor, { weekStartsOn: 0 });
      const end = endOfWeek(cursor, { weekStartsOn: 0 });
      const allDays = eachDayOfInterval({ start, end });
      return {
        days: allDays,
        rangeFrom: formatDate(start),
        rangeTo: formatDate(end),
        headerLabel: start.getMonth() === end.getMonth()
          ? `${format(start, 'M월 d일', { locale: ko })} – ${format(end, 'd일')}`
          : `${format(start, 'M월 d일', { locale: ko })} – ${format(end, 'M월 d일', { locale: ko })}`,
        inMonthDates: new Set(allDays.map(formatDate)),
      };
    }
  }, [cursor, viewMode]);

  // ── 세션 인덱스 ───────────────────────────────────────────────────────────
  const sessionsByDate = useMemo(() => {
    const map = new Map<string, CalendarSession[]>();
    for (const s of optimisticSessions) {
      const existing = map.get(s.session_date) ?? [];
      existing.push(s);
      map.set(s.session_date, existing);
    }
    return map;
  }, [optimisticSessions]);

  // ── 내비게이션 ────────────────────────────────────────────────────────────
  function navigateDir(direction: 'prev' | 'next') {
    setCursor((prev) => {
      const next = viewMode === 'month'
        ? (direction === 'prev' ? subMonths(prev, 1) : addMonths(prev, 1))
        : (direction === 'prev' ? subWeeks(prev, 1) : addWeeks(prev, 1));
      const newStart = viewMode === 'month'
        ? startOfWeek(startOfMonth(next), { weekStartsOn: 0 })
        : startOfWeek(next, { weekStartsOn: 0 });
      const newEnd = viewMode === 'month'
        ? endOfWeek(endOfMonth(next), { weekStartsOn: 0 })
        : endOfWeek(next, { weekStartsOn: 0 });
      onRangeChange(formatDate(newStart), formatDate(newEnd));
      return next;
    });
  }

  function handleViewModeChange(mode: ViewMode) {
    setViewMode(mode);
    onViewModeChange?.(mode);
    const newStart = mode === 'month'
      ? startOfWeek(startOfMonth(cursor), { weekStartsOn: 0 })
      : startOfWeek(cursor, { weekStartsOn: 0 });
    const newEnd = mode === 'month'
      ? endOfWeek(endOfMonth(cursor), { weekStartsOn: 0 })
      : endOfWeek(cursor, { weekStartsOn: 0 });
    onRangeChange(formatDate(newStart), formatDate(newEnd));
  }

  function goToday() {
    const today = new Date();
    setCursor(today);
    const newStart = viewMode === 'month'
      ? startOfWeek(startOfMonth(today), { weekStartsOn: 0 })
      : startOfWeek(today, { weekStartsOn: 0 });
    const newEnd = viewMode === 'month'
      ? endOfWeek(endOfMonth(today), { weekStartsOn: 0 })
      : endOfWeek(today, { weekStartsOn: 0 });
    onRangeChange(formatDate(newStart), formatDate(newEnd));
  }

  // ── 드래그 핸들러 ─────────────────────────────────────────────────────────
  const handleDragStart = useCallback((event: DragStartEvent) => {
    const s = optimisticSessions.find((s) => s.id === event.active.id);
    setActiveSession(s ?? null);
  }, [optimisticSessions]);

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    setActiveSession(null);
    const { active, over } = event;
    if (!over) return;

    const targetDate = over.id as string;
    if (!inMonthDates.has(targetDate)) return;

    const session = optimisticSessions.find((s) => s.id === active.id);
    if (!session || session.session_date === targetDate) return;

    const prevDate = session.session_date;
    setOptimisticSessions((prev) =>
      prev.map((s) => s.id === session.id ? { ...s, session_date: targetDate } : s)
    );

    window.api.sessions.updateDate(session.id, targetDate).then(() => {
      onSessionMoved?.(session.id, targetDate);
    }).catch((e) => {
      console.error('[Calendar] updateDate', e);
      setOptimisticSessions((prev) =>
        prev.map((s) => s.id === session.id ? { ...s, session_date: prevDate } : s)
      );
    });
  }, [optimisticSessions, inMonthDates, onSessionMoved]);

  // ── 시간/날짜 업데이트 ────────────────────────────────────────────────────
  const handleTimeUpdate = useCallback((sessionId: number, time: string | null) => {
    setOptimisticSessions((prev) =>
      prev.map((s) => s.id === sessionId ? { ...s, appointment_time: time ?? undefined } : s)
    );
    onTimeUpdate?.(sessionId, time);
    window.api.sessions.update(sessionId, { appointment_time: time }).catch((e) => {
      console.error('[Calendar] time update', e);
      setOptimisticSessions(sessions);
    });
  }, [sessions, onTimeUpdate]);

  const handleDateUpdate = useCallback((sessionId: number, newDate: string) => {
    const session = optimisticSessions.find((s) => s.id === sessionId);
    if (!session || session.session_date === newDate) return;
    const prevDate = session.session_date;
    setOptimisticSessions((prev) =>
      prev.map((s) => s.id === sessionId ? { ...s, session_date: newDate } : s)
    );
    window.api.sessions.updateDate(sessionId, newDate).then(() => {
      onSessionMoved?.(sessionId, newDate);
    }).catch((e) => {
      console.error('[Calendar] updateDate', e);
      setOptimisticSessions((prev) =>
        prev.map((s) => s.id === sessionId ? { ...s, session_date: prevDate } : s)
      );
    });
  }, [optimisticSessions, onSessionMoved]);

  function resolveHolidayName(dateStr: string): string | undefined {
    return dynamicHolidays[dateStr] ?? getHolidayName(dateStr);
  }

  // suppress unused warning (used in memo above)
  void rangeFrom; void rangeTo;

  // ── 렌더 ─────────────────────────────────────────────────────────────────
  return (
    <DndContext sensors={sensors} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
      <div className="flex flex-col gap-0">
        {/* 헤더 */}
        <div className="flex items-center justify-between px-1 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigateDir('prev')}
              className="rounded-md p-1.5 hover:bg-secondary text-muted-foreground transition-colors"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="text-[1rem] font-semibold text-foreground min-w-[120px] text-center">
              {headerLabel}
            </span>
            <button
              onClick={() => navigateDir('next')}
              className="rounded-md p-1.5 hover:bg-secondary text-muted-foreground transition-colors"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
            <Button variant="outline" size="sm" className="ml-2 h-7 text-xs" onClick={goToday}>
              오늘
            </Button>
          </div>

          {/* 뷰 토글 탭 */}
          <DndContext
            sensors={tabSensors}
            collisionDetection={closestCenter}
            onDragEnd={(e) => {
              const { active, over } = e;
              if (!over || active.id === over.id) return;
              setTabOrder((prev) => {
                const oldIdx = prev.indexOf(active.id as ViewMode);
                const newIdx = prev.indexOf(over.id as ViewMode);
                const next = arrayMove(prev, oldIdx, newIdx);
                handleViewModeChange(next[0]);
                return next;
              });
            }}
          >
            <SortableContext items={tabOrder} strategy={horizontalListSortingStrategy}>
              <div className="flex items-center gap-1 rounded-lg border border-border bg-secondary p-0.5">
                {tabOrder.map((mode) => (
                  <SortableTab
                    key={mode}
                    mode={mode}
                    isActive={viewMode === mode}
                    onClick={() => handleViewModeChange(mode)}
                  />
                ))}
              </div>
            </SortableContext>
          </DndContext>
        </div>

        {/* 요일 헤더 */}
        <div className="grid grid-cols-7 border-t border-border">
          {DOW_LABELS.map((d, i) => (
            <div
              key={d}
              className={cn(
                'py-2 text-center text-[0.75rem] font-medium',
                i === 0 ? 'text-red-500' : i === 6 ? 'text-blue-500' : 'text-muted-foreground'
              )}
            >
              {d}
            </div>
          ))}
        </div>

        {/* 날짜 그리드 */}
        {viewMode === 'month' ? (
          <MonthGrid
            days={days}
            cursor={cursor}
            sessionsByDate={sessionsByDate}
            inMonthDates={inMonthDates}
            draggingId={activeSession?.id ?? null}
            onSessionClick={(s) => navigate(`/cases/${s.case_id}/sessions/${s.id}`, { state: { from: 'calendar' } })}
            onDateClick={(d) => onDateClick?.(d)}
            onAddSession={onAddSession}
            onDateUpdate={handleDateUpdate}
            onTimeUpdate={handleTimeUpdate}
            getHolidayName={resolveHolidayName}
            getSchoolEventName={(d) => resolveHolidayName(d) ? undefined : schoolEvents[d]}
          />
        ) : (
          <WeekGrid
            days={days}
            sessionsByDate={sessionsByDate}
            inMonthDates={inMonthDates}
            draggingId={activeSession?.id ?? null}
            onSessionClick={(s) => navigate(`/cases/${s.case_id}/sessions/${s.id}`, { state: { from: 'calendar' } })}
            onDateClick={(d) => onDateClick?.(d)}
            onAddSession={onAddSession}
            onDateUpdate={handleDateUpdate}
            onTimeUpdate={handleTimeUpdate}
            getHolidayName={resolveHolidayName}
            getSchoolEventName={(d) => resolveHolidayName(d) ? undefined : schoolEvents[d]}
          />
        )}
      </div>

      {/* 드래그 오버레이 */}
      <DragOverlay dropAnimation={null}>
        {activeSession ? (
          <SessionPill session={activeSession} onClick={() => {}} compact={viewMode === 'month'} isDragging />
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}
