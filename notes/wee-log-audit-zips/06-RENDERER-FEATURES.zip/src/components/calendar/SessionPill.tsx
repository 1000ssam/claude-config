import { useState } from 'react';
import { useDraggable } from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import { ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Popover, PopoverTrigger, PopoverContent } from '@/components/ui/popover';
import { DateTimePickerContent } from '@/components/ui/date-time-picker';
import { cn } from '@/lib/utils';
import type { CalendarSession } from '../../../../lib/queries/calendar';

const PILL_COLOR = 'bg-transparent text-foreground border-border/50 shadow-[0_1px_2px_rgba(0,0,0,0.04)]';

const CATEGORY_COLORS: Record<string, string> = {
  '심리·정서': PILL_COLOR,
  '학교폭력': PILL_COLOR,
  '진로·학업': PILL_COLOR,
  '가족': PILL_COLOR,
  '위기': PILL_COLOR,
  '복지': PILL_COLOR,
  default: PILL_COLOR,
};

export function getCategoryColor(category: string): string {
  for (const [key, val] of Object.entries(CATEGORY_COLORS)) {
    if (category?.includes(key)) return val;
  }
  return CATEGORY_COLORS.default;
}

// ── 세션 필 ───────────────────────────────────────────────────────────────────

interface SessionPillProps {
  session: CalendarSession;
  onClick: () => void;
  compact: boolean;
  isDragging?: boolean;
  onDateUpdate?: (sessionId: number, newDate: string) => void;
  onTimeUpdate?: (sessionId: number, time: string | null) => void;
}

export function SessionPill({ session, onClick, compact, isDragging, onDateUpdate, onTimeUpdate }: SessionPillProps) {
  const [open, setOpen] = useState(false);
  const color = getCategoryColor(session.category_large);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          title={`${session.appointment_time ? session.appointment_time + ' ' : ''}${session.student_names}`}
          className={cn(
            'w-full rounded border text-left transition-opacity hover:opacity-80 active:opacity-60',
            compact ? 'px-1.5 py-0.5' : 'px-2 py-1',
            color,
            isDragging && 'shadow-lg rotate-1 scale-105',
          )}
        >
          <div className={cn('font-medium truncate', compact ? 'text-[0.6875rem]' : 'text-[0.75rem]')}>
            {session.appointment_time && (
              <span className="mr-1 opacity-70">{session.appointment_time}</span>
            )}
            {session.student_names}
          </div>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <div className="flex items-center justify-between px-3 pt-2.5 pb-2 border-b">
          <p className="text-sm font-medium truncate max-w-[180px]">{session.student_names}</p>
          <Button
            size="sm"
            variant="ghost"
            className="h-6 px-2 text-xs ml-2 shrink-0 text-muted-foreground hover:text-foreground"
            onClick={() => { setOpen(false); onClick(); }}
          >
            <ExternalLink className="h-3 w-3 mr-1" />
            상세
          </Button>
        </div>
        <DateTimePickerContent
          date={session.session_date}
          time={session.appointment_time ?? null}
          onDateChange={(d) => onDateUpdate?.(session.id, d)}
          onTimeChange={(t) => onTimeUpdate?.(session.id, t)}
        />
      </PopoverContent>
    </Popover>
  );
}

// ── Draggable 세션 필 ─────────────────────────────────────────────────────────

interface DraggableSessionPillProps {
  session: CalendarSession;
  onClick: () => void;
  compact: boolean;
  isDraggingThis: boolean;
  onDateUpdate?: (sessionId: number, newDate: string) => void;
  onTimeUpdate?: (sessionId: number, time: string | null) => void;
}

export function DraggableSessionPill({ session, onClick, compact, isDraggingThis, onDateUpdate, onTimeUpdate }: DraggableSessionPillProps) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: session.id,
  });

  const style = transform
    ? { transform: CSS.Translate.toString(transform) }
    : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={cn(isDragging || isDraggingThis ? 'opacity-40' : '')}
    >
      <SessionPill session={session} onClick={onClick} compact={compact} onDateUpdate={onDateUpdate} onTimeUpdate={onTimeUpdate} />
    </div>
  );
}
