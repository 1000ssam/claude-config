import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { CalendarDays, AlignJustify } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { ViewMode } from './calendar-types';

export const TAB_CONFIG: Record<ViewMode, { icon: typeof CalendarDays; label: string }> = {
  month: { icon: CalendarDays, label: '월간' },
  week: { icon: AlignJustify, label: '주간' },
};

interface SortableTabProps {
  mode: ViewMode;
  isActive: boolean;
  onClick: () => void;
}

export function SortableTab({ mode, isActive, onClick }: SortableTabProps) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: mode });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };
  const cfg = TAB_CONFIG[mode];
  return (
    <button
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      onClick={onClick}
      className={cn(
        'flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-medium transition-colors cursor-grab active:cursor-grabbing',
        isActive
          ? 'bg-background text-foreground shadow-sm'
          : 'text-muted-foreground hover:text-foreground'
      )}
    >
      <cfg.icon className="h-3.5 w-3.5" />
      {cfg.label}
    </button>
  );
}
