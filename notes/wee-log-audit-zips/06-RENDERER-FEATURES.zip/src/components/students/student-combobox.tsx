import { useState, useEffect, useRef, KeyboardEvent } from 'react';
import { Search, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { formatStudentCompact } from '@/lib/format-student';
import type { StudentWithEnrollment } from '@/types/student';

interface StudentComboboxProps {
  onSelect: (student: StudentWithEnrollment) => void;
  onClear: () => void;
  selectedStudent: StudentWithEnrollment | null;
}

export function StudentCombobox({ onSelect, onClear, selectedStudent }: StudentComboboxProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<StudentWithEnrollment[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [highlightIndex, setHighlightIndex] = useState(-1);
  const [loading, setLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Debounced search
  useEffect(() => {
    if (!query || query.trim().length === 0) {
      setResults([]);
      setIsOpen(false);
      return;
    }

    setLoading(true);
    const timer = setTimeout(async () => {
      try {
        const data = await window.api.students.search(query.trim());
        setResults(data);
        setIsOpen(true);
        setHighlightIndex(-1);
      } catch (error) {
        console.error('Failed to search students:', error);
        setResults([]);
      } finally {
        setLoading(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [query]);

  // Click outside to close
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  function handleSelect(student: Student) {
    onSelect(student);
    setQuery('');
    setResults([]);
    setIsOpen(false);
  }

  function handleClear() {
    onClear();
    setQuery('');
    setResults([]);
    setIsOpen(false);
    inputRef.current?.focus();
  }

  function handleKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (!isOpen || results.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightIndex(prev => (prev < results.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightIndex(prev => (prev > 0 ? prev - 1 : -1));
    } else if (e.key === 'Enter' && highlightIndex >= 0) {
      e.preventDefault();
      handleSelect(results[highlightIndex]);
    } else if (e.key === 'Escape') {
      setIsOpen(false);
      setHighlightIndex(-1);
    }
  }


  if (selectedStudent) {
    return (
      <div className="relative">
        <label className="block text-sm font-medium mb-1.5">기존 학생 검색</label>
        <div className="flex gap-2">
          <Input
            value={formatStudentCompact(selectedStudent)}
            readOnly
            className="flex-1 bg-muted cursor-not-allowed"
          />
          <button
            type="button"
            onClick={handleClear}
            className="px-3 py-2 rounded-md border border-input bg-background hover:bg-accent hover:text-accent-foreground"
            title="선택 해제"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          학생 정보가 자동으로 입력되었습니다. 필요시 아래에서 수정 가능합니다.
        </p>
      </div>
    );
  }

  return (
    <div ref={containerRef} className="relative">
      <label className="block text-sm font-medium mb-1.5">기존 학생 검색 (선택사항)</label>
      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          ref={inputRef}
          type="text"
          placeholder="학생 이름으로 검색..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          className="pl-10"
        />
      </div>

      {isOpen && (
        <div className="absolute z-50 w-full mt-1 rounded-md border bg-popover text-popover-foreground shadow-md max-h-60 overflow-y-auto">
          {loading ? (
            <div className="px-3 py-2 text-sm text-muted-foreground">검색 중...</div>
          ) : results.length === 0 ? (
            <div className="px-3 py-2 text-sm text-muted-foreground">
              일치하는 학생이 없습니다. 아래에서 직접 입력하세요.
            </div>
          ) : (
            <ul>
              {results.map((student, index) => (
                <li
                  key={student.id}
                  className={`px-3 py-2 text-sm cursor-pointer ${
                    index === highlightIndex ? 'bg-accent text-accent-foreground' : 'hover:bg-accent hover:text-accent-foreground'
                  }`}
                  onClick={() => handleSelect(student)}
                  onMouseEnter={() => setHighlightIndex(index)}
                >
                  {formatStudentCompact(student)}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <p className="text-xs text-muted-foreground mt-1">
        이전에 등록한 학생이면 검색하여 선택하세요. 없으면 아래에서 직접 입력하세요.
      </p>
    </div>
  );
}
