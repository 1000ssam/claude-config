import { useState } from 'react';
import { Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import type { ExcelStudentRow, ExcelUploadResult } from '@/types/student';

export interface UploadPreview {
  academicYear: string;
  grade: string;
  rowCount: number;
  filePath: string;
  sampleRows: ExcelStudentRow[];
}

interface StudentUploadDialogProps {
  open: boolean;
  preview: UploadPreview | null;
  onClose: () => void;
  /** 업로드 완료 후 호출. 새 학년도 목록과 선택된 학년도를 반환. */
  onSuccess: (newYears: string[], pickedYear: string) => void;
}

export function StudentUploadDialog({ open, preview, onClose, onSuccess }: StudentUploadDialogProps) {
  const { addToast } = useToast();
  const [uploadResult, setUploadResult] = useState<ExcelUploadResult | null>(null);
  const [uploading, setUploading] = useState(false);
  const [checkedCreated, setCheckedCreated] = useState<Set<number>>(new Set());
  const [checkedMissing, setCheckedMissing] = useState<Set<number>>(new Set());
  const [deletingChecked, setDeletingChecked] = useState(false);

  function handleOpenChange(o: boolean) {
    if (!o) {
      setUploadResult(null);
      setCheckedCreated(new Set());
      setCheckedMissing(new Set());
      onClose();
    }
  }

  async function handleConfirmUpload() {
    if (!preview) return;
    setUploading(true);
    try {
      const res = await window.api.students.confirmUpload(preview.filePath);
      if (!res.success) {
        addToast({ title: res.message || '업로드 실패', variant: 'destructive' });
        return;
      }
      setUploadResult(res.result!);
      setCheckedCreated(new Set());
      setCheckedMissing(new Set());
      const years = await window.api.enrollments.years();
      onSuccess(years, res.result!.academic_year);
    } catch {
      addToast({ title: '업로드 처리 중 오류 발생', variant: 'destructive' });
    } finally {
      setUploading(false);
    }
  }

  async function handleDeleteChecked() {
    const ids = [...checkedCreated, ...checkedMissing];
    if (ids.length === 0) return;
    setDeletingChecked(true);
    try {
      for (const id of ids) {
        await window.api.students.delete(id);
      }
      addToast({ title: `${ids.length}명 삭제 완료`, variant: 'success' });
      if (uploadResult) {
        setUploadResult({
          ...uploadResult,
          createdStudents: uploadResult.createdStudents.filter((s) => !checkedCreated.has(s.student_id)),
          missingStudents: uploadResult.missingStudents.filter((s) => !checkedMissing.has(s.student_id)),
        });
      }
      setCheckedCreated(new Set());
      setCheckedMissing(new Set());
    } catch {
      addToast({ title: '삭제 중 오류 발생', variant: 'destructive' });
    } finally {
      setDeletingChecked(false);
    }
  }

  function toggleChecked(set: Set<number>, setFn: (s: Set<number>) => void, id: number, checked: boolean) {
    const next = new Set(set);
    if (checked) next.add(id); else next.delete(id);
    setFn(next);
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[560px]">
        <DialogHeader>
          <DialogTitle>반배정 파일 업로드</DialogTitle>
          <DialogDescription>
            NEIS에서 내보낸 반배정 엑셀 파일을 업로드합니다.
          </DialogDescription>
        </DialogHeader>

        {uploadResult ? (
          <div className="space-y-3 max-h-[70vh] overflow-y-auto">
            <p className="text-sm text-muted-foreground">{uploadResult.academic_year}학년도 · {uploadResult.total_rows}명 처리 완료</p>
            <div className="grid grid-cols-3 gap-3 text-center">
              <Card><CardContent className="pt-4 pb-3">
                <p className="text-2xl font-bold text-green-600">{uploadResult.created}</p>
                <p className="text-xs text-muted-foreground">신규 등록</p>
              </CardContent></Card>
              <Card><CardContent className="pt-4 pb-3">
                <p className="text-2xl font-bold text-blue-600">{uploadResult.updated}</p>
                <p className="text-xs text-muted-foreground">학적 갱신</p>
              </CardContent></Card>
              <Card><CardContent className="pt-4 pb-3">
                <p className="text-2xl font-bold text-gray-400">{uploadResult.skipped}</p>
                <p className="text-xs text-muted-foreground">스킵</p>
              </CardContent></Card>
            </div>

            {uploadResult.createdStudents.length > 0 && (
              <div className="space-y-1.5">
                <p className="text-sm font-medium text-amber-700">매칭 실패 → 신규 생성 ({uploadResult.createdStudents.length}명)</p>
                <p className="text-xs text-muted-foreground">기존 학생의 개명/오타일 수 있습니다. 확인 후 불필요한 항목을 선택하여 삭제하세요.</p>
                <div className="border rounded max-h-36 overflow-y-auto divide-y">
                  {uploadResult.createdStudents.map((s) => (
                    <label key={s.student_id} className="flex items-center gap-2.5 px-3 py-2 text-sm cursor-pointer hover:bg-muted/50">
                      <Checkbox
                        checked={checkedCreated.has(s.student_id)}
                        onCheckedChange={(c) => toggleChecked(checkedCreated, setCheckedCreated, s.student_id, !!c)}
                      />
                      <span className="font-medium">{s.name}</span>
                      <span className="text-xs text-muted-foreground">{s.grade}-{s.class_name}-{s.number}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {uploadResult.missingStudents.length > 0 && (
              <div className="space-y-1.5">
                <p className="text-sm font-medium text-orange-700">전년도 재학 → 올해 파일 누락 ({uploadResult.missingStudents.length}명)</p>
                <p className="text-xs text-muted-foreground">전학/자퇴/졸업 등으로 올해 반배정에 없는 학생입니다. 확인 후 삭제할 수 있습니다.</p>
                <div className="border rounded max-h-36 overflow-y-auto divide-y">
                  {uploadResult.missingStudents.map((s) => (
                    <label key={s.student_id} className="flex items-center gap-2.5 px-3 py-2 text-sm cursor-pointer hover:bg-muted/50">
                      <Checkbox
                        checked={checkedMissing.has(s.student_id)}
                        onCheckedChange={(c) => toggleChecked(checkedMissing, setCheckedMissing, s.student_id, !!c)}
                      />
                      <span className="font-medium">{s.name}</span>
                      <span className="text-xs text-muted-foreground">{s.grade}-{s.class_name}-{s.number} (전년도)</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {uploadResult.errors.length > 0 && (
              <div className="text-sm text-destructive bg-destructive/10 rounded p-3 max-h-32 overflow-y-auto">
                {uploadResult.errors.map((e, i) => <p key={i}>{e}</p>)}
              </div>
            )}

            <DialogFooter className="gap-2">
              {(checkedCreated.size + checkedMissing.size) > 0 && (
                <Button variant="destructive" size="sm" onClick={handleDeleteChecked} disabled={deletingChecked}>
                  <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                  {deletingChecked ? '삭제 중...' : `선택 ${checkedCreated.size + checkedMissing.size}명 삭제`}
                </Button>
              )}
              <Button onClick={() => { setUploadResult(null); onClose(); }}>
                확인
              </Button>
            </DialogFooter>
          </div>
        ) : preview ? (
          <div className="space-y-3">
            <div className="flex gap-4 text-sm">
              <span>학년도: <strong>{preview.academicYear}</strong></span>
              {preview.grade && <span>학년: <strong>{preview.grade}</strong></span>}
              <span>학생 수: <strong>{preview.rowCount}명</strong></span>
            </div>
            <div className="border rounded max-h-[50vh] overflow-y-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 sticky top-0">
                  <tr>
                    <th className="px-3 py-1.5 text-left font-medium">이름</th>
                    <th className="px-3 py-1.5 text-left font-medium">학년-반-번</th>
                    <th className="px-3 py-1.5 text-left font-medium">성별</th>
                    <th className="px-3 py-1.5 text-left font-medium">이전학적</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {preview.sampleRows.map((r, i) => (
                    <tr key={i}>
                      <td className="px-3 py-1.5">{r.name}</td>
                      <td className="px-3 py-1.5">{r.grade}-{r.class_name}-{r.number}</td>
                      <td className="px-3 py-1.5">{r.gender}</td>
                      <td className="px-3 py-1.5 text-muted-foreground">
                        {r.prev_grade ? `${r.prev_grade}-${r.prev_class_name}-${r.prev_number}` : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={onClose}>취소</Button>
              <Button onClick={handleConfirmUpload} disabled={uploading}>
                {uploading ? '처리 중...' : `${preview.rowCount}명 업로드`}
              </Button>
            </DialogFooter>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
