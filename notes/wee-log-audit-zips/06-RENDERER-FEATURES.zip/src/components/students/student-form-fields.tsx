import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { GRADE_OPTIONS, GUARDIAN_RELATION_OPTIONS } from '@/lib/constants/options';
import type { useStudentForm } from '@/hooks/use-student-form';

/** 학생 폼에서 노출할 학년 선택지(‘해당없음’·‘혼합’ 제외 — 개별 학생은 단일 학년). */
const STUDENT_GRADE_OPTIONS = GRADE_OPTIONS.filter((g) => g !== '해당없음' && g !== '혼합');

type StudentFormHook = ReturnType<typeof useStudentForm>;

interface StudentFormFieldsProps {
  /** `useStudentForm()` 반환값 (폼 상태 + `updateField`). */
  hook: StudentFormHook;
  /**
   * 라벨/인풋 `id` 충돌 방지용 접두사. 같은 화면에 폼이 여러 개일 수 있으므로
   * 호출부마다 고유값을 준다(예: `'create'`, `'edit'`, `'detail-edit'`).
   */
  idPrefix: string;
  /**
   * 학적 필드(학년·반·번호) 노출 여부. 기본 `true`.
   * 학적은 학년도별(enrollment) 데이터라, 학생 레코드 자체만 수정하는
   * 상세 페이지 편집에서는 `false`로 숨긴다.
   */
  showEnrollmentFields?: boolean;
}

/**
 * 학생 등록/수정 공용 폼 필드 그리드.
 *
 * 등록 다이얼로그·수정 다이얼로그(StudentsPage)·상세 페이지 편집(StudentDetailPage)이
 * 동일한 필드를 공유한다. `<form>` 래퍼·제출 버튼·제출 핸들러는 각 호출부가 소유한다
 * (등록/수정/상세의 제출 동작·라벨·로딩 상태가 서로 다르므로).
 */
export function StudentFormFields({
  hook,
  idPrefix,
  showEnrollmentFields = true,
}: StudentFormFieldsProps) {
  const { form, updateField } = hook;
  // 보호자명이 없으면 관계·연락처는 저장되지 않으므로(이름 없는 보호자=미등록) 비활성 처리해 시그널.
  const noGuardianName = !form.guardian_name?.trim();
  return (
    <div className="grid gap-3 grid-cols-2">
      <div className="space-y-1.5 col-span-2">
        <Label htmlFor={`${idPrefix}-name`}>이름 *</Label>
        <Input
          id={`${idPrefix}-name`}
          value={form.name || ''}
          onChange={(e) => updateField('name', e.target.value)}
          placeholder="학생 이름"
          autoFocus
        />
      </div>
      {showEnrollmentFields && (
        <>
          <div className="space-y-1.5">
            <Label htmlFor={`${idPrefix}-grade`}>학년</Label>
            <Select
              value={form.grade || ''}
              onValueChange={(v) => updateField('grade', v)}
            >
              <SelectTrigger id={`${idPrefix}-grade`}>
                <SelectValue placeholder="학년 선택" />
              </SelectTrigger>
              <SelectContent>
                {STUDENT_GRADE_OPTIONS.map((g) => (
                  <SelectItem key={g} value={g}>{g}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor={`${idPrefix}-class`}>반</Label>
            <Input
              id={`${idPrefix}-class`}
              value={form.class_name || ''}
              onChange={(e) => updateField('class_name', e.target.value)}
              placeholder="예: 3"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor={`${idPrefix}-number`}>번호</Label>
            <Input
              id={`${idPrefix}-number`}
              value={form.number || ''}
              onChange={(e) => updateField('number', e.target.value)}
              placeholder="예: 15"
            />
          </div>
        </>
      )}
      <div className="space-y-1.5">
        <Label htmlFor={`${idPrefix}-gender`}>성별</Label>
        <Select
          value={form.gender || ''}
          onValueChange={(v) => updateField('gender', v)}
        >
          <SelectTrigger id={`${idPrefix}-gender`}>
            <SelectValue placeholder="성별 선택" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="남">남</SelectItem>
            <SelectItem value="여">여</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-1.5 col-span-2">
        <Label htmlFor={`${idPrefix}-contact`}>연락처</Label>
        <Input
          id={`${idPrefix}-contact`}
          value={form.contact || ''}
          onChange={(e) => updateField('contact', e.target.value)}
          placeholder="010-0000-0000"
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor={`${idPrefix}-guardian-name`}>보호자명</Label>
        <Input
          id={`${idPrefix}-guardian-name`}
          value={form.guardian_name || ''}
          onChange={(e) => updateField('guardian_name', e.target.value)}
          placeholder="보호자 이름"
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor={`${idPrefix}-guardian-relation`} className={cn(noGuardianName && 'text-muted-foreground')}>관계</Label>
        <Select
          value={form.guardian_relation || ''}
          onValueChange={(v) => updateField('guardian_relation', v)}
          disabled={noGuardianName}
        >
          <SelectTrigger id={`${idPrefix}-guardian-relation`}>
            <SelectValue placeholder="관계 선택" />
          </SelectTrigger>
          <SelectContent>
            {GUARDIAN_RELATION_OPTIONS.map((r) => (
              <SelectItem key={r} value={r}>{r}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-1.5 col-span-2">
        <Label htmlFor={`${idPrefix}-guardian-contact`} className={cn(noGuardianName && 'text-muted-foreground')}>보호자 연락처</Label>
        <Input
          id={`${idPrefix}-guardian-contact`}
          value={form.guardian_contact || ''}
          onChange={(e) => updateField('guardian_contact', e.target.value)}
          placeholder="010-0000-0000"
          disabled={noGuardianName}
        />
        {noGuardianName && (form.guardian_relation || form.guardian_contact) && (
          <p className="text-xs text-muted-foreground">
            보호자명을 입력해야 관계·연락처가 저장됩니다.
          </p>
        )}
      </div>
    </div>
  );
}
