// STT 워커 생명주기 관리 (메인 프로세스에서 실행).
// - utilityProcess.fork 로 워커를 띄움
// - 워커 ready 전까지 메시지 큐잉
// - 메인 ↔ 워커 메시지 릴레이

import { utilityProcess, type UtilityProcess } from 'electron';
import path from 'path';

import type { SttWorkerRequest, SttWorkerResponse } from './stt-types';

export type SttWorkerListener = (msg: SttWorkerResponse) => void;

export class SttHost {
  private worker: UtilityProcess | null = null;
  private workerReady = false;
  private workerPath: string;
  private queue: SttWorkerRequest[] = [];
  private listeners = new Set<SttWorkerListener>();
  private exitHandler: (() => void) | null = null;

  constructor(workerPath: string) {
    this.workerPath = workerPath;
  }

  start(): void {
    if (this.worker) return;
    this.workerReady = false;

    this.worker = utilityProcess.fork(this.workerPath, [], {
      serviceName: 'wee-log-stt-worker',
      stdio: 'pipe',
    });

    this.worker.stdout?.on('data', (data: Buffer) => {
      process.stdout.write(`[stt-worker] ${data}`);
    });
    this.worker.stderr?.on('data', (data: Buffer) => {
      process.stderr.write(`[stt-worker ERR] ${data}`);
    });

    this.worker.on('message', (msg: SttWorkerResponse) => {
      if (msg.type === 'ready') {
        this.workerReady = true;
        // 큐잉된 메시지 전송
        for (const req of this.queue) this.worker?.postMessage(req);
        this.queue = [];
      }
      for (const l of this.listeners) l(msg);
    });

    this.worker.on('exit', (code) => {
      this.workerReady = false;
      this.worker = null;
      this.queue = [];
      this.exitHandler?.();
      if (code !== 0) {
        for (const l of this.listeners) {
          l({ type: 'error', message: `STT 워커가 비정상 종료 (code=${code})` });
        }
      }
    });
  }

  send(req: SttWorkerRequest): void {
    if (!this.worker) this.start();
    if (this.workerReady && this.worker) {
      this.worker.postMessage(req);
    } else {
      this.queue.push(req);
    }
  }

  onMessage(listener: SttWorkerListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  onExit(handler: () => void): void {
    this.exitHandler = handler;
  }

  stop(): void {
    if (!this.worker) return;
    this.send({ type: 'dispose' });
    // 워커가 dispose 처리 후 자체 exit
    setTimeout(() => {
      try { this.worker?.kill(); } catch { /* noop */ }
      this.worker = null;
      this.workerReady = false;
    }, 1500);
  }

  isReady(): boolean {
    return this.workerReady;
  }
}

/**
 * 메인 프로세스에서 stt-worker.js 파일 경로 결정.
 * - electron-vite 가 out/main/stt-worker.js 로 빌드한다고 가정
 */
export function resolveSttWorkerPath(): string {
  return path.join(__dirname, 'stt-worker.js');
}
