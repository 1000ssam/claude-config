// STT 서비스 (메인 프로세스 싱글톤).
// - 워커 생명주기, 모델 다운로드, 전사 요청 큐를 통합 관리
// - 외부에는 EventEmitter('stt-event') 로 상태 푸시
// - IPC 핸들러(electron/main.ts)에서 이 모듈의 sttService() 를 호출

import { app } from 'electron';
import { EventEmitter } from 'events';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { randomUUID } from 'crypto';

import { getSetting, updateSettings } from '@/lib/queries/settings';
import {
  STT_MODEL_INFO,
  type SttDownloadStartResult,
  type SttEvent,
  type SttModelId,
  type SttModelStatus,
  type SttServiceState,
  type SttStatus,
  type SttTranscribePayload,
  type SttWorkerResponse,
} from './stt-types';
import {
  cancelStttModelDownload,
  getActiveStttDownload,
  getInstalledStttModelStatus,
  getStttModelPath,
  isStttModelInstalled,
  startStttModelDownload,
} from './stt-model-manager';
import { SttHost, resolveSttWorkerPath } from './stt-host';

const DEFAULT_MODEL: SttModelId = 'ggml-small-q5_1';

// 사용자가 명시적으로 설정 안 한 경우 기본값 — settings 디폴트와 일치해야 함
const FALLBACK_SETTINGS = {
  stt_enabled: '1',
  stt_engine: 'whisper-cli',
  stt_model: DEFAULT_MODEL,
  stt_language: 'ko',
} as const;

class SttService extends EventEmitter {
  private host: SttHost | null = null;
  private hostListener: (() => void) | null = null;
  private serviceState: SttServiceState = 'idle';
  private serviceMessage: string | undefined;
  private modelStatus: SttModelStatus = { id: DEFAULT_MODEL, state: 'absent' };
  private configured = false;
  private configuredModelId: SttModelId | null = null;
  private configurePromise: Promise<void> | null = null;

  /* ───── public API ────────────────────────────────────────────────── */

  getStatus(): SttStatus {
    const enabled = readSetting('stt_enabled') === '1';
    const engine = (readSetting('stt_engine') as 'whisper-cli');
    const modelId = (readSetting('stt_model') as SttModelId) || DEFAULT_MODEL;
    const modelStatus = this.modelStatus.id === modelId
      ? this.modelStatus
      : getInstalledStttModelStatus(modelId);

    return {
      enabled,
      engine,
      model: modelStatus,
      serviceState: enabled ? this.serviceState : 'disabled',
      binaryAvailable: isBinaryAvailable(),
      errorMessage: this.serviceMessage,
    };
  }

  refreshModelStatus(): SttModelStatus {
    const modelId = (readSetting('stt_model') as SttModelId) || DEFAULT_MODEL;
    this.modelStatus = getInstalledStttModelStatus(modelId);
    this.emitEvent({ type: 'model-state', status: this.modelStatus });
    return this.modelStatus;
  }

  /**
   * 현재 선택된 모델을 다운로드 시작.
   * 이미 다른 다운로드 진행 중이면 started=false.
   */
  startDownload(): SttDownloadStartResult {
    if (getActiveStttDownload()) {
      return { started: false, reason: '이미 다운로드가 진행 중입니다.' };
    }
    const modelId = (readSetting('stt_model') as SttModelId) || DEFAULT_MODEL;
    if (isStttModelInstalled(modelId)) {
      this.modelStatus = { id: modelId, state: 'ready' };
      this.emitEvent({ type: 'model-state', status: this.modelStatus });
      return { started: false, reason: '이미 설치되어 있습니다.' };
    }

    this.modelStatus = { id: modelId, state: 'downloading', progress: 0 };
    this.emitEvent({ type: 'model-state', status: this.modelStatus });

    const handle = startStttModelDownload(modelId, {
      onProgress: (status) => {
        this.modelStatus = status;
        this.emitEvent({ type: 'model-state', status });
      },
      onComplete: (status) => {
        this.modelStatus = status;
        this.emitEvent({ type: 'model-state', status });
      },
      onError: (status) => {
        this.modelStatus = status;
        this.emitEvent({ type: 'model-state', status });
      },
    });

    if (!handle) {
      return { started: false, reason: '다운로드 시작 실패' };
    }
    return { started: true };
  }

  cancelDownload(): boolean {
    const ok = cancelStttModelDownload();
    if (ok) {
      const modelId = (readSetting('stt_model') as SttModelId) || DEFAULT_MODEL;
      this.modelStatus = { id: modelId, state: 'absent' };
      this.emitEvent({ type: 'model-state', status: this.modelStatus });
    }
    return ok;
  }

  /**
   * 오디오를 받아 전사 요청을 워커에 위임.
   * - 임시 파일로 저장 후 워커에 경로만 전달 (대용량 buffer postMessage 회피)
   * - requestId 즉시 반환, 결과는 stt:event 로 푸시
   */
  async transcribe(payload: SttTranscribePayload): Promise<{ requestId: string }> {
    if (readSetting('stt_enabled') !== '1') {
      throw new Error('STT가 비활성 상태입니다.');
    }
    if (!isBinaryAvailable()) {
      throw new Error('whisper-cli 바이너리가 설치되어 있지 않습니다.');
    }
    const modelId = (readSetting('stt_model') as SttModelId) || DEFAULT_MODEL;
    if (!isStttModelInstalled(modelId)) {
      throw new Error('STT 모델이 설치되어 있지 않습니다. 설정에서 다운로드해주세요.');
    }

    await this.ensureWorker(modelId);

    const requestId = randomUUID();
    const tempPath = await writeTempAudio(payload);

    this.setServiceState('transcribing');
    this.emitEvent({ type: 'request-state', requestId, state: 'queued' });
    this.host?.send({
      type: 'transcribe',
      requestId,
      inputAudioPath: tempPath,
      mimeType: payload.mimeType,
      language: payload.language ?? 'ko',
    });
    return { requestId };
  }

  cancel(requestId: string): boolean {
    if (!this.host) return false;
    this.host.send({ type: 'cancel', requestId });
    return true;
  }

  async dispose(): Promise<void> {
    if (this.host) {
      this.host.stop();
      this.host = null;
      this.configured = false;
      this.configuredModelId = null;
    }
    this.setServiceState('idle');
  }

  /* ───── private ───────────────────────────────────────────────────── */

  private async ensureWorker(modelId: SttModelId): Promise<void> {
    if (!this.host) {
      this.host = new SttHost(resolveSttWorkerPath());
      this.hostListener = this.host.onMessage((msg) => this.handleWorkerMessage(msg));
      this.host.onExit(() => {
        this.configured = false;
        this.configuredModelId = null;
        this.configurePromise = null;
        this.host = null;
        this.setServiceState('idle');
      });
      this.host.start();
      this.setServiceState('preparing');
    }

    if (this.configured && this.configuredModelId === modelId) {
      return;
    }

    // 동시 호출 dedupe — 이미 configure 진행 중이면 그 promise 재사용
    if (this.configurePromise) {
      return this.configurePromise;
    }

    this.configurePromise = new Promise<void>((resolve, reject) => {
      const off = this.host!.onMessage((msg) => {
        if (msg.type === 'configured') {
          this.configured = true;
          this.configuredModelId = modelId;
          this.setServiceState('ready');
          off();
          resolve();
        } else if (msg.type === 'error' && !msg.requestId) {
          off();
          this.setServiceState('error', msg.message);
          reject(new Error(msg.message));
        }
      });

      this.host!.send({
        type: 'configure',
        whisperCliPath: getWhisperCliPath(),
        ffmpegPath: getFfmpegPath(),
        modelPath: getStttModelPath(modelId),
        modelId,
      });
    });

    try {
      await this.configurePromise;
    } finally {
      this.configurePromise = null;
    }
  }

  private handleWorkerMessage(msg: SttWorkerResponse): void {
    switch (msg.type) {
      case 'state':
        this.emitEvent({
          type: 'request-state',
          requestId: msg.requestId,
          state: msg.state,
          progress: msg.progress,
        });
        break;
      case 'transcribed':
        this.emitEvent({
          type: 'transcribed',
          requestId: msg.requestId,
          result: msg.result,
        });
        this.setServiceState('ready');
        break;
      case 'cancelled':
        this.emitEvent({ type: 'request-cancelled', requestId: msg.requestId });
        this.setServiceState('ready');
        break;
      case 'error':
        if (msg.requestId) {
          this.emitEvent({
            type: 'request-error',
            requestId: msg.requestId,
            message: msg.message,
            code: msg.code,
          });
          this.setServiceState('ready');
        } else {
          this.setServiceState('error', msg.message);
        }
        break;
      case 'configured':
      case 'ready':
        // ensureWorker 안에서 별도 리스너로 처리
        break;
    }
  }

  private setServiceState(state: SttServiceState, message?: string): void {
    this.serviceState = state;
    this.serviceMessage = message;
    this.emitEvent({ type: 'service-state', state, message });
  }

  private emitEvent(evt: SttEvent): void {
    this.emit('stt-event', evt);
  }
}

let _instance: SttService | null = null;

export function sttService(): SttService {
  if (!_instance) {
    _instance = new SttService();
    // 첫 호출 시 모델 상태 초기화
    _instance.refreshModelStatus();
  }
  return _instance;
}

/* ───── 외부 의존 헬퍼 ──────────────────────────────────────────────── */

function readSetting(key: keyof typeof FALLBACK_SETTINGS): string {
  try {
    const value = getSetting(key);
    return value || FALLBACK_SETTINGS[key];
  } catch {
    return FALLBACK_SETTINGS[key];
  }
}

/**
 * whisper-cli 바이너리 경로.
 * - 패키징 시: process.resourcesPath/whisper/win32-x64/whisper-cli.exe
 * - 개발 시:   <repo>/binaries/whisper/win32-x64/whisper-cli.exe
 */
export function getWhisperCliPath(): string {
  const sub = path.join('whisper', `${process.platform}-${process.arch}`);
  const exe = process.platform === 'win32' ? 'whisper-cli.exe' : 'whisper-cli';
  if (app.isPackaged) {
    return path.join(process.resourcesPath, sub, exe);
  }
  // 개발 환경: 워크트리 루트의 binaries/
  return path.join(app.getAppPath(), 'binaries', sub, exe);
}

/**
 * ffmpeg-static 바이너리 경로.
 * - ffmpeg-static 모듈이 노출하는 경로를 사용
 * - 패키징 시 asarUnpack 처리되어 app.asar.unpacked 에서 로드됨
 */
export function getFfmpegPath(): string {
  // dynamic require — 모듈이 없거나 바이너리 누락 시 명확한 에러 메시지
  let raw: string | null;
  try {
    raw = require('ffmpeg-static') as string | null;
  } catch (err) {
    throw new Error(`ffmpeg-static 모듈을 찾을 수 없습니다: ${(err as Error).message}`);
  }
  if (!raw) {
    throw new Error('ffmpeg-static이 바이너리 경로를 노출하지 않습니다.');
  }
  // electron-builder asar 패키징 시 'app.asar' 경로 → 'app.asar.unpacked' 로 치환
  return raw.replace('app.asar', 'app.asar.unpacked');
}

function isBinaryAvailable(): boolean {
  try {
    return fs.existsSync(getWhisperCliPath());
  } catch {
    return false;
  }
}

async function writeTempAudio(payload: SttTranscribePayload): Promise<string> {
  const dir = path.join(os.tmpdir(), 'wee-stt-input');
  await fs.promises.mkdir(dir, { recursive: true });
  const ext = mimeToExt(payload.mimeType);
  const filePath = path.join(dir, `${randomUUID()}${ext}`);
  await fs.promises.writeFile(filePath, Buffer.from(payload.audio));
  return filePath;
}

function mimeToExt(mime: string): string {
  if (mime.includes('webm')) return '.webm';
  if (mime.includes('ogg')) return '.ogg';
  if (mime.includes('mp4')) return '.m4a';
  if (mime.includes('wav')) return '.wav';
  if (mime.includes('mpeg')) return '.mp3';
  return '.bin';
}

/**
 * 설정 변경 시 호출 — 다음 transcribe 요청에서 새 모델로 reconfigure.
 */
export function updateSttSettings(updates: Partial<{
  stt_enabled: '0' | '1';
  stt_engine: 'whisper-cli';
  stt_model: SttModelId;
  stt_language: 'ko';
}>): void {
  updateSettings(updates as never);
  // 모델 ID 가 바뀌었으면 worker reconfigure 강제
  if (_instance && (updates as { stt_model?: SttModelId }).stt_model) {
    (_instance as unknown as { configured: boolean }).configured = false;
    (_instance as unknown as { configuredModelId: SttModelId | null }).configuredModelId = null;
    _instance.refreshModelStatus();
  }
}

export { STT_MODEL_INFO };
