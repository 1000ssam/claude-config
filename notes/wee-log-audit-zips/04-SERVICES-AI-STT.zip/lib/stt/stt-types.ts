// STT 서비스 공용 타입 정의
// - 메인 프로세스(lib/stt, electron/main)와 렌더러(src/) 양쪽에서 공유
// - 직렬화 가능한 값만 사용 (IPC 경계 통과)

export type SttEngineId = 'whisper-cli';

export type SttModelId = 'ggml-small-q5_1' | 'ggml-medium-q5_0';

export type SttLanguage = 'ko';

export const STT_MODEL_INFO: Record<SttModelId, {
  label: string;
  fileName: string;
  sizeBytes: number;
  downloadUrl: string;
  description: string;
}> = {
  'ggml-small-q5_1': {
    label: 'Small (180MB)',
    fileName: 'ggml-small-q5_1.bin',
    sizeBytes: 190_085_487,
    downloadUrl: 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small-q5_1.bin',
    description: '회기 메모 받아쓰기에 충분한 정확도. 메모리 사용 적음.',
  },
  'ggml-medium-q5_0': {
    label: 'Medium (515MB)',
    fileName: 'ggml-medium-q5_0.bin',
    sizeBytes: 539_212_467,
    downloadUrl: 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium-q5_0.bin',
    description: '더 정확하지만 메모리·시간 부담 증가. 학교 PC에서는 권장하지 않음.',
  },
};

export type SttModelState =
  | 'absent'        // 디스크에 없음, 다운로드 필요
  | 'downloading'   // 다운로드 진행 중
  | 'ready'         // 사용 가능
  | 'error';        // 다운로드 실패 등

export interface SttModelStatus {
  id: SttModelId;
  state: SttModelState;
  progress?: number;        // 0~1, downloading 상태에서만
  bytesDownloaded?: number;
  totalBytes?: number;
  errorMessage?: string;
}

export type SttServiceState =
  | 'idle'
  | 'preparing'      // 모델 로드 또는 워커 부팅
  | 'ready'
  | 'transcribing'   // 전사 작업 진행 중
  | 'error'
  | 'disabled';      // stt_enabled='0'

export interface SttStatus {
  enabled: boolean;
  engine: SttEngineId;
  model: SttModelStatus;
  serviceState: SttServiceState;
  binaryAvailable: boolean;   // whisper-cli.exe + DLL이 패키지 안에 있는지
  errorMessage?: string;
}

// IPC 요청 페이로드
export interface SttTranscribePayload {
  // 렌더러가 보내는 오디오 데이터 (webm/opus 등)
  audio: ArrayBuffer;
  mimeType: string;          // 'audio/webm;codecs=opus' 등
  durationMs?: number;       // 클라이언트가 측정한 녹음 시간 (디버깅용)
  language?: SttLanguage;    // 기본 'ko'
}

export interface SttTranscribeResult {
  requestId: string;
  text: string;
  segments?: SttSegment[];
  durationMs?: number;       // 실제 처리 시간
}

export interface SttSegment {
  start: number;             // 초 단위
  end: number;
  text: string;
}

// 푸시 이벤트 (메인 → 렌더러)
export type SttEvent =
  | { type: 'model-state'; status: SttModelStatus }
  | { type: 'service-state'; state: SttServiceState; message?: string }
  | { type: 'request-state'; requestId: string; state: 'queued' | 'converting' | 'transcribing'; progress?: number }
  | { type: 'transcribed'; requestId: string; result: SttTranscribeResult }
  | { type: 'request-error'; requestId: string; message: string; code?: string }
  | { type: 'request-cancelled'; requestId: string };

// 모델 다운로드 시작 결과
export interface SttDownloadStartResult {
  started: boolean;
  reason?: string;        // started=false 시 이유
}

// 워커 메시지 프로토콜 (메인 ↔ utilityProcess)
export type SttWorkerRequest =
  | { type: 'configure'; whisperCliPath: string; ffmpegPath: string; modelPath: string; modelId: SttModelId }
  | { type: 'transcribe'; requestId: string; inputAudioPath: string; mimeType: string; language: SttLanguage }
  | { type: 'cancel'; requestId: string }
  | { type: 'dispose' };

export type SttWorkerResponse =
  | { type: 'ready' }
  | { type: 'configured' }
  | { type: 'state'; requestId: string; state: 'converting' | 'transcribing'; progress?: number }
  | { type: 'transcribed'; requestId: string; result: SttTranscribeResult }
  | { type: 'error'; requestId?: string; message: string; code?: string }
  | { type: 'cancelled'; requestId: string };
