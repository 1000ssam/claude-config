// STT 워커 (utilityProcess.fork 로 메인에서 실행).
// - 메시지 프로토콜: SttWorkerRequest / SttWorkerResponse (stt-types)
// - 책임: 오디오 변환(ffmpeg) → 전사(whisper-cli) → 결과 반환
// - 메인 프로세스 차단을 피하기 위해 별도 워커로 분리

import { spawn } from 'child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { randomUUID } from 'crypto';

import type {
  SttEngineId,
  SttModelId,
  SttWorkerRequest,
  SttWorkerResponse,
} from './stt-types';
import type { SttProvider } from './providers/stt-provider';
import { WhisperCliProvider } from './providers/whisper-cli-provider';

// utilityProcess 환경 — parentPort 로 메인과 통신
declare const process: NodeJS.Process & {
  parentPort?: NodeJS.EventEmitter & { postMessage: (msg: unknown) => void };
};

const port = process.parentPort;
if (!port) {
  // dev 환경에서 잘못 import 되는 케이스 — 워커 외부에서는 no-op
  // (electron-vite가 lib/stt/stt-worker.ts를 같이 번들하면 모듈 로드 시점에 여기 도달 가능)
  // 메인이 아닌 환경에서는 즉시 종료.
} else {
  setupWorker(port);
}

interface WorkerState {
  provider: SttProvider | null;
  ffmpegPath: string;
  modelPath: string;
  modelId: SttModelId | null;
  engineId: SttEngineId | null;
  whisperCliPath: string;
  abortControllers: Map<string, AbortController>;
  tmpRoot: string;
}

function setupWorker(parentPort: NonNullable<typeof process.parentPort>) {
  const state: WorkerState = {
    provider: null,
    ffmpegPath: '',
    modelPath: '',
    modelId: null,
    engineId: null,
    whisperCliPath: '',
    abortControllers: new Map(),
    tmpRoot: path.join(os.tmpdir(), 'wee-stt-' + randomUUID()),
  };
  fs.mkdirSync(state.tmpRoot, { recursive: true });

  // 워커 부팅 알림
  send({ type: 'ready' });

  parentPort.on('message', async (raw: unknown) => {
    // Electron utilityProcess 의 양방향 message API 가 비대칭이다:
    //   - 메인 → 워커: 워커 측에서 MessageEvent({data: payload}) 형태로 수신
    //   - 워커 → 메인: 메인 측에서 payload 직접 수신
    // 그래서 워커 측은 raw.data 를 꺼내야 한다. 향후 Electron 동작이 바뀌어
    // raw 가 payload 직접일 수도 있어 fallback 로 raw 자체도 허용.
    const msg = ((raw as { data?: SttWorkerRequest })?.data
      ?? (raw as SttWorkerRequest));
    try {
      switch (msg.type) {
        case 'configure':
          await handleConfigure(msg);
          break;
        case 'transcribe':
          await handleTranscribe(msg);
          break;
        case 'cancel':
          handleCancel(msg);
          break;
        case 'dispose':
          await handleDispose();
          break;
      }
    } catch (err) {
      const message = (err as Error).message ?? String(err);
      const requestId = (msg as { requestId?: string }).requestId;
      send({ type: 'error', requestId, message });
    }
  });

  async function handleConfigure(msg: Extract<SttWorkerRequest, { type: 'configure' }>) {
    state.ffmpegPath = msg.ffmpegPath;
    state.modelPath = msg.modelPath;
    state.whisperCliPath = msg.whisperCliPath;
    state.modelId = msg.modelId;
    state.engineId = 'whisper-cli';

    state.provider = new WhisperCliProvider({
      whisperCliPath: msg.whisperCliPath,
      modelPath: msg.modelPath,
      modelId: msg.modelId,
    });
    await state.provider.init();
    send({ type: 'configured' });
  }

  async function handleTranscribe(msg: Extract<SttWorkerRequest, { type: 'transcribe' }>) {
    if (!state.provider) {
      send({
        type: 'error',
        requestId: msg.requestId,
        message: '워커가 아직 configure 되지 않음',
        code: 'NOT_CONFIGURED',
      });
      return;
    }

    const abort = new AbortController();
    state.abortControllers.set(msg.requestId, abort);

    try {
      // 1) 오디오 변환: <임의 포맷> → 16kHz mono WAV
      send({ type: 'state', requestId: msg.requestId, state: 'converting' });
      const wavPath = await convertToWav({
        inputPath: msg.inputAudioPath,
        ffmpegPath: state.ffmpegPath,
        tmpDir: state.tmpRoot,
        signal: abort.signal,
      });

      if (abort.signal.aborted) {
        send({ type: 'cancelled', requestId: msg.requestId });
        return;
      }

      // 2) 전사
      send({ type: 'state', requestId: msg.requestId, state: 'transcribing' });
      const result = await state.provider.transcribeFile(wavPath, {
        language: msg.language,
        signal: abort.signal,
      });

      // 3) 임시 파일 정리
      try { fs.unlinkSync(wavPath); } catch { /* noop */ }
      try { fs.unlinkSync(msg.inputAudioPath); } catch { /* noop */ }

      send({
        type: 'transcribed',
        requestId: msg.requestId,
        result: { ...result, requestId: msg.requestId },
      });
    } catch (err) {
      if ((err as Error).name === 'AbortError') {
        send({ type: 'cancelled', requestId: msg.requestId });
      } else {
        send({
          type: 'error',
          requestId: msg.requestId,
          message: (err as Error).message,
        });
      }
    } finally {
      state.abortControllers.delete(msg.requestId);
    }
  }

  function handleCancel(msg: Extract<SttWorkerRequest, { type: 'cancel' }>) {
    const ac = state.abortControllers.get(msg.requestId);
    if (ac) ac.abort();
  }

  async function handleDispose() {
    for (const ac of state.abortControllers.values()) ac.abort();
    state.abortControllers.clear();
    try { await state.provider?.dispose(); } catch { /* noop */ }
    try { fs.rmSync(state.tmpRoot, { recursive: true, force: true }); } catch { /* noop */ }
    process.exit(0);
  }

  function send(resp: SttWorkerResponse) {
    parentPort.postMessage(resp);
  }
}

interface ConvertOptions {
  inputPath: string;
  ffmpegPath: string;
  tmpDir: string;
  signal: AbortSignal;
}

async function convertToWav(opts: ConvertOptions): Promise<string> {
  const outPath = path.join(opts.tmpDir, `${path.basename(opts.inputPath, path.extname(opts.inputPath))}-16k.wav`);

  return new Promise<string>((resolve, reject) => {
    const child = spawn(opts.ffmpegPath, [
      '-y',                       // overwrite
      '-i', opts.inputPath,
      '-ar', '16000',             // 16kHz sample rate
      '-ac', '1',                 // mono
      '-f', 'wav',
      outPath,
    ], { windowsHide: true });

    let stderr = '';
    let killed = false;

    child.stderr.on('data', (chunk: Buffer) => { stderr += chunk.toString(); });

    const onAbort = () => {
      killed = true;
      try { child.kill(); } catch { /* noop */ }
    };
    opts.signal.addEventListener('abort', onAbort, { once: true });

    child.on('error', (err) => {
      opts.signal.removeEventListener('abort', onAbort);
      reject(new Error(`ffmpeg 실행 실패: ${err.message}`));
    });

    child.on('close', (code) => {
      opts.signal.removeEventListener('abort', onAbort);
      if (killed) {
        reject(new DOMException('Aborted', 'AbortError'));
        return;
      }
      if (code !== 0) {
        reject(new Error(`ffmpeg 변환 실패 (code=${code}): ${stderr.slice(-300)}`));
        return;
      }
      resolve(outPath);
    });
  });
}
