// STT 모델 디스크 관리 + 다운로드.
// - 모델 저장 위치: userData/stt-models/<fileName>
// - LLM 의 model-manager 패턴을 따름
// - 다운로드는 fetch + stream (Node 18+ / Electron 내장)

import { app, net } from 'electron';
import fs from 'fs';
import path from 'path';

import { STT_MODEL_INFO, type SttModelId, type SttModelStatus } from './stt-types';

const MODELS_SUBDIR = 'stt-models';

export function getStttModelsDir(): string {
  const dir = path.join(app.getPath('userData'), MODELS_SUBDIR);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return dir;
}

export function getStttModelPath(modelId: SttModelId): string {
  return path.join(getStttModelsDir(), STT_MODEL_INFO[modelId].fileName);
}

export function isStttModelInstalled(modelId: SttModelId): boolean {
  const p = getStttModelPath(modelId);
  if (!fs.existsSync(p)) return false;
  const stat = fs.statSync(p);
  // 최소 크기 가드 (예: 1MB) — 다운로드 도중 끊긴 파일 제외
  return stat.size > 1_000_000;
}

export function getInstalledStttModelStatus(modelId: SttModelId): SttModelStatus {
  if (isStttModelInstalled(modelId)) {
    return { id: modelId, state: 'ready' };
  }
  return { id: modelId, state: 'absent' };
}

export interface DownloadHandle {
  modelId: SttModelId;
  cancel: () => void;
}

let activeDownload: DownloadHandle | null = null;

export function getActiveStttDownload(): DownloadHandle | null {
  return activeDownload;
}

export interface DownloadCallbacks {
  onProgress: (status: SttModelStatus) => void;
  onComplete: (status: SttModelStatus) => void;
  onError: (status: SttModelStatus) => void;
}

export function startStttModelDownload(
  modelId: SttModelId,
  cb: DownloadCallbacks,
): DownloadHandle | null {
  if (activeDownload) return null;

  const info = STT_MODEL_INFO[modelId];
  const targetPath = getStttModelPath(modelId);
  const tempPath = `${targetPath}.downloading`;
  const expectedTotal = info.sizeBytes;

  let cancelled = false;
  let writeStream: fs.WriteStream | null = null;

  const handle: DownloadHandle = {
    modelId,
    cancel: () => {
      cancelled = true;
      try { writeStream?.destroy(); } catch { /* noop */ }
      try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch { /* noop */ }
    },
  };
  activeDownload = handle;

  // electron net 사용 (시스템 프록시·인증 자동 처리)
  const req = net.request({
    url: info.downloadUrl,
    method: 'GET',
    redirect: 'follow',
  });

  req.on('response', (res) => {
    if (res.statusCode < 200 || res.statusCode >= 300) {
      activeDownload = null;
      cb.onError({
        id: modelId,
        state: 'error',
        errorMessage: `다운로드 실패 (HTTP ${res.statusCode})`,
      });
      try { req.abort(); } catch { /* noop */ }
      return;
    }

    const contentLength = Number(res.headers['content-length']) || expectedTotal;
    let downloaded = 0;
    writeStream = fs.createWriteStream(tempPath);

    res.on('data', (chunk: Buffer) => {
      if (cancelled) return;
      downloaded += chunk.length;
      writeStream?.write(chunk);
      cb.onProgress({
        id: modelId,
        state: 'downloading',
        progress: contentLength > 0 ? Math.min(1, downloaded / contentLength) : undefined,
        bytesDownloaded: downloaded,
        totalBytes: contentLength,
      });
    });

    res.on('end', () => {
      writeStream?.end();
      writeStream?.on('finish', () => {
        if (cancelled) {
          try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch { /* noop */ }
          activeDownload = null;
          return;
        }
        // 무결성 체크: 다운로드 결과 파일 크기가 예상값의 95% 이상이어야 OK
        // (HuggingFace LFS 크기는 정확값과 1~2% 오차가 있을 수 있음 — 그 정도는 허용)
        try {
          const downloadedSize = fs.statSync(tempPath).size;
          const minAcceptable = Math.floor(expectedTotal * 0.95);
          if (downloadedSize < minAcceptable) {
            try { fs.unlinkSync(tempPath); } catch { /* noop */ }
            activeDownload = null;
            cb.onError({
              id: modelId,
              state: 'error',
              errorMessage: `다운로드 손상 의심 — 파일 크기 ${downloadedSize} < 예상 ${expectedTotal}. 다시 시도하세요.`,
            });
            return;
          }
          fs.renameSync(tempPath, targetPath);
          activeDownload = null;
          cb.onComplete({ id: modelId, state: 'ready' });
        } catch (err) {
          activeDownload = null;
          cb.onError({
            id: modelId,
            state: 'error',
            errorMessage: `파일 이동 실패: ${(err as Error).message}`,
          });
        }
      });
    });

    res.on('error', (err: Error) => {
      activeDownload = null;
      try { writeStream?.destroy(); } catch { /* noop */ }
      try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch { /* noop */ }
      cb.onError({
        id: modelId,
        state: 'error',
        errorMessage: `다운로드 중단: ${err.message}`,
      });
    });
  });

  req.on('error', (err) => {
    activeDownload = null;
    cb.onError({
      id: modelId,
      state: 'error',
      errorMessage: `네트워크 오류: ${err.message}`,
    });
  });

  req.end();
  return handle;
}

export function cancelStttModelDownload(): boolean {
  if (!activeDownload) return false;
  activeDownload.cancel();
  activeDownload = null;
  return true;
}
