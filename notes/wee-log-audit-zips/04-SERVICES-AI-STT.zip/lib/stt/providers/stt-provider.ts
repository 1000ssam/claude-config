// STT 엔진 추상화 인터페이스
// - 새로운 엔진 추가 시 이 인터페이스만 구현하면 됨
// - 워커(lib/stt/stt-worker.ts)에서 팩토리로 인스턴스 생성

import type { SttEngineId, SttLanguage, SttModelId, SttTranscribeResult } from '../stt-types';

export interface SttTranscribeOptions {
  language: SttLanguage;
  signal?: AbortSignal;
  onProgress?: (progress: number) => void;  // 0~1, 추정치
}

export interface SttProvider {
  readonly id: SttEngineId;
  readonly modelId: SttModelId;

  /**
   * 모델·바이너리 검증. 실패 시 throw.
   * 짧은 핫경로(파일 존재 확인 등)만. 무거운 로드는 transcribeFile 안에서 처리.
   */
  init(): Promise<void>;

  /**
   * 16kHz mono WAV 파일을 받아 한국어로 전사.
   * - 메모리에서 변환 안 함 — 호출자가 미리 ffmpeg로 변환해서 wavPath로 넘긴 상태여야 함
   * - 결과는 텍스트 + (가능하면) segments
   */
  transcribeFile(wavPath: string, opts: SttTranscribeOptions): Promise<SttTranscribeResult>;

  /**
   * 리소스 해제. child_process 기반 엔진이면 보통 no-op (spawn 종료 시 알아서 정리됨).
   */
  dispose(): Promise<void>;
}

export interface SttProviderFactoryInput {
  modelId: SttModelId;
  modelPath: string;        // 모델 파일 절대 경로 (.bin)
  whisperCliPath?: string;  // engine='whisper-cli'일 때 바이너리 경로
}

export type SttProviderFactory = (engineId: SttEngineId, input: SttProviderFactoryInput) => SttProvider;
