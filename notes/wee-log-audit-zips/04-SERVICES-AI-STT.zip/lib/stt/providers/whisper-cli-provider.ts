// whisper.cpp 의 whisper-cli.exe 를 child_process 로 호출하는 SttProvider 구현.
// - 16kHz mono WAV 입력 → 한국어 텍스트 출력
// - .txt 출력을 파싱 (segments는 -ojf 옵션으로 JSON 출력 시 파싱 가능)

import { spawn } from 'child_process';
import fs from 'fs';
import os from 'os';
import path from 'path';

import type { SttEngineId, SttModelId, SttTranscribeResult } from '../stt-types';
import type { SttProvider, SttTranscribeOptions } from './stt-provider';

export interface WhisperCliProviderOptions {
  whisperCliPath: string;     // whisper-cli.exe 절대 경로
  modelPath: string;          // .bin 모델 절대 경로
  modelId: SttModelId;
  threads?: number;           // -t 옵션, 기본 navigator.hardwareConcurrency / 2
}

export class WhisperCliProvider implements SttProvider {
  readonly id: SttEngineId = 'whisper-cli';
  readonly modelId: SttModelId;
  private readonly whisperCliPath: string;
  private readonly modelPath: string;
  private readonly threads: number;

  constructor(opts: WhisperCliProviderOptions) {
    this.whisperCliPath = opts.whisperCliPath;
    this.modelPath = opts.modelPath;
    this.modelId = opts.modelId;
    this.threads = Math.max(1, opts.threads ?? Math.max(1, Math.floor(os.cpus().length / 2)));
  }

  async init(): Promise<void> {
    if (!fs.existsSync(this.whisperCliPath)) {
      throw new Error(`whisper-cli 바이너리를 찾을 수 없음: ${this.whisperCliPath}`);
    }
    if (!fs.existsSync(this.modelPath)) {
      throw new Error(`STT 모델 파일을 찾을 수 없음: ${this.modelPath}`);
    }
  }

  async transcribeFile(wavPath: string, opts: SttTranscribeOptions): Promise<SttTranscribeResult> {
    if (!fs.existsSync(wavPath)) {
      throw new Error(`입력 오디오 파일 없음: ${wavPath}`);
    }

    // 출력 prefix (.txt 가 자동 생성됨)
    const outPrefix = path.join(
      path.dirname(wavPath),
      `${path.basename(wavPath, path.extname(wavPath))}-stt`,
    );
    const outTxtPath = `${outPrefix}.txt`;

    const args = [
      '-m', this.modelPath,
      '-f', wavPath,
      '-l', opts.language,
      '-t', String(this.threads),
      '-otxt',                  // text output
      '-of', outPrefix,         // output file prefix (확장자 자동)
      '--no-prints',            // 진행상황 stderr 출력 억제
      '--no-timestamps',        // 텍스트 출력에서 [00:00.000 --> 00:01.000] 제거
    ];

    const startedAt = Date.now();

    return new Promise<SttTranscribeResult>((resolve, reject) => {
      const child = spawn(this.whisperCliPath, args, {
        cwd: path.dirname(this.whisperCliPath),  // DLL 로드를 위해 바이너리 폴더에서 실행
        windowsHide: true,
      });

      let stderr = '';
      let killed = false;

      child.stderr.on('data', (chunk: Buffer) => {
        stderr += chunk.toString();
      });

      const onAbort = () => {
        killed = true;
        try { child.kill(); } catch { /* noop */ }
      };
      opts.signal?.addEventListener('abort', onAbort, { once: true });

      child.on('error', (err) => {
        opts.signal?.removeEventListener('abort', onAbort);
        reject(new Error(`whisper-cli 실행 실패: ${err.message}`));
      });

      child.on('close', (code) => {
        opts.signal?.removeEventListener('abort', onAbort);

        if (killed) {
          reject(new DOMException('Aborted', 'AbortError'));
          return;
        }

        if (code !== 0) {
          reject(new Error(`whisper-cli 비정상 종료 (code=${code}): ${stderr.slice(-500)}`));
          return;
        }

        try {
          const text = fs.existsSync(outTxtPath) ? fs.readFileSync(outTxtPath, 'utf-8').trim() : '';
          // 임시 출력 파일 정리 (실패는 무시)
          try { fs.unlinkSync(outTxtPath); } catch { /* noop */ }

          resolve({
            requestId: '',  // 호출자(worker)가 채움
            text: normalizeTranscriptText(text),
            durationMs: Date.now() - startedAt,
          });
        } catch (err) {
          reject(new Error(`전사 결과 읽기 실패: ${(err as Error).message}`));
        }
      });
    });
  }

  async dispose(): Promise<void> {
    // child_process 기반이라 보관 중인 리소스 없음
  }
}

/**
 * whisper-cli 출력 정리:
 * - 줄바꿈 정리
 * - [BLANK_AUDIO], [Music], [Silence] 등 메타 토큰 제거
 * - 한글 사이 공백 정리
 */
function normalizeTranscriptText(raw: string): string {
  return raw
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line.length > 0)
    .map((line) => line.replace(/\[[A-Z_\s]+\]/g, '').trim())
    .filter((line) => line.length > 0)
    .join('\n');
}
