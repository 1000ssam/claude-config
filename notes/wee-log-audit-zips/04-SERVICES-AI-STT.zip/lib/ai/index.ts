/**
 * lib/ai 공개 API. 메인 프로세스(electron/main.ts)에서만 import.
 */

export { aiService } from './ai-service';
export type { AiService } from './ai-service';
export { DEFAULT_MODEL } from './model-manager';
export type {
  AiBackend,
  AiEvent,
  AiErrorCode,
  AiStatus,
  AiTask,
  ChatMessage,
  ContextRequest,
  FinishReason,
  GenerateStartPayload,
  GenerationOptions,
  GenerationResult,
  GenerationUsage,
  ModelDescriptor,
  ModelState,
  ProviderCapabilities,
  ProviderConfig,
} from './types';
