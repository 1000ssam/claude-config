/**
 * 토큰 추정·예산·절단 헬퍼.
 *
 * **왜 추정인가**: 토크나이저는 워커 측 node-llama-cpp 인스턴스만 보유. 메인 프로세스에서
 * 매 섹션마다 워커에 토큰 카운트를 요청하면 라운드트립 비용이 누적된다. ContextBuilder는
 * 예산 결정만 하면 충분하므로 글자수 기반 근사로 처리하고, 최종 메시지 직렬화 단계의
 * 약간의 오차는 워커 측 capabilities.contextWindow에서 흡수한다(아래 SAFETY_MARGIN).
 *
 * **근사 모델**: Kanana(LLaMA 계열) 한국어 토크나이저 기준 한글 1자 ≈ 2.0~3.0 토큰,
 * ASCII 1자 ≈ 0.25~0.5 토큰. 안전을 위해 **상한**으로 잡는다(예산 초과 방지가 목적이라
 * 과대추정이 안전).
 *
 * - 한글 음절 1자 ≈ 2.5 토큰
 * - 영문/숫자/공백 1자 ≈ 0.35 토큰
 * - 그 외(이모지·한자·기타) ≈ 1.5 토큰
 */

/** 한글 음절 범위 (가-힣). */
const HANGUL_RE = /[가-힣]/;
/** ASCII 영숫자·기본 부호. */
const ASCII_RE = /[\x20-\x7E]/;

/** 문자열의 토큰 수를 보수적으로 추정한다 (상한). */
export function estimateTokens(text: string): number {
  if (!text) return 0;
  let total = 0;
  for (const ch of text) {
    if (HANGUL_RE.test(ch)) total += 2.5;
    else if (ASCII_RE.test(ch)) total += 0.35;
    else total += 1.5;
  }
  // 1 토큰 미만 결과는 0으로 떨어지지 않게 올림.
  return Math.ceil(total);
}

/** 토큰 한도에 맞는 대략적 글자 한도를 역산 (한글 가정, 보수적). */
export function approxCharBudget(tokenBudget: number): number {
  // 1 토큰당 한글 약 0.4자. 보수적으로 0.4를 적용.
  return Math.floor(tokenBudget * 0.4);
}

/**
 * 머리·꼬리를 보존하고 가운데를 `…(중략)…`으로 대체하는 절단.
 * 머리:꼬리 비율 기본 2:1 (앞 맥락이 보통 더 중요).
 *
 * `maxTokens` 이내가 되도록 잘라낸다. 본문이 이미 한도 이내이면 원문 반환.
 *
 * @param text 원문
 * @param maxTokens 절단 후 목표 토큰 상한
 * @param headRatio 머리에 할당할 비율 (0~1, 기본 0.66)
 */
export function trimMiddle(
  text: string,
  maxTokens: number,
  headRatio: number = 0.66,
): string {
  if (maxTokens <= 0) return '';
  if (estimateTokens(text) <= maxTokens) return text;

  const ellipsis = '…(중략)…';
  const ellipsisTokens = estimateTokens(ellipsis);
  const usable = Math.max(0, maxTokens - ellipsisTokens);
  if (usable <= 0) return ellipsis;

  const charBudget = approxCharBudget(usable);
  const headChars = Math.max(1, Math.floor(charBudget * headRatio));
  const tailChars = Math.max(1, charBudget - headChars);

  // 문자열 길이가 head+tail보다 짧으면 원문 반환 (estimateTokens 보수성 때문에 발생 가능).
  if (text.length <= headChars + tailChars) return text;

  const head = text.slice(0, headChars).replace(/\s+\S*$/, '');
  const tail = text.slice(text.length - tailChars).replace(/^\S*\s+/, '');
  return `${head}${ellipsis}${tail}`;
}

/**
 * 맥락 예산 계산. capabilities·옵션을 받아 ContextBuilder가 사용할 수 있는
 * 토큰 수를 반환한다.
 *
 *   budget = contextWindow − baseSystemTokens − taskPromptTokens − maxOutput − margin
 *
 * margin(기본 256)은 추정 오차·메시지 직렬화 오버헤드 흡수용.
 */
export function computeContextBudget(params: {
  contextWindow: number;
  baseSystemTokens: number;
  taskPromptTokens: number;
  maxOutputTokens: number;
  margin?: number;
}): number {
  const margin = params.margin ?? 256;
  const budget =
    params.contextWindow -
    params.baseSystemTokens -
    params.taskPromptTokens -
    params.maxOutputTokens -
    margin;
  return Math.max(0, budget);
}
