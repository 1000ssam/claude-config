/**
 * Vite의 `?raw` 쿼리 import 타입 선언.
 *
 * 워커 빌드(electron-vite의 main 빌드)에서 `.md?raw`를 문자열 인라인으로 가져오기 위함.
 * 이 선언은 `lib/ai/prompt-composer.ts`만 의존.
 */

declare module '*.md?raw' {
  const content: string;
  export default content;
}
