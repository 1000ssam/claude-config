/**
 * LLM utility process 엔트리포인트.
 *
 * 메인 프로세스가 `utilityProcess.fork(out/main/llm-worker.js)`로 띄운다.
 * `process.parentPort`로 메인과 메시지를 주고받는다.
 *
 * 책임:
 *  - 모델 다운로드 (node-llama-cpp의 createModelDownloader)
 *  - Provider 인스턴스 생성/초기화/해제
 *  - 토큰 스트리밍 생성 + 요청별 취소
 *
 * 비책임 (보안 경계):
 *  - DB 접근 / 암호화 키 보유 — 메인 프로세스 전담
 *  - 평문 프롬프트 문자열만 메인으로부터 받아서 처리한다.
 */

import path from 'path';
import type {
  ChatMessage,
  GenerationOptions,
  ProviderCapabilities,
  ProviderConfig,
  WorkerRequest,
  WorkerResponse,
} from './types';
import { createProvider, type LLMProvider } from './providers';

// Electron utility process의 parentPort. 타입 정의가 process에 augment되어 있다.
const parentPort = (process as unknown as { parentPort?: ElectronParentPortLike })
  .parentPort;
if (!parentPort) {
  // utility process 환경이 아니면 즉시 종료
  console.error('[llm-worker] parentPort 미존재 — utility process가 아닙니다.');
  process.exit(1);
}

interface ElectronParentPortLike {
  on: (
    event: 'message',
    cb: (e: { data: WorkerRequest }) => void,
  ) => void;
  postMessage: (msg: WorkerResponse) => void;
}

function post(msg: WorkerResponse): void {
  parentPort!.postMessage(msg);
}

function log(level: 'info' | 'warn' | 'error', message: string): void {
  post({ type: 'log', level, message });
}

// ── 상태 ────────────────────────────────────────────────────────────────────

let providerConfig: ProviderConfig | null = null;
let provider: LLMProvider | null = null;
let capabilities: ProviderCapabilities | null = null;

/** 진행 중 생성 요청의 AbortController 맵 */
const activeGenerations = new Map<string, AbortController>();

/** 진행 중 다운로드의 취소용 */
let downloadCancel: { cancel: () => void } | null = null;

// ── 동적 import 캐시 (node-llama-cpp은 ESM-only) ─────────────────────────

let nlcCache: NLCApi | null = null;
interface NLCApi {
  createModelDownloader: (opts: {
    modelUri?: string;
    modelUrl?: string;
    dirPath: string;
    onProgress?: (p: { totalSize: number; downloadedSize: number }) => void;
  }) => Promise<{
    download: () => Promise<string>;
    cancel?: () => void;
    totalSize?: number;
    entrypointFilePath?: string;
  }>;
}

async function getNLC(): Promise<NLCApi> {
  if (nlcCache) return nlcCache;
  const mod = (await import('node-llama-cpp')) as unknown as NLCApi;
  nlcCache = mod;
  return mod;
}

// ── 메시지 디스패처 ──────────────────────────────────────────────────────────

parentPort.on('message', (e) => {
  const req = e.data;
  // 요청은 비동기 처리하되 await 없이 시작 — 응답은 post()로 비동기 송신
  handleMessage(req).catch((err: unknown) => {
    log('error', `메시지 처리 실패: ${(err as Error).message}`);
  });
});

post({ type: 'ready' });

async function handleMessage(req: WorkerRequest): Promise<void> {
  switch (req.type) {
    case 'configure':
      providerConfig = req.config;
      log('info', `provider 설정 수신: ${req.config.backend}`);
      return;

    case 'download':
      await handleDownload(req.uri, req.targetDir);
      return;

    case 'cancel-download':
      try {
        downloadCancel?.cancel();
      } catch {
        /* noop */
      }
      return;

    case 'init':
      await handleInit();
      return;

    case 'generate':
      await handleGenerate(req.requestId, req.messages, req.options);
      return;

    case 'cancel': {
      const ctl = activeGenerations.get(req.requestId);
      ctl?.abort();
      return;
    }

    case 'dispose':
      await disposeProvider();
      process.exit(0);
  }
}

async function handleDownload(uri: string, targetDir: string): Promise<void> {
  try {
    const { createModelDownloader } = await getNLC();
    let cancelled = false;
    downloadCancel = {
      cancel: () => {
        cancelled = true;
      },
    };

    const downloader = await createModelDownloader({
      modelUri: uri,
      dirPath: targetDir,
      onProgress: ({ totalSize, downloadedSize }) => {
        if (cancelled) return;
        post({
          type: 'download-progress',
          downloaded: downloadedSize,
          total: totalSize,
        });
      },
    });

    if (cancelled) {
      try {
        downloader.cancel?.();
      } catch {
        /* noop */
      }
      post({ type: 'download-error', message: '다운로드가 취소되었습니다.' });
      downloadCancel = null;
      return;
    }

    const filePath = await downloader.download();
    downloadCancel = null;
    post({ type: 'download-done', path: filePath ?? path.join(targetDir, 'model.gguf') });
  } catch (err: unknown) {
    downloadCancel = null;
    post({
      type: 'download-error',
      message: (err as Error).message ?? '알 수 없는 다운로드 오류',
    });
  }
}

async function handleInit(): Promise<void> {
  try {
    if (!providerConfig) {
      post({ type: 'init-error', message: 'provider 설정이 없습니다.' });
      return;
    }
    if (provider) {
      // 이미 초기화됨
      post({
        type: 'init-done',
        capabilities: capabilities ?? provider.getCapabilities(),
      });
      return;
    }
    provider = createProvider(providerConfig);
    await provider.init();
    capabilities = provider.getCapabilities();
    post({ type: 'init-done', capabilities });
  } catch (err: unknown) {
    provider = null;
    capabilities = null;
    post({ type: 'init-error', message: (err as Error).message });
  }
}

async function handleGenerate(
  requestId: string,
  messages: ChatMessage[],
  options: GenerationOptions,
): Promise<void> {
  if (!provider || !provider.isReady()) {
    post({
      type: 'generation-error',
      requestId,
      code: 'not_initialized',
      message: '모델이 아직 준비되지 않았습니다.',
    });
    return;
  }
  const ctl = new AbortController();
  activeGenerations.set(requestId, ctl);
  try {
    const result = await provider.generate(
      messages,
      options,
      (tok) => {
        post({ type: 'token', requestId, token: tok });
      },
      ctl.signal,
    );
    post({
      type: 'generation-done',
      requestId,
      finishReason: result.finishReason,
      usage: result.usage,
    });
  } catch (err: unknown) {
    const aborted = ctl.signal.aborted;
    post({
      type: 'generation-error',
      requestId,
      code: aborted ? 'aborted' : 'backend_error',
      message: (err as Error).message ?? '추론 실패',
    });
  } finally {
    activeGenerations.delete(requestId);
  }
}

async function disposeProvider(): Promise<void> {
  for (const ctl of activeGenerations.values()) ctl.abort();
  activeGenerations.clear();
  try {
    await provider?.dispose();
  } catch {
    /* noop */
  }
  provider = null;
  capabilities = null;
}
