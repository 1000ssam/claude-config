/**
 * 회기 자동 요약 큐.
 *
 * 회기 저장/수정 후 백그라운드에서 80자 한 줄 요약을 생성해 sessions.summary_short에
 * 저장한다. ai-service의 단일슬롯과 공존하기 위해 다음과 같이 동작:
 *
 * - **동시성 1**: 한 번에 하나의 요약만 처리. 처리 중인 항목의 ai-event를 구독해
 *   완료/에러 신호로 다음 항목을 트리거한다.
 * - **사용자 활동 양보**: ai-service가 다른 요청 중이면 1.5초 대기 후 재시도. 큐는
 *   사용자 인라인 AI보다 우선순위가 낮다.
 * - **재시도 2회**: 에러 시 최대 2회 재시도. 그 뒤에도 실패하면 `summary_status='failed'`로
 *   마킹하고 큐에서 제거. 사용자가 사이드패널의 "갱신" 버튼으로 다시 enqueue 가능.
 * - **모델 상태 의존**: 모델 미준비 또는 AI 비활성/잠금 상태이면 큐는 대기. 모델이
 *   ready로 전환되면 자동 재개.
 * - **본문 빈 회기**: `session_content`가 비어 있으면 큐에서 조용히 스킵 (오류 아님,
 *   원본을 다시 채우면 updateSession이 status='pending'으로 reset).
 *
 * import 방향성: queries → summary-queue 는 금지(import cycle). 이 모듈은
 * queries를 import하고, queries는 이 모듈을 모름. enqueue 호출은 호출자(electron/main.ts의
 * IPC 핸들러)가 책임진다.
 */

import { randomUUID } from 'crypto';
import { aiService } from './ai-service';
import type { AiEvent } from './types';
import { getSetting } from '../queries/settings';
import { isKeyLoaded } from '../crypto/key-manager';
import {
  getSessionById,
  setSessionSummary,
  markSessionSummaryStatus,
  listSessionsNeedingSummary,
} from '../queries/sessions';

interface ProcessingState {
  sessionId: number;
  requestId: string;
  /** 스트리밍 토큰 누적 — 'done' 이벤트에서 후처리하여 저장 */
  buffer: string;
}

const MAX_ATTEMPTS = 2;
const BUSY_RETRY_MS = 1500;
const SUMMARY_MAX_CHARS = 80;

const queue: number[] = [];
const attempts = new Map<number, number>();
let processing: ProcessingState | null = null;
let aiEventSubscribed = false;
let busyTimer: ReturnType<typeof setTimeout> | null = null;

/** 한 번만 ai-event를 구독한다 (lazy). */
function ensureSubscription(): void {
  if (aiEventSubscribed) return;
  aiEventSubscribed = true;
  aiService().on('ai-event', handleAiEvent);
}

/** 큐 + 처리 중 항목에 sessionId가 이미 들어있는지. */
function hasSession(sessionId: number): boolean {
  if (processing?.sessionId === sessionId) return true;
  return queue.includes(sessionId);
}

/**
 * 회기 요약 큐에 추가. 중복 enqueue는 no-op.
 * 호출자(main.ts의 sessions:create/update 핸들러)가 createSession/updateSession 직후 호출.
 */
export function enqueueSummary(sessionId: number): void {
  if (hasSession(sessionId)) return;
  queue.push(sessionId);
  console.log(`[summary-queue] enqueued sessionId=${sessionId} queueSize=${queue.length}`);
  ensureSubscription();
  scheduleProcess();
}

/** 여러 회기를 한 번에. 부트스트랩에서 사용. */
export function enqueueAllSummaries(sessionIds: number[]): void {
  for (const id of sessionIds) {
    if (!hasSession(id)) queue.push(id);
  }
  if (queue.length > 0) {
    ensureSubscription();
    scheduleProcess();
  }
}

/**
 * 앱 시작 시 또는 잠금 해제 직후 호출. DB에 summary_status='pending'/'failed'로
 * 남은 회기를 일괄 enqueue. failed였더라도 사용자가 명시적으로 재시도 트리거(사이드패널)에
 * 호출하지 않는 한 자동 재시도는 하지 않으므로, 부트스트랩은 pending만 보장한다.
 */
export function bootstrapSummaryQueue(): void {
  if (!isKeyLoaded()) return;
  const ids = listSessionsNeedingSummary();
  if (ids.length === 0) return;
  // 'failed' 상태는 자동 재시도 대상이 아님 — 사용자가 명시 갱신 시에만 enqueue.
  // listSessionsNeedingSummary는 둘 다 반환하므로 여기서 필터링.
  const pendingIds: number[] = [];
  for (const id of ids) {
    const s = getSessionById(id);
    if (s && s.summary_status === 'pending') pendingIds.push(id);
  }
  if (pendingIds.length > 0) {
    enqueueAllSummaries(pendingIds);
  }
}

/**
 * 명시 갱신용 — 'failed' 또는 'pending' 회기를 한꺼번에 enqueue. 사이드패널 "갱신" 버튼.
 * failed였던 항목은 attempts 카운트가 리셋된다 (사용자의 명시 요청은 새 시도).
 */
export function refreshSummaries(caseId?: number): { enqueued: number } {
  if (!isKeyLoaded()) return { enqueued: 0 };
  const ids = listSessionsNeedingSummary(caseId);
  let enqueued = 0;
  for (const id of ids) {
    if (hasSession(id)) continue;
    attempts.delete(id); // 사용자 명시 시도이므로 카운트 리셋
    // failed였다면 pending으로 되돌려야 사이드패널의 "누락 N건" 카운트가 정합.
    const s = getSessionById(id);
    if (s?.summary_status === 'failed') {
      markSessionSummaryStatus(id, 'pending');
    }
    queue.push(id);
    enqueued += 1;
  }
  if (enqueued > 0) {
    ensureSubscription();
    scheduleProcess();
  }
  return { enqueued };
}

function scheduleProcess(): void {
  // 다음 마이크로태스크로 미뤄서 같은 트랜잭션 안의 추가 enqueue를 모은다.
  queueMicrotask(() => processNext());
}

function processNext(): void {
  if (processing) return;
  if (queue.length === 0) return;

  // 게이트 확인.
  if (!canProcessNow()) {
    // 키 로드/모델 ready 신호를 받으면 외부에서 다시 호출됨.
    return;
  }

  const status = aiService().getStatus();
  if (!status.providerReady) {
    // 모델은 ready지만 워밍업 전 → warm-up 트리거. capabilities가 잡히면 model-state
    // 이벤트로 재진입할 수도 있고, 다음 enqueue/이벤트에서 자연스럽게 재시도된다.
    aiService().warmUp();
    // 워밍업 완료를 기다리지 않고 일단 반환 — 이벤트 루프에서 다시 시도.
    setTimeout(() => processNext(), BUSY_RETRY_MS);
    return;
  }

  const sessionId = queue.shift()!;
  const session = getSessionById(sessionId);
  if (!session) {
    // 삭제됐거나 접근 불가 → 조용히 다음으로.
    attempts.delete(sessionId);
    scheduleProcess();
    return;
  }
  const content = (session.session_content || '').trim();
  if (!content) {
    // 빈 본문 → 마킹 없이 다음 (updateSession이 본문 변경 시 'pending' reset하므로
    // 다시 enqueue되는 경로는 살아 있음).
    attempts.delete(sessionId);
    scheduleProcess();
    return;
  }

  const requestId = `summary-${randomUUID()}`;
  processing = { sessionId, requestId, buffer: '' };

  aiService().generate({
    requestId,
    task: 'session-summary',
    userInput: content,
  });
}

/** AI 활성·키·모델 상태가 모두 충족되는지. */
function canProcessNow(): boolean {
  if (!isKeyLoaded()) return false;
  // ai_enabled 미설정 시 기본 '0' 취급 (사용자 명시 활성화 전).
  if (getSetting('ai_enabled' as never) !== '1') return false;
  const s = aiService().getStatus();
  if (s.model.state !== 'ready') return false;
  // ai-service의 단일슬롯: 다른 요청이 점유 중이면 양보.
  if (busyTimer) return false;
  return true;
}

function handleAiEvent(e: AiEvent): void {
  if (e.requestId === '*') {
    // 모델 상태 전이: ready로 바뀌면 큐 재개.
    if (e.type === 'model-state' && e.state === 'ready') {
      scheduleProcess();
    }
    return;
  }
  if (!processing || e.requestId !== processing.requestId) return;

  switch (e.type) {
    case 'token':
      processing.buffer += e.token;
      return;

    case 'done': {
      const final = postProcessSummary(processing.buffer);
      const sessionId = processing.sessionId;
      processing = null;
      if (final) {
        try {
          setSessionSummary(sessionId, final);
          attempts.delete(sessionId);
          console.log(
            `[summary-queue] done sessionId=${sessionId} chars=${final.length} preview="${final.slice(0, 40)}${final.length > 40 ? '…' : ''}"`,
          );
        } catch (err) {
          console.error('[summary-queue] setSessionSummary failed:', err);
          handleAttemptFailure(sessionId);
        }
      } else {
        // 모델이 빈 결과나 "(요약 불가)"만 반환 — 재시도 의미 없음, 실패 처리.
        attempts.set(sessionId, MAX_ATTEMPTS + 1);
        handleAttemptFailure(sessionId);
      }
      scheduleProcess();
      return;
    }

    case 'error': {
      const sessionId = processing.sessionId;
      const code = e.code;
      processing = null;

      if (code === 'busy') {
        // 충돌 — 횟수 증가 없이 후미에 재배치, 잠시 대기 후 재시도.
        if (!queue.includes(sessionId)) queue.push(sessionId);
        if (busyTimer) clearTimeout(busyTimer);
        busyTimer = setTimeout(() => {
          busyTimer = null;
          processNext();
        }, BUSY_RETRY_MS);
        return;
      }

      if (code === 'no_model' || code === 'locked' || code === 'not_initialized') {
        // 환경 문제 — 재시도해도 같은 결과. 큐에 되돌려놓고 멈춤. ready 이벤트가 재개.
        if (!queue.includes(sessionId)) queue.unshift(sessionId);
        return;
      }

      console.warn(`[summary-queue] error sessionId=${sessionId} code=${code} msg=${e.message}`);
      handleAttemptFailure(sessionId);
      scheduleProcess();
      return;
    }
  }
}

function handleAttemptFailure(sessionId: number): void {
  const current = (attempts.get(sessionId) ?? 0) + 1;
  attempts.set(sessionId, current);
  if (current >= MAX_ATTEMPTS + 1) {
    try {
      markSessionSummaryStatus(sessionId, 'failed');
    } catch (err) {
      console.error('[summary-queue] markSessionSummaryStatus failed:', err);
    }
    attempts.delete(sessionId);
  } else {
    // 횟수 남았으면 다시 후미에 배치.
    if (!queue.includes(sessionId)) queue.push(sessionId);
  }
}

/**
 * 모델이 만든 출력을 80자 한 줄로 정규화.
 * - 첫 비어있지 않은 줄만 채택
 * - 글머리표·따옴표·코드펜스·"요약:" 같은 머리말 제거
 * - 80자 초과 시 단어 경계에서 자르고 …  표시 X (DB에 그대로 저장, UI에서 그대로 노출)
 * - "(요약 불가)" 또는 빈 결과는 null 반환 → 호출자가 실패 처리
 */
function postProcessSummary(raw: string): string | null {
  if (!raw) return null;
  let text = raw.trim();
  // 코드펜스(```...```) 제거
  text = text.replace(/^```[\w-]*\n?/gm, '').replace(/```\s*$/gm, '');
  // 첫 비어있지 않은 줄만 사용
  const firstLine = text.split('\n').map((l) => l.trim()).find((l) => l.length > 0);
  if (!firstLine) return null;
  let line = firstLine;
  // 머리말 제거: "요약:", "회기 요약:", "- " 등
  line = line.replace(/^(요약|회기 요약|회기요약)[:：]\s*/i, '');
  line = line.replace(/^[-•・]\s*/, '');
  // 따옴표 양끝
  line = line.replace(/^["'“”‘’]+|["'“”‘’]+$/g, '');
  line = line.trim();
  if (!line) return null;
  if (/^\(?\s*요약\s*불가\s*\)?$/.test(line)) return null;
  if (line.length > SUMMARY_MAX_CHARS) {
    // 단어 경계 자르기 — 한글은 띄어쓰기 기준
    const cut = line.slice(0, SUMMARY_MAX_CHARS);
    const lastSpace = cut.lastIndexOf(' ');
    line = lastSpace > SUMMARY_MAX_CHARS - 12 ? cut.slice(0, lastSpace) : cut;
  }
  return line;
}

// ── 테스트·디버그 노출 ────────────────────────────────────────────────────
export const __testing = { postProcessSummary };
