/**
 * llm-worker (utility process) 호스트 — 메인 프로세스 측.
 * fork·재기동·메시지 송수신을 캡슐화하고 타입드 이벤트로 노출한다.
 */

import path from 'path';
import { utilityProcess, type UtilityProcess } from 'electron';
import { EventEmitter } from 'events';
import type {
  ChatMessage,
  GenerationOptions,
  ProviderCapabilities,
  ProviderConfig,
  WorkerRequest,
  WorkerResponse,
} from './types';

export interface LlmHostEvents {
  /** 토큰 등 모든 워커 응답을 그대로 노출 (ai-service에서 분류) */
  message: (msg: WorkerResponse) => void;
  exit: (code: number | null) => void;
}

export interface LlmHost {
  on<K extends keyof LlmHostEvents>(event: K, listener: LlmHostEvents[K]): void;
  off<K extends keyof LlmHostEvents>(event: K, listener: LlmHostEvents[K]): void;

  /** 워커가 살아 있고 ready 메시지를 보냈는지 */
  isReady(): boolean;

  configure(config: ProviderConfig): void;
  download(uri: string, targetDir: string): void;
  cancelDownload(): void;
  /** init 호출. capabilities는 init-done 메시지로 받음. */
  init(): void;
  generate(
    requestId: string,
    messages: ChatMessage[],
    options: GenerationOptions,
  ): void;
  cancel(requestId: string): void;
  dispose(): Promise<void>;
}

/** 워커 JS 파일 경로 — 빌드 산출물 out/main/llm-worker.js 와 동일 위치 */
function resolveWorkerPath(): string {
  // 메인 프로세스 번들은 out/main/main.js, 워커는 out/main/llm-worker.js
  return path.join(__dirname, 'llm-worker.js');
}

export function createLlmHost(): LlmHost {
  const emitter = new EventEmitter();
  let child: UtilityProcess | null = null;
  let ready = false;
  let pendingMessages: WorkerRequest[] = [];

  function spawn(): void {
    if (child) return;
    const workerPath = resolveWorkerPath();
    child = utilityProcess.fork(workerPath, [], {
      serviceName: 'wee-log-llm',
      stdio: 'inherit',
    });
    child.on('message', (msg: WorkerResponse) => {
      if (msg.type === 'ready') {
        ready = true;
        // 큐잉된 메시지를 일괄 송신
        const queued = pendingMessages;
        pendingMessages = [];
        for (const m of queued) child?.postMessage(m);
      }
      if (msg.type === 'log') {
        const tag = `[llm-worker:${msg.level}]`;
        if (msg.level === 'error') console.error(tag, msg.message);
        else if (msg.level === 'warn') console.warn(tag, msg.message);
        else console.log(tag, msg.message);
      }
      emitter.emit('message', msg);
    });
    child.on('exit', (code: number | null) => {
      ready = false;
      child = null;
      pendingMessages = [];
      emitter.emit('exit', code);
    });
  }

  function send(msg: WorkerRequest): void {
    if (!child) spawn();
    if (!ready) {
      pendingMessages.push(msg);
      return;
    }
    child!.postMessage(msg);
  }

  return {
    on: (event, listener) => {
      emitter.on(event, listener as (...args: unknown[]) => void);
    },
    off: (event, listener) => {
      emitter.off(event, listener as (...args: unknown[]) => void);
    },
    isReady: () => ready,
    configure: (config) => send({ type: 'configure', config }),
    download: (uri, targetDir) => send({ type: 'download', uri, targetDir }),
    cancelDownload: () => send({ type: 'cancel-download' }),
    init: () => send({ type: 'init' }),
    generate: (requestId, messages, options) =>
      send({ type: 'generate', requestId, messages, options }),
    cancel: (requestId) => send({ type: 'cancel', requestId }),
    dispose: async () => {
      if (!child) return;
      try {
        child.postMessage({ type: 'dispose' } satisfies WorkerRequest);
        // 워커가 자체 종료(process.exit) 하므로 짧게 대기
        await new Promise<void>((resolve) => {
          const t = setTimeout(() => {
            try {
              child?.kill();
            } catch {
              /* noop */
            }
            resolve();
          }, 1500);
          child?.once('exit', () => {
            clearTimeout(t);
            resolve();
          });
        });
      } finally {
        child = null;
        ready = false;
      }
    },
  };
}

// ProviderCapabilities는 외부에서 init-done 메시지를 통해 얻는다 — 호스트는 단순 통과.
export type { ProviderCapabilities };
