/**
 * AI 오케스트레이터.
 * - utility process(LlmHost) 소유
 * - 모델 상태 추적 (절대 + downloading 진행률)
 * - 단일슬롯 생성 큐
 * - 워커 메시지를 AiEvent로 변환해 이벤트 emit
 *
 * IPC 핸들러(electron/main.ts)와 렌더러 이벤트 릴레이는 별도 — 이 모듈은 그 둘 사이의 도메인 로직만 담는다.
 */

import { EventEmitter } from 'events';
import { app } from 'electron';
import { getSetting } from '../queries/settings';
import type {
  AiBackend,
  AiEvent,
  AiStatus,
  ChatMessage,
  GenerateStartPayload,
  GenerationOptions,
  ModelState,
  ProviderCapabilities,
  ProviderConfig,
  WorkerResponse,
} from './types';
import { createLlmHost, type LlmHost } from './llm-host';
import {
  DEFAULT_MODEL,
  findInstalledModel,
  getModelsDir,
  resolveModelStateFromDisk,
} from './model-manager';
import { buildContext } from './context-builder';
import {
  composeSystemPrompt,
  composeUserMessage,
  getRawPrompts,
} from './prompt-composer';
import { computeContextBudget, estimateTokens } from './token-estimate';

const DEFAULT_CONTEXT_SIZE = 4096;

/** 작업별 출력 토큰 상한 (Phase 1 시점 — 추후 task별로 조정) */
const DEFAULT_MAX_TOKENS: Record<string, number> = {
  refine: 512,
  summarize: 384,
  continue: 256,
  conceptualize: 900,
  report: 600,
  qa: 512,
  // 80자 한 줄 → 한글 추정 ~200토큰. 약간 여유.
  'session-summary': 120,
};

interface DownloadState {
  inProgress: boolean;
  downloaded: number;
  total: number;
}

class AiService {
  private host: LlmHost | null = null;
  private emitter = new EventEmitter();
  private capabilities: ProviderCapabilities | null = null;
  private modelState: ModelState = 'absent';
  private modelPath: string | undefined;
  private modelSize: number | undefined;
  private download: DownloadState = { inProgress: false, downloaded: 0, total: 0 };
  /** 단일슬롯: 현재 생성 중인 요청 ID */
  private activeRequestId: string | null = null;
  /** 진행 중인 워밍업 약속. init-done/init-error 응답 시 resolve. */
  private warmUpPending: {
    promise: Promise<boolean>;
    resolve: (ok: boolean) => void;
  } | null = null;

  constructor() {
    // 디스크 상태로 초기화
    const disk = resolveModelStateFromDisk();
    this.modelState = disk.state;
    this.modelPath = disk.path;
    this.modelSize = disk.sizeBytes;
  }

  on(event: 'ai-event', listener: (e: AiEvent) => void): void {
    this.emitter.on(event, listener);
  }

  off(event: 'ai-event', listener: (e: AiEvent) => void): void {
    this.emitter.off(event, listener);
  }

  private emit(e: AiEvent): void {
    this.emitter.emit('ai-event', e);
  }

  // ── 상태 ──────────────────────────────────────────────────────────────────

  getStatus(): AiStatus {
    const enabled = getSetting('ai_enabled' as never) === '1';
    const backend = (getSetting('ai_backend' as never) || 'local') as AiBackend;

    // 디스크 재확인 (외부에서 파일이 추가/삭제되었을 수 있음)
    if (!this.download.inProgress) {
      const disk = resolveModelStateFromDisk();
      this.modelState = disk.state;
      this.modelPath = disk.path;
      this.modelSize = disk.sizeBytes;
    }

    return {
      enabled,
      backend,
      model: {
        state: this.modelState,
        path: this.modelPath,
        sizeBytes: this.modelSize,
        downloadedBytes: this.download.inProgress ? this.download.downloaded : undefined,
      },
      providerReady: this.host?.isReady() === true && this.capabilities !== null,
      capabilities: this.capabilities ?? undefined,
    };
  }

  // ── 워커 라이프사이클 ──────────────────────────────────────────────────────

  private ensureHost(): LlmHost {
    if (this.host) return this.host;
    const host = createLlmHost();
    this.host = host;
    host.on('message', (msg) => this.handleWorkerMessage(msg));
    host.on('exit', (code) => {
      console.warn(`[ai-service] worker exited (code=${code})`);
      this.host = null;
      this.capabilities = null;
      this.activeRequestId = null;
      this.download.inProgress = false;
    });
    return host;
  }

  private handleWorkerMessage(msg: WorkerResponse): void {
    switch (msg.type) {
      case 'ready':
        return; // 호스트 내부에서 처리됨

      case 'download-progress':
        this.download.downloaded = msg.downloaded;
        this.download.total = msg.total;
        this.emit({
          requestId: '*',
          type: 'download-progress',
          downloaded: msg.downloaded,
          total: msg.total,
          percent: msg.total > 0 ? Math.floor((msg.downloaded / msg.total) * 100) : 0,
        });
        return;

      case 'download-done':
        this.download.inProgress = false;
        this.modelPath = msg.path;
        this.modelState = 'ready';
        this.emit({ requestId: '*', type: 'download-done', path: msg.path });
        this.emit({ requestId: '*', type: 'model-state', state: 'ready' });
        return;

      case 'download-error':
        this.download.inProgress = false;
        this.modelState = 'error';
        this.emit({ requestId: '*', type: 'download-error', message: msg.message });
        this.emit({ requestId: '*', type: 'model-state', state: 'error' });
        return;

      case 'init-done':
        this.capabilities = msg.capabilities;
        // 카드 배지가 'ready'로 즉시 전이되도록 model-state 이벤트 재발사.
        // (모델 파일은 이전부터 ready였으므로 의미상 멱등 — 렌더러는 providerReady도
        // 같이 갱신하기 위해 getStatus를 다시 호출.)
        this.emit({ requestId: '*', type: 'model-state', state: 'ready' });
        if (this.warmUpPending) {
          this.warmUpPending.resolve(true);
          this.warmUpPending = null;
        }
        return;

      case 'init-error':
        this.capabilities = null;
        console.error('[ai-service] init-error:', msg.message);
        if (this.warmUpPending) {
          this.warmUpPending.resolve(false);
          this.warmUpPending = null;
        }
        return;

      case 'token':
        this.emit({ requestId: msg.requestId, type: 'token', token: msg.token });
        return;

      case 'generation-done':
        if (this.activeRequestId === msg.requestId) this.activeRequestId = null;
        this.emit({
          requestId: msg.requestId,
          type: 'done',
          finishReason: msg.finishReason,
          usage: msg.usage,
        });
        return;

      case 'generation-error':
        if (this.activeRequestId === msg.requestId) this.activeRequestId = null;
        this.emit({
          requestId: msg.requestId,
          type: 'error',
          code: msg.code,
          message: msg.message,
        });
        return;

      case 'log':
        return; // host가 콘솔에 이미 찍었음
    }
  }

  // ── 다운로드 ───────────────────────────────────────────────────────────────

  startDownload(): { started: boolean } {
    if (this.download.inProgress) return { started: false };
    if (this.modelState === 'ready') return { started: false };

    const host = this.ensureHost();
    this.download.inProgress = true;
    this.download.downloaded = 0;
    this.download.total = 0;
    this.modelState = 'downloading';
    this.emit({ requestId: '*', type: 'model-state', state: 'downloading' });

    host.download(DEFAULT_MODEL.uri, getModelsDir());
    return { started: true };
  }

  cancelDownload(): { ok: boolean } {
    if (!this.download.inProgress) return { ok: false };
    this.host?.cancelDownload();
    return { ok: true };
  }

  // ── 초기화 / 워밍업 ────────────────────────────────────────────────────────

  /**
   * 모델을 워커에 로드. 워커의 init-done/init-error 응답까지 await — 호출자가 토스트를
   * 띄우는 시점에 capabilities가 보장된다 (Phase 4 검증에서 발견된 "여러 번 눌러야 ready"
   * 버그의 근본 픽스). 이미 capabilities가 있으면 즉시 ok=true.
   */
  async warmUp(): Promise<{ ok: boolean }> {
    if (this.modelState !== 'ready' || !this.modelPath) return { ok: false };
    if (this.capabilities) return { ok: true };
    // 동시 호출 합치기 — 두 번째 클릭은 첫 호출의 promise를 공유.
    if (this.warmUpPending) {
      const ok = await this.warmUpPending.promise;
      return { ok };
    }
    let resolveFn: (ok: boolean) => void = () => {};
    const promise = new Promise<boolean>((r) => {
      resolveFn = r;
    });
    this.warmUpPending = { promise, resolve: resolveFn };

    const host = this.ensureHost();
    host.configure({
      backend: 'local',
      modelPath: this.modelPath,
      contextSize: DEFAULT_CONTEXT_SIZE,
    });
    host.init();

    const ok = await promise;
    return { ok };
  }

  // ── 생성 ──────────────────────────────────────────────────────────────────

  /**
   * 생성 시작. IPC 호환을 위해 동기 반환 + 비동기 작업은 내부에서 진행.
   * 진행 상황·결과는 모두 `ai-event`로 emit.
   *
   * Phase 3:
   * - `contextRequest`가 있으면 메인 측에서 DB 복호화 + redact + 토큰 예산 절단 후
   *   시스템 프롬프트에 주입한다.
   * - 없으면 BASE_SYSTEM + TASK_PROMPT만 사용 (설정의 원시 프롬프트 박스 등).
   */
  generate(payload: GenerateStartPayload): { requestId: string } {
    const { requestId } = payload;

    if (this.modelState !== 'ready' || !this.modelPath) {
      queueMicrotask(() => {
        this.emit({
          requestId,
          type: 'error',
          code: 'no_model',
          message: '모델이 준비되지 않았습니다. 설정에서 다운로드해주세요.',
        });
      });
      return { requestId };
    }

    if (this.activeRequestId) {
      queueMicrotask(() => {
        this.emit({
          requestId,
          type: 'error',
          code: 'busy',
          message: '이전 작업이 진행 중입니다. 잠시 후 다시 시도하세요.',
        });
      });
      return { requestId };
    }

    // 슬롯 선점: contextBuild가 await 되는 동안 다른 generate가 들어와도 busy 처리되도록.
    this.activeRequestId = requestId;

    // 비동기 컨텍스트 빌드 → 메시지 조립 → 워커 호출. 실패는 ai-event로 보고.
    void this.runGeneration(payload).catch((err: unknown) => {
      const message = err instanceof Error ? err.message : String(err);
      console.error('[ai-service] runGeneration failed:', err);
      if (this.activeRequestId === requestId) this.activeRequestId = null;
      this.emit({
        requestId,
        type: 'error',
        code: 'backend_error',
        message: `생성 준비 중 오류: ${message}`,
      });
    });

    return { requestId };
  }

  private async runGeneration(payload: GenerateStartPayload): Promise<void> {
    const { requestId, task } = payload;
    const host = this.ensureHost();

    // 매번 configure + init 호출해도 워커 측에서 멱등 처리됨
    const config: ProviderConfig = {
      backend: 'local',
      modelPath: this.modelPath!,
      contextSize: DEFAULT_CONTEXT_SIZE,
    };
    host.configure(config);
    if (!this.capabilities) host.init();

    const maxTokens = DEFAULT_MAX_TOKENS[task] ?? 512;
    const contextWindow = this.capabilities?.contextWindow ?? DEFAULT_CONTEXT_SIZE;

    // ── 시스템 프롬프트: BASE + TASK + (옵션) 맥락
    const taskPromptText = getRawPrompts().tasks[task];
    const baseText = getRawPrompts().base;
    const baseTokens = estimateTokens(baseText);
    const taskTokens = estimateTokens(taskPromptText);
    const budget = computeContextBudget({
      contextWindow,
      baseSystemTokens: baseTokens,
      taskPromptTokens: taskTokens,
      maxOutputTokens: maxTokens,
    });

    let serializedContext = '';
    if (payload.contextRequest) {
      const built = await buildContext(payload.contextRequest, budget, task);
      serializedContext = built.text;
      // 디버그 로그 — 토큰 사용·D-2 분기·폴백 가시화.
      console.log(
        `[ai-service] context built: budget=${budget} tokens=${built.totalTokens} fallback=${built.fallbackCount}`,
        built.sectionsApplied.map((s) => `${s.label}(${s.outcome}, ${s.tokens}t)`).join(' | '),
        'redactMapping:', built.redactMapping,
      );
    }

    const systemContent = composeSystemPrompt(task, serializedContext);
    const userContent = composeUserMessage({
      task,
      userInput: payload.userInput,
      selectionText: payload.selectionText,
      fieldHint: payload.fieldHint,
    });

    const messages: ChatMessage[] = [
      { role: 'system', content: systemContent },
    ];
    // qa 등에서 직전 대화 히스토리 포함
    if (payload.history && payload.history.length > 0) {
      messages.push(...payload.history);
    }
    messages.push({ role: 'user', content: userContent });

    const options: GenerationOptions = {
      maxTokens,
      // 결정성·재현성이 중요한 task는 낮은 온도. refine은 '원문 변환'이라 가장 낮게
      // (짧은 입력 환각 폭발 완화 — 0.3→0.2). 요약 계열은 0.3, 생성형은 0.7.
      temperature:
        task === 'refine'
          ? 0.2
          : task === 'summarize' || task === 'session-summary'
            ? 0.3
            : 0.7,
      topP: 0.9,
    };

    host.generate(requestId, messages, options);
  }

  cancel(requestId: string): { ok: boolean } {
    if (!this.host) return { ok: false };
    this.host.cancel(requestId);
    if (this.activeRequestId === requestId) this.activeRequestId = null;
    return { ok: true };
  }

  async dispose(): Promise<void> {
    if (this.host) {
      await this.host.dispose();
      this.host = null;
    }
    this.capabilities = null;
    this.activeRequestId = null;
    this.download.inProgress = false;
  }
}

// 모듈 싱글톤 — 메인 프로세스에서 단 하나의 인스턴스를 공유.
// app이 초기화되기 전 import되면 app.getPath 호출이 실패할 수 있으므로
// 지연 생성을 보장하기 위해 함수 경유로 노출.
let instance: AiService | null = null;
export function aiService(): AiService {
  if (!instance) instance = new AiService();
  return instance;
}

export type { AiService };
// (모델 매니저 헬퍼 일부 재노출 — 필요시 사용)
export { findInstalledModel };
// app 미사용 경고 회피 (app은 model-manager 경유로만 사용)
void app;
