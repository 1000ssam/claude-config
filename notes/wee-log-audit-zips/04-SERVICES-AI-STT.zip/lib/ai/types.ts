/**
 * AI 모듈 공유 타입.
 * 메인 프로세스, utility worker, 렌더러가 함께 의존하는 계약을 한곳에 모은다.
 */

export type AiTask =
  | 'refine'
  | 'summarize'
  | 'continue'
  | 'conceptualize'
  | 'report'
  | 'qa'
  /**
   * 시스템 task: 회기 저장/수정 시 백그라운드 큐가 호출하는 80자 한 줄 요약.
   * 사용자 UI 카탈로그(AI_ACTIONS)에는 노출되지 않는다.
   */
  | 'session-summary';

export type AiBackend = 'local' | 'remote';

export type ModelState = 'absent' | 'downloading' | 'ready' | 'error';

export type FinishReason = 'stop' | 'length' | 'aborted' | 'error';

export type AiErrorCode =
  | 'no_model'
  | 'busy'
  | 'context_overflow'
  | 'backend_error'
  | 'aborted'
  | 'locked'
  | 'not_initialized';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface GenerationOptions {
  maxTokens?: number;
  temperature?: number;
  topP?: number;
  stopSequences?: string[];
}

export interface GenerationUsage {
  promptTokens: number;
  completionTokens: number;
}

export interface GenerationResult {
  text: string;
  finishReason: FinishReason;
  usage: GenerationUsage;
}

export interface ProviderCapabilities {
  contextWindow: number;
  maxOutputTokens: number;
}

export type ProviderConfig =
  | {
      backend: 'local';
      modelPath: string;
      contextSize: number;
      threads?: number;
    }
  | {
      backend: 'remote';
      baseUrl: string;
      apiKey?: string;
      model: string;
      contextWindow: number;
    };

// ── 렌더러 ↔ 메인 IPC 계약 ────────────────────────────────────────────────

/** 현재 페이지/엔티티 맥락 디스크립터. 메인에서 DB를 복호화 fetch 하여 직렬화한다. */
export interface ContextRequest {
  kind: 'session-form' | 'case-form' | 'conceptualization' | 'report-block';
  caseId: number;
  sessionId?: number;
  /** 폼의 미저장 필드 값 */
  draft: Record<string, string>;
  /** 개념화 양식: wee_standard | cbt | sfbt */
  templateType?: string;
  /** 보고서 블록의 종류·라벨 등 추가 메타 */
  meta?: Record<string, unknown>;
}

export interface GenerateStartPayload {
  /** 렌더러에서 crypto.randomUUID()로 생성 */
  requestId: string;
  task: AiTask;
  /** 페이지 맥락 디스크립터. Phase 1에서는 미사용. */
  contextRequest?: ContextRequest;
  /** refine/continue의 초안, qa의 질문 */
  userInput?: string;
  /** 선택 영역만 처리할 때 */
  selectionText?: string;
  /** 직전 대화 히스토리 (qa에서 사용) */
  history?: ChatMessage[];
  /**
   * 필드 의미·형식 힌트. 짧은 한 줄(예: "회기 제목 필드 — 명사구 한 줄, 본문처럼 늘이지 말 것").
   * prompt-composer가 user 메시지 상단에 [지침] 라인으로 박는다. 모델이 짧은 필드에서
   * 본문처럼 길게 응답하는 문제를 막기 위함.
   */
  fieldHint?: string;
}

export interface AiModelStatus {
  state: ModelState;
  path?: string;
  sizeBytes?: number;
  downloadedBytes?: number;
}

export interface AiStatus {
  enabled: boolean;
  backend: AiBackend;
  model: AiModelStatus;
  providerReady: boolean;
  capabilities?: ProviderCapabilities;
}

/** 토큰 스트리밍·라이프사이클 이벤트. 채널 `ai:event`로 라우팅. */
export type AiEvent =
  | { requestId: string; type: 'token'; token: string }
  | {
      requestId: string;
      type: 'done';
      finishReason: FinishReason;
      usage: GenerationUsage;
    }
  | { requestId: string; type: 'error'; code: AiErrorCode; message: string }
  | {
      requestId: '*';
      type: 'download-progress';
      downloaded: number;
      total: number;
      percent: number;
    }
  | { requestId: '*'; type: 'download-done'; path: string }
  | { requestId: '*'; type: 'download-error'; message: string }
  | { requestId: '*'; type: 'model-state'; state: ModelState };

// ── 모델 디스크립터 ───────────────────────────────────────────────────────

export interface ModelDescriptor {
  /** node-llama-cpp가 해석하는 모델 URI (hf:repo:quant 또는 절대경로) */
  uri: string;
  /** 표시용 이름 */
  label: string;
  /** 다운로드 후 저장 파일 추정명 (검증용) */
  fileName?: string;
}

// ── 메인 ↔ 워커 메시지 프로토콜 ──────────────────────────────────────────

export type WorkerRequest =
  | { type: 'configure'; config: ProviderConfig }
  | { type: 'download'; uri: string; targetDir: string }
  | { type: 'cancel-download' }
  | { type: 'init' }
  | {
      type: 'generate';
      requestId: string;
      messages: ChatMessage[];
      options: GenerationOptions;
    }
  | { type: 'cancel'; requestId: string }
  | { type: 'dispose' };

export type WorkerResponse =
  | { type: 'ready' }
  | { type: 'download-progress'; downloaded: number; total: number }
  | { type: 'download-done'; path: string }
  | { type: 'download-error'; message: string }
  | { type: 'init-done'; capabilities: ProviderCapabilities }
  | { type: 'init-error'; message: string }
  | { type: 'token'; requestId: string; token: string }
  | {
      type: 'generation-done';
      requestId: string;
      finishReason: FinishReason;
      usage: GenerationUsage;
    }
  | {
      type: 'generation-error';
      requestId: string;
      code: AiErrorCode;
      message: string;
    }
  | { type: 'log'; level: 'info' | 'warn' | 'error'; message: string };
