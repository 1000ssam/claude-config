/**
 * ContextBuilder.
 *
 * `ContextRequest` → 생산자 호출 → 토큰 예산 안에서 우선순위대로 채움 → 직렬화된
 * 문자열 1개 반환. 결과는 시스템 프롬프트의 "## 참고 정보 (상담 맥락)" 블록에 그대로 박힘.
 *
 * **알고리즘**:
 * 1. 생산자에서 받은 ContextSection[]을 priority 오름차순(작은 게 먼저), 같은 priority 안에서
 *    원래 순서 보존(stable sort).
 * 2. 각 섹션을 직렬화(`## label\n{text}`) 후 토큰 추정.
 * 3. 예산을 채워가며 각 섹션 처리:
 *    - 남은 예산 ≥ 섹션 토큰 → 그대로 포함.
 *    - 예산 부족 + trimmable → `trimMiddle`로 남은 예산에 맞게 절단해 포함.
 *    - 예산 부족 + 비trimmable → 통째 제외, `[일부 생략됨: <label>]` 마커만 삽입.
 * 4. 결합해서 반환.
 *
 * 예산이 0이거나 음수면 빈 문자열 반환.
 */

import type { AiTask, ContextRequest } from './types';
import { produceContext, type ContextSection } from './context-sources';
import {
  estimateTokens,
  trimMiddle,
} from './token-estimate';

/** 한 섹션의 직렬화·예산 처리 결과. */
interface BuiltSection {
  serialized: string;
  tokens: number;
  /** 'full' | 'trimmed' | 'omitted' */
  outcome: 'full' | 'trimmed' | 'omitted';
  label: string;
}

export interface BuildContextResult {
  /** 시스템 프롬프트에 박을 직렬화 텍스트 ("" 가능). */
  text: string;
  /** 추정된 총 토큰 수. */
  totalTokens: number;
  /** 디버그·노출용 상세. */
  sectionsApplied: Array<{ label: string; outcome: BuiltSection['outcome']; tokens: number }>;
  /** redact 일관성 검증용 (테스트에서 사용). */
  redactMapping: Record<string, string>;
  /** 요약 폴백을 사용한 회기 수. 0 이상. */
  fallbackCount: number;
}

/** 섹션 하나의 헤더 + 본문 직렬화. */
function serializeSection(s: ContextSection): string {
  return `## ${s.label}\n${s.text}`;
}

/** 헤더만의 토큰 비용 (절단 시 본문 예산 계산용). */
function headerTokens(label: string): number {
  return estimateTokens(`## ${label}\n`);
}

/**
 * 메인 진입점.
 *
 * @param req 렌더러가 보낸 컨텍스트 요청
 * @param budgetTokens `computeContextBudget`로 산정된 맥락 토큰 예산
 */
export async function buildContext(
  req: ContextRequest,
  budgetTokens: number,
  task: AiTask,
): Promise<BuildContextResult> {
  if (budgetTokens <= 0) {
    return { text: '', totalTokens: 0, sectionsApplied: [], redactMapping: {}, fallbackCount: 0 };
  }

  const { sections, redact, fallbackCount } = await produceContext(req, task);

  // 안정 정렬: priority 오름차순, 같은 priority에서 원래 인덱스 보존
  const indexed = sections.map((s, i) => ({ s, i }));
  indexed.sort((a, b) => a.s.priority - b.s.priority || a.i - b.i);

  const applied: BuiltSection[] = [];
  let used = 0;

  for (const { s } of indexed) {
    const serialized = serializeSection(s);
    const tokens = estimateTokens(serialized);
    const remaining = budgetTokens - used;

    if (tokens <= remaining) {
      applied.push({ serialized, tokens, outcome: 'full', label: s.label });
      used += tokens;
      continue;
    }

    if (s.trimmable) {
      const headerCost = headerTokens(s.label);
      const bodyBudget = remaining - headerCost;
      if (bodyBudget > 16) {
        // 본문에 의미 있는 토큰을 줄 수 있을 때만 절단 포함.
        const trimmedBody = trimMiddle(s.text, bodyBudget);
        const trimmedSection: ContextSection = { ...s, text: trimmedBody };
        const trimmedSerial = serializeSection(trimmedSection);
        const trimmedTokens = estimateTokens(trimmedSerial);
        if (trimmedTokens <= remaining) {
          applied.push({
            serialized: trimmedSerial,
            tokens: trimmedTokens,
            outcome: 'trimmed',
            label: s.label,
          });
          used += trimmedTokens;
          continue;
        }
      }
    }

    // 통째 제외 — 마커만 삽입
    const marker = `## ${s.label}\n[일부 생략됨]`;
    const markerTokens = estimateTokens(marker);
    if (markerTokens <= budgetTokens - used) {
      applied.push({ serialized: marker, tokens: markerTokens, outcome: 'omitted', label: s.label });
      used += markerTokens;
    }
    // 마커조차 안 들어가면 그냥 스킵 (드문 케이스)
  }

  return {
    text: applied.map((a) => a.serialized).join('\n\n'),
    totalTokens: used,
    sectionsApplied: applied.map((a) => ({ label: a.label, outcome: a.outcome, tokens: a.tokens })),
    redactMapping: redact.getMapping(),
    fallbackCount,
  };
}

export type { ContextSection } from './context-sources';
