/**
 * ContextKind별 맥락 섹션 생산자.
 *
 * 각 생산자는 `ContextRequest`를 받아 `lib/queries/*`로 복호화된 도메인 데이터를 fetch하고,
 * `redact` 컨텍스트를 통해 PII를 일관 익명화한 `ContextSection[]`을 반환한다.
 *
 * 직접 토큰 예산 절단은 하지 않는다 — 그건 `context-builder`의 책임. 여기서는
 * "이런 정보가 있다, priority N, trimmable Y/N"까지만 명시한다.
 *
 * **internal_notes**: 회기·사례의 `internal_notes`는 어느 생산자도 맥락에 넣지 않는다.
 * 그 필드 자체를 다듬는 호출에서만 user 메시지로 전달된다.
 */

import { getCaseById } from '@/lib/queries/cases';
import { getSessionsByCaseId, getSessionById } from '@/lib/queries/sessions';
import { getConceptualization } from '@/lib/queries/conceptualizations';
import { getTemplateByType } from '@/lib/constants/conceptualization-templates';
import type { Case } from '@/types/case';
import type { Session } from '@/types/session';
import type { AiTask, ContextRequest } from './types';
import { createRedactContext, type RedactContext } from './redact';
import { trimMiddle } from './token-estimate';

/**
 * task별 "최근 회기" 포함 개수 (D-2 모드에서).
 * 짧은 답을 만드는 task일수록 적은 회기만 본다.
 */
const RECENT_SESSION_COUNT: Partial<Record<AiTask, number>> = {
  refine: 1,
  continue: 1,
  summarize: 3,
  qa: 3,
};

/** 회기 요약 폴백 시 본문에서 잘라쓸 길이 (글자 수). */
const FALLBACK_CONTENT_CHARS = 60;

export interface ContextSection {
  /** 섹션 라벨 (직렬화 시 `## <label>` 헤더로 사용) */
  label: string;
  text: string;
  /** 작은 숫자가 더 중요. 채움 순서를 결정. */
  priority: number;
  /** 토큰 예산 초과 시 trimMiddle 적용 가능 여부 */
  trimmable: boolean;
}

/** 한 ContextRequest를 처리하기 위한 결과: 섹션 + 사용된 redact 컨텍스트(검증용). */
export interface ContextProduction {
  sections: ContextSection[];
  redact: RedactContext;
  /** 요약 누락으로 본문 폴백을 사용한 회기 수 (H — 시스템에 워닝 추가용). */
  fallbackCount: number;
}

const PRIORITY = {
  /** 가장 중요 — 절대 제외 금지 (현재 작성 중 초안, 사례 분류 등) */
  CRITICAL: 1,
  /** 핵심 맥락 — 주호소·목표·기본정보 */
  CORE: 2,
  /** 보조 맥락 — 작성 중 다른 섹션, 학생 기본정보 등 */
  SUPPORT: 3,
  /** 과거 회기 등 큰 덩어리 — 가장 먼저 trim 대상 */
  HISTORY: 4,
} as const;

const DRAFT_LABELS_SESSION: Record<string, string> = {
  session_title: '회기 제목 초안',
  session_content: '회기 내용 초안',
  internal_notes: '회기 내부 메모 초안',
};
const DRAFT_LABELS_CASE: Record<string, string> = {
  main_complaint: '주호소 초안',
  counseling_goal: '상담 목표 초안',
  teacher_opinion: '교사 의견 초안',
};
const DRAFT_LABELS_CONCEPT: Record<string, string> = {
  // 키는 템플릿마다 다르므로 라벨 매핑은 템플릿 조회로 보강.
};

/** 한 produceContext 호출 동안 생산자들이 공유하는 가변 상태. */
interface ProduceState {
  redact: RedactContext;
  /** 회기 요약 폴백을 사용한 횟수. H — 시스템 워닝용. */
  fallbackCount: number;
}

/** ContextKind별 디스패치. task는 D-2 분기·N결정에 사용. */
export async function produceContext(
  req: ContextRequest,
  task: AiTask,
): Promise<ContextProduction> {
  const state: ProduceState = { redact: createRedactContext(), fallbackCount: 0 };

  let sections: ContextSection[];
  switch (req.kind) {
    case 'session-form':
      sections = await produceSessionForm(req, state, task);
      break;
    case 'case-form':
      sections = await produceCaseForm(req, state);
      break;
    case 'conceptualization':
      sections = await produceConceptualization(req, state);
      break;
    case 'report-block':
      sections = await produceReportBlock(req, state);
      break;
    default:
      // 미지원 kind는 빈 섹션만 반환 (호출자가 안전 동작 보장)
      sections = [];
  }

  // H — 폴백이 1건 이상이면 시스템 워닝 섹션을 최우선으로 삽입.
  if (state.fallbackCount > 0) {
    sections.unshift({
      label: '주의 — 요약 미반영 회기 있음',
      text: `이 사례의 회기 ${state.fallbackCount}건은 자동 요약이 생성되지 않아 본문 첫 ${FALLBACK_CONTENT_CHARS}자만 발췌되어 있습니다. 핵심 맥락이 누락됐을 수 있으니 단정적 결론을 피하고 필요 시 사용자에게 보완을 요청하세요.`,
      priority: PRIORITY.CRITICAL,
      trimmable: false,
    });
  }

  return { sections, redact: state.redact, fallbackCount: state.fallbackCount };
}

// ─── 공통 헬퍼 ──────────────────────────────────────────────────────────────

/** 사례에 등장하는 인물(학생·보호자·의뢰인)을 redact 컨텍스트에 등록. */
function registerCasePeople(c: Case, redact: RedactContext): void {
  for (const s of c.students) {
    if (s.name) redact.registerPerson(s.name, 'student');
    if (s.guardian_name) redact.registerPerson(s.guardian_name, 'guardian');
  }
  if (c.referrer_name) redact.registerPerson(c.referrer_name, 'referrer');
}

/** Draft 객체를 priority 1 비trimmable 섹션 배열로 변환. */
function draftSections(
  draft: Record<string, string>,
  labelMap: Record<string, string>,
  redact: RedactContext,
  fallbackLabelPrefix: string,
): ContextSection[] {
  const out: ContextSection[] = [];
  for (const [k, raw] of Object.entries(draft)) {
    const v = (raw || '').trim();
    if (!v) continue;
    out.push({
      label: labelMap[k] ?? `${fallbackLabelPrefix} (${k})`,
      text: redact.redact(v),
      priority: PRIORITY.CRITICAL,
      trimmable: false,
    });
  }
  return out;
}

/** 사례 분류(카테고리) 한 줄. */
function caseClassificationSection(c: Case, redact: RedactContext): ContextSection | null {
  const bits: string[] = [];
  bits.push(`사례번호: ${c.case_number || '-'}`);
  bits.push(`학년도: ${c.academic_year || '-'}`);
  bits.push(`상태: ${c.status === 'active' ? '진행 중' : '종결'}`);
  if (c.close_reason) bits.push(`종결사유: ${c.close_reason}`);
  return {
    label: '사례 분류',
    text: redact.redact(bits.join(' / ')),
    priority: PRIORITY.CRITICAL,
    trimmable: false,
  };
}

/** 학생 기본정보 묶음. 비식별 정보 위주(이니셜·학년·성별). */
function studentsSection(c: Case, redact: RedactContext): ContextSection | null {
  if (!c.students || c.students.length === 0) return null;
  const lines = c.students.map((s) => {
    const initial = redact.redact(s.name || '학생');
    const grade = s.grade ? `${s.grade}학년` : '학년정보 없음';
    const cls = s.class_name ? ` ${s.class_name}반` : '';
    const gender = s.gender ? ` / ${s.gender}` : '';
    return `- ${initial} (${grade}${cls}${gender})`;
  });
  return {
    label: '대상 학생',
    text: lines.join('\n'),
    priority: PRIORITY.SUPPORT,
    trimmable: false,
  };
}

// ─── session-form ───────────────────────────────────────────────────────────

async function produceSessionForm(
  req: ContextRequest,
  state: ProduceState,
  task: AiTask,
): Promise<ContextSection[]> {
  const { redact } = state;
  const sections: ContextSection[] = [];
  const c = getCaseById(req.caseId);
  if (!c) return [];
  registerCasePeople(c, redact);

  // ── 맥락 주입 정책 (task별 차등) ──────────────────────────────────────────
  // 다듬기(refine)·요약(summarize)은 '이 텍스트' 자체를 다듬거나 압축하는 작업이라
  // 사례 맥락이 불필요하다. 사례 사실(주호소·상담목표·이전 회기 등)을 주입하면 경량
  // (2.1B) 모델이 그 사실을 결과에 융합(날조)하므로 의도적으로 비운다.
  // (초안 본문은 어차피 user 메시지로 전달되므로 손실 없음.)
  // 사례 맥락은 '이어쓰기(continue)'에서만 사용한다 — 앞선 맥락을 이어 생성해야 하므로.
  if (task === 'refine' || task === 'summarize') {
    return [];
  }

  // p1: 현재 작성 중인 초안 (draft) — internal_notes 제외
  const draftFiltered: Record<string, string> = {};
  for (const [k, v] of Object.entries(req.draft || {})) {
    if (k === 'internal_notes') continue; // 정책: 맥락에 넣지 않음
    draftFiltered[k] = v;
  }
  sections.push(...draftSections(draftFiltered, DRAFT_LABELS_SESSION, redact, '회기 초안'));

  // p2: 주호소
  if (c.main_complaint?.trim()) {
    sections.push({
      label: '사례 주호소',
      text: redact.redact(c.main_complaint),
      priority: PRIORITY.CORE,
      trimmable: true,
    });
  }

  // p3: 상담 목표
  if (c.counseling_goal?.trim()) {
    sections.push({
      label: '상담 목표',
      text: redact.redact(c.counseling_goal),
      priority: PRIORITY.CORE,
      trimmable: true,
    });
  }

  // ── D-2 분기: 개념화 fresh 판정 ──────────────────────────────────────────
  // 회기 자체를 작성/요약/이어쓰기/질의응답 하는 task에서만 D-2 적용.
  // (conceptualize/report는 produceSessionForm 경로에 오지 않으므로 굳이 분기 안 함.)
  // 개념화가 최신이면 그 본문 + 최근 회기 N건만 보낸다 (ctx 4K 절약).
  const allSessions = getSessionsByCaseId(req.caseId);
  const priorSessions = allSessions.filter((s) => !req.sessionId || s.id !== req.sessionId);
  const concept = getConceptualization(req.caseId);
  const conceptFresh = isConceptualizationFresh(concept, priorSessions);
  const recentN = RECENT_SESSION_COUNT[task] ?? 1;

  if (conceptFresh && concept) {
    // D-2: 개념화 본문 + 최근 N회 회기만.
    const conceptText = renderConceptualizationBody(concept, redact);
    if (conceptText) {
      sections.push({
        label: '사례개념화 (최신본)',
        text: conceptText,
        priority: PRIORITY.CORE,
        trimmable: true,
      });
    }
    const recent = priorSessions.slice(0, recentN);
    if (recent.length > 0) {
      const lines = recent.map((s) => formatSessionLine(s, state));
      sections.push({
        label: `최근 회기 ${recent.length}건`,
        text: lines.join('\n\n'),
        priority: PRIORITY.HISTORY,
        trimmable: true,
      });
    }
  } else if (priorSessions.length > 0) {
    // D-1: 모든 회기를 summary_short(있으면) 기준으로 직렬화. 폴백은 본문 첫 60자.
    const lines = priorSessions.map((s) => formatSessionLine(s, state));
    sections.push({
      label: `이전 회기 요약 (총 ${priorSessions.length}회)`,
      text: lines.join('\n\n'),
      priority: PRIORITY.HISTORY,
      trimmable: true,
    });
  }

  // p1 (다시): 사례 분류 — 짧고 비trimmable
  const cls = caseClassificationSection(c, redact);
  if (cls) sections.push({ ...cls, priority: PRIORITY.CRITICAL });

  // p3: 학생 기본정보
  const stu = studentsSection(c, redact);
  if (stu) sections.push(stu);

  return sections;
}

/**
 * 회기 1건을 한 줄(헤더) + 본문(요약 우선·폴백)으로 직렬화.
 * summary_short가 있으면 그걸, 없으면 session_content 첫 60자를 사용하며 fallbackCount를 누적.
 */
function formatSessionLine(s: Session, state: ProduceState): string {
  const { redact } = state;
  const head = `[${s.session_date} · ${s.category_large}${s.category_medium ? '/' + s.category_medium : ''}${s.session_number ? ` · ${s.session_number}회기` : ''}]`;
  const summary = (s.summary_short || '').trim();
  if (summary && s.summary_status === 'done') {
    return `${head}\n${redact.redact(summary)}`;
  }
  // 폴백: 본문 첫 60자 + 카운트 누적.
  const body = (s.session_content || '').trim();
  if (!body) return `${head}\n(본문 없음)`;
  state.fallbackCount += 1;
  const head_ = body.slice(0, FALLBACK_CONTENT_CHARS).replace(/\s+\S*$/, '');
  const ellipsis = body.length > FALLBACK_CONTENT_CHARS ? '…' : '';
  return `${head}\n${redact.redact(head_ + ellipsis)}`;
}

/** 개념화가 최신 회기보다 더 최근에 갱신됐는지 (D-2 판정). */
function isConceptualizationFresh(
  concept: ReturnType<typeof getConceptualization>,
  sessions: Session[],
): boolean {
  if (!concept) return false;
  const sectionMap = (concept.sections ?? {}) as Record<string, string>;
  const hasContent = Object.values(sectionMap).some((v) => v && v.trim());
  if (!hasContent) return false;
  if (sessions.length === 0) return true; // 회기 없으면 그냥 최신
  const conceptDate = (concept.updated_at || '').slice(0, 10);
  if (!conceptDate) return false;
  // sessions는 session_date DESC 정렬이므로 [0]이 최신.
  const lastSessionDate = sessions[0].session_date;
  return conceptDate >= lastSessionDate;
}

/** 개념화 본문을 섹션별 헤더와 함께 직렬화. */
function renderConceptualizationBody(
  concept: NonNullable<ReturnType<typeof getConceptualization>>,
  redact: RedactContext,
): string {
  const sectionMap = (concept.sections ?? {}) as Record<string, string>;
  const tpl = getTemplateByType(concept.template_type);
  const labelByKey: Record<string, string> = {};
  if (tpl) {
    for (const s of tpl.sections) labelByKey[s.key] = s.label;
  }
  const lines: string[] = [];
  for (const [k, v] of Object.entries(sectionMap)) {
    const text = (v || '').trim();
    if (!text) continue;
    const label = labelByKey[k] ?? k;
    lines.push(`### ${label}\n${redact.redact(text)}`);
  }
  return lines.join('\n\n');
}

// ─── case-form ──────────────────────────────────────────────────────────────

async function produceCaseForm(req: ContextRequest, state: ProduceState): Promise<ContextSection[]> {
  const { redact } = state;
  const sections: ContextSection[] = [];
  const c = getCaseById(req.caseId);
  // case-form은 사례 신규 작성 단계일 수도 있어 case가 없을 수 있음.
  // 그 경우엔 draft만 노출.
  if (c) registerCasePeople(c, redact);

  // p1: draft (사례 폼 필드)
  sections.push(...draftSections(req.draft || {}, DRAFT_LABELS_CASE, redact, '사례 초안'));

  if (c) {
    const cls = caseClassificationSection(c, redact);
    if (cls) sections.push({ ...cls, priority: PRIORITY.CORE });

    const stu = studentsSection(c, redact);
    if (stu) sections.push({ ...stu, priority: PRIORITY.SUPPORT });
  }

  return sections;
}

// ─── conceptualization ─────────────────────────────────────────────────────

async function produceConceptualization(req: ContextRequest, state: ProduceState): Promise<ContextSection[]> {
  const { redact } = state;
  const sections: ContextSection[] = [];
  const c = getCaseById(req.caseId);
  if (!c) return [];
  registerCasePeople(c, redact);

  // p1 비trimmable: 사례 기본정보
  const baseBits: string[] = [];
  baseBits.push(`사례번호: ${c.case_number || '-'}`);
  if (c.main_complaint?.trim()) baseBits.push(`주호소: ${redact.redact(c.main_complaint.trim())}`);
  if (c.counseling_goal?.trim()) baseBits.push(`상담 목표: ${redact.redact(c.counseling_goal.trim())}`);
  sections.push({
    label: '사례 기본정보',
    text: baseBits.join('\n'),
    priority: PRIORITY.CRITICAL,
    trimmable: false,
  });

  // p1 비trimmable: 선택된 양식의 섹션 구조 (LLM이 동일한 key로 응답하도록)
  if (req.templateType) {
    const tpl = getTemplateByType(req.templateType);
    if (tpl) {
      const struct = tpl.sections.map((s) => `- ${s.key}: ${s.label}`).join('\n');
      sections.push({
        label: `선택 양식 (${tpl.label}) 섹션 구조`,
        text: struct,
        priority: PRIORITY.CRITICAL,
        trimmable: false,
      });
    }
  }

  // p2: 전체 회기 요약 (오래된 것부터 절단되도록 ContextBuilder가 trimMiddle 처리)
  // D-1: summary_short가 있으면 그걸, 없으면 본문 첫 60자(폴백, fallbackCount 누적).
  const sessions = getSessionsByCaseId(req.caseId);
  if (sessions.length > 0) {
    // session_date DESC → 우선순위가 최근 회기. 직렬화는 시간순(오래된 → 최근)이 자연스러움.
    const ordered = [...sessions].reverse();
    const lines = ordered.map((s) => formatSessionLine(s, state));
    sections.push({
      label: '전체 회기 요약',
      text: lines.join('\n\n'),
      priority: PRIORITY.CORE,
      trimmable: true,
    });
  }

  // p3: 이미 작성된 개념화 섹션 (있을 경우)
  const concept = getConceptualization(req.caseId);
  // `concept.sections`는 Record<string, string> 이지만 lib/queries/conceptualizations 가
  // src/types로 import 되어 있어 메인 측 tsconfig에서 unknown으로 떨어진다. 명시 캐스팅.
  const conceptSections = (concept?.sections ?? {}) as Record<string, string>;
  if (concept && Object.keys(conceptSections).length > 0) {
    const lines = Object.entries(conceptSections)
      .filter(([, v]) => v && v.trim())
      .map(([k, v]) => `### ${k}\n${redact.redact(v.trim())}`);
    if (lines.length > 0) {
      sections.push({
        label: '작성된 개념화 (참고)',
        text: lines.join('\n\n'),
        priority: PRIORITY.SUPPORT,
        trimmable: true,
      });
    }
  }

  // p1 비trimmable: draft (사용자가 폼에서 작성 중이던 값이 있다면 우선)
  const draft = req.draft || {};
  const tpl = req.templateType ? getTemplateByType(req.templateType) : undefined;
  const labelMap: Record<string, string> = {};
  if (tpl) {
    for (const s of tpl.sections) labelMap[s.key] = `개념화 초안 (${s.label})`;
  }
  sections.push(...draftSections(draft, labelMap, redact, '개념화 초안'));

  return sections;
}

// ─── report-block ──────────────────────────────────────────────────────────

async function produceReportBlock(req: ContextRequest, state: ProduceState): Promise<ContextSection[]> {
  const { redact } = state;
  const sections: ContextSection[] = [];

  // p1: 블록 메타 (보고서 종류, 블록 종류)
  const meta = req.meta || {};
  const metaBits: string[] = [];
  for (const [k, v] of Object.entries(meta)) {
    if (v == null) continue;
    metaBits.push(`${k}: ${typeof v === 'string' ? v : JSON.stringify(v)}`);
  }
  if (metaBits.length > 0) {
    sections.push({
      label: '보고서 블록 메타',
      text: metaBits.join('\n'),
      priority: PRIORITY.CRITICAL,
      trimmable: false,
    });
  }

  // p2: 통계 결과 (draft.statistics 또는 meta.statistics)
  const stats = req.draft?.statistics || (typeof meta.statistics === 'string' ? meta.statistics : undefined);
  if (stats && stats.trim()) {
    sections.push({
      label: '통계 결과',
      text: redact.redact(stats),
      priority: PRIORITY.CORE,
      trimmable: true,
    });
  }

  // p3: 사용자 메모 (draft.userNotes)
  if (req.draft?.userNotes?.trim()) {
    sections.push({
      label: '사용자 메모',
      text: redact.redact(req.draft.userNotes),
      priority: PRIORITY.SUPPORT,
      trimmable: true,
    });
  }

  // p3: 그 외 draft 필드
  for (const [k, v] of Object.entries(req.draft || {})) {
    if (k === 'statistics' || k === 'userNotes') continue;
    if (!v || !v.trim()) continue;
    sections.push({
      label: `보고서 블록 초안 (${k})`,
      text: redact.redact(v),
      priority: PRIORITY.SUPPORT,
      trimmable: true,
    });
  }

  return sections;
}

// 헬퍼 노출 (테스트·디버그용)
export { trimMiddle };
// 의도적 미사용 경고 회피 (sessionById 직접 호출은 향후 단일 세션 fetch 변형에서 사용)
void getSessionById;
void DRAFT_LABELS_CONCEPT;
