/**
 * 모델 경로·상태 관리. 다운로드는 워커가 수행하고 결과 경로만 받는다.
 */

import fs from 'fs';
import path from 'path';
import { app } from 'electron';
import type { ModelDescriptor, ModelState } from './types';

/**
 * 기본 모델 디스크립터.
 * Phase 1 검증용으로는 즉시 받을 수 있는 nano-2.1b-instruct GGUF를 기본값으로 사용.
 * 최종 배포 모델(kanana-1.5-2.1b-instruct-2505 GGUF 변환본)은 사용자 결정 후 교체.
 * 사용자가 직접 GGUF 파일을 USB 등으로 가져다 둘 수도 있다(아래 scan 동작).
 */
export const DEFAULT_MODEL: ModelDescriptor = {
  uri: 'hf:DevQuasar/kakaocorp.kanana-nano-2.1b-instruct-GGUF:Q4_K_M',
  label: 'Kanana Nano 2.1B Instruct (Q4_K_M)',
  fileName: 'kakaocorp.kanana-nano-2.1b-instruct.Q4_K_M.gguf',
};

/** 모델 저장 디렉토리. 첫 사용 시 자동 생성. */
export function getModelsDir(): string {
  const dir = path.join(app.getPath('userData'), 'models');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

/** userData/models/ 안에서 첫 번째 .gguf 파일을 찾는다. */
export function findInstalledModel(): { path: string; sizeBytes: number } | null {
  const dir = getModelsDir();
  let entries: string[];
  try {
    entries = fs.readdirSync(dir);
  } catch {
    return null;
  }
  for (const name of entries) {
    if (!name.toLowerCase().endsWith('.gguf')) continue;
    const full = path.join(dir, name);
    try {
      const stat = fs.statSync(full);
      if (stat.isFile() && stat.size > 0) {
        return { path: full, sizeBytes: stat.size };
      }
    } catch {
      /* continue */
    }
  }
  return null;
}

export interface ResolvedModelState {
  state: ModelState;
  path?: string;
  sizeBytes?: number;
}

/** 디스크 상태에 기반한 모델 상태 (downloading은 ai-service가 별도 추적). */
export function resolveModelStateFromDisk(): ResolvedModelState {
  const found = findInstalledModel();
  if (!found) return { state: 'absent' };
  return { state: 'ready', path: found.path, sizeBytes: found.sizeBytes };
}
