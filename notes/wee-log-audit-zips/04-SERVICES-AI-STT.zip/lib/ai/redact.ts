/**
 * PII 최소화 (redact).
 *
 * **방침**:
 * 1. **요청 단위 매핑**만 유지 — 전역 매핑은 메모리 누수 위험. 한 ContextRequest를
 *    빌드하는 동안 같은 이름이 여러 섹션에 등장하면 같은 이니셜로 일관 치환.
 * 2. **결정론적**: 같은 요청 안에서 등장 순서대로 `학생 A`, `학생 B`, … `보호자 A`, …
 *    로 부여. (해시 기반은 충돌 + 재현성 떨어져 미채택)
 * 3. **온디바이스라도 적용** — Phase 6 원격 백엔드 전환 시 PII 노출 차단의 사전 정비이자,
 *    이름/연락처가 토큰 예산을 갉아먹는 것 방지.
 * 4. **internal_notes 자체는 별도 정책** — `context-sources`에서 기본 제외. 사용자가
 *    그 필드에 "다듬기"를 호출한 경우에만 redact 후 포함.
 */

export interface RedactPersonInput {
  /** 결정론적 우선순위 부여를 위해 등장 순서대로 등록한다. */
  name: string;
  /** 'student' | 'guardian' | 'teacher' | 'referrer' */
  role: PersonRole;
}

export type PersonRole = 'student' | 'guardian' | 'teacher' | 'referrer';

const ROLE_LABEL: Record<PersonRole, string> = {
  student: '학생',
  guardian: '보호자',
  teacher: '교사',
  referrer: '의뢰인',
};

/** A, B, C, …, Z, AA, AB, … (Excel 컬럼 방식) */
function toAlphaIndex(n: number): string {
  let result = '';
  let i = n;
  while (i >= 0) {
    result = String.fromCharCode(65 + (i % 26)) + result;
    i = Math.floor(i / 26) - 1;
  }
  return result;
}

/**
 * 한 요청 안에서 일관된 이름→이니셜 매핑을 유지하는 컨텍스트.
 *
 * 사용 패턴:
 * ```
 * const ctx = createRedactContext();
 * for (const s of students) ctx.registerPerson(s.name, 'student');
 * for (const s of sessions) text = ctx.redact(text);
 * ```
 *
 * **등록 시점이 중요**: 사례 학생을 먼저 등록해야 `학생 A`가 일관되게 부여된다.
 * 등록 전 텍스트에서 이름이 처음 등장하면 그 등장 순서대로 자동 등록되므로 큰 사고는
 * 아니지만, 명시 등록이 예측 가능성 측면에서 권장.
 */
export interface RedactContext {
  /** 인물 등록 (멱등). 등록 순서대로 이니셜 부여. */
  registerPerson(name: string, role: PersonRole): void;
  /** 텍스트의 PII를 치환해 반환. */
  redact(text: string): string;
  /** 디버그·검증용 — 매핑 스냅샷. */
  getMapping(): Record<string, string>;
}

/** 학교명 패턴: "OO초/중/고/여중/여고/대학교" 등. */
const SCHOOL_RE = /[가-힣A-Za-z0-9]{1,12}(?:초등학교|중학교|고등학교|여자중학교|여자고등학교|여중|여고|대학교|특수학교|국제학교)/g;
/** 한국 전화번호: 010-1234-5678 / 010 1234 5678 / 01012345678 / (02)123-4567 등. */
const PHONE_RE = /(?:\+?82[-\s]?|0)(?:\d{1,2})[-.\s]?\d{3,4}[-.\s]?\d{4}/g;
/** 주민등록번호: 7?0101-1234567 (앞 6 + 뒤 7). */
const RRN_RE = /\b\d{6}[-\s]?\d{7}\b/g;
/** 이메일. */
const EMAIL_RE = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
/** 도로명 주소 일부 (시/구/동 + 번지·길). 보수적으로 길이 제한. */
const ADDRESS_RE = /[가-힣]{1,8}(?:특별시|광역시|특별자치시|특별자치도|도)\s?[가-힣\s\d\-]{2,40}(?:구|군|시|동|로|길)\s?\d+(?:[-\s]?\d+)?/g;
/** 한글 이름 후보 (2~4자, 단독 등장). 등록된 이름에만 적용하므로 별도 정규식 사용 X. */

export function createRedactContext(): RedactContext {
  const mapping = new Map<string, string>();
  const counters: Record<PersonRole, number> = {
    student: 0,
    guardian: 0,
    teacher: 0,
    referrer: 0,
  };

  function assign(name: string, role: PersonRole): string {
    const trimmed = name.trim();
    if (!trimmed) return name;
    const existing = mapping.get(trimmed);
    if (existing) return existing;
    const label = `${ROLE_LABEL[role]} ${toAlphaIndex(counters[role])}`;
    counters[role] += 1;
    mapping.set(trimmed, label);
    return label;
  }

  return {
    registerPerson(name, role) {
      if (name && name.trim()) assign(name, role);
    },

    redact(text) {
      if (!text) return text;
      let out = text;

      // 1) 등록된 인물 이름 치환 — 길이 내림차순(긴 이름 우선)으로 부분치환 사고 방지.
      const names = [...mapping.keys()].sort((a, b) => b.length - a.length);
      for (const name of names) {
        const label = mapping.get(name)!;
        // 단순 split/join — 정규식 escape 부담 회피, 부분 매칭 그대로 두는 게 안전한 쪽
        // (한글 이름 가운데 "민수"가 "강민수"의 일부일 때, 등록된 게 "강민수"라면 위에서
        // 먼저 처리되므로 안전. 그 외에는 사람 이름 부분 매칭은 발생 가능성 낮음).
        if (out.includes(name)) out = out.split(name).join(label);
      }

      // 2) 학교명.
      out = out.replace(SCHOOL_RE, '[학교]');

      // 3) 주민번호 (먼저 — 전화번호 정규식이 일부를 잡지 않도록 순서 중요).
      out = out.replace(RRN_RE, '[주민번호]');

      // 4) 전화번호.
      out = out.replace(PHONE_RE, '[전화번호]');

      // 5) 이메일.
      out = out.replace(EMAIL_RE, '[이메일]');

      // 6) 주소 (한국 행정구역 + 도로/동 + 번지).
      out = out.replace(ADDRESS_RE, '[주소]');

      return out;
    },

    getMapping() {
      const obj: Record<string, string> = {};
      for (const [k, v] of mapping) obj[k] = v;
      return obj;
    },
  };
}
