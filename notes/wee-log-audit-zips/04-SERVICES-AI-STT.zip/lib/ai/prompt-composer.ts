/**
 * 시스템 프롬프트 조립.
 *
 * 마크다운 파일을 `?raw` import 로 워커 번들에 인라인한다 (패키징 후 fs 경로 회피).
 * Vite는 `.md?raw` 를 기본 지원하지만, 이 모듈은 메인 측 빌드에서 호출되므로
 * `electron-vite` worker 빌드에서 동일하게 동작해야 한다.
 *
 * **결과 구조**:
 * ```
 * <BASE_SYSTEM>
 *
 * <TASK_PROMPT>
 *
 * ## 참고 정보 (상담 맥락)
 * <serializedContext>
 * ```
 *
 * `serializedContext`가 비어 있으면 "## 참고 정보" 블록을 생략한다 — 자유 질문(qa) 등 맥락이
 * 없을 수 있는 task에서 빈 헤더만 남기지 않기 위해.
 *
 * **refine/continue user 메시지**: 초안 텍스트는 시스템 프롬프트가 아니라 user 역할 메시지의
 * 주 피연산자로 전달해야 한다 (모델이 "다듬을 대상"을 명확히 인식). `composeUserMessage`가
 * task별로 user 텍스트를 만들어 준다.
 */

import type { AiTask } from './types';
import baseSystemRaw from './prompts/base-system.ko.md?raw';
import refineRaw from './prompts/task-refine.ko.md?raw';
import summarizeRaw from './prompts/task-summarize.ko.md?raw';
import continueRaw from './prompts/task-continue.ko.md?raw';
import conceptualizeRaw from './prompts/task-conceptualize.ko.md?raw';
import reportRaw from './prompts/task-report.ko.md?raw';
import qaRaw from './prompts/task-qa.ko.md?raw';
import sessionSummaryRaw from './prompts/task-session-summary.ko.md?raw';

const BASE_SYSTEM: string = baseSystemRaw;

const TASK_PROMPTS: Record<AiTask, string> = {
  refine: refineRaw,
  summarize: summarizeRaw,
  continue: continueRaw,
  conceptualize: conceptualizeRaw,
  report: reportRaw,
  qa: qaRaw,
  'session-summary': sessionSummaryRaw,
};

/** 시스템 프롬프트 본문 조립. */
export function composeSystemPrompt(task: AiTask, serializedContext: string): string {
  const parts: string[] = [BASE_SYSTEM.trim(), TASK_PROMPTS[task].trim()];
  const ctx = (serializedContext || '').trim();
  if (ctx) {
    parts.push(`## 참고 정보 (상담 맥락)\n\n${ctx}`);
  }
  return parts.join('\n\n');
}

/**
 * task별 user 메시지 조립.
 *
 * - `refine`/`continue`: 초안(userInput)이 주 피연산자. 라벨링해서 전달.
 * - `summarize`: selectionText 또는 userInput을 요약 대상으로 전달.
 * - `qa`: 사용자 질문을 그대로.
 * - `conceptualize`/`report`: 맥락에서 모두 끌어오므로 짧은 트리거 문구.
 *
 * `selectionText`가 주어지면 우선한다 (사용자가 선택한 영역만 처리).
 */
export interface UserMessageInput {
  task: AiTask;
  userInput?: string;
  selectionText?: string;
  /** 필드 의미/형식 힌트 — 본문 상단에 [지침] 한 줄로 박힘. */
  fieldHint?: string;
}

/** fieldHint가 있으면 본문 앞에 한 줄 박는다. 없으면 빈 문자열. */
function hintLine(hint?: string): string {
  const h = (hint || '').trim();
  return h ? `[지침: ${h}]\n\n` : '';
}

/** 본문 끝에도 한 번 더 강조 — 2.1B 모델의 lost-in-the-middle 방어. */
function hintReminder(hint?: string): string {
  const h = (hint || '').trim();
  return h ? `\n\n[다시 강조: ${h}. 본문만 한 번 출력, 헤더/머리말/맺음말 금지.]` : '';
}

export function composeUserMessage(input: UserMessageInput): string {
  const { task, fieldHint } = input;
  const draft = (input.selectionText || input.userInput || '').trim();
  const hint = hintLine(fieldHint);
  const reminder = hintReminder(fieldHint);

  switch (task) {
    case 'refine':
      return draft
        ? `${hint}다음 초안을 다듬어 주세요. 결과는 다듬은 본문만 출력합니다.\n\n---\n${draft}\n---${reminder}`
        : `${hint}다듬을 초안이 비어 있습니다. 맥락만으로 짧은 회기 기록 한 문단을 작성하세요.`;

    case 'continue':
      return draft
        ? `${hint}다음 본문 다음을 자연스럽게 이어 작성해 주세요. 원문은 다시 출력하지 않습니다.\n\n---\n${draft}\n---${reminder}`
        : `${hint}이어 쓸 본문이 비어 있습니다. 맥락을 바탕으로 짧은 도입 한 문단을 작성하세요.`;

    case 'summarize':
      return draft
        ? `${hint}다음 내용을 요약하세요.\n\n---\n${draft}\n---`
        : `${hint}제공된 사례 맥락 전체를 요약하세요.`;

    case 'qa':
      return hint + (draft || '제공된 맥락에서 가장 우선 검토할 사항을 한 문단으로 알려주세요.');

    case 'conceptualize':
      return `${hint}제공된 사례 맥락과 양식 섹션 구조를 바탕으로 사례개념화 초안을 JSON으로 작성하세요.`;

    case 'report':
      return `${hint}제공된 보고서 블록 메타와 통계 결과를 바탕으로 해당 블록 본문을 작성하세요.`;

    case 'session-summary':
      return draft
        ? `다음 회기 본문을 80자 한 줄로 압축하세요.\n\n---\n${draft}\n---`
        : '요약할 회기 본문이 비어 있습니다. 빈 문자열을 출력하지 말고 "(요약 불가)"라고 답하세요.';

    default: {
      // 타입 가드 — 새 task 추가 시 여기서 알림이 뜨도록.
      const _exhaustive: never = task;
      return _exhaustive;
    }
  }
}

/** 디버그·검증용 — BASE_SYSTEM과 TASK_PROMPTS 길이 측정에 사용. */
export function getRawPrompts(): { base: string; tasks: Record<AiTask, string> } {
  return { base: BASE_SYSTEM, tasks: TASK_PROMPTS };
}
