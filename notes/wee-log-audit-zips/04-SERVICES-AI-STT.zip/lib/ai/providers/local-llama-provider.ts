/**
 * node-llama-cpp 기반 로컬 추론 provider.
 * 워커(utility process) 전용. node-llama-cpp는 ESM-only이므로 dynamic import로 로드.
 */

import type {
  ChatMessage,
  GenerationOptions,
  GenerationResult,
  GenerationUsage,
  ProviderCapabilities,
} from '../types';
import type { LLMProvider, TokenSink } from './provider';

interface LocalConfig {
  modelPath: string;
  contextSize: number;
  threads?: number;
}

// node-llama-cpp 객체에 대한 느슨한 타입 (dynamic import이므로 any 회피 위함)
type NLC = {
  getLlama: (opts?: Record<string, unknown>) => Promise<{
    loadModel: (opts: { modelPath: string }) => Promise<LlamaModelLike>;
  }>;
  LlamaChatSession: new (opts: {
    contextSequence: LlamaSequenceLike;
    systemPrompt?: string;
  }) => LlamaChatSessionLike;
};

interface LlamaModelLike {
  createContext: (opts: {
    contextSize?: number;
    threads?: number;
  }) => Promise<LlamaContextLike>;
  tokenize: (text: string) => Uint32Array | number[];
  dispose: () => Promise<void>;
}

interface LlamaContextLike {
  getSequence: () => LlamaSequenceLike;
  contextSize: number;
  dispose: () => Promise<void>;
}

interface LlamaSequenceLike {
  clearHistory?: () => void;
}

interface LlamaChatSessionLike {
  prompt: (
    text: string,
    opts: {
      onTextChunk?: (chunk: string) => void;
      signal?: AbortSignal;
      maxTokens?: number;
      temperature?: number;
      topP?: number;
      customStopTriggers?: string[];
    },
  ) => Promise<string>;
}

let nlcModule: NLC | null = null;
async function loadNLC(): Promise<NLC> {
  if (nlcModule) return nlcModule;
  // CJS 빌드 안에서 ESM 모듈을 가져오기 위한 동적 import
  const mod = (await import('node-llama-cpp')) as unknown as NLC;
  nlcModule = mod;
  return mod;
}

export class LocalLlamaProvider implements LLMProvider {
  readonly id = 'local' as const;
  private cfg: LocalConfig;
  private model: LlamaModelLike | null = null;
  private context: LlamaContextLike | null = null;
  private sequence: LlamaSequenceLike | null = null;
  private capabilities: ProviderCapabilities | null = null;

  constructor(cfg: LocalConfig) {
    this.cfg = cfg;
  }

  async init(): Promise<void> {
    if (this.model) return;
    const { getLlama } = await loadNLC();
    const llama = await getLlama();
    this.model = await llama.loadModel({ modelPath: this.cfg.modelPath });
    this.context = await this.model.createContext({
      contextSize: this.cfg.contextSize,
      threads: this.cfg.threads,
    });
    this.sequence = this.context.getSequence();
    this.capabilities = {
      contextWindow: this.context.contextSize ?? this.cfg.contextSize,
      maxOutputTokens: Math.min(1024, Math.floor(this.cfg.contextSize / 2)),
    };
  }

  isReady(): boolean {
    return this.model !== null && this.sequence !== null;
  }

  async generate(
    messages: ChatMessage[],
    options: GenerationOptions,
    onToken: TokenSink,
    signal: AbortSignal,
  ): Promise<GenerationResult> {
    if (!this.model || !this.sequence) {
      throw new Error('Provider not initialized');
    }
    const { LlamaChatSession } = await loadNLC();

    // system 메시지는 systemPrompt로 모은다. Phase 1: history는 무시하고
    // 마지막 user 메시지만 prompt에 넣는다 (qa 멀티턴은 추후 setChatHistory로 확장).
    const systemPrompt = messages
      .filter((m) => m.role === 'system')
      .map((m) => m.content)
      .join('\n\n');
    const userMessages = messages.filter((m) => m.role !== 'system');
    const lastUser = userMessages[userMessages.length - 1];
    if (!lastUser || lastUser.role !== 'user') {
      throw new Error('마지막 user 메시지가 필요합니다.');
    }

    // 시퀀스 KV 캐시 초기화 (요청 간 독립성 보장)
    if (this.sequence.clearHistory) this.sequence.clearHistory();

    const session = new LlamaChatSession({
      contextSequence: this.sequence,
      systemPrompt: systemPrompt || undefined,
    });

    let collected = '';
    let aborted = false;
    let length = false;

    try {
      const text = await session.prompt(lastUser.content, {
        onTextChunk: (chunk: string) => {
          collected += chunk;
          onToken(chunk);
        },
        signal,
        maxTokens: options.maxTokens,
        temperature: options.temperature,
        topP: options.topP,
        customStopTriggers: options.stopSequences,
      });
      // 일부 버전은 prompt 종료 후 누적과 반환값이 다를 수 있어 최종 텍스트를 우선한다
      collected = text ?? collected;
    } catch (err: unknown) {
      if (signal.aborted) {
        aborted = true;
      } else {
        throw err;
      }
    }

    if (options.maxTokens && collected.length > 0) {
      // node-llama-cpp는 토큰 종료 사유를 prompt 반환만으로는 알기 어려움.
      // 대략적인 추정: 최대치 근접이면 length, 아니면 stop.
      const approx = await this.countTokens(collected);
      if (approx >= options.maxTokens - 1) length = true;
    }

    const finishReason = aborted ? 'aborted' : length ? 'length' : 'stop';
    const promptText = (systemPrompt ? systemPrompt + '\n\n' : '') + lastUser.content;
    const usage: GenerationUsage = {
      promptTokens: await this.countTokens(promptText),
      completionTokens: await this.countTokens(collected),
    };

    return { text: collected, finishReason, usage };
  }

  async countTokens(text: string): Promise<number> {
    if (!this.model) return Math.ceil(text.length / 2);
    try {
      const tokens = this.model.tokenize(text);
      return (tokens as { length: number }).length;
    } catch {
      return Math.ceil(text.length / 2);
    }
  }

  getCapabilities(): ProviderCapabilities {
    if (!this.capabilities) {
      // init 전엔 cfg 값으로 보수적 응답
      return {
        contextWindow: this.cfg.contextSize,
        maxOutputTokens: Math.min(1024, Math.floor(this.cfg.contextSize / 2)),
      };
    }
    return this.capabilities;
  }

  async dispose(): Promise<void> {
    try {
      if (this.context) await this.context.dispose();
    } catch {
      /* noop */
    }
    try {
      if (this.model) await this.model.dispose();
    } catch {
      /* noop */
    }
    this.model = null;
    this.context = null;
    this.sequence = null;
    this.capabilities = null;
  }
}
