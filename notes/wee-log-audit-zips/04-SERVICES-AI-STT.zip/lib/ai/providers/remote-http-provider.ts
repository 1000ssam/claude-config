/**
 * OpenAI 호환 HTTP 엔드포인트 provider.
 * 추후 국내 자체 서버/서버리스에 띄운 추론 엔드포인트와 연결한다.
 * 해외 클라우드 SaaS는 대상이 아니다.
 *
 * Phase 1: 인터페이스 완성 + SSE 스트리밍 파서. 실제 검증은 Phase 6.
 */

import type {
  ChatMessage,
  GenerationOptions,
  GenerationResult,
  GenerationUsage,
  ProviderCapabilities,
} from '../types';
import type { LLMProvider, TokenSink } from './provider';

interface RemoteConfig {
  baseUrl: string;
  apiKey?: string;
  model: string;
  contextWindow: number;
}

export class RemoteHttpProvider implements LLMProvider {
  readonly id = 'remote' as const;
  private cfg: RemoteConfig;
  private ready = false;
  private capabilities: ProviderCapabilities;

  constructor(cfg: RemoteConfig) {
    this.cfg = cfg;
    this.capabilities = {
      contextWindow: cfg.contextWindow,
      maxOutputTokens: Math.min(2048, Math.floor(cfg.contextWindow / 2)),
    };
  }

  async init(): Promise<void> {
    // 간단한 헬스 체크: /v1/models를 시도하고 실패해도 generate 시점 오류로 미룬다.
    try {
      const url = this.url('/v1/models');
      await fetch(url, { headers: this.headers() });
    } catch {
      /* 엔드포인트 검증 실패는 init 단계에서 강제하지 않음 */
    }
    this.ready = true;
  }

  isReady(): boolean {
    return this.ready;
  }

  async generate(
    messages: ChatMessage[],
    options: GenerationOptions,
    onToken: TokenSink,
    signal: AbortSignal,
  ): Promise<GenerationResult> {
    const url = this.url('/v1/chat/completions');
    const body = {
      model: this.cfg.model,
      messages: messages.map((m) => ({ role: m.role, content: m.content })),
      stream: true,
      temperature: options.temperature,
      top_p: options.topP,
      max_tokens: options.maxTokens,
      stop: options.stopSequences,
    };

    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...this.headers() },
      body: JSON.stringify(body),
      signal,
    });

    if (!res.ok || !res.body) {
      const text = await res.text().catch(() => '');
      throw new Error(`원격 추론 서버 응답 실패 (${res.status}): ${text.slice(0, 200)}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let collected = '';
    let aborted = false;
    let finishReason: 'stop' | 'length' | 'aborted' | 'error' = 'stop';
    let buffer = '';

    try {
      // SSE 라인 파싱: "data: {json}" 또는 "data: [DONE]"
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const raw of lines) {
          const line = raw.trim();
          if (!line.startsWith('data:')) continue;
          const payload = line.slice(5).trim();
          if (payload === '[DONE]') break;
          try {
            const obj = JSON.parse(payload) as {
              choices?: { delta?: { content?: string }; finish_reason?: string }[];
            };
            const delta = obj.choices?.[0]?.delta?.content;
            const reason = obj.choices?.[0]?.finish_reason;
            if (typeof delta === 'string' && delta.length > 0) {
              collected += delta;
              onToken(delta);
            }
            if (reason === 'length') finishReason = 'length';
            else if (reason === 'stop') finishReason = 'stop';
          } catch {
            /* malformed chunk — 무시 */
          }
        }
      }
    } catch (err: unknown) {
      if (signal.aborted) {
        aborted = true;
        finishReason = 'aborted';
      } else {
        throw err;
      }
    }

    const promptText = messages.map((m) => m.content).join('\n');
    const usage: GenerationUsage = {
      promptTokens: Math.ceil(promptText.length / 3),
      completionTokens: Math.ceil(collected.length / 3),
    };

    return {
      text: collected,
      finishReason: aborted ? 'aborted' : finishReason,
      usage,
    };
  }

  async countTokens(text: string): Promise<number> {
    // 원격은 글자수 휴리스틱 (한국어 평균 ~3자/토큰)
    return Math.ceil(text.length / 3);
  }

  getCapabilities(): ProviderCapabilities {
    return this.capabilities;
  }

  async dispose(): Promise<void> {
    this.ready = false;
  }

  private url(path: string): string {
    const base = this.cfg.baseUrl.replace(/\/+$/, '');
    return `${base}${path}`;
  }

  private headers(): Record<string, string> {
    return this.cfg.apiKey ? { Authorization: `Bearer ${this.cfg.apiKey}` } : {};
  }
}
