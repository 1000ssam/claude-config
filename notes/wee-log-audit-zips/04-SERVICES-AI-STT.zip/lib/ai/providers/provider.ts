/**
 * LLM Provider 인터페이스.
 * 로컬(node-llama-cpp) ↔ 원격(국내 OpenAI 호환 HTTP) 교체 가능하게 추상화한다.
 *
 * 이 파일은 타입·인터페이스만 담는다 — 메인 프로세스와 워커 양쪽에서 안전하게 import.
 * 구현체(local-llama-provider, remote-http-provider)는 워커 전용이다.
 */

import type {
  ChatMessage,
  GenerationOptions,
  GenerationResult,
  ProviderCapabilities,
  ProviderConfig,
} from '../types';

export type TokenSink = (token: string) => void;

export interface LLMProvider {
  readonly id: 'local' | 'remote';
  /** 모델 로드/엔드포인트 검증. 멱등. */
  init(): Promise<void>;
  isReady(): boolean;
  /** 스트리밍 생성. 토큰은 onToken으로 push, 완료 시 결과 반환. */
  generate(
    messages: ChatMessage[],
    options: GenerationOptions,
    onToken: TokenSink,
    signal: AbortSignal,
  ): Promise<GenerationResult>;
  /** 토큰 카운트 (예산 계산용). 로컬: 모델 토크나이저, 원격: 글자수 휴리스틱. */
  countTokens(text: string): Promise<number>;
  /** 컨텍스트 윈도우·최대 출력 토큰. init() 후 호출. */
  getCapabilities(): ProviderCapabilities;
  dispose(): Promise<void>;
}

export type { ProviderConfig };
