/**
 * Provider 팩토리. 설정값으로 LocalLlamaProvider/RemoteHttpProvider를 만든다.
 * 워커(utility process) 전용 — main 프로세스에서 호출하지 않는다.
 */

import type { ProviderConfig } from '../types';
import type { LLMProvider } from './provider';
import { LocalLlamaProvider } from './local-llama-provider';
import { RemoteHttpProvider } from './remote-http-provider';

export function createProvider(config: ProviderConfig): LLMProvider {
  if (config.backend === 'local') {
    return new LocalLlamaProvider({
      modelPath: config.modelPath,
      contextSize: config.contextSize,
      threads: config.threads,
    });
  }
  return new RemoteHttpProvider({
    baseUrl: config.baseUrl,
    apiKey: config.apiKey,
    model: config.model,
    contextWindow: config.contextWindow,
  });
}

export type { LLMProvider };
