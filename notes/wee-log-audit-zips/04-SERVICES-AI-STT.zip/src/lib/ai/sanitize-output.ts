/**
 * AI 생성 결과에서 모델이 자주 붙이는 메타 텍스트(머리말·맺음말·코드펜스·따옴표)를 제거.
 *
 * 프롬프트로 강제하지만 2.1B 모델은 자주 어긴다 — 후처리로 견고하게.
 *
 * 정책:
 * - 코드펜스 ```...``` 양 끝 제거
 * - 머리말: "다듬은 결과:", "수정본:", "다음과 같이 다듬었습니다.", "요약:" 등
 * - 맺음말: "어떠신가요?", "도움이 되었으면 합니다.", "참고하시기 바랍니다." 등
 * - 결과 전체를 감싼 따옴표("..." / '...' / "..." 등)
 * - 앞뒤 빈 줄 정리
 *
 * refine/summarize는 모델이 "[정답] → 구분선(---) → 설명 → 라벨 → [정답 반복]" 식으로
 * 본문 뒤에 사족을 폭발시키는 패턴이 잦다. task를 알면 아래 두 규칙을 추가로 적용한다
 * (둘 다 순서 무관 — 메타가 본문 앞/뒤 어디에 오든 방어):
 *   1. 최종 라벨("다듬은 본문:") 뒤 본문 추출 (뒤 본문이 실질적일 때만)
 *   2. 구분선 기준 블록 분리 후 메타 블록만 제거
 * 그 외 task(continue/qa/conceptualize/report)는 기존 보수적 파이프라인만 적용 — 회귀 방지.
 *
 * append 모드(continue task)는 원본 뒤에 이어 붙이므로, 첫 줄에 "이어서:" 같은 메타가
 * 있으면 제거하되 본문은 유지.
 */

const LEADING_META_PATTERNS = [
  // "다음 초안을 다듬은 결과는 다음과 같습니다:" / "다듬은 본문:" / "수정 결과:" 등.
  // 첫 줄 안에서 "(...)다듬은 (결과|본문|문장|내용)(...)다음과 같습니다[:.]?" 또는 "(...)다듬은 (결과|본문|문장|내용)[:.]?" 모두 매치.
  /^[^\n]*?(다듬은\s*(결과|본문|문장|내용))[^\n]*?(다음과\s*같(습니다|음)|입니다)[:：.]?\s*/,
  /^[^\n]*?(다듬은\s*(결과|본문|문장|내용))[:：]\s*/,
  /^[^\n]*?(수정\s*(결과|본문)|수정본)[:：]\s*/,
  /^[^\n]*?(다음과|아래와)\s*같이\s*다듬(었습니다|어\s*봤습니다|어\s*보겠습니다)[:：.]?\s*/,
  /^(요약|회기\s*요약|회기요약|정리|핵심)[:：]\s*/,
  /^(이어서|이어\s*쓰면|다음과\s*같이\s*이어서)[:：\s]+/,
  /^(답변|응답)[:：]\s*/,
];

/**
 * 모델이 본문 중간에 박는 라벨 패턴. 줄바꿈 없이 "원문 echo + 라벨 + 새 본문" 식으로
 * 나오는 케이스를 잡는다. 라벨 이전 텍스트는 echo로 간주하고 라벨 포함 잘라낸다.
 */
const INLINE_LABEL_PATTERNS = [
  /다듬은\s*(결과|본문|문장|내용)[:：]\s*/,
  /수정본[:：]\s*/,
  /수정\s*결과[:：]\s*/,
  /다음과\s*같이\s*다듬었습니다[:：.]?\s*/,
  /아래와\s*같이\s*다듬었습니다[:：.]?\s*/,
];

const TRAILING_META_PATTERNS = [
  /(어떠신가요\??|어떻습니까\??|도움이\s*되었으면\s*합니다\.?|참고하시기\s*바랍니다\.?|확인\s*부탁드립니다\.?|문의가\s*있으면.*?[.?!])\s*$/,
];

/**
 * "이렇게 다듬은 본문은 다음과 같습니다:" 같은 라벨이 본문 중간/끝에 등장하면 그 라벨 이후
 * 부분이 보통 같은 본문의 재출력이다. 라벨 이전(첫 번째 본문)만 채택.
 */
const REPEAT_LABEL_PATTERNS = [
  /이렇게\s*다듬은\s*본문[은이가]?\s*다음과\s*같습니다[:：.]?/,
  /위(와|처럼)?\s*같이\s*다듬어?\s*(봤습니다|보겠습니다)[:：.]?/,
  /다음과\s*같이\s*다듬어?\s*(봤습니다|보겠습니다)[:：.]?/,
  /최종\s*결과[:：]/,
  /정리하면\s*다음과\s*같(습니다|음)[:：.]?/,
];

// ── refine/summarize 전용 강한 규칙 ──────────────────────────────────────────

/** 모델이 "최종 답은 여기" 의미로 붙이는 라벨 — 이 라벨 뒤 본문이 모델이 의도한 결과. */
const FINAL_ANSWER_LABEL =
  /(?:다듬은\s*(?:결과|본문|문장|내용)|수정\s*(?:결과|본문)|수정본|최종\s*(?:결과|본문|다듬은\s*본문))\s*[:：]/g;

/** 수평 구분선만 있는 줄(`---`, `***`, `===`, `___`). */
const SEPARATOR_LINE = /^\s*([-*=_])\1{2,}\s*$/;

/**
 * 블록 전체가 '편집 행위를 설명하는 경어체 메타 문장'으로 끝나는지.
 * 상담 기록 본문은 명사형 어미(~함/~음/~됨)라 이 경어체 종결이 본문일 가능성이 낮다.
 * 끝(`$`)에 앵커해 "본문 중간에 우연히 포함된 인용" 오탐을 줄인다.
 * (예: `...라고 '도움이 되었으면 합니다'라고 말함`은 끝이 "말함"이라 메타로 보지 않음)
 */
const META_BLOCK_END =
  /(다듬어\s*보겠습니다|다듬겠습니다|수정하겠습니다|보겠습니다|봤습니다|보았습니다|드리겠습니다|다음과\s*같습니다|사용하고\s*있습니다|정리하면|어떠신가요|어떻습니까|도움이\s*되었으면\s*합니다|참고하시기\s*바랍니다|확인\s*부탁(?:드립니다|드려요)?)[\s.。!?]*$/;

/** 라벨만 있고 본문이 없는 블록(예: "다듬은 본문:"). */
const PURE_LABEL_BLOCK =
  /^\s*(?:다듬은\s*(?:결과|본문|문장|내용)|수정\s*(?:결과|본문)|수정본|최종\s*(?:결과|본문))\s*[:：]?\s*$/;

// ── refine 환각-폭발 가드 (튜닝 상수) ─────────────────────────────────────────
/**
 * refine은 '원문 변환'이지 '신규 생성'이 아니다. 2.1B 모델은 짧은 원문에 없는 사실을
 * 폭발적으로 지어내는 관용이 있다(예: "진로 이야기함"(7자) → 138자 날조). 출력이 입력 대비
 * 아래 두 임계를 *동시에* 넘으면 환각 폭발로 보고 **원문을 그대로 보존**한다.
 * (다듬기 손실 < 없는 임상 사실 주입. 경미한 환각은 비율이 낮아 못 잡음 — temp/모델 레버.)
 */
const REFINE_MAX_EXPANSION_RATIO = 2.2; // 출력/입력 공백제외 글자수 비
const REFINE_MAX_ABS_GROWTH = 40; // 절대 증가 글자수

/** 공백 제외 글자수. */
function denseLen(s: string): number {
  return s.replace(/\s/g, '').length;
}

/**
 * refine 결과가 입력 대비 과팽창했으면 원문(input)을 그대로 돌려준다(환각 폭발 차단).
 * task가 refine이 아니거나 input이 없으면 cleaned 그대로.
 */
function guardRefineExpansion(cleaned: string, input?: string): string {
  const src = (input || '').trim();
  if (!src) return cleaned;
  const inLen = denseLen(src);
  const outLen = denseLen(cleaned);
  if (inLen === 0) return cleaned;
  if (outLen > inLen * REFINE_MAX_EXPANSION_RATIO && outLen - inLen > REFINE_MAX_ABS_GROWTH) {
    return src; // 안전한 무변경
  }
  return cleaned;
}

/** 코드펜스(```lang ... ```) 양 끝 제거. */
function stripCodeFence(text: string): string {
  let t = text.trim();
  if (t.startsWith('```')) {
    const firstNL = t.indexOf('\n');
    if (firstNL > -1) t = t.slice(firstNL + 1);
  }
  if (t.endsWith('```')) {
    t = t.slice(0, t.length - 3);
  }
  return t.trim();
}

/** 텍스트 전체를 감싼 따옴표 한 쌍 제거. */
function stripWrappingQuotes(text: string): string {
  const t = text.trim();
  const m = t.match(/^([`"'“”‘’「『])([\s\S]*)([`"'”’」』])$/);
  if (m) return m[2].trim();
  return t;
}

/** 첫 줄의 머리말 패턴 제거. */
function stripLeadingMeta(text: string): string {
  let t = text.trimStart();
  for (const re of LEADING_META_PATTERNS) {
    if (re.test(t)) {
      t = t.replace(re, '');
      break;
    }
  }
  return t;
}

/**
 * 본문 중간에 박힌 "다듬은 본문:" 같은 라벨이 있으면 라벨 이전 부분(원문 echo)을 통째로
 * 잘라내고 라벨 이후 부분만 남긴다. 라벨이 본문의 첫 80자 이내에 등장할 때만 적용 —
 * 진짜 본문 한복판에 우연히 비슷한 표현이 들어간 케이스 보호.
 */
function stripInlineEchoLabel(text: string): string {
  for (const re of INLINE_LABEL_PATTERNS) {
    const m = text.match(re);
    if (m && m.index !== undefined && m.index <= 80) {
      return text.slice(m.index + m[0].length);
    }
  }
  return text;
}

/**
 * "이렇게 다듬은 본문은 다음과 같습니다:" 같은 라벨이 본문 후반에 등장하면 그 라벨 이후는
 * 보통 같은 본문의 재출력 — 라벨 이전(첫 출력)만 남긴다.
 */
function stripRepeatLabel(text: string): string {
  for (const re of REPEAT_LABEL_PATTERNS) {
    const m = text.match(re);
    if (m && m.index !== undefined && m.index > 0) {
      return text.slice(0, m.index).trimEnd();
    }
  }
  return text;
}

/**
 * 마크다운 헤더(`#`, `##`, `###`)로 시작하는 줄 제거.
 * 모델이 "### 관찰", "### 상호작용" 같은 임의 섹션 라벨을 추가하는 케이스 방어.
 * 헤더 줄만 제거 — 그 아래 본문 내용은 유지.
 */
function stripMarkdownHeaders(text: string): string {
  return text
    .split('\n')
    .filter((line) => !/^\s{0,3}#{1,6}\s+\S/.test(line))
    .join('\n');
}

/**
 * 같은 문장이 2번 이상 등장하면 두 번째 이후를 제거. 모델이 본문을 통째로 반복하는 경우 방어.
 * 30자 이상 문장만 대상 — 짧은 항목 중복은 정상.
 */
function dedupeRepeatedParagraphs(text: string): string {
  const paragraphs = text.split(/\n{2,}/);
  const seen = new Set<string>();
  const out: string[] = [];
  for (const p of paragraphs) {
    const key = p.trim();
    if (key.length >= 30 && seen.has(key)) continue;
    if (key.length >= 30) seen.add(key);
    out.push(p);
  }
  return out.join('\n\n');
}

/** 마지막 줄/문장의 맺음말 패턴 제거. */
function stripTrailingMeta(text: string): string {
  let t = text.trimEnd();
  for (const re of TRAILING_META_PATTERNS) {
    if (re.test(t)) {
      t = t.replace(re, '');
      break;
    }
  }
  return t.trimEnd();
}

/**
 * (refine/summarize) "다듬은 본문:" 류 최종 라벨이 있으면 *마지막* 라벨 뒤 본문을 채택.
 * 모델이 "[echo/설명/구분선] → 라벨 → [정답]" 구조로 답을 라벨링하는 관용을 이용한다.
 * 라벨 뒤 본문이 실질적(한글 2자 이상)일 때만 자른다 — 라벨이 끝에 덩그러니 있어
 * 뒤가 비면 잘못 자른 것이므로 원문을 보존한다(본문 손실 방지 > 찌꺼기 제거).
 */
function extractAfterFinalLabel(text: string): string {
  let last: { index: number; len: number } | null = null;
  for (const m of text.matchAll(FINAL_ANSWER_LABEL)) {
    if (m.index !== undefined) last = { index: m.index, len: m[0].length };
  }
  if (!last) return text;
  const after = text.slice(last.index + last.len).trim();
  if (after.replace(/\s/g, '').length >= 2) return after;
  return text;
}

/**
 * (refine/summarize) 수평 구분선(`---`)으로 블록을 나눈 뒤, 메타 블록만 제거한다.
 * 제거 대상: 빈 블록 / 구분선만 / 라벨만 / '편집 설명 경어체'로 끝나는 블록 / 중복 블록.
 * 본문 블록은 보존하며, 모든 블록이 제거되면(과잉) 원문을 그대로 돌려준다 — 본문 손실 방지.
 * 구분선이 없으면 단일 블록이라 사실상 무동작(메타-only 출력만 예외적으로 비움 → fallback).
 */
function dropMetaSeparatorBlocks(text: string): string {
  const lines = text.split('\n');
  const blocks: string[] = [];
  let cur: string[] = [];
  for (const line of lines) {
    if (SEPARATOR_LINE.test(line)) {
      blocks.push(cur.join('\n'));
      cur = [];
    } else {
      cur.push(line);
    }
  }
  blocks.push(cur.join('\n'));

  const kept: string[] = [];
  const seen = new Set<string>();
  for (const b of blocks) {
    const t = b.trim();
    if (!t) continue;
    if (PURE_LABEL_BLOCK.test(t)) continue;
    if (META_BLOCK_END.test(t)) continue;
    if (seen.has(t)) continue;
    seen.add(t);
    kept.push(t);
  }
  if (kept.length === 0) return text.trim(); // 안전망: 다 떨어지면 원문 보존
  return kept.join('\n\n');
}

/**
 * (refine/summarize) 맨 앞/뒤에 덩그러니 남은 라벨·구분선 줄만 제거한다.
 * 가장자리만 손대므로 본문 한복판은 절대 건드리지 않는다(본문 손실 방지).
 * 예: "...귀가함\n\n다듬은 본문:" → 끝 라벨 줄 제거.
 */
function trimDanglingMetaLines(text: string): string {
  const lines = text.split('\n');
  const isEdgeMeta = (l: string): boolean => {
    const t = l.trim();
    return t === '' || SEPARATOR_LINE.test(l) || PURE_LABEL_BLOCK.test(t);
  };
  let start = 0;
  let end = lines.length;
  while (start < end && isEdgeMeta(lines[start])) start++;
  while (end > start && isEdgeMeta(lines[end - 1])) end--;
  return lines.slice(start, end).join('\n');
}

/**
 * AI 결과의 메타 텍스트 제거 + 양 끝 정리.
 *
 * @param raw  모델 원문(스트리밍 누적 결과)
 * @param task 생성 task. 'refine'/'summarize'면 구조적 강한 규칙을 추가 적용.
 *             그 외/미지정이면 기존 보수적 파이프라인만(회귀 방지).
 * @param originalInput refine 원문. 주어지면 과팽창(환각 폭발) 가드를 적용해 원문을 보존.
 */
export function sanitizeAiOutput(raw: string, task?: string, originalInput?: string): string {
  if (!raw) return '';
  let text = raw;
  text = stripCodeFence(text);
  text = stripWrappingQuotes(text);

  // refine/summarize: 본문 뒤 사족 폭발 패턴을 구조적으로 제거(순서 무관).
  if (task === 'refine' || task === 'summarize') {
    text = extractAfterFinalLabel(text);
    text = dropMetaSeparatorBlocks(text);
    text = trimDanglingMetaLines(text);
  }

  // 원문 echo + 라벨이 본문 중간에 박힌 케이스를 먼저 잘라낸다.
  text = stripInlineEchoLabel(text);
  text = stripLeadingMeta(text);
  // "이렇게 다듬은 본문은 다음과 같습니다:" 이후의 본문 재출력 제거.
  text = stripRepeatLabel(text);
  // 모델이 임의로 추가한 마크다운 섹션 헤더(### 관찰 등) 제거.
  text = stripMarkdownHeaders(text);
  // 같은 본문을 두 번 이상 출력한 경우 한 번만.
  text = dedupeRepeatedParagraphs(text);
  text = stripTrailingMeta(text);
  // 내부 멀티 빈 줄 → 1개로
  text = text.replace(/\n{3,}/g, '\n\n');
  text = text.trim();
  // refine: 환각 폭발(과팽창) 시 원문 보존.
  if (task === 'refine') text = guardRefineExpansion(text, originalInput);
  return text;
}
