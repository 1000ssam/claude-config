/**
 * 렌더러 측 ContextRequest 디스크립터 헬퍼.
 *
 * **역할**: 인라인 AI 버튼(Phase 4)·사이드 패널(Phase 5)이 폼의 현재 상태를
 * `ContextRequest`로 묶어 `window.api.ai.generate({ contextRequest, ... })` 호출 시
 * 메인 프로세스에 전달할 수 있도록 한다.
 *
 * **원칙**:
 * - 렌더러는 DB 복호화를 직접 하지 않는다. caseId/sessionId만 보내고, 메인이
 *   `lib/queries/*`로 가져온다.
 * - 미저장 폼 값은 `draft`로 함께 보낸다 (DB에는 없는 사용자의 최신 입력).
 * - PII redact는 메인 측 `lib/ai/redact.ts`가 일괄 적용 — 렌더러는 원문 그대로 전달.
 */

import type { AiContextRequest } from '@/types/ai';

export interface SessionFormDraft {
  session_title?: string;
  session_content?: string;
  /**
   * `internal_notes`는 메인 측 `context-sources`가 기본 제외한다.
   * 이 필드에 대한 "다듬기"를 호출할 때만 user 메시지에 포함되어 전달됨.
   */
  internal_notes?: string;
}

export function buildSessionFormContext(args: {
  caseId: number;
  sessionId?: number;
  draft: SessionFormDraft;
}): AiContextRequest {
  return {
    kind: 'session-form',
    caseId: args.caseId,
    sessionId: args.sessionId,
    draft: pickNonEmpty(args.draft as Record<string, string | undefined>),
  };
}

export interface CaseFormDraft {
  main_complaint?: string;
  counseling_goal?: string;
  teacher_opinion?: string;
}

export function buildCaseFormContext(args: {
  caseId: number;
  draft: CaseFormDraft;
}): AiContextRequest {
  return {
    kind: 'case-form',
    caseId: args.caseId,
    draft: pickNonEmpty(args.draft as Record<string, string | undefined>),
  };
}

export function buildConceptualizationContext(args: {
  caseId: number;
  templateType: string;
  /** 현재 작성 중인 섹션별 텍스트 (키는 템플릿의 section.key) */
  draft: Record<string, string>;
}): AiContextRequest {
  return {
    kind: 'conceptualization',
    caseId: args.caseId,
    templateType: args.templateType,
    draft: pickNonEmpty(args.draft),
  };
}

export function buildReportBlockContext(args: {
  caseId: number;
  blockMeta: Record<string, unknown>;
  /** statistics / userNotes / 그 외 블록별 키 */
  draft: Record<string, string>;
}): AiContextRequest {
  return {
    kind: 'report-block',
    caseId: args.caseId,
    draft: pickNonEmpty(args.draft),
    meta: args.blockMeta,
  };
}

/** 빈 문자열·undefined 필드를 제거. 메인 측 draftSections가 빈 값에 대해 안전하긴 하지만,
 *  IPC 페이로드를 가볍게 유지하기 위해. */
function pickNonEmpty(obj: Record<string, string | undefined>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (typeof v === 'string' && v.trim()) out[k] = v;
  }
  return out;
}
