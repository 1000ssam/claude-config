/**
 * 경량 줄단위 diff (LCS 기반).
 *
 * 상담 기록은 보통 수십~수백 줄 — DP O(NM)면 충분(N·M < 1000 가정). 더 큰 텍스트를 다룰 일이
 * 생기면 myers-diff로 교체.
 *
 * 결과 표현:
 * - 같은 줄: `kind:'unchanged'`
 * - 추가된 줄: `kind:'added'`
 * - 삭제된 줄: `kind:'removed'`
 *
 * 한 줄을 부분 수정한 경우는 "삭제 + 추가" 한 쌍으로 표현된다. 더 정교한 inline-diff는
 * 시각적 노이즈가 커서 첫 버전에서는 미도입.
 */

export type DiffOpKind = 'unchanged' | 'added' | 'removed';

export interface DiffOp {
  kind: DiffOpKind;
  text: string;
}

/** 빈 입력은 자명한 결과로 빠르게 처리. */
function trivialDiff(oldLines: string[], newLines: string[]): DiffOp[] | null {
  if (oldLines.length === 0 && newLines.length === 0) return [];
  if (oldLines.length === 0) return newLines.map((t) => ({ kind: 'added', text: t }));
  if (newLines.length === 0) return oldLines.map((t) => ({ kind: 'removed', text: t }));
  return null;
}

/** 줄 단위로 split. CRLF/CR/LF 모두 처리. */
export function splitLines(text: string): string[] {
  if (!text) return [];
  return text.replace(/\r\n?/g, '\n').split('\n');
}

/** LCS 길이 DP 테이블. */
function lcsLengths(a: string[], b: string[]): number[][] {
  const dp: number[][] = Array.from({ length: a.length + 1 }, () =>
    new Array<number>(b.length + 1).fill(0),
  );
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      if (a[i - 1] === b[j - 1]) dp[i][j] = dp[i - 1][j - 1] + 1;
      else dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
    }
  }
  return dp;
}

/**
 * 두 텍스트의 줄 단위 diff.
 * 동일 줄은 unchanged 1건으로 합치지 않는다 — 시각적으로는 호출자가 인접한 unchanged를
 * 한 블록으로 렌더하면 그만.
 */
export function diffLines(oldText: string, newText: string): DiffOp[] {
  const oldLines = splitLines(oldText);
  const newLines = splitLines(newText);
  const trivial = trivialDiff(oldLines, newLines);
  if (trivial) return trivial;

  const dp = lcsLengths(oldLines, newLines);
  const ops: DiffOp[] = [];

  let i = oldLines.length;
  let j = newLines.length;
  while (i > 0 && j > 0) {
    if (oldLines[i - 1] === newLines[j - 1]) {
      ops.push({ kind: 'unchanged', text: oldLines[i - 1] });
      i -= 1;
      j -= 1;
    } else if (dp[i - 1][j] >= dp[i][j - 1]) {
      ops.push({ kind: 'removed', text: oldLines[i - 1] });
      i -= 1;
    } else {
      ops.push({ kind: 'added', text: newLines[j - 1] });
      j -= 1;
    }
  }
  while (i > 0) {
    ops.push({ kind: 'removed', text: oldLines[i - 1] });
    i -= 1;
  }
  while (j > 0) {
    ops.push({ kind: 'added', text: newLines[j - 1] });
    j -= 1;
  }

  return ops.reverse();
}

/**
 * 결과를 사용자가 보기 좋게 unchanged 블록을 합쳐 반환.
 * 예: [unchanged "a", unchanged "b", removed "c"] → [unchanged "a\nb", removed "c"]
 */
export function collapseUnchanged(ops: DiffOp[]): DiffOp[] {
  const out: DiffOp[] = [];
  for (const op of ops) {
    const last = out[out.length - 1];
    if (last && last.kind === op.kind && (op.kind === 'unchanged')) {
      last.text = last.text + '\n' + op.text;
    } else {
      out.push({ ...op });
    }
  }
  return out;
}
