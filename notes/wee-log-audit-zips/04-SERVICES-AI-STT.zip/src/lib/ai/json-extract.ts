/**
 * 모델 JSON 출력에서 실제 JSON 객체만 견고하게 추출.
 *
 * 2.1B 로컬 모델은 `conceptualize` 같은 JSON 출력 task에서 다음 군더더기를 자주 덧붙인다:
 * - 마크다운 코드펜스: ```json … ``` 또는 ``` … ```
 * - JSON 앞뒤 설명문("아래는 …입니다:", "위 내용을 정리했습니다." 등)
 *
 * 이 군더더기가 붙으면 `JSON.parse` 가 곧장 throw → 적용 단계에서 "해석 실패"로 떨어진다.
 * 본 모듈은 펜스를 벗기고 **첫 번째 균형 잡힌 `{ … }` 블록**만 잘라내어 파싱 성공률을 높인다.
 *
 * 설계 원칙:
 * - 문자열 리터럴 안의 중괄호(`"a{b}c"`)는 깊이 계산에서 제외 — 깨진 추출 방지.
 * - 추출만 하고 의미 보정/수선은 하지 않는다. 균형이 안 맞으면 null(영리함보다 명시성).
 * - 순수 함수. 의존성 없음.
 */

/**
 * raw 문자열에서 첫 번째 균형 잡힌 JSON 객체 문자열을 추출한다.
 * 코드펜스는 먼저 제거한다. 객체를 못 찾거나 균형이 안 맞으면 null.
 */
export function extractJsonObject(raw: string): string | null {
  if (!raw) return null;
  let s = raw.trim();

  // 1) 전체를 감싼 마크다운 코드펜스 제거 (```json\n … \n``` / ``` … ```).
  const fenced = s.match(/^```[A-Za-z0-9]*\s*\n?([\s\S]*?)\n?```$/);
  if (fenced) s = fenced[1].trim();

  // 2) 첫 '{' 부터 균형 잡힌 짝까지 스캔. 문자열 리터럴 내부는 무시.
  const start = s.indexOf('{');
  if (start === -1) return null;

  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < s.length; i++) {
    const ch = s[i];
    if (inStr) {
      if (esc) esc = false;
      else if (ch === '\\') esc = true;
      else if (ch === '"') inStr = false;
      continue;
    }
    if (ch === '"') inStr = true;
    else if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return s.slice(start, i + 1);
    }
  }

  return null; // 닫히지 않은 객체.
}

/**
 * extractJsonObject + JSON.parse 를 합친 편의 함수.
 * 추출 실패·파싱 실패 모두 null 반환(throw 하지 않음).
 */
export function parseJsonObject<T = Record<string, unknown>>(raw: string): T | null {
  const extracted = extractJsonObject(raw);
  if (extracted === null) return null;
  try {
    return JSON.parse(extracted) as T;
  } catch {
    return null;
  }
}
