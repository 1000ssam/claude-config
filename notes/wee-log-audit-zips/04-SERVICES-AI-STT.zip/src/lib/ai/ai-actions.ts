import type { UserFacingAiTask } from '@/types/ai';

/**
 * AiTask 메타데이터 카탈로그.
 *
 * Phase 4에서 사례 기록/개념화 폼의 인라인 AI 버튼이 이 카탈로그를 참조해
 * 라벨·아이콘·대상 컨텍스트를 결정한다. Phase 2에서는 설정 화면의 원시 프롬프트
 * 박스가 task 셀렉터를 노출할 때 사용한다.
 *
 * 변경 규칙:
 * - 새 task를 추가할 때 `AiTask` 유니온(`src/types/ai.d.ts` + `lib/ai/types.ts`)도 함께 갱신.
 * - 시스템 task(예: session-summary)는 `UserFacingAiTask`에서 제외되어 카탈로그에 안 들어옴.
 * - 모든 라벨은 한글 (한국 상담교사 대상).
 */
export interface AiActionMeta {
  /** UI 표시명 (한글) */
  label: string;
  /** 한 줄 설명 — 셀렉트 옵션·툴팁 등에 사용 */
  description: string;
  /** 대상 폼/필드 힌트. Phase 4 인라인 UI에서 사용. */
  target: {
    /** 어떤 페이지·엔티티에서 호출 가능한지 — Phase 4에서 좁힐 예정 */
    surfaces: Array<
      'session-form' | 'case-form' | 'conceptualization' | 'report-block'
    >;
    /** 사용자 입력이 필요한지 (qa의 질문, refine의 초안 등) */
    needsUserInput?: boolean;
  };
}

export const AI_ACTIONS: Record<UserFacingAiTask, AiActionMeta> = {
  refine: {
    label: '문장 다듬기',
    description: '입력한 초안을 자연스러운 상담 기록 문장으로 다듬습니다.',
    target: {
      surfaces: ['session-form', 'case-form'],
      needsUserInput: true,
    },
  },
  summarize: {
    label: '요약',
    description: '선택한 내용을 핵심만 간추려 요약합니다.',
    target: {
      surfaces: ['session-form', 'case-form', 'conceptualization'],
      needsUserInput: false,
    },
  },
  continue: {
    label: '이어쓰기',
    description: '현재 작성된 내용 다음을 자연스럽게 이어 작성합니다.',
    target: {
      surfaces: ['session-form', 'case-form'],
      needsUserInput: false,
    },
  },
  conceptualize: {
    label: '사례개념화 초안',
    description: '수집된 정보를 바탕으로 사례개념화 양식 초안을 만듭니다.',
    target: {
      surfaces: ['conceptualization'],
      needsUserInput: false,
    },
  },
  report: {
    label: '보고서 블록 작성',
    description: '보고서의 특정 블록을 통계·맥락에 맞춰 작성합니다.',
    target: {
      surfaces: ['report-block'],
      needsUserInput: false,
    },
  },
  qa: {
    label: '자유 질문',
    description: '상담 기록·통계·법규 등에 대해 자유롭게 질문합니다.',
    target: {
      surfaces: ['session-form', 'case-form', 'conceptualization'],
      needsUserInput: true,
    },
  },
};

/** UI 셀렉터에서 일정한 순서로 보여주기 위한 정렬 키. */
export const AI_TASK_ORDER: UserFacingAiTask[] = [
  'qa',
  'refine',
  'continue',
  'summarize',
  'conceptualize',
  'report',
];
