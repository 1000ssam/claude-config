/** json-extract (모델 JSON 출력 견고 추출) 회귀 체크. */
import { extractJsonObject, parseJsonObject } from '../src/lib/ai/json-extract.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('json-extract');

// ── extractJsonObject: 펜스/군더더기 제거 ─────────────────────────────
t.eq('펜스 없는 순수 객체', extractJsonObject('{"a":1}'), '{"a":1}');
t.eq('```json 펜스', extractJsonObject('```json\n{"a":1}\n```'), '{"a":1}');
t.eq('``` 언어표기 없는 펜스', extractJsonObject('```\n{"a":1}\n```'), '{"a":1}');
t.eq('펜스 한 줄', extractJsonObject('```json {"a":1} ```'), '{"a":1}');
t.eq(
  '앞뒤 설명문 사이의 객체',
  extractJsonObject('아래는 결과입니다:\n{"문제":"불안"}\n이상입니다.'),
  '{"문제":"불안"}',
);
t.eq('앞 공백/개행', extractJsonObject('\n\n  {"a":1}  \n'), '{"a":1}');

// ── 중첩/문자열 내 중괄호 안전 ────────────────────────────────────────
t.eq('중첩 객체', extractJsonObject('{"a":{"b":2}}'), '{"a":{"b":2}}');
t.eq('문자열 내 중괄호 무시', extractJsonObject('{"a":"x{y}z"}'), '{"a":"x{y}z"}');
t.eq('문자열 내 닫는 중괄호만', extractJsonObject('{"a":"end}"}'), '{"a":"end}"}');
t.eq(
  '이스케이프된 따옴표',
  extractJsonObject('{"a":"he said \\"hi\\""}'),
  '{"a":"he said \\"hi\\""}',
);
t.eq(
  '첫 균형 객체까지만(뒤 잔여 무시)',
  extractJsonObject('{"a":1} 그리고 {"b":2}'),
  '{"a":1}',
);

// ── 실패 케이스 → null ────────────────────────────────────────────────
t.eq('빈 문자열', extractJsonObject(''), null);
t.eq('객체 없음', extractJsonObject('설명만 있고 객체 없음'), null);
t.eq('닫히지 않은 객체', extractJsonObject('{"a":1'), null);
t.eq('객체 시작 전에 끝남', extractJsonObject('}{'), null);

// ── parseJsonObject: 추출+파싱 통합 ──────────────────────────────────
t.eq('펜스 객체 파싱', parseJsonObject('```json\n{"문제":"불안","목표":"안정"}\n```'), {
  문제: '불안',
  목표: '안정',
});
t.eq('순수 객체 파싱', parseJsonObject('{"n":1,"s":"x"}'), { n: 1, s: 'x' });
t.eq('추출 실패 → null', parseJsonObject('객체 없음'), null);
t.eq('깨진 JSON → null', parseJsonObject('{"a": }'), null);
t.eq('빈 입력 → null', parseJsonObject(''), null);

// ── conceptualize 적용 형태: 문자열 값만 추리는 소비측 모사 ──────────
{
  const parsed = parseJsonObject<Record<string, unknown>>(
    '```json\n{"호소문제":"시험 불안","상담목표":"이완 훈련","숫자필드":3}\n```',
  );
  t.ok('파싱 성공', parsed !== null);
  const strOnly: Record<string, string> = {};
  if (parsed) for (const [k, v] of Object.entries(parsed)) if (typeof v === 'string') strOnly[k] = v;
  t.eq('문자열 값만 추출(소비측 동작 모사)', strOnly, { 호소문제: '시험 불안', 상담목표: '이완 훈련' });
}

t.report();
