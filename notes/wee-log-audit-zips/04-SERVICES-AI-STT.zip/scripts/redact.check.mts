/** redact (PII 최소화) 회귀 체크. */
import { createRedactContext } from '../lib/ai/redact.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('redact');

// ── 인물 매핑: 역할별 등장 순서대로 A,B,… ────────────────────────────
{
  const ctx = createRedactContext();
  ctx.registerPerson('홍길동', 'student');
  ctx.registerPerson('김철수', 'student');
  ctx.registerPerson('이영희', 'guardian');
  t.eq('역할별 결정론적 라벨', ctx.getMapping(), {
    홍길동: '학생 A',
    김철수: '학생 B',
    이영희: '보호자 A',
  });
  t.eq(
    '등록 이름 치환',
    ctx.redact('홍길동이 김철수와 다툼, 이영희 면담'),
    '학생 A이 학생 B와 다툼, 보호자 A 면담',
  );
}

// ── 등록 멱등(중복 등록해도 카운터 안 늘어남) ─────────────────────────
{
  const ctx = createRedactContext();
  ctx.registerPerson('홍길동', 'student');
  ctx.registerPerson('홍길동', 'student');
  ctx.registerPerson('김철수', 'student');
  t.eq('멱등 등록', ctx.getMapping(), { 홍길동: '학생 A', 김철수: '학생 B' });
}

// ── 긴 이름 우선 치환(부분치환 사고 방지) ─────────────────────────────
{
  const ctx = createRedactContext();
  ctx.registerPerson('강민수', 'student');
  ctx.registerPerson('민수', 'student');
  t.eq('긴 이름 먼저 치환', ctx.redact('강민수와 민수가 대화'), '학생 A와 학생 B가 대화');
}

// ── 미등록 이름은 통과(현재 동작; redact 는 자동등록 안 함) ───────────
{
  const ctx = createRedactContext();
  t.eq('미등록 이름 통과', ctx.redact('박개똥 학생 상담'), '박개똥 학생 상담');
}

// ── PII 정규식 ────────────────────────────────────────────────────────
{
  const ctx = createRedactContext();
  t.eq('전화번호', ctx.redact('연락처는 010-1234-5678'), '연락처는 [전화번호]');
  t.eq('주민등록번호', ctx.redact('주민번호 010101-1234567 확인'), '주민번호 [주민번호] 확인');
  t.eq('이메일', ctx.redact('메일 hong@example.com 으로'), '메일 [이메일] 으로');
  t.eq('학교명', ctx.redact('인창고등학교 재학'), '[학교] 재학');
  t.eq('여중 약칭도 학교', ctx.redact('서울여중 출신'), '[학교] 출신');

  const addr = ctx.redact('주소 경기도 수원시 영통구 123 거주');
  t.ok('주소 치환됨', addr.includes('[주소]'));
  t.ok('주소 원본 번지 제거', !addr.includes('123'));
}

// ── 과잉 삭제 방지: PII 없는 본문은 그대로 ───────────────────────────
{
  const ctx = createRedactContext();
  const clean = '오늘 상담을 진행하고 종결 처리함';
  t.eq('PII 없는 본문 불변', ctx.redact(clean), clean);
  t.eq('빈 문자열 통과', ctx.redact(''), '');
}

// ── 라벨 알파벳 자리올림 (Z 다음 AA) ─────────────────────────────────
{
  const ctx = createRedactContext();
  for (let i = 0; i < 27; i++) ctx.registerPerson(`사람${i}`, 'student');
  const m = ctx.getMapping();
  t.eq('26번째 = 학생 Z', m['사람25'], '학생 Z');
  t.eq('27번째 = 학생 AA', m['사람26'], '학생 AA');
}

t.report();
