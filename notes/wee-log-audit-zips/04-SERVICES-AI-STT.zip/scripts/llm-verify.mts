/**
 * llm-verify.mts — 온디바이스 LLM 출력 품질 A/B 검증 하니스 (앱-실측판)
 *
 * 목적: GUI/DB 없이 앱과 *동일한 프롬프트 조립 + 동일 파라미터 + 동일 후처리(sanitize)* 로
 *       모델을 직접 때려 출력 품질(환각·메타문구·헤더·어미·반복)을 빠르게 반복 검증한다.
 *       → raw(모델 원문)와 clean(앱이 실제로 쓰는 sanitize 후) 둘 다 보여주고, 점검은 clean 기준.
 *
 * ⚠️ 반드시 PowerShell(Windows Node)에서 실행. WSL Linux Node는 node-llama-cpp Windows
 *    prebuilt를 못 읽는다.
 *
 *   cd C:\dev\wee-log-integration
 *   chcp 65001
 *   node --experimental-strip-types scripts\llm-verify.mts                 # 전체 배터리
 *   node --experimental-strip-types scripts\llm-verify.mts refine          # 특정 task 배터리
 *   node --experimental-strip-types scripts\llm-verify.mts refine "원문"   # 임의 입력 1회
 *
 * 프롬프트는 lib/ai/prompts/*.ko.md 를 디스크에서 직접 읽고, sanitize는 src의 실제 모듈을
 * import 한다 → .md/sanitizer 를 고치면 재빌드 없이 즉시 반영.
 *
 * 출처(앱과 일치): prompt-composer.ts, ai-service.ts(파라미터), local-llama-provider.ts(호출부),
 *   model-manager.ts(경로), src/lib/ai/sanitize-output.ts(후처리, 실제 import).
 */

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { sanitizeAiOutput } from '../src/lib/ai/sanitize-output.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROMPTS_DIR = path.join(__dirname, '..', 'lib', 'ai', 'prompts');

// ── 앱과 동일한 파라미터 (출처: ai-service.ts) ────────────────────────────────
const DEFAULT_CONTEXT_SIZE = 4096;
const DEFAULT_MAX_TOKENS: Record<string, number> = {
  refine: 512,
  summarize: 384,
  continue: 256,
  conceptualize: 700,
  report: 600,
  qa: 512,
  'session-summary': 120,
};
const tempFor = (task: string) =>
  task === 'refine' ? 0.2 : task === 'summarize' || task === 'session-summary' ? 0.3 : 0.7;
const TOP_P = 0.9;

// ── 프롬프트 조립 (출처: prompt-composer.ts, 1:1 포팅 — ?raw 라 직접 import 불가) ──
const readPrompt = (name: string) => fs.readFileSync(path.join(PROMPTS_DIR, name), 'utf8');
const BASE_SYSTEM = readPrompt('base-system.ko.md');
const TASK_PROMPTS: Record<string, string> = {
  refine: readPrompt('task-refine.ko.md'),
  summarize: readPrompt('task-summarize.ko.md'),
  continue: readPrompt('task-continue.ko.md'),
  conceptualize: readPrompt('task-conceptualize.ko.md'),
  report: readPrompt('task-report.ko.md'),
  qa: readPrompt('task-qa.ko.md'),
  'session-summary': readPrompt('task-session-summary.ko.md'),
};

function composeSystemPrompt(task: string, serializedContext: string): string {
  const parts = [BASE_SYSTEM.trim(), TASK_PROMPTS[task].trim()];
  const ctx = (serializedContext || '').trim();
  if (ctx) parts.push(`## 참고 정보 (상담 맥락)\n\n${ctx}`);
  return parts.join('\n\n');
}
const hintLine = (h?: string) => ((h || '').trim() ? `[지침: ${(h as string).trim()}]\n\n` : '');
const hintReminder = (h?: string) =>
  (h || '').trim() ? `\n\n[다시 강조: ${(h as string).trim()}. 본문만 한 번 출력, 헤더/머리말/맺음말 금지.]` : '';

function composeUserMessage(task: string, userInput?: string, fieldHint?: string): string {
  const draft = (userInput || '').trim();
  const hint = hintLine(fieldHint);
  const reminder = hintReminder(fieldHint);
  switch (task) {
    case 'refine':
      return draft
        ? `${hint}다음 초안을 다듬어 주세요. 결과는 다듬은 본문만 출력합니다.\n\n---\n${draft}\n---${reminder}`
        : `${hint}다듬을 초안이 비어 있습니다. 맥락만으로 짧은 회기 기록 한 문단을 작성하세요.`;
    case 'continue':
      return draft
        ? `${hint}다음 본문 다음을 자연스럽게 이어 작성해 주세요. 원문은 다시 출력하지 않습니다.\n\n---\n${draft}\n---${reminder}`
        : `${hint}이어 쓸 본문이 비어 있습니다. 맥락을 바탕으로 짧은 도입 한 문단을 작성하세요.`;
    case 'summarize':
      return draft ? `${hint}다음 내용을 요약하세요.\n\n---\n${draft}\n---` : `${hint}제공된 사례 맥락 전체를 요약하세요.`;
    case 'qa':
      return hint + (draft || '제공된 맥락에서 가장 우선 검토할 사항을 한 문단으로 알려주세요.');
    case 'session-summary':
      return draft
        ? `다음 회기 본문을 80자 한 줄로 압축하세요.\n\n---\n${draft}\n---`
        : '요약할 회기 본문이 비어 있습니다. 빈 문자열을 출력하지 말고 "(요약 불가)"라고 답하세요.';
    default:
      return hint + draft;
  }
}

// ── 출력 휴리스틱 검사 (clean 기준) ───────────────────────────────────────────
interface Check { name: string; ok: boolean; detail?: string }
function checkOutput(task: string, input: string | undefined, output: string): Check[] {
  const o = output.trim();
  const checks: Check[] = [];
  const add = (name: string, ok: boolean, detail = '') => checks.push({ name, ok, detail });

  add('마크다운 헤더 없음', !/^#{1,3}\s/m.test(o));
  add('코드펜스 없음', !/```/.test(o));
  add('메타 문구 없음', !/다듬은\s*(본문|결과)|수정\s*결과|어떠신가요|도움이\s*되|위와\s*같이|다음과\s*같(습니다|아요)|^요약\s*:/m.test(o));
  if (task !== 'qa' && task !== 'session-summary') {
    add('명사형 어미(경어체 없음)', !/(습니다|합니다|입니다|해요|예요)[.\s)\]]*$/m.test(o), '"~합니다/~입니다" 종결 금지');
  }
  if (task === 'refine' && input) {
    const ratio = o.length / Math.max(1, input.trim().length);
    add('과팽창 없음 (≤3배)', ratio <= 3, `길이비 ${ratio.toFixed(1)}배`);
  }
  if (task === 'continue' && input) {
    const head = input.trim().slice(0, Math.min(20, input.trim().length));
    add('원문 echo 없음', head.length < 6 || !o.includes(head));
  }
  return checks;
}

// ── 테스트 배터리 ─────────────────────────────────────────────────────────────
const FAKE_CONTEXT = [
  '학생: 학생 A',
  '사례 주호소: 최근 성적이 급격히 하락하고 등교를 거부함.',
  '상담 목표: 학습 동기 회복 및 정서 안정.',
  '이전 회기 요약 (총 3회): 1회기 - 부모와의 갈등 호소. 2회기 - 담임 면담 후 전화 상담 진행. 3회기 - 다음 회기 계획 수립.',
].join('\n');

interface TC { task: string; label: string; userInput: string; context: string; note?: string }
const BATTERY: TC[] = [
  { task: 'refine', label: '환각취약(욕설톤) · 맥락없음 [현재동작]', userInput: '학부모 염병떨고 감', context: '',
    note: '기대: 비속어 톤만 중화. 전화/성적/다음회기/감정 발명 금지.' },
  { task: 'refine', label: '환각취약(욕설톤) · 가짜맥락주입 [옛버그 대조군]', userInput: '학부모 염병떨고 감', context: FAKE_CONTEXT,
    note: '대조군: 맥락의 성적/전화/다음회기가 결과로 새면 = 누수. 앱은 이 경로 안 탐(bd3acfa).' },
  { task: 'refine', label: '짧은입력 · 맥락없음', userInput: '진로 이야기함', context: '',
    note: '기대: 어미만 정리, 살 안 붙임.' },
  { task: 'refine', label: '정상본문(5문장) · 맥락없음', context: '',
    userInput: '오늘 상담에서 학생은 친구관계 때문에 힘들다고 말했다. 쉬는시간에 혼자 있는 경우가 많다고 했다. 그래도 미술 동아리는 재밌다고 함. 선생님이 도와주면 좋겠다고 말했다. 다음에 또 오기로 했어요.',
    note: '기대: 명사형 어미, 헤더/메타 0, 반복 0, 내용 보존.' },
  { task: 'summarize', label: '본문요약 · 맥락없음', context: '',
    userInput: '학생은 최근 수업 집중이 어렵다고 호소하였다. 밤에 휴대폰 사용이 늘어 수면이 부족하다고 한다. 아침에 일어나기 힘들어 지각이 잦아짐. 부모와는 휴대폰 사용 시간을 두고 자주 다툰다. 상담자는 수면 위생과 휴대폰 사용 규칙을 함께 점검하기로 함.',
    note: '기대: 개조식 압축, 메타/헤더 0, 없는 사실 추가 0.' },
  { task: 'continue', label: '이어쓰기 · 맥락동반', userInput: '학생은 시험 불안이 크다고 호소함. 손에 땀이 나고 가슴이 답답하다고 함.', context: FAKE_CONTEXT,
    note: '기대: 원문 미반복, 명사형, 주제 일관, 없는 사건 발명 경계.' },
];

// ── 모델 경로 탐색 (출처: model-manager.ts) ───────────────────────────────────
function findModelPath(): string | null {
  const override = process.env.WEELOG_MODEL_PATH;
  if (override && fs.existsSync(override)) return override;
  const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
  for (const dir of [path.join(appData, 'Wee-Story', 'models'), path.join(appData, 'wee-log', 'models')]) {
    if (!fs.existsSync(dir)) continue;
    const gguf = fs.readdirSync(dir).find((f) => f.toLowerCase().endsWith('.gguf'));
    if (gguf) return path.join(dir, gguf);
  }
  return null;
}

const fmtChecks = (cs: Check[]) =>
  cs.map((c) => `   ${c.ok ? '✅' : '❌'} ${c.name}${c.detail ? ` — ${c.detail}` : ''}`).join('\n');
const indent = (s: string, p = '  | ') => s.trim().split('\n').map((l) => p + l).join('\n');

async function main() {
  const argTask = process.argv[2];
  const argInput = process.argv[3];

  const modelPath = findModelPath();
  if (!modelPath) {
    console.error('❌ 모델 .gguf 못 찾음. 앱에서 모델 다운로드 먼저, 또는 WEELOG_MODEL_PATH 지정.');
    process.exit(1);
  }
  console.log(`모델: ${modelPath}\n컨텍스트: ${DEFAULT_CONTEXT_SIZE}, topP: ${TOP_P}`);
  console.log('점검 기준 = clean(앱 sanitize 후). raw는 sanitize가 뭔가 제거했을 때만 함께 표시.\n');

  const { getLlama, LlamaChatSession } = await import('node-llama-cpp');
  const llama = await getLlama();
  const model = await llama.loadModel({ modelPath });
  const context = await model.createContext({ contextSize: DEFAULT_CONTEXT_SIZE });
  const sequence = context.getSequence();

  let cases: TC[] = BATTERY;
  if (argTask) {
    cases = argInput
      ? [{ task: argTask, label: '임의입력', userInput: argInput, context: '' }]
      : BATTERY.filter((c) => c.task === argTask);
    if (cases.length === 0) {
      console.error(`task "${argTask}" 배터리 케이스 없음. (refine/summarize/continue)`);
      process.exit(1);
    }
  }

  for (let i = 0; i < cases.length; i++) {
    const tc = cases[i];
    const system = composeSystemPrompt(tc.task, tc.context || '');
    const user = composeUserMessage(tc.task, tc.userInput);
    const maxTokens = DEFAULT_MAX_TOKENS[tc.task] ?? 512;
    const temperature = tempFor(tc.task);

    console.log('━'.repeat(78));
    console.log(`[${i + 1}/${cases.length}] task=${tc.task} · ${tc.label}`);
    console.log(`  temp=${temperature} maxTokens=${maxTokens} 맥락주입=${(tc.context || '').trim() ? 'O' : 'X'}`);
    if (tc.note) console.log(`  ▸ ${tc.note}`);
    console.log(`  ── 입력 ──\n${indent(tc.userInput || '(빈 입력)')}`);

    if (sequence.clearHistory) sequence.clearHistory();
    const session = new LlamaChatSession({ contextSequence: sequence, systemPrompt: system });

    let raw = '';
    try {
      raw = await session.prompt(user, { maxTokens, temperature, topP: TOP_P });
    } catch (err) {
      console.log(`  ❌ 생성 에러: ${(err as Error)?.message || err}`);
      continue;
    }
    const clean = sanitizeAiOutput(raw, tc.task, tc.userInput);

    if (clean.trim() !== raw.trim()) {
      console.log(`  ── raw(모델 원문) ──\n${indent(raw)}`);
    }
    console.log(`  ── clean(앱 실제 출력) ──\n${indent(clean)}`);
    const checks = checkOutput(tc.task, tc.userInput, clean);
    console.log(`  ── 자동 점검(clean) ──\n${fmtChecks(checks)}`);
    const fails = checks.filter((c) => !c.ok).length;
    console.log(`  결과: ${fails === 0 ? '✅ 전부 통과' : `❌ ${fails}건 실패`}`);
    if (tc.task === 'refine' || tc.task === 'continue') {
      console.log('  ⚠️ 의미적 환각(없는 사실 발명)은 자동점검이 못 잡음 — 위 clean 본문을 눈으로 확인.');
    }
    console.log('');
  }

  await context.dispose();
  await model.dispose();
  console.log('완료. (temperature>0이라 실행마다 출력 변동 — 환각 케이스는 2회 권장)');
}

main().catch((e) => { console.error(e); process.exit(1); });
