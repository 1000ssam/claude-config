/** token-estimate (토큰 추정·예산·절단) 회귀 체크. */
import {
  estimateTokens,
  approxCharBudget,
  trimMiddle,
  computeContextBudget,
} from '../lib/ai/token-estimate.ts';
import { createSuite } from './_assert.mts';

const t = createSuite('token-estimate');

// ── estimateTokens (보수적 상한, 올림) ────────────────────────────────
t.eq('빈 문자열 → 0', estimateTokens(''), 0);
t.eq('ASCII 1자 올림', estimateTokens('a'), 1); // 0.35 → 1
t.eq('ASCII 2자', estimateTokens('ab'), 1); // 0.70 → 1
t.eq('ASCII 3자', estimateTokens('abc'), 2); // 1.05 → 2
t.eq('한글 1자', estimateTokens('가'), 3); // 2.5 → 3
t.eq('한글 2자', estimateTokens('가나'), 5); // 5.0 → 5
t.eq('한글+ASCII 혼합', estimateTokens('가a'), 3); // 2.85 → 3
t.eq('기타(이모지)', estimateTokens('😀'), 2); // 1.5 → 2

// ── approxCharBudget ──────────────────────────────────────────────────
t.eq('예산 100 → 40자', approxCharBudget(100), 40);
t.eq('예산 0 → 0자', approxCharBudget(0), 0);
t.eq('예산 250 → 100자', approxCharBudget(250), 100);

// ── trimMiddle ────────────────────────────────────────────────────────
t.eq('maxTokens<=0 → 빈 문자열', trimMiddle('가'.repeat(100), 0), '');
t.eq('한도 이내 → 원문 보존', trimMiddle('짧은글', 100), '짧은글');
t.eq(
  '초과 시 머리+중략+꼬리 (결정론적)',
  trimMiddle('가'.repeat(100), 50),
  '가'.repeat(10) + '…(중략)…' + '가'.repeat(6),
);
t.eq('usable<=0 이면 중략표시만', trimMiddle('가'.repeat(100), 5), '…(중략)…');
t.ok('절단 결과는 항상 중략표시 포함', trimMiddle('가'.repeat(100), 50).includes('…(중략)…'));

// ── computeContextBudget ─────────────────────────────────────────────
t.eq(
  '기본 margin 256',
  computeContextBudget({ contextWindow: 1000, baseSystemTokens: 100, taskPromptTokens: 50, maxOutputTokens: 200 }),
  394,
);
t.eq(
  '음수는 0으로 클램프',
  computeContextBudget({ contextWindow: 100, baseSystemTokens: 100, taskPromptTokens: 50, maxOutputTokens: 200 }),
  0,
);
t.eq(
  'margin 커스텀',
  computeContextBudget({ contextWindow: 1000, baseSystemTokens: 100, taskPromptTokens: 50, maxOutputTokens: 200, margin: 0 }),
  650,
);

t.report();
