/**
 * sanitizeAiOutput 회귀 체크 (실제 모듈 import).
 * 러너 미설치 환경이라 esbuild 번들 → node 실행으로 구동한다:
 *   npm run test:sanitize
 *
 * 두 축으로 검증:
 *   A. 모델 찌꺼기(머리말·구분선·라벨·반복)가 깨끗이 제거되는가
 *   B. 멀쩡한 본문이 손상되지 않는가(과잉삭제 방지) — 가장 중요
 */
import { sanitizeAiOutput } from '../src/lib/ai/sanitize-output.ts';

let pass = 0;
const failures: string[] = [];

function check(name: string, got: string, want: string): void {
  if (got === want) {
    pass++;
  } else {
    failures.push(
      `❌ ${name}\n   want: ${JSON.stringify(want)}\n   got : ${JSON.stringify(got)}`,
    );
  }
}

const ANSWER = '학부모가 항의 후 귀가함';

// ── A. 찌꺼기 제거 (task='refine') ──────────────────────────────────────────

// 실제 라이브 실패 케이스: [정답] → 구분선 → 설명(보겠습니다) → 라벨 → [정답 반복]
check(
  'A1 라이브 실패 케이스(정답-구분선-설명-라벨-반복)',
  sanitizeAiOutput(
    `${ANSWER}\n\n---\n\n이 초안은 학부모가 "염병떨고 감"이라는 비속어 표현을 사용하고 있습니다. 이를 명사형 어미로 다듬어 보겠습니다.\n\n다듬은 본문:\n${ANSWER}`,
    'refine',
  ),
  ANSWER,
);

// 순서 뒤집힘: 설명(메타)이 먼저, 정답이 나중 — stop sequence가 못 잡는 케이스
check(
  'A2 메타 먼저, 정답 나중',
  sanitizeAiOutput(`이 초안을 명사형으로 다듬어 보겠습니다.\n\n---\n\n${ANSWER}`, 'refine'),
  ANSWER,
);

// 인라인 echo + 라벨: 원문 echo 뒤 라벨, 그 뒤 정답
check(
  'A3 원문 echo + 라벨 + 정답',
  sanitizeAiOutput(`학부모 염병떨고 감\n다듬은 본문: ${ANSWER}`, 'refine'),
  ANSWER,
);

// 정답 + 구분선 + 맺음말
check(
  'A4 정답 + 구분선 + 맺음말',
  sanitizeAiOutput(`${ANSWER}\n\n---\n도움이 되었으면 합니다.`, 'refine'),
  ANSWER,
);

// 정답 + 끝에 덩그러니 남은 라벨
check(
  'A5 정답 + 끝 dangling 라벨',
  sanitizeAiOutput(`${ANSWER}\n\n다듬은 본문:`, 'refine'),
  ANSWER,
);

// 정답 + 구분선 + 정답(통째 반복)
check(
  'A6 정답 + 구분선 + 정답 반복',
  sanitizeAiOutput(`${ANSWER}\n\n---\n\n${ANSWER}`, 'refine'),
  ANSWER,
);

// 코드펜스로 감쌈
check('A7 코드펜스', sanitizeAiOutput('```\n' + ANSWER + '\n```', 'refine'), ANSWER);

// 라벨이 같은 줄 맨 앞
check('A8 라벨 inline 선두', sanitizeAiOutput(`다듬은 본문: ${ANSWER}`, 'refine'), ANSWER);

// ── B. 과잉삭제 방지 — 멀쩡한 본문은 그대로 ──────────────────────────────────

// B1 깨끗한 단일 문장은 무손상
check('B1 깨끗한 단일 문장', sanitizeAiOutput(ANSWER, 'refine'), ANSWER);

// B2 여러 명사형 줄(정상 기록) 무손상
{
  const clean = '학생이 수업 중 산만한 모습이 관찰됨\n또래와의 갈등이 보고됨\n상담 지속이 필요함';
  check('B2 다줄 명사형 기록', sanitizeAiOutput(clean, 'refine'), clean);
}

// B3 본문 한복판에 경어체 인용이 있어도(끝은 명사형) 메타로 오인 금지
{
  const quoted = "학부모가 '도움이 되었으면 합니다'라고 말하며 귀가함";
  check('B3 경어체 인용 포함, 끝은 명사형', sanitizeAiOutput(quoted, 'refine'), quoted);
}

// B4 짧은 항목 반복은 정상 — 잘못 dedupe 금지
{
  const bullets = '결석함\n결석함';
  check('B4 짧은 항목 중복 보존', sanitizeAiOutput(bullets, 'refine'), bullets);
}

// B5 "다음과 같이" 가 본문 내용으로 쓰였고 끝이 명사형이면 보존
{
  const body = '담임 교사와 협의한 결과 다음과 같이 조치하기로 함';
  check('B5 "다음과 같이"가 본문', sanitizeAiOutput(body, 'refine'), body);
}

// ── C. task 게이팅 — refine/summarize 외엔 강한 규칙 미적용(회귀 방지) ──────────

// C1 continue: 구분선이 본문에 있어도 블록 제거 안 함(보수적 유지)
{
  const cont = '앞 문장임\n---\n뒤 문장임';
  check('C1 continue 구분선 보존', sanitizeAiOutput(cont, 'continue'), cont);
}

// C2 task 미지정: 강한 규칙 미적용(기존 동작) — 라벨이 80자 밖이면 안 잘림 → 비어있지 않음
{
  const out = sanitizeAiOutput(
    `${ANSWER}\n\n---\n\n설명이 길게 이어지는 머리말 문장입니다 그리고 더 길게 늘어집니다 여기까지.\n\n다듬은 본문:\n${ANSWER}`,
    undefined,
  );
  check('C2 미지정 task는 비지 않음(동작 보존)', out.length > 0 ? 'nonempty' : 'EMPTY', 'nonempty');
}

// ── D. refine 환각-폭발 가드 (과팽창 시 원문 보존) ───────────────────────────

// D1 짧은 입력 대폭발 → 원문 그대로 보존 (실제 ③ 케이스: 7자 → 138자 날조)
{
  const shortIn = '진로 이야기함';
  const balloon =
    '학생 A와 진로 이야기함. 학생의 관심사와 목표를 탐색하며, 다양한 직업과 학과에 대해 논의함. 학생의 흥미와 적성을 파악하여 맞춤형 진로 계획을 제안함. 다음 회기에서는 구체적인 진로 목표 설정을 위한 추가 상담을 진행하기로 함.';
  check('D1 과팽창 → 원문 보존', sanitizeAiOutput(balloon, 'refine', shortIn), shortIn);
}

// D2 정상 다듬기(길이 비슷)는 가드 미발동 — 무손상
{
  const normIn = '오늘 학생과 진로에 대해 이야기를 나누었다';
  const normOut = '오늘 학생과 진로에 대해 이야기를 나눔';
  check('D2 정상 다듬기 보존', sanitizeAiOutput(normOut, 'refine', normIn), normOut);
}

// D3 짧은 톤중화(① 류)는 가드 미발동 — refine 본연의 가치 보존
{
  const aggrIn = '학부모 염병떨고 감';
  const aggrOut = ANSWER; // '학부모가 항의 후 귀가함' — 증가 미미
  check('D3 짧은 톤중화 보존', sanitizeAiOutput(aggrOut, 'refine', aggrIn), aggrOut);
}

// D4 summarize는 과팽창 가드 미적용(요약은 refine 아님)
{
  const sumIn = '짧음';
  const sumOut = '학생은 수업 집중이 어렵다고 호소하며 수면 부족과 지각 문제가 보고됨';
  check('D4 summarize 가드 미적용', sanitizeAiOutput(sumOut, 'summarize', sumIn), sumOut);
}

// D5 originalInput 미지정 시 가드 스킵(하위호환)
check('D5 input 없으면 가드 스킵', sanitizeAiOutput(ANSWER, 'refine'), ANSWER);

// D6 백틱 감싸기 제거(② 모델이 `...`로 감싼 케이스)
check('D6 백틱 감싸기 제거', sanitizeAiOutput('`' + ANSWER + '`', 'refine'), ANSWER);

// ── 결과 ────────────────────────────────────────────────────────────────────
console.log(`\nsanitizeAiOutput check: ${pass} passed, ${failures.length} failed\n`);
if (failures.length > 0) {
  console.error(failures.join('\n\n'));
  process.exit(1);
}
console.log('✅ 전부 통과');
